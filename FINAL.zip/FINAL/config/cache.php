<?php
/**
 * Shared cache + parallel cURL helper
 * Include this ONCE at top of any page: require_once __DIR__ . '/../config/cache.php';
 */

if (!defined('SUPABASE_URL')) {
    define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
    define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');
}

/**
 * File-based cache. TTL in seconds.
 * $fetch is called only when cache is expired.
 */
function appCache(string $key, int $ttl, callable $fetch) {
    $file = sys_get_temp_dir() . '/app_' . md5($key) . '.json';
    if (file_exists($file) && (time() - filemtime($file)) < $ttl) {
        $v = json_decode(file_get_contents($file), true);
        if ($v !== null) return $v;
    }
    $data = $fetch();
    @file_put_contents($file, json_encode($data));
    return $data;
}

/** Clear all app caches — call after writes */
function clearAppCache(string $prefix = '') {
    foreach (glob(sys_get_temp_dir() . '/app_*.json') as $f) {
        if (!$prefix || strpos(basename($f), md5($prefix)) !== false) {
            @unlink($f);
        }
    }
}

/**
 * Fire multiple Supabase REST queries IN PARALLEL.
 * $queries = [ 'key' => ['t' => 'table_name', 'p' => [...params]] ]
 */
function sbParallel(array $queries): array {
    $mh = curl_multi_init();
    $handles = [];
    foreach ($queries as $key => $q) {
        $url = SUPABASE_URL . '/rest/v1/' . $q['t'];
        if (!empty($q['p'])) $url .= '?' . http_build_query($q['p']);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER     => [
                'apikey: '               . SUPABASE_ANON_KEY,
                'Authorization: Bearer ' . SUPABASE_ANON_KEY,
                'Content-Type: application/json',
            ],
        ]);
        curl_multi_add_handle($mh, $ch);
        $handles[$key] = $ch;
    }
    do {
        $status = curl_multi_exec($mh, $running);
        if ($running) curl_multi_select($mh);
    } while ($running > 0 && $status === CURLM_OK);

    $results = [];
    foreach ($handles as $key => $ch) {
        $raw  = curl_multi_getcontent($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_multi_remove_handle($mh, $ch);
        if ($code >= 200 && $code < 300 && $raw) {
            $d = json_decode($raw, true);
            $results[$key] = is_array($d) ? array_values(array_filter($d, fn($r) => is_array($r))) : [];
        } else {
            $results[$key] = [];
        }
    }
    curl_multi_close($mh);
    return $results;
}

/** Single Supabase GET with timeout */
function sbGet(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
        ],
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300 && $resp) {
        $d = json_decode($resp, true);
        return is_array($d) ? $d : [];
    }
    return [];
}
