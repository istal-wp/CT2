<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit;
}

define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>[
        'apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,
        'Content-Type: application/json','Accept: application/json']]);
    $resp = curl_exec($ch); curl_close($ch);
    $data = json_decode($resp, true);
    return is_array($data) ? $data : [];
}
function sb_post(string $table, array $body, array $extra=[]): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $headers = ['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,
                'Content-Type: application/json','Prefer: return=representation'];
    foreach($extra as $h) $headers[] = $h;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>json_encode($body),CURLOPT_HTTPHEADER=>$headers]);
    $resp = curl_exec($ch); curl_close($ch);
    $data = json_decode($resp, true);
    return is_array($data) ? $data : [];
}
function sb_patch(string $table, array $filters, array $body): bool {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'PATCH',
        CURLOPT_POSTFIELDS=>json_encode($body),CURLOPT_HTTPHEADER=>[
        'apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,
        'Content-Type: application/json','Prefer: return=minimal']]);
    $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return $code >= 200 && $code < 300;
}

function getCore1DriverMap(array $core2DriverIds): array {
    if (empty($core2DriverIds)) return [];
    $inList = implode(',', array_map('intval', array_unique($core2DriverIds)));
    $rows = sb_get('core1_drivers', [
        'select'          => 'id,driver_name,license_number,phone,email,status,wallet_balance,boundary_amount,assigned_vehicle_id,core2_driver_id,current_lat,current_lng,location_updated_at',
        'core2_driver_id' => 'in.(' . $inList . ')',
    ]);
    $map = [];
    foreach ($rows as $d) {
        if (!empty($d['core2_driver_id'])) $map[(int)$d['core2_driver_id']] = $d;
    }
    return $map;
}

function mergeDriverData(array $record, array $c1Map): array {
    $did = (int)($record['driver_id'] ?? 0);
    if ($did && isset($c1Map[$did])) {
        $c = $c1Map[$did];
        $record['driver_name']         = $c['driver_name']          ?? null;
        $record['driver_phone']        = $c['phone']                ?? null;
        $record['driver_email']        = $c['email']                ?? null;
        $record['driver_license']      = $c['license_number']       ?? null;
        $record['driver_status']       = $c['status']               ?? null;
        $record['driver_wallet']       = $c['wallet_balance']       ?? null;
        $record['driver_boundary']     = $c['boundary_amount']      ?? null;
        $record['core1_driver_id']     = $c['id']                   ?? null;
        $record['current_lat']         = $c['current_lat']          ?? null;
        $record['current_lng']         = $c['current_lng']          ?? null;
        $record['location_updated_at'] = $c['location_updated_at']  ?? null;
    }
    return $record;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    try {
        switch ($_POST['action']) {

            case 'get_active_trips': {
                $rides = sb_get('core2_rides', [
                    'select'      => 'ride_id,booking_id,customer_id,driver_id,fleet_id,start_time,start_location,end_location,ride_status',
                    'ride_status' => 'eq.In Progress',
                    'order'       => 'start_time.desc',
                    'limit'       => '100',
                ]);
                if (empty($rides)) { echo json_encode(['success'=>true,'trips'=>[]]); break; }

                $dIds  = array_filter(array_column($rides,'driver_id'));
                $c1Map = getCore1DriverMap($dIds);

                $custIds = array_unique(array_column($rides,'customer_id'));
                $custs   = [];
                if ($custIds) {
                    $rows = sb_get('core2_customers',['select'=>'customer_id,name,phone','customer_id'=>'in.('.implode(',',$custIds).')']);
                    foreach($rows as $r) $custs[(int)$r['customer_id']] = $r;
                }

                $bookIds = array_filter(array_column($rides,'booking_id'));
                $books   = [];
                if ($bookIds) {
                    $rows = sb_get('core2_bookings',['select'=>'booking_id,booking_reference,service_id,total_amount','booking_id'=>'in.('.implode(',',$bookIds).')']);
                    foreach($rows as $r) $books[(int)$r['booking_id']] = $r;
                    $svcIds = array_unique(array_column($rows,'service_id'));
                    $svcs   = [];
                    if ($svcIds) {
                        $srows = sb_get('core2_services',['select'=>'service_id,service_name','service_id'=>'in.('.implode(',',$svcIds).')']);
                        foreach($srows as $s) $svcs[(int)$s['service_id']] = $s['service_name'];
                    }
                    foreach($books as &$b) $b['service_name'] = $svcs[$b['service_id']] ?? 'N/A';
                }

                $trips = [];
                foreach ($rides as $ride) {
                    $ride = mergeDriverData($ride, $c1Map);
                    $cust = $custs[(int)$ride['customer_id']] ?? [];
                    $book = $books[(int)$ride['booking_id']]  ?? [];
                    $start = $ride['start_time'] ?? null;
                    $durMin = $start ? (int)round((time() - strtotime($start)) / 60) : 0;
                    $trips[] = [
                        'ride_id'            => $ride['ride_id'],
                        'booking_id'         => $ride['booking_id'],
                        'booking_reference'  => $book['booking_reference']  ?? 'N/A',
                        'service_name'       => $book['service_name']        ?? 'N/A',
                        'total_amount'       => $book['total_amount']        ?? 0,
                        'customer_name'      => $cust['name']                ?? 'Guest',
                        'customer_phone'     => $cust['phone']               ?? null,
                        'driver_name'        => $ride['driver_name']         ?? 'Unassigned',
                        'driver_phone'       => $ride['driver_phone']        ?? null,
                        'driver_license'     => $ride['driver_license']      ?? null,
                        'driver_status'      => $ride['driver_status']       ?? null,
                        'core1_driver_id'    => $ride['core1_driver_id']     ?? null,
                        'current_lat'        => $ride['current_lat']         ?? null,
                        'current_lng'        => $ride['current_lng']         ?? null,
                        'location_updated_at'=> $ride['location_updated_at'] ?? null,
                        'pickup'             => $ride['start_location']      ?? 'N/A',
                        'dropoff'            => $ride['end_location']        ?? 'N/A',
                        'start_time'         => $start,
                        'duration_minutes'   => $durMin,
                        'ride_status'        => $ride['ride_status'],
                    ];
                }
                echo json_encode(['success'=>true,'trips'=>$trips]);
                break;
            }

            case 'get_live_location': {
                $bookingId = (int)$_POST['booking_id'];
                $ride = sb_get('core2_rides', ['select'=>'ride_id,driver_id,ride_status,start_location,end_location,start_time','booking_id'=>'eq.'.$bookingId,'limit'=>'1']);
                if (empty($ride)) { echo json_encode(['success'=>false,'message'=>'Ride not found']); break; }
                $r    = $ride[0];
                $c1Map = getCore1DriverMap([(int)$r['driver_id']]);
                $r     = mergeDriverData($r, $c1Map);

                $pts = sb_get('core2_booking_history',['select'=>'history_id','booking_id'=>'eq.'.$bookingId,'notes'=>'like.GPS_POINT%']);
                echo json_encode([
                    'success'            => true,
                    'latitude'           => $r['current_lat']          ?? null,
                    'longitude'          => $r['current_lng']          ?? null,
                    'location_updated_at'=> $r['location_updated_at']  ?? null,
                    'driver_name'        => $r['driver_name']          ?? null,
                    'driver_phone'       => $r['driver_phone']         ?? null,
                    'driver_status'      => $r['driver_status']        ?? null,
                    'ride_status'        => $r['ride_status']          ?? null,
                    'pickup'             => $r['start_location']       ?? null,
                    'dropoff'            => $r['end_location']         ?? null,
                    'gps_points_logged'  => count($pts),
                ]);
                break;
            }

            case 'get_all_drivers_location': {
                $drivers = sb_get('core1_drivers', [
                    'select' => 'id,driver_name,phone,status,current_lat,current_lng,location_updated_at,assigned_vehicle_id,core2_driver_id',
                    'status' => 'neq.Offline',
                    'current_lat' => 'not.is.null',
                ]);
                $vehicles = [];
                $vIds = array_filter(array_column($drivers,'assigned_vehicle_id'));
                if ($vIds) {
                    $vrows = sb_get('core1_vehicles',['select'=>'id,plate_number,model','id'=>'in.('.implode(',',array_unique($vIds)).')']);
                    foreach($vrows as $v) $vehicles[(int)$v['id']] = $v;
                }
                $result = [];
                foreach ($drivers as $d) {
                    $v = $vehicles[(int)$d['assigned_vehicle_id']] ?? [];
                    $result[] = [
                        'core1_id'           => $d['id'],
                        'driver_name'        => $d['driver_name'],
                        'phone'              => $d['phone'],
                        'status'             => $d['status'],
                        'current_lat'        => $d['current_lat'],
                        'current_lng'        => $d['current_lng'],
                        'location_updated_at'=> $d['location_updated_at'],
                        'plate_number'       => $v['plate_number'] ?? 'N/A',
                        'vehicle_model'      => $v['model']        ?? 'N/A',
                    ];
                }
                echo json_encode(['success'=>true,'drivers'=>$result]);
                break;
            }

            case 'get_completed_trips': {
                $search = trim($_POST['search'] ?? '');
                $rides = sb_get('core2_rides', [
                    'select'      => 'ride_id,booking_id,customer_id,driver_id,start_time,end_time,start_location,end_location,ride_status',
                    'ride_status' => 'eq.Completed',
                    'order'       => 'end_time.desc',
                    'limit'       => '150',
                ]);
                if (empty($rides)) { echo json_encode(['success'=>true,'trips'=>[]]); break; }

                $dIds  = array_filter(array_column($rides,'driver_id'));
                $c1Map = getCore1DriverMap($dIds);
                $custIds = array_unique(array_filter(array_column($rides,'customer_id')));
                $custs = [];
                if ($custIds) {
                    $crow = sb_get('core2_customers',['select'=>'customer_id,name,phone','customer_id'=>'in.('.implode(',',$custIds).')']);
                    foreach($crow as $r) $custs[(int)$r['customer_id']] = $r;
                }
                $bookIds = array_unique(array_filter(array_column($rides,'booking_id')));
                $books   = [];
                if ($bookIds) {
                    $brow = sb_get('core2_bookings',['select'=>'booking_id,booking_reference,service_id,total_amount,booking_date','booking_id'=>'in.('.implode(',',$bookIds).')']);
                    foreach($brow as $b) $books[(int)$b['booking_id']] = $b;
                    $svcIds = array_unique(array_column($brow,'service_id'));
                    $svcs = [];
                    if ($svcIds) {
                        $sr = sb_get('core2_services',['select'=>'service_id,service_name','service_id'=>'in.('.implode(',',$svcIds).')']);
                        foreach($sr as $s) $svcs[(int)$s['service_id']] = $s['service_name'];
                    }
                    foreach($books as &$b) $b['service_name'] = $svcs[$b['service_id']] ?? 'N/A';
                }

                $trips = [];
                foreach ($rides as $ride) {
                    $ride = mergeDriverData($ride, $c1Map);
                    $cust = $custs[(int)$ride['customer_id']] ?? [];
                    $book = $books[(int)$ride['booking_id']]  ?? [];
                    $dur  = 0;
                    if (!empty($ride['start_time']) && !empty($ride['end_time'])) {
                        $dur = (int)round((strtotime($ride['end_time']) - strtotime($ride['start_time'])) / 60);
                    }

                    $pts = sb_get('core2_booking_history',['select'=>'history_id','booking_id'=>'eq.'.$ride['booking_id'],'notes'=>'like.GPS_POINT%']);
                    $entry = [
                        'ride_id'           => $ride['ride_id'],
                        'booking_id'        => $ride['booking_id'],
                        'booking_reference' => $book['booking_reference'] ?? 'N/A',
                        'booking_date'      => $book['booking_date']      ?? null,
                        'service_name'      => $book['service_name']      ?? 'N/A',
                        'total_amount'      => $book['total_amount']      ?? 0,
                        'customer_name'     => $cust['name']              ?? 'Guest',
                        'customer_phone'    => $cust['phone']             ?? null,
                        'driver_name'       => $ride['driver_name']       ?? 'N/A',
                        'driver_phone'      => $ride['driver_phone']      ?? null,
                        'driver_license'    => $ride['driver_license']    ?? null,
                        'pickup'            => $ride['start_location']    ?? 'N/A',
                        'dropoff'           => $ride['end_location']      ?? 'N/A',
                        'start_time'        => $ride['start_time'],
                        'end_time'          => $ride['end_time'],
                        'duration_minutes'  => $dur,
                        'gps_points'        => count($pts),
                    ];

                    if ($search) {
                        $hay = strtolower($entry['booking_reference'].$entry['customer_name'].$entry['driver_name'].$entry['pickup'].$entry['dropoff']);
                        if (strpos($hay, strtolower($search)) === false) continue;
                    }
                    $trips[] = $entry;
                }
                echo json_encode(['success'=>true,'trips'=>$trips]);
                break;
            }

            case 'get_playback_data': {
                $bookingId = (int)$_POST['booking_id'];

                $hist = sb_get('core2_booking_history',[
                    'select'     => 'notes,changed_at',
                    'booking_id' => 'eq.'.$bookingId,
                    'notes'      => 'like.GPS_TRIP_HISTORY%',
                    'order'      => 'changed_at.desc',
                    'limit'      => '1',
                ]);
                $coords = [];
                $totalPoints = 0;
                $startT = null; $endT = null;
                if (!empty($hist)) {
                    $td = json_decode(substr($hist[0]['notes'], strlen('GPS_TRIP_HISTORY:')), true) ?? [];
                    $coords      = $td['coordinates']  ?? [];
                    $totalPoints = $td['total_points']  ?? count($coords);
                    $startT      = $td['start_time']    ?? null;
                    $endT        = $td['end_time']       ?? null;
                } else {

                    $pts = sb_get('core2_booking_history',[
                        'select'     => 'notes,changed_at',
                        'booking_id' => 'eq.'.$bookingId,
                        'notes'      => 'like.GPS_POINT%',
                        'order'      => 'changed_at.asc',
                    ]);
                    foreach ($pts as $p) {
                        $c = json_decode(substr($p['notes'], strlen('GPS_POINT:')), true) ?? [];
                        if ($c) $coords[] = $c;
                    }
                    $totalPoints = count($coords);
                    if (!empty($pts)) { $startT = $pts[0]['changed_at']; $endT = end($pts)['changed_at']; }
                }
                $book = sb_get('core2_bookings',['select'=>'booking_reference,booking_date','booking_id'=>'eq.'.$bookingId,'limit'=>'1']);
                $ride = sb_get('core2_rides',['select'=>'start_location,end_location,driver_id','booking_id'=>'eq.'.$bookingId,'limit'=>'1']);
                $rideRow = $ride[0] ?? [];
                $c1Map = getCore1DriverMap([(int)($rideRow['driver_id']??0)]);
                $rideRow = mergeDriverData($rideRow, $c1Map);
                echo json_encode([
                    'success'           => true,
                    'booking_reference' => $book[0]['booking_reference'] ?? 'N/A',
                    'booking_date'      => $book[0]['booking_date']      ?? null,
                    'driver_name'       => $rideRow['driver_name']       ?? null,
                    'driver_license'    => $rideRow['driver_license']    ?? null,
                    'pickup'            => $rideRow['start_location']    ?? null,
                    'dropoff'           => $rideRow['end_location']      ?? null,
                    'total_points'      => $totalPoints,
                    'start_time'        => $startT,
                    'end_time'          => $endT,
                    'coordinates'       => $coords,
                ]);
                break;
            }

            case 'check_route_deviation': {
                $bookingId = (int)$_POST['booking_id'];
                $pts = sb_get('core2_booking_history',[
                    'select'     => 'notes,changed_at',
                    'booking_id' => 'eq.'.$bookingId,
                    'notes'      => 'like.GPS_POINT%',
                    'order'      => 'changed_at.asc',
                ]);
                if (empty($pts)) { echo json_encode(['success'=>false,'message'=>'No GPS data']); break; }
                $coords = array_map(fn($p)=>json_decode(substr($p['notes'],strlen('GPS_POINT:')),true), $pts);

                $totalDist = 0;
                for ($i=1;$i<count($coords);$i++) {
                    $lat1=deg2rad($coords[$i-1]['lat']??0); $lon1=deg2rad($coords[$i-1]['lng']??0);
                    $lat2=deg2rad($coords[$i]['lat']??0);   $lon2=deg2rad($coords[$i]['lng']??0);
                    $dlat=$lat2-$lat1; $dlon=$lon2-$lon1;
                    $a=sin($dlat/2)**2+cos($lat1)*cos($lat2)*sin($dlon/2)**2;
                    $totalDist += 6371*2*atan2(sqrt($a),sqrt(1-$a));
                }

                $first=$coords[0]; $last=$coords[count($coords)-1];
                $lat1=deg2rad($first['lat']??0); $lon1=deg2rad($first['lng']??0);
                $lat2=deg2rad($last['lat']??0);  $lon2=deg2rad($last['lng']??0);
                $dlat=$lat2-$lat1; $dlon=$lon2-$lon1;
                $a=sin($dlat/2)**2+cos($lat1)*cos($lat2)*sin($dlon/2)**2;
                $straightLine = 6371*2*atan2(sqrt($a),sqrt(1-$a));
                $deviationPct = $straightLine > 0 ? round(($totalDist/$straightLine-1)*100,1) : 0;
                $isDeviated   = $deviationPct > 30; 
                echo json_encode([
                    'success'         => true,
                    'total_distance'  => round($totalDist,2),
                    'straight_line'   => round($straightLine,2),
                    'deviation_pct'   => $deviationPct,
                    'is_deviated'     => $isDeviated,
                    'gps_points'      => count($coords),
                ]);
                break;
            }

            case 'save_gps_point': {
                $bookingId = (int)($_POST['booking_id'] ?? 0);
                $lat = (float)($_POST['latitude']  ?? 0);
                $lng = (float)($_POST['longitude'] ?? 0);
                $spd = (float)($_POST['speed']     ?? 0);
                if (!$bookingId || !$lat || !$lng) { echo json_encode(['success'=>false,'message'=>'Missing data']); break; }
                $payload = json_encode(['lat'=>$lat,'lng'=>$lng,'spd'=>$spd,'ts'=>date('c')]);
                $ok = sb_post('core2_booking_history',[
                    'booking_id'=>$bookingId,'change_type'=>'Status Change',
                    'changed_by'=>$_SESSION['user_id']??null,
                    'notes'=>'GPS_POINT:'.$payload,'changed_at'=>date('c'),
                ], ['Prefer: return=minimal']);

                if (!empty($_POST['core1_driver_id'])) {
                    sb_patch('core1_drivers',['id'=>'eq.'.(int)$_POST['core1_driver_id']],[
                        'current_lat'=>$lat,'current_lng'=>$lng,'location_updated_at'=>date('c'),
                    ]);
                }
                echo json_encode(['success'=>true]);
                break;
            }

            case 'end_tracking': {
                $bookingId = (int)$_POST['booking_id'];
                $pts = sb_get('core2_booking_history',[
                    'select'=>'notes,changed_at','booking_id'=>'eq.'.$bookingId,
                    'notes'=>'like.GPS_POINT%','order'=>'changed_at.asc',
                ]);
                $coords = array_map(fn($p)=>json_decode(substr($p['notes'],strlen('GPS_POINT:')),true), $pts);
                $tripData = ['total_points'=>count($coords),'start_time'=>$pts[0]['changed_at']??null,'end_time'=>end($pts)['changed_at']??null,'coordinates'=>$coords];
                sb_post('core2_booking_history',['booking_id'=>$bookingId,'change_type'=>'Status Change','changed_by'=>$_SESSION['user_id']??null,'notes'=>'GPS_TRIP_HISTORY:'.json_encode($tripData),'changed_at'=>date('c')],['Prefer: return=minimal']);
                sb_patch('core2_rides',['booking_id'=>'eq.'.$bookingId],['ride_status'=>'Completed','end_time'=>date('c')]);
                sb_patch('core2_bookings',['booking_id'=>'eq.'.$bookingId],['booking_status'=>'Completed']);
                echo json_encode(['success'=>true,'message'=>'Trip completed & GPS history saved','total_points'=>count($coords)]);
                break;
            }

            case 'get_trip_stats': {
                $bookingId = (int)$_POST['booking_id'];
                $ride = sb_get('core2_rides',['select'=>'start_time,end_time,driver_id','booking_id'=>'eq.'.$bookingId,'limit'=>'1']);
                $pts  = sb_get('core2_booking_history',['select'=>'notes','booking_id'=>'eq.'.$bookingId,'notes'=>'like.GPS_POINT%']);
                $coords = array_filter(array_map(fn($p)=>json_decode(substr($p['notes'],strlen('GPS_POINT:')),true),$pts));
                $totalDist = 0;
                $speeds = [];
                $arr = array_values($coords);
                for ($i=1;$i<count($arr);$i++) {
                    $lat1=deg2rad($arr[$i-1]['lat']??0); $lon1=deg2rad($arr[$i-1]['lng']??0);
                    $lat2=deg2rad($arr[$i]['lat']??0);   $lon2=deg2rad($arr[$i]['lng']??0);
                    $dlat=$lat2-$lat1; $dlon=$lon2-$lon1;
                    $a=sin($dlat/2)**2+cos($lat1)*cos($lat2)*sin($dlon/2)**2;
                    $totalDist += 6371*2*atan2(sqrt($a),sqrt(1-$a));
                }
                foreach ($arr as $c) if(isset($c['spd'])) $speeds[] = $c['spd'];
                $r = $ride[0]??[];
                $dur = (!empty($r['start_time'])&&!empty($r['end_time'])) ? (int)round((strtotime($r['end_time'])-strtotime($r['start_time']))/60) : null;
                echo json_encode([
                    'success'=>true,
                    'total_distance_km' => round($totalDist,2),
                    'gps_points'        => count($arr),
                    'avg_speed'         => $speeds ? round(array_sum($speeds)/count($speeds),1) : 0,
                    'max_speed'         => $speeds ? round(max($speeds),1) : 0,
                    'duration_minutes'  => $dur,
                ]);
                break;
            }

            case 'get_driver_performance': {
                $core1Id = (int)$_POST['core1_driver_id'];
                $driver  = sb_get('core1_drivers',['select'=>'id,driver_name,status,wallet_balance,boundary_amount,core2_driver_id','id'=>'eq.'.$core1Id,'limit'=>'1']);
                if (empty($driver)) { echo json_encode(['success'=>false,'message'=>'Driver not found']); break; }
                $d = $driver[0];
                $trips = sb_get('core1_trips',['select'=>'id,earnings,status,created_at','driver_id'=>'eq.'.$core1Id,'order'=>'created_at.desc','limit'=>'50']);
                $ratings = sb_get('core2_ratings',['select'=>'rating_value','driver_id'=>'eq.'.$d['core2_driver_id']]);
                $avgRating = !empty($ratings) ? round(array_sum(array_column($ratings,'rating_value'))/count($ratings),1) : null;
                $completed = count(array_filter($trips, fn($t)=>$t['status']==='COMPLETED'));
                $cancelled = count(array_filter($trips, fn($t)=>$t['status']==='CANCELLED'));
                $totalEarnings = array_sum(array_column($trips,'earnings'));
                echo json_encode([
                    'success'          => true,
                    'driver_name'      => $d['driver_name'],
                    'status'           => $d['status'],
                    'wallet_balance'   => $d['wallet_balance'],
                    'boundary_amount'  => $d['boundary_amount'],
                    'trips_completed'  => $completed,
                    'trips_cancelled'  => $cancelled,
                    'total_earnings'   => round($totalEarnings,2),
                    'avg_rating'       => $avgRating,
                    'rating_count'     => count($ratings),
                ]);
                break;
            }

            case 'get_trip_reports': {
                $rideId = (int)$_POST['ride_id'];
                $reports = sb_get('core2_reports',['select'=>'report_id,report_type,description,severity,status,reported_at','ride_id'=>'eq.'.$rideId,'order'=>'reported_at.desc']);
                echo json_encode(['success'=>true,'reports'=>$reports]);
                break;
            }

            default:
                echo json_encode(['success'=>false,'message'=>'Invalid action']);
        }
    } catch (Exception $e) {
        echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
    }
    exit;
}

// Shared cache + parallel helper
if (!function_exists('appCache')) { require_once __DIR__ . '/../config/cache.php'; }

$stat_active=$stat_completed=$stat_drivers_online=$stat_gps_pts=$stat_deviations=$stat_today_trips=0;
$today=date('Y-m-d');
try {
    $todayKey = date('Y-m-d');
    $_gs = appCache('gps_stats_'.$todayKey, 120, function() use ($todayKey) {
        return sbParallel([
            'active'  =>['t'=>'core2_rides','p'=>['select'=>'ride_id','ride_status'=>'eq.In Progress']],
            'done'    =>['t'=>'core2_rides','p'=>['select'=>'ride_id','ride_status'=>'eq.Completed']],
            'drivers' =>['t'=>'core1_drivers','p'=>['select'=>'id','status'=>'in.(Active,In Progress)','current_lat'=>'not.is.null']],
            'today'   =>['t'=>'core2_rides','p'=>['select'=>'ride_id','ride_status'=>'eq.Completed','end_time'=>'gte.'.$todayKey.'T00:00:00']],
        ]);
    });
    $stat_active         = count($_gs['active']  ?? []);
    $stat_completed      = count($_gs['done']    ?? []);
    $stat_drivers_online = count($_gs['drivers'] ?? []);
    $stat_today_trips    = count($_gs['today']   ?? []);
    $stat_gps_pts        = 0;
} catch(Exception $e){}

$userName    = htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin');
$userInitial = strtoupper(substr($userName, 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GPS Tracking – EnviroCab</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%}
:root{
  --g:#00D084;--gd:#00A86B;--gx:#005A38;--gg:rgba(0,208,132,.1);
  --bg:#F0F4F2;--surf:#fff;--surf2:#F7FAF8;--surf3:#EEF5F1;
  --bdr:#DDE8E2;--bdr2:#C8DDD5;
  --txt:#0D1F18;--txt2:#3A5248;--txt3:#7A9A8E;--txt4:#B0C8BC;
  --blue:#3B8EF0;--purple:#8B6FE8;--orange:#F07830;--red:#E84040;--yellow:#E8A020;
  --sb-bg:#991B1B;--sb-txt:#FECACA;--sb-txt2:#FCA5A5;
  --sb-bdr:rgba(255,255,255,.1);--sb-hover:rgba(255,255,255,.09);
  --sb-active:rgba(255,255,255,.16);--sb-active-bdr:rgba(255,255,255,.28);
  --sw:248px;--th:58px;--r:16px;--rs:10px;
  --shadow:0 1px 3px rgba(0,0,0,.04),0 4px 16px rgba(0,0,0,.06);
  --shadow-md:0 2px 8px rgba(0,0,0,.05),0 8px 28px rgba(0,0,0,.09);
}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--txt);-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit}
.trunc{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mono{font-family:'DM Mono',monospace}
.badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:3px 8px;border-radius:5px;text-transform:uppercase;letter-spacing:.4px}
.badge::before{content:'';width:5px;height:5px;border-radius:50%;flex-shrink:0}
.badge-green{background:rgba(0,208,132,.12);color:#008A58}.badge-green::before{background:#00A86B}
.badge-blue{background:rgba(59,142,240,.1);color:#1966C2}.badge-blue::before{background:#3B8EF0}
.badge-yellow{background:rgba(232,160,32,.12);color:#9A6A00}.badge-yellow::before{background:#E8A020}
.badge-red{background:rgba(232,64,64,.1);color:#C22020}.badge-red::before{background:#E84040}
.badge-purple{background:rgba(139,111,232,.1);color:#5A3FBB}.badge-purple::before{background:#8B6FE8}
.badge-orange{background:rgba(240,120,48,.1);color:#C24800}.badge-orange::before{background:#F07830}

@media(min-width:900px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}

  .sidebar{width:var(--sw);flex-shrink:0;height:100vh;display:flex;flex-direction:column;background:var(--sb-bg);overflow:hidden;box-shadow:3px 0 18px rgba(153,27,27,.22)}
  .sb-logo{height:var(--th);display:flex;align-items:center;gap:10px;padding:0 18px;border-bottom:1px solid var(--sb-bdr);flex-shrink:0}
  .sb-logo img{height:26px;filter:brightness(0) invert(1)}
  .sb-brand{font-size:16px;font-weight:800;letter-spacing:-.3px;color:#fff}.sb-brand span{color:#FCA5A5}
  .sb-nav{flex:1;overflow-y:auto;padding:12px 10px;display:flex;flex-direction:column;gap:1px}
  .sb-label{font-size:9.5px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:var(--sb-txt2);padding:14px 10px 5px}
  .sb-item{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:9px;cursor:pointer;color:rgba(255,255,255,.75);font-size:13px;font-weight:500;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover);color:#fff}
  .sb-item.active{background:var(--sb-active);color:#fff;border-color:var(--sb-active-bdr);font-weight:600}
  .sb-ico{width:30px;height:30px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item:hover .sb-ico,.sb-item.active .sb-ico{background:rgba(255,255,255,.16)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-foot{padding:12px 10px;border-top:1px solid var(--sb-bdr);flex-shrink:0;display:flex;gap:8px;align-items:center}
  .sb-av{width:34px;height:34px;border-radius:9px;flex-shrink:0;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;border:1px solid rgba(255,255,255,.28)}
  .sb-uname{font-size:12.5px;font-weight:600;color:#fff}
  .sb-urole{font-size:11px;color:var(--sb-txt2)}
  .sb-out{margin-left:auto;width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s}
  .sb-out:hover{background:rgba(239,68,68,.3)}
  .sb-out svg{stroke:#fff!important}

  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:var(--th);flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 24px;gap:12px}
  .tb-title{flex:1;font-size:16px;font-weight:800;letter-spacing:-.2px}
  .tb-date{font-size:12px;color:var(--txt3);font-weight:500}
  .tb-sep{width:1px;height:18px;background:var(--bdr)}
  .tb-btn{height:34px;padding:0 14px;border-radius:8px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12.5px;font-weight:600;color:var(--txt2);transition:all .15s}
  .tb-btn:hover{background:var(--bg)}
  .tb-btn svg{stroke:var(--txt3)!important}
  .scroll{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:16px}
  .scroll::-webkit-scrollbar{width:0px}
  .scroll{scrollbar-width:none}

  .kpi-row{display:grid;grid-template-columns:repeat(6,1fr);gap:11px}
  .kpi{background:var(--surf);border-radius:14px;padding:14px 16px;border:1px solid var(--bdr);transition:all .2s}
  .kpi:hover{box-shadow:var(--shadow);transform:translateY(-1px)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
  .kpi-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-num{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:26px;font-weight:800;line-height:1;margin-bottom:3px;letter-spacing:-.4px}
  .kpi-lbl{font-size:11px;color:var(--txt3)}
  .kpi-sub{font-size:10px;color:var(--txt4);margin-top:2px}
  .pulse{animation:pulse-dot 2s infinite}
  @keyframes pulse-dot{0%,100%{opacity:1}50%{opacity:.3}}

  .tool-bar{display:flex;align-items:center;gap:8px;background:var(--surf);border-radius:var(--r);padding:12px 14px;border:1px solid var(--bdr);flex-wrap:wrap}
  .search-wrap{position:relative;flex:1;min-width:160px}
  .search-ico{position:absolute;left:9px;top:50%;transform:translateY(-50%);pointer-events:none}
  .search-box{width:100%;height:34px;padding:0 10px 0 32px;border-radius:8px;border:1px solid var(--bdr);background:var(--surf2);font-size:12.5px;font-family:'DM Sans',sans-serif;color:var(--txt);transition:border .15s}
  .search-box:focus{outline:none;border-color:var(--g)}
  .tabs-bar{display:flex;gap:2px;background:var(--surf2);border-radius:8px;padding:2px;border:1px solid var(--bdr)}
  .tab-btn{padding:5px 12px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s;display:flex;align-items:center;gap:4px;white-space:nowrap}
  .tab-btn.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.07)}
  .tab-badge{font-size:9.5px;background:rgba(0,0,0,.07);color:var(--txt3);padding:1px 5px;border-radius:10px;font-weight:700}
  .tab-btn.active .tab-badge{background:rgba(0,208,132,.12);color:var(--gd)}
  .filter-sep{width:1px;height:18px;background:var(--bdr)}

  .panel{background:var(--surf);border-radius:var(--r);border:1px solid var(--bdr);overflow:hidden}
  .panel-hdr{padding:14px 18px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .panel-title{font-size:13px;font-weight:700;color:var(--txt)}

  .trips-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;padding:14px}
  .trip-card{background:var(--surf2);border:1.5px solid var(--bdr);border-radius:14px;overflow:hidden;transition:all .2s}
  .trip-card:hover{border-color:var(--gd);box-shadow:var(--shadow)}
  .tc-head{padding:11px 14px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .tc-ref{font-size:13px;font-weight:800;color:var(--txt)}
  .tc-body{padding:12px 14px;display:flex;flex-direction:column;gap:7px}
  .tc-row{display:flex;gap:8px;font-size:12px}
  .tc-lbl{width:82px;font-size:10.5px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .tc-val{color:var(--txt2);font-weight:500;flex:1;font-size:12px}
  .tc-map{background:linear-gradient(135deg,#E0EEFB 0%,#C7DDF5 100%);border-radius:10px;height:130px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px;margin:0 14px;color:var(--txt3)}
  .tc-map.has-loc{background:linear-gradient(135deg,#E0F7EE 0%,#C7EDDA 100%);cursor:pointer}
  .tc-map.has-loc:hover{background:linear-gradient(135deg,#d0f0e4 0%,#b0e4cc 100%)}
  .tc-foot{padding:10px 14px;border-top:1px solid var(--bdr);display:flex;gap:6px;flex-wrap:wrap}

  .tbl-wrap{overflow-x:auto}
  table{width:100%;border-collapse:collapse;font-size:12px}
  thead tr{background:var(--surf2)}
  thead th{padding:9px 12px;text-align:left;font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  tbody tr{border-bottom:1px solid var(--bdr);transition:background .12s;cursor:pointer}
  tbody tr:last-child{border-bottom:none}
  tbody tr:hover{background:var(--surf2)}
  tbody td{padding:9px 12px;vertical-align:middle}
  .td-ref{font-weight:700;font-size:12.5px}
  .td-sub{font-size:10.5px;color:var(--txt3);margin-top:1px}
  .empty-row td{text-align:center;padding:48px;color:var(--txt3)}

  .btn{padding:6px 12px;border-radius:8px;font-size:11.5px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:5px}
  .btn-sm{padding:5px 9px;font-size:11px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-purple{background:linear-gradient(135deg,#A78BFA,#8B6FE8);color:#fff}
  .btn:hover{opacity:.9;transform:translateY(-1px)}

  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);z-index:1000;align-items:center;justify-content:center;padding:16px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:18px;max-width:560px;width:100%;max-height:88vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide{max-width:740px}
  .modal-xl{max-width:900px}
  .modal-hdr{padding:16px 20px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:14px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:18px 20px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 20px;border-top:1px solid var(--bdr);display:flex;gap:8px}
  .d-row{display:flex;align-items:flex-start;padding:8px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:130px;font-size:11px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:2px}
  .d-val{font-size:12.5px;color:var(--txt);font-weight:500;flex:1}
  .section-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:8px;margin-top:12px}
  .section-label:first-child{margin-top:0}

  .map-box{background:linear-gradient(135deg,#E8F4FD 0%,#D0E8F7 100%);border-radius:12px;height:320px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;color:var(--txt3);border:1.5px solid #C0D8EE;position:relative;overflow:hidden;cursor:pointer}
  .map-box:hover{background:linear-gradient(135deg,#DDF0FA 0%,#C4E0F2 100%)}
  .map-box-sm{height:200px}
  .map-coords{position:absolute;bottom:10px;left:10px;background:rgba(255,255,255,.9);border-radius:7px;padding:5px 10px;font-size:11px;font-weight:600;color:var(--txt2)}

  .play-bar{background:var(--surf2);border:1px solid var(--bdr);border-radius:12px;padding:14px 16px;display:flex;align-items:center;gap:12px;margin-top:12px}
  .play-btn{width:38px;height:38px;border-radius:10px;background:var(--g);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s}
  .play-btn:hover{background:var(--gd)}
  .play-slider{flex:1;-webkit-appearance:none;appearance:none;height:4px;border-radius:2px;background:var(--bdr);outline:none;cursor:pointer}
  .play-slider::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;border-radius:50%;background:var(--g);cursor:pointer}
  .play-time{font-size:11px;font-weight:600;color:var(--txt3);white-space:nowrap;min-width:80px;text-align:right}

  .stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px}
  .stat-box{background:var(--surf2);border:1px solid var(--bdr);border-radius:10px;padding:12px 14px;text-align:center}
  .stat-v{font-size:22px;font-weight:800;line-height:1;margin-bottom:3px}
  .stat-l{font-size:10.5px;color:var(--txt3)}

  .toast{position:fixed;bottom:18px;right:18px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:#0D5F3A;color:#fff;padding:10px 14px;border-radius:9px;font-size:12.5px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:8px;animation:toastIn .3s ease;max-width:300px}
  .toast-item.error{background:#5F1313}
  .toast-item.warn{background:#7A4400}
  .toast-item.info{background:#1A3A6A}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}

  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:13px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}

  .deviation-alert{display:none;background:rgba(240,120,48,.1);border:1.5px solid rgba(240,120,48,.3);border-radius:10px;padding:10px 14px;font-size:12.5px;font-weight:600;color:var(--orange);align-items:center;gap:8px;margin-bottom:12px}
  .deviation-alert.show{display:flex}

  .breadcrumb-trail{height:4px;background:var(--bdr);border-radius:2px;overflow:hidden;margin:8px 0}
  .breadcrumb-fill{height:100%;background:linear-gradient(90deg,var(--g),var(--gd));border-radius:2px;transition:width 1s ease}

  .live-dot{width:8px;height:8px;border-radius:50%;background:var(--g);display:inline-block;margin-right:4px;animation:pulse-dot 1.5s infinite}
}

@media(min-width:768px) and (max-width:899px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}
  .sidebar{width:62px;height:100vh;background:var(--sb-bg);display:flex;flex-direction:column;align-items:center;padding:10px 0;gap:3px;flex-shrink:0;box-shadow:3px 0 14px rgba(153,27,27,.2)}
  .sb-logo{width:100%;height:52px;display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--sb-bdr);margin-bottom:6px}
  .sb-logo img{height:24px;filter:brightness(0) invert(1)}
  .sb-brand,.sb-label,.sb-uname,.sb-urole{display:none}
  .sb-nav{flex:1;width:100%;padding:4px 7px;display:flex;flex-direction:column;align-items:center;gap:2px}
  .sb-item{width:44px;height:44px;border-radius:11px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:1px solid transparent;transition:all .15s}
  .sb-item span{display:none}
  .sb-item:hover{background:var(--sb-hover)}
  .sb-item.active{background:var(--sb-active);border-color:var(--sb-active-bdr)}
  .sb-ico{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-item.active .sb-ico{background:rgba(255,255,255,.16)}
  .sb-foot{padding:8px;border-top:1px solid var(--sb-bdr);width:100%;display:flex;flex-direction:column;align-items:center;gap:5px}
  .sb-av{width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:#fff}
  .sb-out{width:28px;height:28px;border-radius:7px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .sb-out svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:52px;flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 16px;gap:10px}
  .tb-title{flex:1;font-size:15px;font-weight:800}
  .tb-date{font-size:11px;color:var(--txt3)}
  .tb-sep{width:1px;height:16px;background:var(--bdr)}
  .tb-btn{height:30px;padding:0 11px;border-radius:7px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:5px;cursor:pointer;font-size:11.5px;font-weight:600;color:var(--txt2)}
  .scroll{flex:1;overflow-y:auto;padding:14px 16px;display:flex;flex-direction:column;gap:14px}
  .kpi-row{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .kpi{background:var(--surf);border-radius:12px;padding:13px 15px;border:1px solid var(--bdr)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:9px}
  .kpi-ico{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-num{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:22px;font-weight:800;line-height:1;margin-bottom:3px}
  .kpi-lbl{font-size:10.5px;color:var(--txt3)}
  .tool-bar{display:flex;align-items:center;gap:7px;background:var(--surf);border-radius:12px;padding:10px 12px;border:1px solid var(--bdr);flex-wrap:wrap}
  .search-wrap{position:relative;flex:1}
  .search-ico{position:absolute;left:8px;top:50%;transform:translateY(-50%);pointer-events:none}
  .search-box{width:100%;height:32px;padding:0 10px 0 28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);font-size:12px;font-family:'DM Sans',sans-serif;color:var(--txt)}
  .search-box:focus{outline:none;border-color:var(--g)}
  .tabs-bar{display:flex;gap:2px;background:var(--surf2);border-radius:8px;padding:2px;border:1px solid var(--bdr)}
  .tab-btn{padding:5px 9px;border-radius:6px;font-size:11.5px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;white-space:nowrap}
  .tab-btn.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.07)}
  .tab-badge{font-size:9px;background:rgba(0,0,0,.07);color:var(--txt3);padding:1px 4px;border-radius:8px;font-weight:700}
  .tab-btn.active .tab-badge{background:rgba(0,208,132,.12);color:var(--gd)}
  .filter-sep{width:1px;height:16px;background:var(--bdr)}
  .panel{background:var(--surf);border-radius:14px;border:1px solid var(--bdr);overflow:hidden}
  .panel-hdr{padding:12px 14px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .panel-title{font-size:12.5px;font-weight:700}
  .trips-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:12px}
  .trip-card{background:var(--surf2);border:1.5px solid var(--bdr);border-radius:12px;overflow:hidden}
  .tc-head{padding:10px 12px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .tc-ref{font-size:12px;font-weight:800}
  .tc-body{padding:10px 12px;display:flex;flex-direction:column;gap:6px}
  .tc-row{display:flex;gap:6px;font-size:11.5px}
  .tc-lbl{width:75px;font-size:10px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .tc-val{color:var(--txt2);font-weight:500;flex:1;font-size:11.5px}
  .tc-map{background:linear-gradient(135deg,#E0EEFB,#C7DDF5);border-radius:9px;height:100px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:7px;margin:0 12px;color:var(--txt3)}
  .tc-map.has-loc{background:linear-gradient(135deg,#E0F7EE,#C7EDDA);cursor:pointer}
  .tc-foot{padding:9px 12px;border-top:1px solid var(--bdr);display:flex;gap:5px;flex-wrap:wrap}
  .tbl-wrap{overflow-x:auto}
  table{width:100%;border-collapse:collapse;font-size:11.5px}
  thead tr{background:var(--surf2)}
  thead th{padding:8px 10px;text-align:left;font-size:9.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  tbody tr{border-bottom:1px solid var(--bdr);cursor:pointer}
  tbody tr:hover{background:var(--surf2)}
  tbody td{padding:8px 10px;vertical-align:middle}
  .empty-row td{text-align:center;padding:36px;color:var(--txt3)}
  .btn{padding:6px 10px;border-radius:7px;font-size:11px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:4px}
  .btn-sm{padding:5px 8px;font-size:10.5px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-purple{background:linear-gradient(135deg,#A78BFA,#8B6FE8);color:#fff}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);z-index:1000;align-items:center;justify-content:center;padding:14px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:16px;max-width:500px;width:100%;max-height:86vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide{max-width:660px}
  .modal-xl{max-width:800px}
  .modal-hdr{padding:14px 16px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:13.5px;font-weight:800}
  .modal-close{width:26px;height:26px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:16px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 16px;border-top:1px solid var(--bdr);display:flex;gap:6px}
  .d-row{display:flex;padding:7px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:115px;font-size:10.5px;font-weight:600;color:var(--txt3);flex-shrink:0}
  .d-val{font-size:12px;font-weight:500;flex:1}
  .section-label{font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--txt3);margin-bottom:6px;margin-top:10px}
  .section-label:first-child{margin-top:0}
  .map-box{background:linear-gradient(135deg,#E8F4FD,#D0E8F7);border-radius:11px;height:260px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:9px;color:var(--txt3);border:1.5px solid #C0D8EE;position:relative;overflow:hidden;cursor:pointer}
  .map-box-sm{height:170px}
  .map-coords{position:absolute;bottom:9px;left:9px;background:rgba(255,255,255,.9);border-radius:6px;padding:4px 9px;font-size:10.5px;font-weight:600;color:var(--txt2)}
  .play-bar{background:var(--surf2);border:1px solid var(--bdr);border-radius:10px;padding:11px 14px;display:flex;align-items:center;gap:10px;margin-top:10px}
  .play-btn{width:34px;height:34px;border-radius:9px;background:var(--g);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .play-slider{flex:1;-webkit-appearance:none;appearance:none;height:3px;border-radius:2px;background:var(--bdr);outline:none;cursor:pointer}
  .play-slider::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;background:var(--g);cursor:pointer}
  .play-time{font-size:10.5px;font-weight:600;color:var(--txt3);white-space:nowrap;min-width:70px;text-align:right}
  .stats-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:10px}
  .stat-box{background:var(--surf2);border:1px solid var(--bdr);border-radius:9px;padding:10px 12px;text-align:center}
  .stat-v{font-size:18px;font-weight:800;line-height:1;margin-bottom:3px}
  .stat-l{font-size:10px;color:var(--txt3)}
  .deviation-alert{display:none;background:rgba(240,120,48,.1);border:1.5px solid rgba(240,120,48,.3);border-radius:9px;padding:9px 12px;font-size:12px;font-weight:600;color:var(--orange);align-items:center;gap:7px;margin-bottom:10px}
  .deviation-alert.show{display:flex}
  .breadcrumb-trail{height:4px;background:var(--bdr);border-radius:2px;overflow:hidden;margin:7px 0}
  .breadcrumb-fill{height:100%;background:linear-gradient(90deg,var(--g),var(--gd));border-radius:2px;transition:width 1s ease}
  .live-dot{width:7px;height:7px;border-radius:50%;background:var(--g);display:inline-block;margin-right:4px;animation:pulse-dot 1.5s infinite}
  @keyframes pulse-dot{0%,100%{opacity:1}50%{opacity:.3}}
  .toast{position:fixed;bottom:14px;right:14px;z-index:9999;display:flex;flex-direction:column;gap:6px}
  .toast-item{background:#0D5F3A;color:#fff;padding:9px 13px;border-radius:9px;font-size:12px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:7px;animation:toastIn .3s ease;max-width:280px}
  .toast-item.error{background:#5F1313}
  .toast-item.warn{background:#7A4400}
  .toast-item.info{background:#1A3A6A}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:12px;padding:20px 26px;text-align:center}
  .spinner{width:36px;height:36px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
}

@media(max-width:767px){
  .sidebar,.desk-wrap{display:none!important}
  body{background:var(--bg);padding-bottom:80px}
  .mob-header{position:sticky;top:0;z-index:100;background:rgba(255,255,255,.92);backdrop-filter:blur(16px);border-bottom:1px solid rgba(0,0,0,.06);padding:12px 15px;display:flex;align-items:center;gap:10px}
  .mh-back{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mh-title{flex:1;font-size:16px;font-weight:800;text-align:center}
  .mh-btn{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mob-body{padding:13px 13px 16px;display:flex;flex-direction:column;gap:12px}
  .m-kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
  .mkpi{background:#fff;border-radius:13px;padding:12px 10px;border:1px solid var(--bdr);text-align:center}
  .mkpi-v{font-size:22px;font-weight:800;line-height:1}
  .mkpi-l{font-size:10.5px;color:var(--txt3);margin-top:3px}
  .m-filters{display:flex;gap:6px;overflow-x:auto;padding-bottom:4px}
  .m-filter-btn{padding:7px 13px;border-radius:20px;font-size:12px;font-weight:600;border:1.5px solid var(--bdr);background:#fff;white-space:nowrap;cursor:pointer}
  .m-filter-btn.active{background:var(--gg);border-color:rgba(0,208,132,.3);color:#008A58}
  .m-search{position:relative}
  .m-search input{width:100%;height:38px;padding:0 13px 0 35px;border-radius:12px;border:1.5px solid var(--bdr);background:#fff;font-size:13px;font-family:'DM Sans',sans-serif;color:var(--txt)}
  .m-search input:focus{outline:none;border-color:var(--g)}
  .m-search svg{position:absolute;left:10px;top:50%;transform:translateY(-50%);pointer-events:none}
  .m-trips{display:flex;flex-direction:column;gap:10px}
  .m-trip{background:#fff;border-radius:15px;border:1.5px solid var(--bdr);overflow:hidden}
  .mt-head{padding:11px 14px;border-bottom:1px solid var(--surf3);display:flex;align-items:center;justify-content:space-between}
  .mt-ref{font-size:13.5px;font-weight:800}
  .mt-body{padding:11px 14px;display:flex;flex-direction:column;gap:6px}
  .mt-row{display:flex;gap:7px;font-size:12.5px}
  .mt-lbl{font-size:11px;font-weight:600;color:var(--txt3);width:70px;flex-shrink:0}
  .mt-val{color:var(--txt2);font-weight:500;flex:1}
  .mt-foot{padding:10px 14px;border-top:1px solid var(--surf3);display:flex;gap:6px;flex-wrap:wrap}
  .btn{padding:8px 13px;border-radius:9px;font-size:12px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:5px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:rgba(0,0,0,.04);color:var(--txt2)}
  .btn-purple{background:linear-gradient(135deg,#A78BFA,#8B6FE8);color:#fff}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1000;align-items:flex-end;justify-content:center}
  .modal.open{display:flex}
  .modal-box{background:#fff;border-radius:22px 22px 0 0;width:100%;max-height:88vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide,.modal-xl{max-height:92vh}
  .modal-hdr{padding:16px 18px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:16px 18px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 18px;border-top:1px solid var(--bdr);display:flex;gap:8px}
  .d-row{display:flex;padding:7px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:110px;font-size:11px;font-weight:600;color:var(--txt3);flex-shrink:0}
  .d-val{font-size:12.5px;font-weight:500;flex:1}
  .section-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--txt3);margin-bottom:7px;margin-top:10px}
  .section-label:first-child{margin-top:0}
  .map-box{background:linear-gradient(135deg,#E8F4FD,#D0E8F7);border-radius:14px;height:220px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;color:var(--txt3);border:1.5px solid #C0D8EE;position:relative;overflow:hidden;cursor:pointer}
  .map-box-sm{height:160px}
  .map-coords{position:absolute;bottom:10px;left:10px;background:rgba(255,255,255,.9);border-radius:7px;padding:5px 10px;font-size:11px;font-weight:600;color:var(--txt2)}
  .play-bar{background:var(--surf2);border:1px solid var(--bdr);border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:10px;margin-top:10px}
  .play-btn{width:36px;height:36px;border-radius:10px;background:var(--g);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .play-slider{flex:1;-webkit-appearance:none;appearance:none;height:4px;border-radius:2px;background:var(--bdr);outline:none}
  .play-slider::-webkit-slider-thumb{-webkit-appearance:none;width:13px;height:13px;border-radius:50%;background:var(--g)}
  .play-time{font-size:11px;font-weight:600;color:var(--txt3);white-space:nowrap}
  .stats-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px}
  .stat-box{background:var(--surf2);border:1px solid var(--bdr);border-radius:11px;padding:11px 13px;text-align:center}
  .stat-v{font-size:20px;font-weight:800;line-height:1;margin-bottom:3px}
  .stat-l{font-size:10.5px;color:var(--txt3)}
  .deviation-alert{display:none;background:rgba(240,120,48,.1);border:1.5px solid rgba(240,120,48,.3);border-radius:10px;padding:10px 13px;font-size:12.5px;font-weight:600;color:var(--orange);align-items:center;gap:8px;margin-bottom:12px}
  .deviation-alert.show{display:flex}
  .breadcrumb-trail{height:4px;background:var(--bdr);border-radius:2px;overflow:hidden;margin:8px 0}
  .breadcrumb-fill{height:100%;background:linear-gradient(90deg,var(--g),var(--gd));border-radius:2px;transition:width 1s ease}
  .live-dot{width:7px;height:7px;border-radius:50%;background:var(--g);display:inline-block;margin-right:4px;animation:pulse-dot 1.5s infinite}
  @keyframes pulse-dot{0%,100%{opacity:1}50%{opacity:.3}}
  .mob-nav{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.96);backdrop-filter:blur(20px);border-top:1px solid rgba(0,0,0,.06);padding:8px 0 16px;display:grid;grid-template-columns:repeat(4,1fr);z-index:99}
  .mn{display:flex;flex-direction:column;align-items:center;gap:2px;padding:5px;cursor:pointer;border:none;background:none}
  .mn-ico{width:40px;height:26px;display:flex;align-items:center;justify-content:center}
  .mn-ico svg{stroke:#718096;opacity:.5}
  .mn.active .mn-ico svg{stroke:var(--g);opacity:1}
  .mn-lbl{font-size:10px;font-weight:600;color:#718096;opacity:.7}
  .mn.active .mn-lbl{color:var(--g);opacity:1}
  .m-toast{position:fixed;bottom:88px;left:13px;right:13px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .m-toast-item{background:#0D5F3A;color:#fff;padding:11px 15px;border-radius:12px;font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px;animation:toastIn .3s ease}
  .m-toast-item.error{background:#5F1313}
  .m-toast-item.warn{background:#7A4400}
  .m-empty{text-align:center;padding:44px 20px;background:#fff;border-radius:16px;border:1px solid var(--bdr)}
  .m-empty p{font-size:13px;color:var(--txt3);margin-top:10px}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:#fff;border-radius:16px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes toastIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
}
</style>
</head>
<body>

<?php
function ico($path, $stroke='#4A5568', $size=18){
  return "<svg width='$size' height='$size' viewBox='0 0 24 24' fill='none' stroke='$stroke' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>$path</svg>";
}
$iHome    ="<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>";
$iBook    ="<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>";
$iPay     ="<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iCrm     ="<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iGps     ="<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/>";
$iBar     ="<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>";
$iDoc     ="<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/>";
$iOut     ="<path d='M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'/><polyline points='16 17 21 12 16 7'/><line x1='21' y1='12' x2='9' y2='12'/>";
$iRefresh ="<path d='M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2'/>";
$iSearch  ="<circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/>";
$iPlay    ="<polygon points='5 3 19 12 5 21 5 3'/>";
$iPause   ="<rect x='6' y='4' width='4' height='16'/><rect x='14' y='4' width='4' height='16'/>";
$iEye     ="<path d='M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z'/><circle cx='12' cy='12' r='3'/>";
$iClock   ="<circle cx='12' cy='12' r='10'/><polyline points='12 6 12 12 16 14'/>";
$iList    ="<line x1='8' y1='6' x2='21' y2='6'/><line x1='8' y1='12' x2='21' y2='12'/><line x1='8' y1='18' x2='21' y2='18'/><line x1='3' y1='6' x2='3.01' y2='6'/><line x1='3' y1='12' x2='3.01' y2='12'/><line x1='3' y1='18' x2='3.01' y2='18'/>";
$iUser    ="<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>";
$iAlert   ="<path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'/><line x1='12' y1='9' x2='12' y2='13'/><line x1='12' y1='17' x2='12.01' y2='17'/>";
$iTruck   ="<rect x='1' y='3' width='15' height='13'/><polygon points='16 8 20 8 23 11 23 16 16 16 16 8'/><circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/>";
$iCheck   ="<polyline points='20 6 9 17 4 12'/>";
$iBack    ="<path d='M19 12H5M12 19l-7-7 7-7'/>";
$iDownload="<path d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'/><polyline points='7 10 12 15 17 10'/><line x1='12' y1='15' x2='12' y2='3'/>";
$iRoute   ="<circle cx='6' cy='19' r='3'/><path d='M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15'/><circle cx='18' cy='5' r='3'/>";
$iStar    ="<polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/>";
?>

<aside class="sidebar">
  <div class="sb-logo">
    <img src="../images/envirocab_logo.png" alt="EnviroCab" onerror="this.style.display='none'">
  </div>
  <nav class="sb-nav">
    <div class="sb-label">Core 2</div>
    <a href="dashboard.php" class="sb-item"><div class="sb-ico"><?=ico($iHome,'#4A5568')?></div><span>Dashboard</span></a>
    <a href="booking_system.php" class="sb-item"><div class="sb-ico"><?=ico($iBook,'#4A5568')?></div><span>Booking System</span></a>
    <a href="payment_fares.php" class="sb-item"><div class="sb-ico"><?=ico($iPay,'#4A5568')?></div><span>Payment &amp; Fares</span></a>
    <a href="crm_system.php" class="sb-item"><div class="sb-ico"><?=ico($iCrm,'#4A5568')?></div><span>CRM</span></a>
    <a href="gps_tracking.php" class="sb-item active"><div class="sb-ico"><?=ico($iGps,'#4A5568')?></div><span>GPS Tracking</span></a>
    <div class="sb-label">Analytics</div>
    <a href="transport_analytics.php" class="sb-item"><div class="sb-ico"><?=ico($iBar,'#4A5568')?></div><span>Analytics &amp; KPIs</span></a>
    <a href="sop_compliance.php" class="sb-item"><div class="sb-ico"><?=ico($iDoc,'#4A5568')?></div><span>SOP Compliance</span></a>
  </nav>
  <div class="sb-foot">
    <div class="sb-av"><?=$userInitial?></div>
    <div style="flex:1;min-width:0">
      <div class="sb-uname trunc"><?=$userName?></div>
      <div class="sb-urole">Administrator</div>
    </div>
    <button class="sb-out" onclick="if(confirm('Logout?'))location.href='../auth/logout.php'" title="Logout"><?=ico($iOut,'#EF4444',14)?></button>
  </div>
</aside>

<div class="desk-wrap">
  <header class="topbar">
    <div class="tb-title">GPS Tracking &amp; Trip Playback</div>
    <div class="tb-date" id="liveDate"><?=date('D, M j, Y')?></div>
    <div class="tb-sep"></div>
    <button class="tb-btn" onclick="exportHistory()"><?=ico($iDownload,'#4A5568',13)?> Export</button>
    <button class="tb-btn" onclick="fullRefresh()"><?=ico($iRefresh,'#4A5568',13)?> Refresh</button>
  </header>

  <div class="scroll">

    <div class="kpi-row">
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iGps,'#00A86B',17)?></div>
          <div class="kpi-num" style="background:rgba(0,208,132,.12);color:#008A58">LIVE</div>
        </div>
        <div class="kpi-val" id="kpi-active"><?=$stat_active?></div>
        <div class="kpi-lbl">Active Trips</div>
        <div class="kpi-sub"><span class="live-dot"></span>Real-time</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(59,142,240,.1)"><?=ico($iTruck,'#3B8EF0',17)?></div>
          <div class="kpi-num">ONLINE</div>
        </div>
        <div class="kpi-val" id="kpi-drivers"><?=$stat_drivers_online?></div>
        <div class="kpi-lbl">Drivers Online</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(139,111,232,.1)"><?=ico($iCheck,'#8B6FE8',17)?></div>
          <div class="kpi-num">TODAY</div>
        </div>
        <div class="kpi-val" id="kpi-today"><?=$stat_today_trips?></div>
        <div class="kpi-lbl">Completed Today</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iClock,'#00A86B',17)?></div>
          <div class="kpi-num">TOTAL</div>
        </div>
        <div class="kpi-val" id="kpi-completed"><?=$stat_completed?></div>
        <div class="kpi-lbl">All Completed</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(232,160,32,.1)"><?=ico($iRoute,'#E8A020',17)?></div>
          <div class="kpi-num">LOGGED</div>
        </div>
        <div class="kpi-val"><?=number_format($stat_gps_pts/max($stat_gps_pts,1000),1)?>K</div>
        <div class="kpi-lbl">GPS Points</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(240,120,48,.1)"><?=ico($iAlert,'#F07830',17)?></div>
          <div class="kpi-num">ALERTS</div>
        </div>
        <div class="kpi-val" id="kpi-deviations">0</div>
        <div class="kpi-lbl">Route Deviations</div>
      </div>
    </div>

    <div class="tool-bar">
      <div class="search-wrap">
        <div class="search-ico"><?=ico($iSearch,'#7A9A8E',13)?></div>
        <input type="text" class="search-box" id="tripSearch" placeholder="Search booking ref, driver, customer, location…" oninput="searchTrips(this.value)">
      </div>
      <div class="filter-sep"></div>
      <div class="tabs-bar" id="mainTabs">
        <button class="tab-btn active" onclick="setTab('live',this)">
          <?=ico($iGps,'currentColor',12)?> Live <span class="tab-badge" id="badge-live"><?=$stat_active?></span>
        </button>
        <button class="tab-btn" onclick="setTab('fleet',this)">
          <?=ico($iTruck,'currentColor',12)?> Fleet Map <span class="tab-badge" id="badge-fleet">–</span>
        </button>
        <button class="tab-btn" onclick="setTab('history',this)">
          <?=ico($iList,'currentColor',12)?> History <span class="tab-badge" id="badge-history"><?=$stat_completed?></span>
        </button>
      </div>
      <div class="filter-sep"></div>
      <button class="tb-btn" id="autoRefreshBtn" onclick="toggleAutoRefresh()" title="Toggle auto-refresh">
        <?=ico($iRefresh,'#4A5568',13)?> Auto
      </button>
    </div>

    <div id="tab-live">
      <div class="panel">
        <div class="panel-hdr">
          <div class="panel-title"><?=ico($iGps,'#00A86B',14)?> &nbsp;Active Trips — Real-time GPS</div>
          <span id="last-refresh" style="font-size:11px;color:var(--txt3)">Loading…</span>
        </div>
        <div class="trips-grid" id="live-grid">
          <div style="grid-column:span 2;text-align:center;padding:60px 20px;color:var(--txt3)">
            <div class="spinner" style="margin:0 auto 14px"></div>
            <p style="font-size:13px;font-weight:500">Loading active trips…</p>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-fleet" style="display:none">
      <div class="panel">
        <div class="panel-hdr">
          <div class="panel-title"><?=ico($iTruck,'#3B8EF0',14)?> &nbsp;Fleet Location Map</div>
          <button class="tb-btn" onclick="loadFleetMap()"><?=ico($iRefresh,'#4A5568',12)?> Refresh</button>
        </div>
        <div style="padding:16px">
          <div class="map-box" id="fleetMapBox" onclick="openOSMFleet()" style="height:380px">
            <?=ico("<circle cx='12' cy='12' r='10'/><line x1='2' y1='12' x2='22' y2='12'/><path d='M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z'/>", '#C0D8EE', 48)?>
            <p style="font-size:14px;font-weight:700;color:var(--txt2)">Fleet Map</p>
            <p style="font-size:12px;color:var(--txt3)">Click to open OpenStreetMap with all driver pins</p>
            <div class="map-coords" id="fleet-coords" style="display:none"></div>
          </div>
          <div class="tbl-wrap" style="margin-top:14px">
            <table>
              <thead><tr>
                <th>Driver</th><th>Status</th><th>Vehicle</th>
                <th>Coordinates</th><th>Last Updated</th><th>Actions</th>
              </tr></thead>
              <tbody id="fleetTbody"><tr class="empty-row"><td colspan="6">Loading fleet data…</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-history" style="display:none">
      <div class="panel">
        <div class="panel-hdr">
          <div class="panel-title"><?=ico($iList,'#3B8EF0',14)?> &nbsp;Completed Trip History</div>
          <button class="tb-btn" onclick="loadHistory()"><?=ico($iRefresh,'#4A5568',12)?> Refresh</button>
        </div>
        <div class="tbl-wrap">
          <table>
            <thead><tr>
              <th>Reference</th><th>Customer</th><th>Driver</th>
              <th>Route</th><th>Date</th><th>Duration</th>
              <th>GPS Pts</th><th>Fare</th><th>Actions</th>
            </tr></thead>
            <tbody id="historyTbody"><tr class="empty-row"><td colspan="9">Loading history…</td></tr></tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<header class="mob-header">
  <button class="mh-back" onclick="location.href='dashboard.php'"><?=ico($iBack,'currentColor',16)?></button>
  <div class="mh-title">GPS Tracking</div>
  <button class="mh-btn" onclick="fullRefresh()"><?=ico($iRefresh,'currentColor',16)?></button>
</header>

<div class="mob-body">
  <div class="m-kpis">
    <div class="mkpi"><div class="mkpi-v" style="color:#00A86B" id="m-kpi-active"><?=$stat_active?></div><div class="mkpi-l">Active</div></div>
    <div class="mkpi"><div class="mkpi-v" style="color:#3B8EF0" id="m-kpi-drivers"><?=$stat_drivers_online?></div><div class="mkpi-l">Online</div></div>
    <div class="mkpi"><div class="mkpi-v" style="color:#8B6FE8" id="m-kpi-completed"><?=$stat_completed?></div><div class="mkpi-l">Done</div></div>
  </div>

  <div class="m-filters" id="mTabs">
    <button class="m-filter-btn active" onclick="setMobTab('live',this)"><?=ico($iGps,'currentColor',12)?> Live</button>
    <button class="m-filter-btn" onclick="setMobTab('history',this)"><?=ico($iList,'currentColor',12)?> History</button>
  </div>

  <div class="m-search">
    <?=ico($iSearch,'#7A9A8E',16)?>
    <input type="text" id="mSearch" placeholder="Search trips…" oninput="searchTrips(this.value)">
  </div>

  <div id="mob-live">
    <div class="m-trips" id="mob-live-list"><div class="m-empty"><p>Loading active trips…</p></div></div>
  </div>

  <div id="mob-history" style="display:none">
    <div class="m-trips" id="mob-history-list"><div class="m-empty"><p>Loading history…</p></div></div>
  </div>
</div>

<nav class="mob-nav">
  <button class="mn" onclick="location.href='dashboard.php'">
    <div class="mn-ico"><?=ico($iHome,'currentColor',20)?></div>
    <span class="mn-lbl">Home</span>
  </button>
  <button class="mn" onclick="location.href='booking_system.php'">
    <div class="mn-ico"><?=ico($iBook,'currentColor',20)?></div>
    <span class="mn-lbl">Bookings</span>
  </button>
  <button class="mn active">
    <div class="mn-ico"><?=ico($iGps,'currentColor',20)?></div>
    <span class="mn-lbl">GPS</span>
  </button>
  <button class="mn" onclick="location.href='transport_analytics.php'">
    <div class="mn-ico"><?=ico($iBar,'currentColor',20)?></div>
    <span class="mn-lbl">Analytics</span>
  </button>
</nav>

<div class="modal" id="liveModal" onclick="if(event.target===this)closeModal('liveModal')">
  <div class="modal-box modal-wide">
    <div class="modal-hdr">
      <div class="modal-title"><span class="live-dot"></span>Live Tracking — <span id="lm-ref"></span></div>
      <button class="modal-close" onclick="closeModal('liveModal')"><?=ico("<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>", '#4A5568', 14)?></button>
    </div>
    <div class="modal-body">
      <div class="deviation-alert" id="lm-deviation">
        <?=ico($iAlert,'#F07830',16)?> <span id="lm-deviation-text">Route deviation detected!</span>
      </div>
      <div class="stats-grid" id="lm-stats">
        <div class="stat-box"><div class="stat-v" id="lm-speed" style="color:var(--g)">–</div><div class="stat-l">Speed (km/h)</div></div>
        <div class="stat-box"><div class="stat-v" id="lm-duration" style="color:var(--blue)">–</div><div class="stat-l">Duration (min)</div></div>
        <div class="stat-box"><div class="stat-v" id="lm-pts" style="color:var(--purple)">–</div><div class="stat-l">GPS Points</div></div>
        <div class="stat-box"><div class="stat-v" id="lm-status" style="color:var(--orange)">–</div><div class="stat-l">Ride Status</div></div>
      </div>
      <div class="map-box has-loc" id="lm-map" onclick="openOSMDriver()">
        <?=ico($iGps,'#C0D8EE',40)?>
        <p style="font-size:13px;font-weight:700;color:var(--txt2)">Click to open in OpenStreetMap</p>
        <p style="font-size:11px;color:var(--txt3)">Last GPS from driver app</p>
        <div class="map-coords" id="lm-coords"></div>
      </div>
      <div class="breadcrumb-trail"><div class="breadcrumb-fill" id="lm-trail" style="width:0%"></div></div>
      <div class="section-label">Driver Details</div>
      <div class="d-row"><div class="d-label">Driver</div><div class="d-val" id="lm-driver">–</div></div>
      <div class="d-row"><div class="d-label">Phone</div><div class="d-val" id="lm-phone">–</div></div>
      <div class="d-row"><div class="d-label">Driver Status</div><div class="d-val" id="lm-dstatus">–</div></div>
      <div class="d-row"><div class="d-label">Location</div><div class="d-val mono" id="lm-latlong">–</div></div>
      <div class="d-row"><div class="d-label">Updated</div><div class="d-val" id="lm-updated">–</div></div>
      <div class="section-label">Trip Route</div>
      <div class="d-row"><div class="d-label">Pickup</div><div class="d-val" id="lm-pickup">–</div></div>
      <div class="d-row"><div class="d-label">Drop-off</div><div class="d-val" id="lm-dropoff">–</div></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-orange" onclick="checkDeviation()"><?=ico($iAlert,'#fff',14)?> Check Deviation</button>
      <button class="btn btn-success" onclick="completeTrip()"><?=ico($iCheck,'#fff',14)?> Complete Trip</button>
      <button class="btn btn-ghost" onclick="closeModal('liveModal')">Close</button>
    </div>
  </div>
</div>

<div class="modal" id="playbackModal" onclick="if(event.target===this)closeModal('playbackModal')">
  <div class="modal-box modal-xl">
    <div class="modal-hdr">
      <div class="modal-title"><?=ico($iPlay,'#4A5568',15)?> &nbsp;Trip Playback &mdash; <span id="pb-ref"></span></div>
      <button class="modal-close" onclick="closeModal('playbackModal')"><?=ico("<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>",'#4A5568',14)?></button>
    </div>
    <div class="modal-body">

      <div class="stats-grid" style="margin-bottom:14px">
        <div class="stat-box"><div class="stat-v" id="pb-pts" style="color:var(--g)">0</div><div class="stat-l">GPS Points</div></div>
        <div class="stat-box"><div class="stat-v" id="pb-dur" style="color:var(--blue)">&#x2013;</div><div class="stat-l">Duration</div></div>
        <div class="stat-box"><div class="stat-v" id="pb-dist" style="color:var(--purple)">0 km</div><div class="stat-l">Distance</div></div>
        <div class="stat-box"><div class="stat-v" id="pb-spd" style="color:var(--orange)">0 km/h</div><div class="stat-l">Avg Speed</div></div>
      </div>

      <div id="pb-no-gps" style="display:none;background:rgba(234,179,8,.08);border:1.5px solid rgba(234,179,8,.3);border-radius:10px;padding:11px 15px;align-items:center;gap:10px;margin-bottom:12px">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A16207" stroke-width="2" style="flex-shrink:0"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <div>
          <div style="font-size:12.5px;font-weight:700;color:#92400E">No GPS breadcrumb data for this trip</div>
          <div style="font-size:11px;color:#A16207;margin-top:2px">GPS points are only logged when the driver app is active during a trip. Route playback is unavailable.</div>
        </div>
      </div>

      <div id="pb-map" onclick="openOSMPlayback()" style="background:linear-gradient(135deg,#EFF6FF 0%,#DBEAFE 100%);border-radius:12px;height:280px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px;border:1.5px solid #BFDBFE;position:relative;overflow:hidden;margin-bottom:12px;cursor:pointer" onclick="openOSMPlayback()">
        <?=ico($iRoute,'#BFDBFE',40)?>
        <p style="font-size:13px;font-weight:700;color:var(--txt2);margin:4px 0 0;text-align:center">Click to open route in OpenStreetMap</p>
        <p id="pb-map-hint" style="font-size:11px;color:var(--txt3);text-align:center;margin:0">Load a trip to see the GPS breadcrumb trail</p>
        <div id="pb-coords" style="display:none;position:absolute;bottom:10px;left:50%;transform:translateX(-50%);background:rgba(15,30,24,.7);color:#fff;font-family:'DM Mono',monospace;font-size:10.5px;padding:4px 10px;border-radius:20px;white-space:nowrap"></div>
      </div>

      <div class="play-bar" style="display:flex;align-items:center;gap:10px;padding:10px 0">
        <button class="play-btn" id="pbPlayBtn" onclick="event.stopPropagation();togglePlayback()" title="Play / Pause GPS breadcrumb" style="flex-shrink:0">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        </button>
        <input type="range" class="play-slider" id="pbSlider" min="0" max="0" value="0" oninput="seekPlayback(this.value)" style="flex:1">
        <div id="pbTime" style="min-width:68px;text-align:right;font-size:11.5px;font-weight:600;color:var(--txt3);font-family:'DM Mono',monospace">&#x2013; / &#x2013;</div>
      </div>
      <div id="pb-speed-hint" style="display:none;font-size:10.5px;color:var(--txt4);padding-left:2px;margin-top:-4px;margin-bottom:8px">
        Playback: 1 point per 150ms &nbsp;&bull;&nbsp; <span id="pb-progress-label"></span>
      </div>

      <div class="section-label" style="margin-top:10px">Trip Details</div>
      <div class="d-row"><div class="d-label">Booking Ref</div><div class="d-val" id="pb-ref2">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Driver</div><div class="d-val" id="pb-driver">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">License</div><div class="d-val" id="pb-license">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Pickup</div><div class="d-val" id="pb-pickup">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Drop-off</div><div class="d-val" id="pb-dropoff">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Start Time</div><div class="d-val" id="pb-start">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">End Time</div><div class="d-val" id="pb-end">&#x2013;</div></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-info" onclick="checkDeviationPlayback()"><?=ico($iAlert,'#fff',14)?> Check Deviation</button>
      <button class="btn btn-ghost" onclick="exportTripReport()"><?=ico($iDownload,'#3A5248',14)?> Export Report</button>
      <button class="btn btn-ghost" onclick="closeModal('playbackModal')">Close</button>
    </div>
  </div>
</div>

<div class="modal" id="perfModal" onclick="if(event.target===this)closeModal('perfModal')">
  <div class="modal-box">
    <div class="modal-hdr">
      <div class="modal-title"><?=ico($iUser,'#4A5568',15)?> &nbsp;Driver Performance</div>
      <button class="modal-close" onclick="closeModal('perfModal')"><?=ico("<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>", '#4A5568', 14)?></button>
    </div>
    <div class="modal-body">
      <div class="stats-grid">
        <div class="stat-box"><div class="stat-v" id="pf-completed" style="color:var(--g)">–</div><div class="stat-l">Completed</div></div>
        <div class="stat-box"><div class="stat-v" id="pf-cancelled" style="color:var(--red)">–</div><div class="stat-l">Cancelled</div></div>
        <div class="stat-box"><div class="stat-v" id="pf-earnings" style="color:var(--purple)">–</div><div class="stat-l">Earnings (₱)</div></div>
        <div class="stat-box"><div class="stat-v" id="pf-rating" style="color:var(--yellow)">–</div><div class="stat-l">Avg Rating</div></div>
      </div>
      <div class="section-label">Driver Info</div>
      <div class="d-row"><div class="d-label">Name</div><div class="d-val" id="pf-name">–</div></div>
      <div class="d-row"><div class="d-label">Status</div><div class="d-val" id="pf-status">–</div></div>
      <div class="d-row"><div class="d-label">Wallet</div><div class="d-val" id="pf-wallet">–</div></div>
      <div class="d-row"><div class="d-label">Boundary</div><div class="d-val" id="pf-boundary">–</div></div>
      <div class="d-row"><div class="d-label">Ratings</div><div class="d-val" id="pf-ratings">–</div></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('perfModal')">Close</button>
    </div>
  </div>
</div>

<div class="modal" id="statsModal" onclick="if(event.target===this)closeModal('statsModal')">
  <div class="modal-box modal-wide">
    <div class="modal-hdr">
      <div class="modal-title"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#4A5568" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg> &nbsp;Trip Statistics &mdash; <span id="sm-ref"></span></div>
      <button class="modal-close" onclick="closeModal('statsModal')"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4A5568" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <div class="modal-body">

      <div class="stats-grid">
        <div class="stat-box">
          <div class="stat-v" id="sm-dist" style="color:var(--g)">0 km</div>
          <div class="stat-l">Total Distance</div>
        </div>
        <div class="stat-box">
          <div class="stat-v" id="sm-duration" style="color:var(--blue)">&#x2013;</div>
          <div class="stat-l">Trip Duration</div>
        </div>
        <div class="stat-box">
          <div class="stat-v" id="sm-avg-spd" style="color:var(--purple)">0 km/h</div>
          <div class="stat-l">Avg Speed</div>
        </div>
        <div class="stat-box">
          <div class="stat-v" id="sm-max-spd" style="color:var(--orange)">0 km/h</div>
          <div class="stat-l">Max Speed</div>
        </div>
      </div>

      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;margin-bottom:5px">
          <span style="font-size:11px;font-weight:600;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px">Distance Coverage</span>
          <span id="sm-dist-label" style="font-size:11px;font-weight:700;color:var(--gd)"></span>
        </div>
        <div style="height:8px;background:var(--bdr);border-radius:4px;overflow:hidden">
          <div id="sm-dist-bar" style="height:100%;background:linear-gradient(90deg,var(--g),var(--gd));border-radius:4px;width:0%;transition:width .8s ease"></div>
        </div>
        <div style="font-size:10.5px;color:var(--txt4);margin-top:3px">Reference scale: 50 km</div>
      </div>

      <div style="background:var(--surf2);border:1px solid var(--bdr);border-radius:10px;padding:12px 16px;display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:30px;height:30px;border-radius:8px;background:rgba(0,208,132,.12);display:flex;align-items:center;justify-content:center">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#00A86B" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          </div>
          <span style="font-size:13px;font-weight:600;color:var(--txt2)">GPS Points Recorded</span>
        </div>
        <span id="sm-gps-pts" style="font-size:22px;font-weight:800;color:var(--gd)">0</span>
      </div>

      <div class="section-label">Trip Details</div>
      <div class="d-row"><div class="d-label">Customer</div><div class="d-val" id="sm-customer">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Driver</div><div class="d-val" id="sm-driver">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Date</div><div class="d-val" id="sm-date">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Pickup</div><div class="d-val" id="sm-pickup">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Drop-off</div><div class="d-val" id="sm-dropoff">&#x2013;</div></div>
      <div class="d-row"><div class="d-label">Fare</div><div class="d-val" id="sm-fare" style="font-weight:700;color:var(--gd)">&#x2013;</div></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-info" onclick="viewPlaybackFromStats()"><?php echo ico($iPlay,'#fff',14); ?> View Playback</button>
      <button class="btn btn-ghost" onclick="closeModal('statsModal')">Close</button>
    </div>
  </div>
</div>

<div class="loading" id="loading">
  <div class="spin-box">
    <div class="spinner"></div>
    <p style="font-size:13px;font-weight:600;color:var(--txt2)" id="loadingMsg">Loading…</p>
  </div>
</div>

<div class="toast" id="toast"></div>
<div class="m-toast" id="mToast"></div>

<script>

let currentTab       = 'live';
let currentMobTab    = 'live';
let allTrips         = [];
let historyTrips     = [];
let fleetDrivers     = [];
let autoRefreshTimer = null;
let autoRefreshOn    = false;
let currentBookingId = null;
let currentCore1Id   = null;
let pbCoords         = [];
let pbIndex          = 0;
let pbPlaying        = false;
let pbTimer          = null;
let playbackBookingId= null;
let osmLat = null, osmLng = null;
let osmPbCoords      = [];

async function post(action, extra = {}) {
    const fd = new FormData();
    fd.append('action', action);
    Object.entries(extra).forEach(([k,v]) => fd.append(k, v));
    const r = await fetch('', {method:'POST', body: fd});
    return r.json();
}

function showLoading(show, msg='Loading…') {
    document.getElementById('loading').classList.toggle('show', show);
    document.getElementById('loadingMsg').textContent = msg;
}

function toast(msg, type='success') {
    const t = document.getElementById('toast');
    const m = document.getElementById('mToast');
    const ico = type==='success'?'✓':type==='error'?'✕':type==='warn'?'⚠':type==='info'?'ℹ':'•';
    const el = document.createElement('div');
    el.className = `toast-item ${type !== 'success' ? type : ''}`;
    el.innerHTML = `<span>${ico}</span>${msg}`;
    t.appendChild(el);
    const mel = el.cloneNode(true);
    mel.className = `m-toast-item ${type !== 'success' ? type : ''}`;
    m.appendChild(mel);
    setTimeout(()=>{ el.remove(); mel.remove(); }, 4500);
}

function badge(text, cls) {
    return `<span class="badge badge-${cls}">${text}</span>`;
}

function statusBadge(status) {
    const m = {
        'Active':'green','In Progress':'purple','Completed':'blue',
        'Offline':'','Suspended':'red','Pending':'yellow',
        'Requested':'yellow','Accepted':'blue','Cancelled':'red'
    };
    return badge(status, m[status]||'');
}

function fmtTime(ts) {
    if (!ts) return '–';
    return new Date(ts).toLocaleString('en-PH',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
}

function fmtDur(min) {
    if (!min && min!==0) return '–';
    if (min < 60) return `${min}m`;
    return `${Math.floor(min/60)}h ${min%60}m`;
}

function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function setTab(tab, btn) {
    currentTab = tab;
    document.querySelectorAll('#mainTabs .tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-live').style.display    = tab==='live'    ? '' : 'none';
    document.getElementById('tab-fleet').style.display   = tab==='fleet'   ? '' : 'none';
    document.getElementById('tab-history').style.display = tab==='history' ? '' : 'none';
    if (tab==='live')    loadLive();
    if (tab==='fleet')   loadFleetMap();
    if (tab==='history') loadHistory();
}

function setMobTab(tab, btn) {
    currentMobTab = tab;
    document.querySelectorAll('#mTabs .m-filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('mob-live').style.display    = tab==='live'    ? '' : 'none';
    document.getElementById('mob-history').style.display = tab==='history' ? '' : 'none';
    if (tab==='live')    loadLive();
    if (tab==='history') loadHistory();
}

async function loadLive() {
    try {
        const res = await post('get_active_trips');
        if (!res.success) { toast(res.message||'Failed to load', 'error'); return; }
        allTrips = res.trips || [];
        document.getElementById('badge-live').textContent = allTrips.length;
        document.getElementById('kpi-active').textContent  = allTrips.length;
        document.getElementById('m-kpi-active').textContent= allTrips.length;
        document.getElementById('last-refresh').textContent = 'Updated: ' + new Date().toLocaleTimeString('en-PH');
        renderLive(allTrips);
        renderMobLive(allTrips);
    } catch(e) { toast('Network error', 'error'); }
}

function renderLive(trips) {
    const g = document.getElementById('live-grid');
    const gpsIco = `<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#C0D8EE" stroke-width="1.5"><path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/></svg>`;
    if (!trips.length) {
        g.style.gridTemplateColumns = '1fr';
        g.innerHTML = `<div style="text-align:center;padding:60px 20px;color:var(--txt3)">${gpsIco}<p style="margin-top:16px;font-size:14px;font-weight:600">No active trips</p><p style="font-size:12px;margin-top:6px">Active trips will appear here with live GPS data</p></div>`;
        return;
    }
    g.style.gridTemplateColumns = '';
    g.innerHTML = trips.map(t => {
        const hasLoc = t.current_lat && t.current_lng;
        const mapContent = hasLoc
            ? `<div class="tc-map has-loc" onclick="viewLive(${t.booking_id},'${t.booking_reference}')">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#00A86B" stroke-width="2"><path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/></svg>
                <p style="font-size:12px;font-weight:700;color:var(--gd)"><span class="live-dot"></span>GPS Active</p>
                <p style="font-size:10.5px;color:var(--txt3)">${Number(t.current_lat).toFixed(4)}, ${Number(t.current_lng).toFixed(4)}</p>
               </div>`
            : `<div class="tc-map">
                ${gpsIco}<p style="font-size:11.5px;color:var(--txt3)">Awaiting GPS signal</p>
               </div>`;
        return `
        <div class="trip-card">
          <div class="tc-head">
            <div class="tc-ref">${t.booking_reference}</div>
            ${statusBadge('In Progress')}
          </div>
          <div class="tc-body">
            <div class="tc-row"><div class="tc-lbl">Customer</div><div class="tc-val">${t.customer_name}</div></div>
            <div class="tc-row"><div class="tc-lbl">Driver</div><div class="tc-val">${t.driver_name||'Unassigned'}</div></div>
            <div class="tc-row"><div class="tc-lbl">Phone</div><div class="tc-val">${t.driver_phone||'–'}</div></div>
            <div class="tc-row"><div class="tc-lbl">Service</div><div class="tc-val">${t.service_name}</div></div>
            <div class="tc-row"><div class="tc-lbl">Pickup</div><div class="tc-val" title="${t.pickup||''}">${(t.pickup||'N/A').substring(0,40)}</div></div>
            <div class="tc-row"><div class="tc-lbl">Drop-off</div><div class="tc-val" title="${t.dropoff||''}">${(t.dropoff||'N/A').substring(0,40)}</div></div>
            <div class="tc-row"><div class="tc-lbl">Duration</div><div class="tc-val">${fmtDur(t.duration_minutes)} elapsed</div></div>
          </div>
          ${mapContent}
          <div class="tc-foot" style="margin:10px 0 0">
            <button class="btn btn-info btn-sm" onclick="viewLive(${t.booking_id},'${t.booking_reference}')">${icoSVG('eye')} Live</button>
            <button class="btn btn-purple btn-sm" onclick="viewPerformance(${t.core1_driver_id})">${icoSVG('user')} Driver</button>
            <button class="btn btn-orange btn-sm" onclick="checkDeviation(${t.booking_id})">${icoSVG('alert')} Deviation</button>
            <button class="btn btn-success btn-sm" onclick="completeTripDirect(${t.booking_id})">${icoSVG('check')} Complete</button>
          </div>
        </div>`;
    }).join('');
}

function renderMobLive(trips) {
    const list = document.getElementById('mob-live-list');
    if (!trips.length) { list.innerHTML = `<div class="m-empty"><p>No active trips</p></div>`; return; }
    list.innerHTML = trips.map(t => `
      <div class="m-trip">
        <div class="mt-head"><div class="mt-ref">${t.booking_reference}</div>${statusBadge('In Progress')}</div>
        <div class="mt-body">
          <div class="mt-row"><div class="mt-lbl">Customer</div><div class="mt-val">${t.customer_name}</div></div>
          <div class="mt-row"><div class="mt-lbl">Driver</div><div class="mt-val">${t.driver_name||'–'}</div></div>
          <div class="mt-row"><div class="mt-lbl">Duration</div><div class="mt-val">${fmtDur(t.duration_minutes)}</div></div>
          <div class="mt-row"><div class="mt-lbl">GPS</div><div class="mt-val">${t.current_lat ? `${Number(t.current_lat).toFixed(4)}, ${Number(t.current_lng).toFixed(4)}` : 'No GPS'}</div></div>
        </div>
        <div class="mt-foot">
          <button class="btn btn-info btn-sm" onclick="viewLive(${t.booking_id},'${t.booking_reference}')">Live</button>
          <button class="btn btn-success btn-sm" onclick="completeTripDirect(${t.booking_id})">Complete</button>
        </div>
      </div>`).join('');
}

async function viewLive(bookingId, ref) {
    currentBookingId = bookingId;
    showLoading(true, 'Loading live location…');
    try {
        const res = await post('get_live_location', {booking_id: bookingId});
        showLoading(false);
        document.getElementById('lm-ref').textContent        = ref || 'Trip';
        document.getElementById('lm-driver').textContent     = res.driver_name    || '–';
        document.getElementById('lm-phone').textContent      = res.driver_phone   || '–';
        document.getElementById('lm-dstatus').innerHTML      = res.driver_status  ? statusBadge(res.driver_status) : '–';
        document.getElementById('lm-pickup').textContent     = res.pickup         || '–';
        document.getElementById('lm-dropoff').textContent    = res.dropoff        || '–';
        document.getElementById('lm-status').textContent     = res.ride_status    || '–';
        document.getElementById('lm-pts').textContent        = res.gps_points_logged || 0;

        if (res.latitude && res.longitude) {
            osmLat = res.latitude; osmLng = res.longitude;
            document.getElementById('lm-latlong').textContent  = `${Number(res.latitude).toFixed(6)}, ${Number(res.longitude).toFixed(6)}`;
            document.getElementById('lm-updated').textContent  = res.location_updated_at ? fmtTime(res.location_updated_at) : 'Just now';
            document.getElementById('lm-coords').textContent   = `${Number(res.latitude).toFixed(4)}, ${Number(res.longitude).toFixed(4)}`;
            document.getElementById('lm-map').querySelector('p').textContent = 'Click to open in OpenStreetMap';
        } else {
            osmLat = null; osmLng = null;
            document.getElementById('lm-latlong').textContent = 'No GPS data from driver';
            document.getElementById('lm-coords').textContent  = '';
            document.getElementById('lm-map').querySelector('p').textContent = 'Driver GPS not yet available';
        }

        const pct = Math.min((res.gps_points_logged||0)/100*100, 100);
        document.getElementById('lm-trail').style.width = pct + '%';
        document.getElementById('liveModal').classList.add('open');
    } catch(e) { showLoading(false); toast('Failed to load live data', 'error'); }
}

function openOSMDriver() {
    if (!osmLat || !osmLng) { toast('No GPS coordinates available', 'warn'); return; }
    window.open(`https://www.openstreetmap.org/?mlat=${osmLat}&mlon=${osmLng}#map=16/${osmLat}/${osmLng}`, '_blank');
}

async function checkDeviation(bookingId) {
    const bid = bookingId || currentBookingId;
    if (!bid) return;
    showLoading(true, 'Analyzing route…');
    try {
        const res = await post('check_route_deviation', {booking_id: bid});
        showLoading(false);
        if (!res.success) { toast(res.message, 'error'); return; }
        const msg = `Distance: ${res.total_distance_km}km | Straight: ${res.straight_line_km||res.straight_line}km | Deviation: ${res.deviation_pct}%`;
        if (res.is_deviated) {
            document.getElementById('lm-deviation').classList.add('show');
            document.getElementById('lm-deviation-text').textContent = `⚠ Route deviation detected! ${res.deviation_pct}% over expected route. ${msg}`;
            document.getElementById('kpi-deviations').textContent = parseInt(document.getElementById('kpi-deviations').textContent||0)+1;
            toast(`Route deviation: ${res.deviation_pct}% detour detected`, 'warn');
        } else {
            toast(`Route OK — ${res.deviation_pct}% deviation (within normal)`, 'success');
        }
    } catch(e) { showLoading(false); toast('Analysis failed', 'error'); }
}

async function completeTrip() {
    if (!currentBookingId || !confirm('Mark this trip as completed and save GPS history?')) return;
    completeTripDirect(currentBookingId);
}

async function completeTripDirect(bookingId) {
    if (!confirm('Mark this trip as completed?')) return;
    showLoading(true, 'Completing trip…');
    try {
        const res = await post('end_tracking', {booking_id: bookingId});
        showLoading(false);
        if (res.success) {
            toast(`Trip completed! ${res.total_points} GPS points saved`, 'success');
            closeModal('liveModal');
            loadLive();
        } else toast(res.message||'Failed', 'error');
    } catch(e) { showLoading(false); toast('Error', 'error'); }
}

async function viewPerformance(core1Id) {
    if (!core1Id) { toast('Driver data not available', 'warn'); return; }
    currentCore1Id = core1Id;
    showLoading(true, 'Loading driver data…');
    try {
        const res = await post('get_driver_performance', {core1_driver_id: core1Id});
        showLoading(false);
        if (!res.success) { toast(res.message, 'error'); return; }
        document.getElementById('pf-name').textContent      = res.driver_name    || '–';
        document.getElementById('pf-status').innerHTML      = statusBadge(res.status);
        document.getElementById('pf-wallet').textContent    = '₱' + Number(res.wallet_balance||0).toLocaleString();
        document.getElementById('pf-boundary').textContent  = '₱' + Number(res.boundary_amount||0).toLocaleString();
        document.getElementById('pf-completed').textContent = res.trips_completed || 0;
        document.getElementById('pf-cancelled').textContent = res.trips_cancelled || 0;
        document.getElementById('pf-earnings').textContent  = '₱' + Number(res.total_earnings||0).toLocaleString();
        document.getElementById('pf-rating').textContent    = res.avg_rating ? res.avg_rating + ' ★' : 'N/A';
        document.getElementById('pf-ratings').textContent   = `${res.rating_count||0} ratings`;
        document.getElementById('perfModal').classList.add('open');
    } catch(e) { showLoading(false); toast('Error loading performance', 'error'); }
}

async function loadFleetMap() {
    showLoading(true, 'Loading fleet locations…');
    try {
        const res = await post('get_all_drivers_location');
        showLoading(false);
        if (!res.success) { toast(res.message, 'error'); return; }
        fleetDrivers = res.drivers || [];
        document.getElementById('badge-fleet').textContent = fleetDrivers.length;
        renderFleetTable(fleetDrivers);

        if (fleetDrivers.length) {
            const d = fleetDrivers[0];
            document.getElementById('fleet-coords').textContent = `${fleetDrivers.length} drivers with GPS`;
            document.getElementById('fleet-coords').style.display = '';
        }
    } catch(e) { showLoading(false); toast('Error loading fleet', 'error'); }
}

function renderFleetTable(drivers) {
    const tbody = document.getElementById('fleetTbody');
    if (!drivers.length) { tbody.innerHTML = `<tr class="empty-row"><td colspan="6">No drivers with active GPS</td></tr>`; return; }
    tbody.innerHTML = drivers.map(d => `
      <tr>
        <td><div class="td-ref">${d.driver_name}</div><div class="td-sub">${d.phone||'–'}</div></td>
        <td>${statusBadge(d.status||'Unknown')}</td>
        <td><div>${d.vehicle_model||'–'}</div><div class="td-sub mono">${d.plate_number||'–'}</div></td>
        <td class="mono" style="font-size:11.5px">${d.current_lat ? `${Number(d.current_lat).toFixed(5)}, ${Number(d.current_lng).toFixed(5)}` : '–'}</td>
        <td style="font-size:11.5px">${d.location_updated_at ? fmtTime(d.location_updated_at) : '–'}</td>
        <td>
          <button class="btn btn-info btn-sm" onclick="openOSMSingle(${d.current_lat},${d.current_lng})">${icoSVG('eye')} Map</button>
        </td>
      </tr>`).join('');
}

function openOSMFleet() {
    if (!fleetDrivers.length) { toast('No GPS data to display', 'warn'); return; }
    const d = fleetDrivers[0];
    if (d.current_lat && d.current_lng) {
        window.open(`https://www.openstreetmap.org/?mlat=${d.current_lat}&mlon=${d.current_lng}#map=13/${d.current_lat}/${d.current_lng}`, '_blank');
    }
}

function openOSMSingle(lat, lng) {
    if (!lat || !lng) { toast('No GPS available', 'warn'); return; }
    window.open(`https://www.openstreetmap.org/?mlat=${lat}&mlon=${lng}#map=16/${lat}/${lng}`, '_blank');
}

async function loadHistory() {
    showLoading(true, 'Loading trip history…');
    try {
        const res = await post('get_completed_trips');
        showLoading(false);
        if (!res.success) { toast(res.message, 'error'); return; }
        historyTrips = res.trips || [];
        document.getElementById('badge-history').textContent = historyTrips.length;
        document.getElementById('kpi-completed').textContent = historyTrips.length;
        document.getElementById('m-kpi-completed').textContent = historyTrips.length;
        renderHistoryTable(historyTrips);
        renderMobHistory(historyTrips);
    } catch(e) { showLoading(false); toast('Error loading history', 'error'); }
}

function renderHistoryTable(trips) {
    const tbody = document.getElementById('historyTbody');
    if (!trips.length) { tbody.innerHTML = `<tr class="empty-row"><td colspan="9">No completed trips yet</td></tr>`; return; }
    tbody.innerHTML = trips.map(t => `
      <tr>
        <td><div class="td-ref">${t.booking_reference}</div><div class="td-sub">${t.service_name}</div></td>
        <td><div>${t.customer_name}</div><div class="td-sub">${t.customer_phone||'–'}</div></td>
        <td><div>${t.driver_name}</div><div class="td-sub mono" style="font-size:10px">${t.driver_license||'–'}</div></td>
        <td style="max-width:180px">
          <div class="trunc" style="font-size:11.5px" title="${t.pickup||''}">${(t.pickup||'N/A').substring(0,30)}</div>
          <div class="td-sub trunc" title="${t.dropoff||''}">${(t.dropoff||'N/A').substring(0,30)}</div>
        </td>
        <td style="font-size:11.5px">${t.booking_date ? new Date(t.booking_date).toLocaleDateString('en-PH',{month:'short',day:'numeric',year:'numeric'}) : '–'}</td>
        <td style="font-size:12px;font-weight:600">${fmtDur(t.duration_minutes)}</td>
        <td>${t.gps_points > 0 ? `<span style="color:var(--gd);font-weight:700">${t.gps_points}</span>` : '<span style="color:var(--txt3)">0</span>'}</td>
        <td style="font-weight:700;color:var(--gd)">₱${Number(t.total_amount||0).toLocaleString()}</td>
        <td>
          <div style="display:flex;flex-direction:column;gap:4px;min-width:100px">
            <button class="btn btn-info btn-sm" onclick="viewPlayback(${t.booking_id},'${t.booking_reference}')">${icoSVG('play')} Playback</button>
            <button class="btn btn-ghost btn-sm" onclick="viewTripStats(${t.booking_id})">${icoSVG('chart')} Stats</button>
          </div>
        </td>
      </tr>`).join('');
}

function renderMobHistory(trips) {
    const list = document.getElementById('mob-history-list');
    if (!trips.length) { list.innerHTML = `<div class="m-empty"><p>No completed trips</p></div>`; return; }
    list.innerHTML = trips.map(t => `
      <div class="m-trip">
        <div class="mt-head"><div class="mt-ref">${t.booking_reference}</div>${badge('Completed','blue')}</div>
        <div class="mt-body">
          <div class="mt-row"><div class="mt-lbl">Customer</div><div class="mt-val">${t.customer_name}</div></div>
          <div class="mt-row"><div class="mt-lbl">Driver</div><div class="mt-val">${t.driver_name}</div></div>
          <div class="mt-row"><div class="mt-lbl">Duration</div><div class="mt-val">${fmtDur(t.duration_minutes)}</div></div>
          <div class="mt-row"><div class="mt-lbl">GPS Pts</div><div class="mt-val">${t.gps_points||0}</div></div>
          <div class="mt-row"><div class="mt-lbl">Fare</div><div class="mt-val" style="color:var(--gd);font-weight:700">₱${Number(t.total_amount||0).toLocaleString()}</div></div>
        </div>
        <div class="mt-foot">
          <button class="btn btn-info btn-sm" onclick="viewPlayback(${t.booking_id},'${t.booking_reference}')">Playback</button>
        </div>
      </div>`).join('');
}

async function viewPlayback(bookingId, ref) {
    playbackBookingId = bookingId;
    pbCoords = []; pbIndex = 0; pbPlaying = false;
    clearInterval(pbTimer);
    showLoading(true, 'Loading playback data…');
    try {
        const [pbRes, statsRes] = await Promise.all([
            post('get_playback_data', {booking_id: bookingId}),
            post('get_trip_stats',    {booking_id: bookingId}),
        ]);
        showLoading(false);
        document.getElementById('pb-ref').textContent   = ref || pbRes.booking_reference || 'Trip';
        document.getElementById('pb-ref2').textContent  = pbRes.booking_reference || '–';
        document.getElementById('pb-driver').textContent= pbRes.driver_name        || '–';
        document.getElementById('pb-license').textContent= pbRes.driver_license     || '–';
        document.getElementById('pb-pickup').textContent = pbRes.pickup             || '–';
        document.getElementById('pb-dropoff').textContent= pbRes.dropoff            || '–';
        document.getElementById('pb-start').textContent  = fmtTime(pbRes.start_time);
        document.getElementById('pb-end').textContent    = fmtTime(pbRes.end_time);
        document.getElementById('pb-pts').textContent    = pbRes.total_points || 0;

        if (statsRes.success) {
            const dur = statsRes.duration_minutes || (pbRes.start_time && pbRes.end_time ? Math.round((new Date(pbRes.end_time)-new Date(pbRes.start_time))/60000) : '–');
            document.getElementById('pb-dur').textContent  = fmtDur(dur);
            document.getElementById('pb-dist').textContent = (statsRes.total_distance_km||0) + ' km';
            document.getElementById('pb-spd').textContent  = (statsRes.avg_speed||0) + ' km/h';
        }
        pbCoords = pbRes.coordinates || [];
        osmPbCoords = pbCoords;

        const hasGPS = pbCoords.length > 0;
        const slider = document.getElementById('pbSlider');
        const noGpsEl = document.getElementById('pb-no-gps');
        const mapBox = document.getElementById('pb-map');
        const speedHint = document.getElementById('pb-speed-hint');
        const pbPlayBtn = document.getElementById('pbPlayBtn');

        if (hasGPS) {

            slider.max = pbCoords.length - 1;
            slider.value = 0;
            slider.disabled = false;
            if (noGpsEl) noGpsEl.style.display = 'none';
            if (mapBox) mapBox.style.cursor = 'pointer';
            document.getElementById('pb-map-hint').textContent = `${pbCoords.length} GPS points — click map to open in OpenStreetMap`;
            document.getElementById('pb-map-hint').style.color = '';
            document.getElementById('pb-map-hint').style.fontWeight = '';
            if (pbPlayBtn) pbPlayBtn.disabled = false;
        } else {

            slider.max = 0;
            slider.value = 0;
            slider.disabled = true;
            if (noGpsEl) noGpsEl.style.display = 'flex';
            if (mapBox) mapBox.style.cursor = 'default';
            document.getElementById('pb-map-hint').textContent = 'No GPS breadcrumb data recorded for this trip';
            document.getElementById('pb-map-hint').style.color = '#9A6A00';
            if (pbPlayBtn) pbPlayBtn.disabled = false; 
        }

        document.getElementById('pbTime').textContent = hasGPS ? `1 / ${pbCoords.length}` : '– / –';
        if (speedHint) speedHint.style.display = 'none';
        updatePbDisplay(0);
        document.getElementById('playbackModal').classList.add('open');
    } catch(e) { showLoading(false); toast('Failed to load playback', 'error'); }
}

function updatePbDisplay(idx) {
    if (!pbCoords.length) {
        document.getElementById('pbTime').textContent = '– / –';
        return;
    }
    const c = pbCoords[Math.min(idx, pbCoords.length-1)];
    if (c && c.lat && c.lng) {
        const coordEl = document.getElementById('pb-coords');
        if (coordEl) {
            coordEl.style.display = '';
            coordEl.textContent = `${Number(c.lat).toFixed(5)}, ${Number(c.lng).toFixed(5)} • Pt ${idx+1}/${pbCoords.length}`;
        }
    }
    document.getElementById('pbTime').textContent = `${idx+1} / ${pbCoords.length}`;
    document.getElementById('pbSlider').value = idx;

    const progLabel = document.getElementById('pb-progress-label');
    if (progLabel) progLabel.textContent = `Point ${idx+1} of ${pbCoords.length}`;
}

function togglePlayback() {
    if (!pbCoords.length) {

        const hint = document.getElementById('pb-map-hint');
        if (hint) {
            hint.textContent = 'No GPS breadcrumb data recorded for this trip.';
            hint.style.color = '#C05000';
            hint.style.fontWeight = '600';
        }

        const btn = document.getElementById('pbPlayBtn');
        if (btn) {
            btn.style.background = '#dc2626';
            setTimeout(() => { btn.style.background = ''; }, 600);
        }
        return;
    }
    pbPlaying = !pbPlaying;
    const btn = document.getElementById('pbPlayBtn');
    const pauseSVG = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`;
    const playSVG  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
    btn.innerHTML = pbPlaying ? pauseSVG : playSVG;

    const speedHint = document.getElementById('pb-speed-hint');
    if (speedHint) speedHint.style.display = pbPlaying ? '' : 'none';

    if (pbPlaying) {
        if (pbIndex >= pbCoords.length - 1) pbIndex = 0;
        pbTimer = setInterval(() => {
            pbIndex++;
            if (pbIndex >= pbCoords.length) {
                pbIndex = pbCoords.length - 1;
                pbPlaying = false;
                clearInterval(pbTimer);
                btn.innerHTML = playSVG;
                if (speedHint) speedHint.style.display = 'none';
                return;
            }
            updatePbDisplay(pbIndex);
        }, 150);
    } else {
        clearInterval(pbTimer);
    }
}

function seekPlayback(val) { pbIndex = parseInt(val); updatePbDisplay(pbIndex); }

function openOSMPlayback() {
    if (!osmPbCoords || !osmPbCoords.length) {

        const hint = document.getElementById('pb-map-hint');
        if (hint) {
            hint.textContent = 'No GPS coordinates available to open in map.';
            hint.style.color = '#C05000';
        }
        return;
    }
    const c = osmPbCoords[pbIndex] || osmPbCoords[0];
    if (c && c.lat && c.lng) {
        window.open(`https://www.openstreetmap.org/?mlat=${c.lat}&mlon=${c.lng}#map=15/${c.lat}/${c.lng}`, '_blank');
    }
}

async function checkDeviationPlayback() {
    if (!playbackBookingId) return;
    await checkDeviation(playbackBookingId);
}

async function viewTripStats(bookingId) {
    const trip = historyTrips.find(t => t.booking_id == bookingId) || {};
    showLoading(true, 'Loading trip stats…');
    try {
        const res = await post('get_trip_stats', {booking_id: bookingId});
        showLoading(false);
        if (!res.success) { toast('Failed to load stats', 'error'); return; }

        document.getElementById('sm-ref').textContent      = trip.booking_reference || ('Booking #' + bookingId);
        document.getElementById('sm-customer').textContent = trip.customer_name     || '–';
        document.getElementById('sm-driver').textContent   = trip.driver_name       || '–';
        document.getElementById('sm-date').textContent     = trip.booking_date ? new Date(trip.booking_date).toLocaleDateString('en-PH',{month:'long',day:'numeric',year:'numeric'}) : '–';
        document.getElementById('sm-pickup').textContent   = trip.pickup            || '–';
        document.getElementById('sm-dropoff').textContent  = trip.dropoff           || '–';
        document.getElementById('sm-fare').textContent     = '₱' + Number(trip.total_amount||0).toLocaleString();
        document.getElementById('sm-dist').textContent     = (res.total_distance_km || 0) + ' km';
        document.getElementById('sm-duration').textContent = fmtDur(res.duration_minutes);
        document.getElementById('sm-avg-spd').textContent  = (res.avg_speed || 0) + ' km/h';
        document.getElementById('sm-max-spd').textContent  = (res.max_speed || 0) + ' km/h';
        document.getElementById('sm-gps-pts').textContent  = res.gps_points || 0;
        const distPct = Math.min(((res.total_distance_km||0)/50)*100, 100);
        document.getElementById('sm-dist-bar').style.width = distPct + '%';

        document.getElementById('statsModal').classList.add('open');

        const smDistLabel = document.getElementById('sm-dist-label');
        if (smDistLabel) smDistLabel.textContent = (res.total_distance_km || 0) + ' km';

        statsCurrentBookingId = bookingId;
    } catch(e) { showLoading(false); toast('Error loading stats', 'error'); }
}

let statsCurrentBookingId = null;
function viewPlaybackFromStats() {
    closeModal('statsModal');
    const trip = historyTrips.find(t => t.booking_id == statsCurrentBookingId) || {};
    if (statsCurrentBookingId) viewPlayback(statsCurrentBookingId, trip.booking_reference || '');
}

function exportHistory() {
    const trips = currentTab==='history' ? historyTrips : allTrips;
    if (!trips.length) { toast('No data to export', 'warn'); return; }
    const rows = [['Reference','Customer','Driver','Pickup','Dropoff','Date','Duration','GPS Points','Fare']];
    trips.forEach(t => rows.push([
        t.booking_reference||'', t.customer_name||'', t.driver_name||'',
        t.pickup||'', t.dropoff||'', t.booking_date||'',
        t.duration_minutes||'', t.gps_points||'', t.total_amount||''
    ]));
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = `gps_trips_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    toast('Exported to CSV', 'success');
}

function exportTripReport() {
    toast('Trip report export — feature uses browser print dialog', 'info');
    setTimeout(() => window.print(), 500);
}

function searchTrips(q) {
    const query = q.toLowerCase().trim();
    if (currentTab === 'live' || currentMobTab === 'live') {
        const filtered = allTrips.filter(t =>
            (t.booking_reference||'').toLowerCase().includes(query) ||
            (t.customer_name||'').toLowerCase().includes(query) ||
            (t.driver_name||'').toLowerCase().includes(query) ||
            (t.pickup||'').toLowerCase().includes(query) ||
            (t.dropoff||'').toLowerCase().includes(query)
        );
        renderLive(filtered); renderMobLive(filtered);
    } else {
        const filtered = historyTrips.filter(t =>
            (t.booking_reference||'').toLowerCase().includes(query) ||
            (t.customer_name||'').toLowerCase().includes(query) ||
            (t.driver_name||'').toLowerCase().includes(query) ||
            (t.pickup||'').toLowerCase().includes(query) ||
            (t.dropoff||'').toLowerCase().includes(query)
        );
        renderHistoryTable(filtered); renderMobHistory(filtered);
    }
}

function toggleAutoRefresh() {
    autoRefreshOn = !autoRefreshOn;
    const btn = document.getElementById('autoRefreshBtn');
    if (autoRefreshOn) {
        btn.style.background = 'rgba(0,208,132,.15)';
        btn.style.borderColor = 'rgba(0,208,132,.3)';
        btn.style.color = 'var(--gd)';
        autoRefreshTimer = setInterval(() => {
            if (currentTab==='live') loadLive();
            if (currentTab==='fleet') loadFleetMap();
        }, 15000);
        toast('Auto-refresh ON (15s)', 'success');
    } else {
        btn.style = '';
        clearInterval(autoRefreshTimer);
        toast('Auto-refresh OFF', 'info');
    }
}

function fullRefresh() {
    if (currentTab==='live')    loadLive();
    if (currentTab==='fleet')   loadFleetMap();
    if (currentTab==='history') loadHistory();
    if (currentMobTab==='live') loadLive();
    if (currentMobTab==='history') loadHistory();
}

function icoSVG(name) {
    const p = {
        eye:"<path d='M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z'/><circle cx='12' cy='12' r='3'/>",
        play:"<polygon points='5 3 19 12 5 21 5 3'/>",
        chart:"<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>",
        user:"<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>",
        alert:"<path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'/><line x1='12' y1='9' x2='12' y2='13'/><line x1='12' y1='17' x2='12.01' y2='17'/>",
        check:"<polyline points='20 6 9 17 4 12'/>",
    };
    return `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p[name]||''}</svg>`;
}

window.addEventListener('load', () => {
    loadLive();

    setInterval(() => {
        const d = new Date();
        const el = document.getElementById('liveDate');
        if (el) el.textContent = d.toLocaleDateString('en-PH',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
    }, 60000);
});
</script>
<?php if(file_exists(__DIR__ . '/chat_widget.php')) include __DIR__ . '/chat_widget.php'; ?>
</body>
</html>