<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
        ],
    ]);
    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode < 200 || $httpCode >= 300) return [];
    $data = json_decode($resp, true);
    if (!is_array($data) || isset($data['message'])) return [];
    return array_values(array_filter($data, fn($r) => is_array($r)));
}

function sb_patch(string $table, array $filters, array $body): bool {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($body),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=minimal',
        ],
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 300;
}

function sb_post(string $table, array $body): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($body),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($resp, true);
    return is_array($data) ? $data : [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    try {
        switch ($_POST['action']) {
            case 'update_payment_status':
                $pid    = (int)$_POST['payment_id'];
                $status = $_POST['status'];
                $ok     = sb_patch('core2_payment_authorization', ['payment_id' => 'eq.'.$pid], ['payment_status' => $status, 'updated_at' => date('c')]);
                echo json_encode(['success' => $ok, 'message' => $ok ? 'Payment status updated' : 'Update failed']);
                break;

            case 'process_refund':
                $pid    = (int)$_POST['payment_id'];
                $bid    = (int)$_POST['booking_id'];
                $amount = (float)$_POST['amount'];
                $ok1    = sb_patch('core2_payment_authorization', ['payment_id' => 'eq.'.$pid], ['payment_status' => 'Refunded', 'updated_at' => date('c')]);
                $txn    = sb_post('core2_transaction_processing', [
                    'payment_id'         => $pid,
                    'booking_id'         => $bid,
                    'transaction_type'   => 'Refund',
                    'transaction_status' => 'Completed',
                    'amount'             => $amount,
                    'transaction_time'   => date('c'),
                    'completed_at'       => date('c'),
                ]);
                echo json_encode(['success' => $ok1, 'message' => $ok1 ? 'Refund processed successfully' : 'Refund failed']);
                break;

            case 'update_fare_config':
                $base_fare    = (float)$_POST['base_fare'];
                $distance_rate= (float)$_POST['distance_rate'];
                $surge        = (float)$_POST['surge_multiplier'];

                $ok = sb_patch('core2_services', ['status' => 'eq.Active'], ['unit_price' => $base_fare]);
                echo json_encode(['success' => true, 'message' => 'Fare configuration updated. Base: ₱'.number_format($base_fare,2).', Rate: ₱'.number_format($distance_rate,2).'/km, Surge: '.$surge.'x']);
                break;

            case 'get_payment_detail':
                $pid = (int)$_POST['payment_id'];
                $pay = sb_get('core2_payment_authorization', ['payment_id' => 'eq.'.$pid, 'select' => '*']);
                if (!empty($pay)) {
                    $p = $pay[0];
                    $bk = sb_get('core2_bookings', ['booking_id' => 'eq.'.$p['booking_id'], 'select' => 'booking_reference,total_amount,booking_status,customer_id']);
                    $p['booking_reference'] = $bk[0]['booking_reference'] ?? '—';
                    $p['booking_status']    = $bk[0]['booking_status']    ?? '—';
                    if (!empty($bk[0]['customer_id'])) {
                        $cust = sb_get('core2_customers', ['customer_id' => 'eq.'.$bk[0]['customer_id'], 'select' => 'name,phone,email']);
                        $p['customer_name']  = $cust[0]['name']  ?? '—';
                        $p['customer_phone'] = $cust[0]['phone'] ?? '—';
                        $p['customer_email'] = $cust[0]['email'] ?? '—';
                    }
                    $txns = sb_get('core2_transaction_processing', ['payment_id' => 'eq.'.$pid, 'select' => 'transaction_id,transaction_type,transaction_status,amount,transaction_time', 'order' => 'transaction_time.desc']);
                    echo json_encode(['success' => true, 'payment' => $p, 'transactions' => $txns]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Payment not found']);
                }
                break;

            default:
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Shared cache + parallel helper
if (!function_exists('appCache')) { require_once __DIR__ . '/../config/cache.php'; }

// Cache all 4 queries for 5 minutes
$_pfData = appCache('payment_fares_pageload', 300, function() {
    return sbParallel([
        'pay'=>['t'=>'core2_payment_authorization','p'=>['select'=>'payment_id,booking_id,payment_method,payment_status,amount,currency,authorization_code,transaction_reference,payment_gateway,authorized_at,created_at,updated_at','order'=>'created_at.desc','limit'=>'200']],
        'far'=>['t'=>'core2_fare_computation','p'=>['select'=>'fare_id,booking_id,base_fare,distance_km,distance_rate,surge_multiplier,additional_charges,discount,total_fare,currency,computation_timestamp','order'=>'computation_timestamp.desc','limit'=>'100']],
        'txn'=>['t'=>'core2_transaction_processing','p'=>['select'=>'transaction_id,payment_id,booking_id,transaction_time,transaction_type,transaction_status,amount,completed_at','order'=>'transaction_time.desc','limit'=>'100']],
        'svc'=>['t'=>'core2_services','p'=>['select'=>'service_id,service_name,unit_price,status','order'=>'service_name.asc']],
    ]);
});
$payments=$_pfData['pay']??[];
$fares=$_pfData['far']??[];
$transactions=$_pfData['txn']??[];
$services=$_pfData['svc']??[];

$total_captured = array_sum(array_map(fn($p) => $p['payment_status']==='Captured' ? (float)($p['amount']??0) : 0, $payments));
$total_pending  = array_sum(array_map(fn($p) => $p['payment_status']==='Pending'  ? (float)($p['amount']??0) : 0, $payments));
$total_refunded = array_sum(array_map(fn($p) => $p['payment_status']==='Refunded' ? (float)($p['amount']??0) : 0, $payments));
$count_captured = count(array_filter($payments, fn($p) => ($p['payment_status']??'')==='Captured'));
$count_pending  = count(array_filter($payments, fn($p) => ($p['payment_status']??'')==='Pending'));
$count_failed   = count(array_filter($payments, fn($p) => ($p['payment_status']??'')==='Failed'));
$count_refunded = count(array_filter($payments, fn($p) => ($p['payment_status']??'')==='Refunded'));
$avg_fare       = count($fares) > 0 ? array_sum(array_map(fn($f) => (float)($f['total_fare']??0), $fares)) / count($fares) : 0;
$total_revenue  = $total_captured;

$userName    = htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin');
$userInitial = strtoupper(substr($userName, 0, 1));

function payBadge(string $s): string {
    $map = [
        'Captured'   => 'badge-green',
        'Authorized' => 'badge-blue',
        'Pending'    => 'badge-yellow',
        'Failed'     => 'badge-red',
        'Refunded'   => 'badge-purple',
        'Cancelled'  => 'badge-red',
    ];
    return $map[$s] ?? 'badge-yellow';
}
function txBadge(string $s): string {
    $map = [
        'Completed'  => 'badge-green',
        'Processing' => 'badge-blue',
        'Initiated'  => 'badge-yellow',
        'Failed'     => 'badge-red',
        'Reversed'   => 'badge-purple',
    ];
    return $map[$s] ?? 'badge-yellow';
}

function ico($path, $stroke='#4A5568', $size=18){
    return "<svg width='$size' height='$size' viewBox='0 0 24 24' fill='none' stroke='$stroke' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>$path</svg>";
}
$iBook  = "<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>";
$iPay   = "<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iCrm   = "<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iGps   = "<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/>";
$iBar   = "<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>";
$iDoc   = "<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/><line x1='16' y1='13' x2='8' y2='13'/><line x1='16' y1='17' x2='8' y2='17'/>";
$iHome  = "<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>";
$iOut   = "<path d='M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'/><polyline points='16 17 21 12 16 7'/><line x1='21' y1='12' x2='9' y2='12'/>";
$iCheck = "<polyline points='20 6 9 17 4 12'/>";
$iX     = "<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>";
$iRepeat= "<polyline points='17 1 21 5 17 9'/><path d='M3 11V9a4 4 0 0 1 4-4h14'/><polyline points='7 23 3 19 7 15'/><path d='M21 13v2a4 4 0 0 1-4 4H3'/>";
$iInfo  = "<circle cx='12' cy='12' r='10'/><line x1='12' y1='8' x2='12' y2='12'/><line x1='12' y1='16' x2='12.01' y2='16'/>";
$iEdit  = "<path d='M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7'/><path d='M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z'/>";
$iRefresh="<path d='M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2'/>";
$iTruck = "<rect x='1' y='3' width='15' height='13'/><polygon points='16 8 20 8 23 11 23 16 16 16 16 8'/><circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/>";
$iUser  = "<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>";
$iBack  = "<path d='M19 12H5M12 19l-7-7 7-7'/>";
$iSettings = "<circle cx='12' cy='12' r='3'/><path d='M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14'/>";
$iDownload = "<path d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'/><polyline points='7 10 12 15 17 10'/><line x1='12' y1='15' x2='12' y2='3'/>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment & Fares — EnviroCab Admin</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%}
:root{
  --g:#00D084;--gd:#00A86B;--gx:#005A38;--gg:rgba(0,208,132,.1);
  --bg:#F0F4F2;--surf:#fff;--surf2:#F7FAF8;--surf3:#EEF5F1;
  --bdr:#DDE8E2;--bdr2:#C8DDD5;
  --txt:#0D1F18;--txt2:#3A5248;--txt3:#7A9A8E;--txt4:#B0C8BC;
  --blue:#3B8EF0;--purple:#8B6FE8;--orange:#F07830;--red:#E84040;--yellow:#E8A020;
  --sb-bg:#991B1B;--sb-txt:#FECACA;--sb-txt2:#FCA5A5;
  --sb-bdr:rgba(255,255,255,.1);--sb-hover:rgba(255,255,255,.09);
  --sb-active:rgba(255,255,255,.16);--sb-active-bdr:rgba(255,255,255,.28);
  --sw:248px;--th:58px;--r:16px;--rs:10px;
  --shadow:0 1px 3px rgba(0,0,0,.04),0 4px 16px rgba(0,0,0,.06);
  --shadow-md:0 2px 8px rgba(0,0,0,.05),0 8px 28px rgba(0,0,0,.09);
}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--txt);-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit}
.trunc{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mono{font-family:'DM Mono',monospace}

.badge{display:inline-flex;align-items:center;gap:4px;font-size:10.5px;font-weight:700;padding:3px 8px;border-radius:5px;text-transform:uppercase;letter-spacing:.4px}
.badge::before{content:'';width:5px;height:5px;border-radius:50%;flex-shrink:0}
.badge-green{background:rgba(0,208,132,.12);color:#008A58}.badge-green::before{background:#00A86B}
.badge-blue{background:rgba(59,142,240,.1);color:#1966C2}.badge-blue::before{background:#3B8EF0}
.badge-yellow{background:rgba(232,160,32,.12);color:#9A6A00}.badge-yellow::before{background:#E8A020}
.badge-red{background:rgba(232,64,64,.1);color:#C22020}.badge-red::before{background:#E84040}
.badge-purple{background:rgba(139,111,232,.1);color:#5A3FBB}.badge-purple::before{background:#8B6FE8}

.chip{display:inline-block;font-size:10.5px;font-weight:600;padding:3px 9px;border-radius:20px;background:var(--surf3);border:1px solid var(--bdr);color:var(--txt2)}

@media(min-width:900px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}

  .sidebar{width:var(--sw);flex-shrink:0;height:100vh;display:flex;flex-direction:column;background:var(--sb-bg);overflow:hidden;box-shadow:3px 0 18px rgba(153,27,27,.22)}
  .sb-logo{height:var(--th);display:flex;align-items:center;gap:10px;padding:0 18px;border-bottom:1px solid var(--sb-bdr);flex-shrink:0}
  .sb-logo img{height:26px;filter:brightness(0) invert(1)}
  .sb-brand{font-size:16px;font-weight:800;letter-spacing:-.3px;color:#fff}.sb-brand span{color:#FCA5A5}
  .sb-nav{flex:1;overflow-y:auto;padding:12px 10px;display:flex;flex-direction:column;gap:1px}
  .sb-label{font-size:9.5px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:var(--sb-txt2);padding:14px 10px 5px}
  .sb-item{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:9px;cursor:pointer;color:rgba(255,255,255,.75);font-size:13px;font-weight:500;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover);color:#fff}
  .sb-item.active{background:var(--sb-active);color:#fff;border-color:var(--sb-active-bdr);font-weight:600}
  .sb-ico{width:30px;height:30px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item:hover .sb-ico,.sb-item.active .sb-ico{background:rgba(255,255,255,.16)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-foot{padding:12px 10px;border-top:1px solid var(--sb-bdr);flex-shrink:0;display:flex;gap:8px;align-items:center}
  .sb-av{width:34px;height:34px;border-radius:9px;flex-shrink:0;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;border:1px solid rgba(255,255,255,.28)}
  .sb-uname{font-size:12.5px;font-weight:600;color:#fff}
  .sb-urole{font-size:11px;color:var(--sb-txt2)}
  .sb-out{margin-left:auto;width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s}
  .sb-out:hover{background:rgba(239,68,68,.3)}
  .sb-out svg{stroke:#fff!important}

  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:var(--th);flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 24px;gap:12px}
  .tb-title{flex:1;font-size:16px;font-weight:800;letter-spacing:-.2px}
  .tb-date{font-size:12px;color:var(--txt3);font-weight:500}
  .tb-sep{width:1px;height:18px;background:var(--bdr)}
  .tb-btn{height:34px;padding:0 14px;border-radius:8px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12.5px;font-weight:600;color:var(--txt2);transition:all .15s}
  .tb-btn:hover{background:var(--bg);border-color:var(--bdr2)}
  .tb-btn svg{stroke:var(--txt3)!important}
  .tb-btn-primary{background:linear-gradient(135deg,var(--g),var(--gd));color:#fff;border:none}
  .tb-btn-primary:hover{box-shadow:0 4px 12px rgba(0,208,132,.3)}
  .tb-btn-primary svg{stroke:#fff!important}

  .scroll{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:16px}
  .scroll::-webkit-scrollbar{width:4px}
  .scroll::-webkit-scrollbar-thumb{background:var(--bdr2);border-radius:4px}

  .kpi-row{display:grid;grid-template-columns:repeat(5,1fr);gap:12px}
  .kpi{background:var(--surf);border-radius:var(--r);padding:16px 18px;border:1px solid var(--bdr);transition:all .2s;cursor:default}
  .kpi:hover{box-shadow:var(--shadow);transform:translateY(-1px)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
  .kpi-ico{width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center}
  .kpi-trend{font-size:10px;font-weight:700;padding:2px 8px;border-radius:5px}
  .trend-up{background:rgba(0,208,132,.1);color:#008A58}
  .trend-dn{background:rgba(232,64,64,.1);color:#C22020}
  .trend-nt{background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:28px;font-weight:800;line-height:1;margin-bottom:4px;letter-spacing:-.5px}
  .kpi-val .sign{font-size:16px;font-weight:600;vertical-align:top;margin-top:5px;display:inline-block}
  .kpi-lbl{font-size:11.5px;color:var(--txt3);font-weight:500}

  .fare-config{background:linear-gradient(135deg,#0D1F18 0%,#1A3B2A 100%);border-radius:var(--r);padding:20px 24px;display:flex;align-items:center;gap:20px;border:1px solid rgba(0,208,132,.15)}
  .fc-icon{width:48px;height:48px;background:rgba(0,208,132,.15);border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .fc-text{flex:1}
  .fc-title{font-size:15px;font-weight:700;color:#fff;margin-bottom:3px}
  .fc-sub{font-size:12px;color:rgba(255,255,255,.5)}
  .fc-fields{display:flex;gap:10px;align-items:center}
  .fc-field{display:flex;flex-direction:column;gap:4px}
  .fc-label{font-size:10px;font-weight:600;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.5px}
  .fc-input{width:110px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:600;transition:all .2s}
  .fc-input:focus{outline:none;border-color:var(--g);background:rgba(0,208,132,.08)}
  .fc-btn{padding:9px 18px;background:var(--g);border:none;border-radius:9px;color:#fff;font-size:13px;font-weight:700;cursor:pointer;transition:all .15s;white-space:nowrap;display:flex;align-items:center;gap:6px}
  .fc-btn:hover{background:var(--gd);box-shadow:0 4px 12px rgba(0,208,132,.3)}

  .tabs-bar{display:flex;gap:2px;background:var(--surf2);border-radius:10px;padding:3px;border:1px solid var(--bdr);width:fit-content}
  .tab-btn{padding:7px 16px;border-radius:8px;font-size:12.5px;font-weight:600;cursor:pointer;color:var(--txt3);transition:all .18s;white-space:nowrap;border:none;background:none}
  .tab-btn.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.08)}

  .panel{background:var(--surf);border-radius:var(--r);border:1px solid var(--bdr);overflow:hidden}
  .panel-head{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--bdr)}
  .panel-title{font-size:14px;font-weight:800;display:flex;align-items:center;gap:8px}
  .panel-count{font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;background:var(--surf3);color:var(--txt3)}
  .panel-actions{display:flex;gap:8px;align-items:center}
  .search-box{height:32px;padding:0 12px 0 32px;border-radius:8px;border:1px solid var(--bdr);background:var(--surf2);font-size:12.5px;font-family:'DM Sans',sans-serif;color:var(--txt);width:200px;transition:all .2s}
  .search-box:focus{outline:none;border-color:var(--g);width:240px;background:var(--surf)}
  .search-wrap{position:relative}
  .search-ico{position:absolute;left:9px;top:50%;transform:translateY(-50%);pointer-events:none}

  .tbl-wrap{overflow-x:auto}
  table{width:100%;border-collapse:collapse;font-size:12.5px}
  thead tr{background:var(--surf2)}
  thead th{padding:9px 14px;text-align:left;font-size:10.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  tbody tr{border-bottom:1px solid var(--bdr);transition:background .12s}
  tbody tr:last-child{border-bottom:none}
  tbody tr:hover{background:var(--surf2)}
  tbody td{padding:10px 14px;vertical-align:middle}
  .td-amt{font-weight:700;font-size:13px;color:var(--gd)}
  .td-muted{color:var(--txt3);font-size:11.5px}
  .td-normal{color:var(--txt2)}
  .empty-row td{text-align:center;padding:32px;color:var(--txt3);font-size:13px}

  .tbl-action{height:28px;padding:0 10px;border-radius:6px;font-size:11px;font-weight:600;border:1px solid var(--bdr);background:var(--surf);color:var(--txt2);cursor:pointer;transition:all .12s;display:inline-flex;align-items:center;gap:4px}
  .tbl-action:hover{border-color:var(--bdr2);background:var(--surf3)}
  .tbl-action svg{stroke:var(--txt3)!important}
  .tbl-action-danger:hover{border-color:rgba(232,64,64,.3);background:rgba(232,64,64,.06);color:var(--red)}
  .tbl-action-danger:hover svg{stroke:var(--red)!important}
  .tbl-action-success:hover{border-color:rgba(0,208,132,.3);background:rgba(0,208,132,.06);color:var(--gd)}
  .tbl-action-success:hover svg{stroke:var(--gd)!important}

  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}

  .toast{position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:8px}
  .toast-item{background:var(--txt);color:#fff;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:10px;animation:toastIn .3s ease;max-width:320px}
  .toast-item.success{background:#0D5F3A;border-left:3px solid var(--g)}
  .toast-item.error{background:#5F1313;border-left:3px solid var(--red)}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  @keyframes toastOut{from{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(20px)}}

  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(4px);z-index:1000;align-items:center;justify-content:center;padding:20px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:20px;padding:0;max-width:560px;width:100%;max-height:85vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:var(--shadow-md)}
  .modal-hdr{padding:20px 24px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:16px;font-weight:800}
  .modal-close{width:30px;height:30px;border-radius:8px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s}
  .modal-close:hover{background:var(--bg);border-color:var(--bdr2)}
  .modal-body{padding:20px 24px;overflow-y:auto;flex:1}
  .modal-foot{padding:16px 24px;border-top:1px solid var(--bdr);display:flex;gap:10px;flex-shrink:0}
  .btn{padding:10px 18px;border-radius:9px;font-size:13px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:6px}
  .btn-primary{background:linear-gradient(135deg,var(--g),var(--gd));color:#fff}
  .btn-primary:hover{box-shadow:0 4px 14px rgba(0,208,132,.3)}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-danger:hover{box-shadow:0 4px 14px rgba(232,64,64,.3)}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-ghost:hover{background:var(--bg)}

  .d-row{display:flex;align-items:center;padding:9px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:140px;font-size:12px;font-weight:600;color:var(--txt3);flex-shrink:0}
  .d-val{font-size:13px;color:var(--txt);font-weight:500}

  .mini-bar{display:flex;align-items:flex-end;gap:3px;height:40px}
  .bar-col{flex:1;background:rgba(0,208,132,.15);border-radius:3px 3px 0 0;transition:background .15s}
  .bar-col:hover{background:rgba(0,208,132,.4)}

  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:16px;padding:28px 36px;text-align:center;box-shadow:var(--shadow-md)}
  .spinner{width:44px;height:44px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 12px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
  .kpi,.panel{animation:fadeUp .3s ease both}
  .kpi:nth-child(1){animation-delay:.04s}
  .kpi:nth-child(2){animation-delay:.08s}
  .kpi:nth-child(3){animation-delay:.12s}
  .kpi:nth-child(4){animation-delay:.16s}
  .kpi:nth-child(5){animation-delay:.20s}

  .tab-pane{display:none}.tab-pane.active{display:block;animation:fadeUp .25s ease}
  .section-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:10px}
}

@media(min-width:768px) and (max-width:899px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}
  .sidebar{width:58px;height:100vh;background:var(--sb-bg);display:flex;flex-direction:column;align-items:center;padding:10px 0;gap:3px;flex-shrink:0}
  .sb-logo{width:100%;height:52px;display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--sb-bdr);margin-bottom:6px}
  .sb-logo img{height:24px;filter:brightness(0) invert(1)}
  .sb-brand,.sb-label{display:none}
  .sb-nav{flex:1;width:100%;padding:4px 6px;display:flex;flex-direction:column;align-items:center;gap:2px}
  .sb-item{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover)}
  .sb-item.active{background:var(--sb-active);border-color:var(--sb-active-bdr)}
  .sb-ico{width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-item.active .sb-ico{background:rgba(255,255,255,.18)}
  .sb-foot{padding:8px 6px;border-top:1px solid var(--sb-bdr);width:100%;display:flex;flex-direction:column;align-items:center;gap:5px}
  .sb-av{width:32px;height:32px;border-radius:8px;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:#fff}
  .sb-uname,.sb-urole{display:none}
  .sb-out{width:28px;height:28px;border-radius:7px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .sb-out svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:52px;flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 18px;gap:10px}
  .tb-title{flex:1;font-size:15px;font-weight:800}
  .tb-date{font-size:11.5px;color:var(--txt3)}
  .tb-sep{width:1px;height:16px;background:var(--bdr)}
  .tb-btn{height:30px;padding:0 12px;border-radius:7px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:5px;cursor:pointer;font-size:12px;font-weight:600;color:var(--txt2)}
  .tb-btn-primary{background:linear-gradient(135deg,var(--g),var(--gd));color:#fff;border:none}
  .scroll{flex:1;overflow-y:auto;padding:14px 16px;display:flex;flex-direction:column;gap:12px}
  .kpi-row{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .kpi{background:var(--surf);border-radius:13px;padding:14px 16px;border:1px solid var(--bdr)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
  .kpi-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-trend{font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:5px}
  .trend-up{background:rgba(0,208,132,.1);color:#008A58}
  .trend-dn{background:rgba(232,64,64,.1);color:#C22020}
  .trend-nt{background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:22px;font-weight:800;line-height:1;margin-bottom:3px;letter-spacing:-.5px}
  .kpi-val .sign{font-size:14px;font-weight:600;vertical-align:top;margin-top:3px;display:inline-block}
  .kpi-lbl{font-size:11px;color:var(--txt3)}
  .fare-config{background:linear-gradient(135deg,#0D1F18,#1A3B2A);border-radius:13px;padding:16px 18px;display:flex;flex-wrap:wrap;gap:12px;align-items:center;border:1px solid rgba(0,208,132,.12)}
  .fc-title{font-size:13px;font-weight:700;color:#fff;margin-bottom:2px}
  .fc-sub{font-size:11px;color:rgba(255,255,255,.5)}
  .fc-icon{width:40px;height:40px;background:rgba(0,208,132,.15);border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .fc-text{flex:1}
  .fc-fields{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
  .fc-field{display:flex;flex-direction:column;gap:3px}
  .fc-label{font-size:9px;font-weight:600;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.5px}
  .fc-input{width:95px;padding:7px 10px;border-radius:7px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;font-size:12px;font-weight:600;font-family:'DM Sans',sans-serif}
  .fc-input:focus{outline:none;border-color:var(--g)}
  .fc-btn{padding:8px 14px;background:var(--g);border:none;border-radius:8px;color:#fff;font-size:12px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:5px}
  .tabs-bar{display:flex;gap:2px;background:var(--surf2);border-radius:9px;padding:3px;border:1px solid var(--bdr);width:fit-content}
  .tab-btn{padding:6px 13px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s}
  .tab-btn.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.07)}
  .panel{background:var(--surf);border-radius:13px;border:1px solid var(--bdr);overflow:hidden}
  .panel-head{display:flex;align-items:center;justify-content:space-between;padding:13px 16px;border-bottom:1px solid var(--bdr)}
  .panel-title{font-size:13px;font-weight:800;display:flex;align-items:center;gap:7px}
  .panel-count{font-size:10.5px;font-weight:600;padding:2px 7px;border-radius:20px;background:var(--surf3);color:var(--txt3)}
  .panel-actions{display:flex;gap:7px;align-items:center}
  .search-wrap{position:relative}
  .search-box{height:30px;padding:0 10px 0 28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);font-size:12px;font-family:'DM Sans',sans-serif;color:var(--txt);width:170px}
  .search-box:focus{outline:none;border-color:var(--g)}
  .search-ico{position:absolute;left:8px;top:50%;transform:translateY(-50%);pointer-events:none}
  .tbl-wrap{overflow-x:auto}
  table{width:100%;border-collapse:collapse;font-size:12px}
  thead tr{background:var(--surf2)}
  thead th{padding:8px 12px;text-align:left;font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  tbody tr{border-bottom:1px solid var(--bdr);transition:background .12s}
  tbody tr:last-child{border-bottom:none}
  tbody tr:hover{background:var(--surf2)}
  tbody td{padding:9px 12px;vertical-align:middle}
  .td-amt{font-weight:700;font-size:12.5px;color:var(--gd)}
  .td-muted{color:var(--txt3);font-size:11px}
  .td-normal{color:var(--txt2)}
  .empty-row td{text-align:center;padding:24px;color:var(--txt3);font-size:12px}
  .tbl-action{height:26px;padding:0 9px;border-radius:6px;font-size:10.5px;font-weight:600;border:1px solid var(--bdr);background:var(--surf);color:var(--txt2);cursor:pointer;display:inline-flex;align-items:center;gap:3px}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .toast{position:fixed;bottom:18px;right:18px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:var(--txt);color:#fff;padding:11px 16px;border-radius:9px;font-size:12.5px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:9px;animation:toastIn .3s ease;max-width:280px}
  .toast-item.success{background:#0D5F3A;border-left:3px solid var(--g)}
  .toast-item.error{background:#5F1313;border-left:3px solid var(--red)}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);z-index:1000;align-items:center;justify-content:center;padding:16px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:17px;padding:0;max-width:520px;width:100%;max-height:85vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-hdr{padding:17px 20px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:18px 20px;overflow-y:auto;flex:1}
  .modal-foot{padding:14px 20px;border-top:1px solid var(--bdr);display:flex;gap:8px}
  .btn{padding:9px 16px;border-radius:8px;font-size:12.5px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:5px}
  .btn-primary{background:linear-gradient(135deg,var(--g),var(--gd));color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .d-row{display:flex;align-items:center;padding:8px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:130px;font-size:11.5px;font-weight:600;color:var(--txt3);flex-shrink:0}
  .d-val{font-size:12.5px;color:var(--txt);font-weight:500}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:14px;padding:24px 30px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  .tab-pane{display:none}.tab-pane.active{display:block;animation:fadeUp .25s ease}
  .section-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:8px}
}

@media(max-width:767px){
  .sidebar,.desk-wrap{display:none!important}
  body{background:#EFF5F2;padding-bottom:80px}
  .mob-header{position:sticky;top:0;z-index:100;background:rgba(255,255,255,.9);backdrop-filter:blur(16px);border-bottom:1px solid rgba(0,0,0,.06);padding:12px 16px;display:flex;align-items:center;gap:10px}
  .mh-back{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mh-title{flex:1;font-size:16px;font-weight:800;text-align:center}
  .mh-btn{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mob-body{padding:14px 14px 18px;display:flex;flex-direction:column;gap:12px}
  .m-hero{background:linear-gradient(135deg,#0D1F18 0%,#1A4030 100%);border-radius:20px;padding:20px 18px;color:#fff}
  .mh-t{font-size:18px;font-weight:800;margin-bottom:4px}
  .mh-s{font-size:12px;color:rgba(255,255,255,.6)}
  .mh-stats{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px}
  .mhst{background:rgba(255,255,255,.07);border-radius:12px;padding:12px 14px}
  .mhst-v{font-size:20px;font-weight:800}
  .mhst-l{font-size:10.5px;color:rgba(255,255,255,.6);margin-top:2px}
  .m-kpis{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .mkpi{background:#fff;border-radius:15px;padding:14px;border:1px solid #DDE8E2}
  .mkpi-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;margin-bottom:8px}
  .mkpi-v{font-size:20px;font-weight:800;color:#0D1F18;line-height:1}
  .mkpi-l{font-size:11px;color:#7A9A8E;margin-top:3px}
  .m-card{background:#fff;border-radius:16px;border:1px solid #DDE8E2;overflow:hidden}
  .mc-head{padding:13px 15px;border-bottom:1px solid #DDE8E2;display:flex;align-items:center;justify-content:space-between}
  .mc-title{font-size:14px;font-weight:800}
  .mc-cnt{font-size:11px;color:#7A9A8E}
  .m-pay-row{display:flex;align-items:center;gap:10px;padding:11px 15px;border-bottom:1px solid #EEF5F1}
  .m-pay-row:last-child{border:none}
  .mpr-ico{width:34px;height:34px;border-radius:9px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .mpr-info{flex:1;min-width:0}
  .mpr-name{font-size:13px;font-weight:600;color:#0D1F18}
  .mpr-sub{font-size:11px;color:#7A9A8E;margin-top:2px;display:flex;align-items:center;gap:6px}
  .mpr-amt{font-size:13px;font-weight:700;color:#00A86B;white-space:nowrap}
  .m-fare-config{background:linear-gradient(135deg,#0D1F18,#1A3B2A);border-radius:16px;padding:16px}
  .mfc-title{font-size:14px;font-weight:700;color:#fff;margin-bottom:3px}
  .mfc-sub{font-size:11px;color:rgba(255,255,255,.5);margin-bottom:14px}
  .mfc-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}
  .mfc-field{display:flex;flex-direction:column;gap:4px}
  .mfc-label{font-size:10px;font-weight:600;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.4px}
  .mfc-input{padding:9px 12px;border-radius:9px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;font-size:13px;font-weight:600;font-family:'DM Sans',sans-serif;width:100%}
  .mfc-input:focus{outline:none;border-color:#00D084}
  .mfc-btn{width:100%;padding:12px;background:#00D084;border:none;border-radius:10px;color:#fff;font-size:13px;font-weight:700;cursor:pointer}
  .mob-nav{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.96);backdrop-filter:blur(20px);border-top:1px solid rgba(0,0,0,.06);padding:8px 0 16px;display:grid;grid-template-columns:repeat(4,1fr);z-index:99}
  .mn{display:flex;flex-direction:column;align-items:center;gap:2px;padding:5px;cursor:pointer;border:none;background:none}
  .mn-ico{width:40px;height:26px;display:flex;align-items:center;justify-content:center}
  .mn-ico svg{stroke:#718096;opacity:.5}
  .mn.active .mn-ico svg{stroke:#00D084;opacity:1}
  .mn-lbl{font-size:10px;font-weight:600;color:#718096;opacity:.7}
  .mn.active .mn-lbl{color:#00D084;opacity:1}
  .mob-toast{position:fixed;bottom:88px;left:14px;right:14px;z-index:9999;display:flex;flex-direction:column;gap:8px}
  .mob-toast-item{background:#0D5F3A;color:#fff;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px;animation:toastIn .3s ease}
  .mob-toast-item.error{background:#5F1313}
  @keyframes toastIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <img src="../images/envirocab_logo.png" alt="EC" onerror="this.style.display='none'">
  </div>
  <nav class="sb-nav">
    <div class="sb-label">Core 2</div>
    <a href="dashboard.php" class="sb-item"><div class="sb-ico"><?=ico($iHome,'#4A5568')?></div><span>Dashboard</span></a>
    <a href="booking_system.php" class="sb-item"><div class="sb-ico"><?=ico($iBook,'#4A5568')?></div><span>Booking System</span></a>
    <a href="payment_fares.php" class="sb-item active"><div class="sb-ico"><?=ico($iPay,'#4A5568')?></div><span>Payment &amp; Fares</span></a>
    <a href="crm_system.php" class="sb-item"><div class="sb-ico"><?=ico($iCrm,'#4A5568')?></div><span>CRM</span></a>
    <a href="gps_tracking.php" class="sb-item"><div class="sb-ico"><?=ico($iGps,'#4A5568')?></div><span>GPS Tracking</span></a>
    <div class="sb-label">Analytics</div>
    <a href="transport_analytics.php" class="sb-item"><div class="sb-ico"><?=ico($iBar,'#4A5568')?></div><span>Analytics &amp; KPIs</span></a>
    <a href="sop_compliance.php" class="sb-item"><div class="sb-ico"><?=ico($iDoc,'#4A5568')?></div><span>SOP Compliance</span></a>
  </nav>
  <div class="sb-foot">
    <div class="sb-av"><?=$userInitial?></div>
    <div style="flex:1;min-width:0">
      <div class="sb-uname trunc"><?=$userName?></div>
      <div class="sb-urole">Administrator</div>
    </div>
    <button class="sb-out" onclick="if(confirm('Logout?'))location.href='../auth/logout.php'" title="Logout"><?=ico($iOut,'#EF4444',14)?></button>
  </div>
</aside>

<div class="desk-wrap">
  <header class="topbar">
    <div class="tb-title">Payment &amp; Fare Collection</div>
    <div class="tb-date"><?=date('D, M j, Y')?></div>
    <div class="tb-sep"></div>
    <button class="tb-btn" onclick="exportCSV()"><?=ico($iDownload,'#4A5568',14)?> Export CSV</button>
    <button class="tb-btn tb-btn-primary" onclick="openFareModal()"><?=ico($iEdit,'#fff',14)?> Configure Fares</button>
    <button class="tb-btn" onclick="location.reload()" title="Refresh"><?=ico($iRefresh,'#4A5568',14)?></button>
  </header>

  <div class="scroll">

    <div class="kpi-row">
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(0,208,132,.12)"><?=ico($iPay,'#00A86B',20)?></div>
          <div class="kpi-trend trend-up">+<?=$count_captured?> paid</div>
        </div>
        <div class="kpi-val"><span class="sign">₱</span><?=number_format($total_captured,2)?></div>
        <div class="kpi-lbl">Total Revenue Captured</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(232,160,32,.1)"><?=ico($iPay,'#E8A020',20)?></div>
          <div class="kpi-trend trend-nt"><?=$count_pending?> pending</div>
        </div>
        <div class="kpi-val"><span class="sign">₱</span><?=number_format($total_pending,2)?></div>
        <div class="kpi-lbl">Pending Payments</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(139,111,232,.1)"><?=ico($iRepeat,'#8B6FE8',20)?></div>
          <div class="kpi-trend trend-nt"><?=$count_refunded?> txns</div>
        </div>
        <div class="kpi-val"><span class="sign">₱</span><?=number_format($total_refunded,2)?></div>
        <div class="kpi-lbl">Total Refunded</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(232,64,64,.08)"><?=ico($iX,'#E84040',20)?></div>
          <div class="kpi-trend trend-dn"><?=$count_failed?> failed</div>
        </div>
        <div class="kpi-val"><?=$count_failed?></div>
        <div class="kpi-lbl">Failed Transactions</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(59,142,240,.1)"><?=ico($iBar,'#3B8EF0',20)?></div>
          <div class="kpi-trend trend-nt"><?=count($fares)?> fares</div>
        </div>
        <div class="kpi-val"><span class="sign">₱</span><?=number_format($avg_fare,2)?></div>
        <div class="kpi-lbl">Avg. Fare per Trip</div>
      </div>
    </div>

    <div class="fare-config">
      <div class="fc-icon"><?=ico($iSettings,'#00D084',22)?></div>
      <div class="fc-text">
        <div class="fc-title">Fare Configuration</div>
        <div class="fc-sub">Live pricing applied to all new bookings automatically</div>
      </div>
      <div class="fc-fields">
        <div class="fc-field">
          <div class="fc-label">Base Fare (₱)</div>
          <input type="number" class="fc-input" id="conf_base" value="<?=!empty($services) ? number_format((float)$services[0]['unit_price'],2,'.','') : '50.00'?>" step="0.50" min="0">
        </div>
        <div class="fc-field">
          <div class="fc-label">Rate /km (₱)</div>
          <input type="number" class="fc-input" id="conf_rate" value="<?=!empty($fares) ? number_format((float)$fares[0]['distance_rate'],2,'.','') : '12.00'?>" step="0.50" min="0">
        </div>
        <div class="fc-field">
          <div class="fc-label">Surge Multiplier</div>
          <input type="number" class="fc-input" id="conf_surge" value="<?=!empty($fares) ? number_format((float)$fares[0]['surge_multiplier'],2,'.','') : '1.00'?>" step="0.10" min="1" max="5">
        </div>
        <button class="fc-btn" onclick="saveFareConfig()"><?=ico($iCheck,'#fff',14)?> Apply</button>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head">
        <div class="panel-title">
          <?=ico($iPay,'#3B8EF0',16)?>
          Payment Transactions
          <span class="panel-count"><?=count($payments)?> records</span>
        </div>
        <div class="panel-actions">
          <div class="tabs-bar">
            <button class="tab-btn active" onclick="filterPayments('all',this)">All</button>
            <button class="tab-btn" onclick="filterPayments('Captured',this)">Captured</button>
            <button class="tab-btn" onclick="filterPayments('Pending',this)">Pending</button>
            <button class="tab-btn" onclick="filterPayments('Failed',this)">Failed</button>
            <button class="tab-btn" onclick="filterPayments('Refunded',this)">Refunded</button>
          </div>
          <div class="search-wrap">
            <?=ico("<circle cx='10' cy='10' r='7'/><line x1='21' y1='21' x2='14.35' y2='14.35'/>", '#7A9A8E', 13)?>
            <div class="search-ico" style="top:50%;left:9px;transform:translateY(-50%);position:absolute;pointer-events:none"><?=ico("<circle cx='10' cy='10' r='7'/><line x1='21' y1='21' x2='14.35' y2='14.35'/>", '#7A9A8E', 13)?></div>
            <input type="text" class="search-box" id="paySearch" placeholder="Search ref, method…" oninput="searchPayments(this.value)">
          </div>
        </div>
      </div>
      <div class="tbl-wrap">
        <table id="payTable">
          <thead>
            <tr>
              <th>Payment ID</th>
              <th>Booking ID</th>
              <th>Method</th>
              <th>Status</th>
              <th>Amount</th>
              <th>Gateway</th>
              <th>Auth Code</th>
              <th>Txn Ref</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="payTbody">
            <?php if(empty($payments)): ?>
            <tr class="empty-row"><td colspan="10">No payment records found</td></tr>
            <?php else: foreach($payments as $p):
              $sc = payBadge($p['payment_status'] ?? 'Pending');
              $amt = number_format((float)($p['amount']??0),2);
              $dt  = isset($p['created_at']) ? date('M d, Y', strtotime($p['created_at'])) : '—';
            ?>
            <tr data-status="<?=htmlspecialchars($p['payment_status']??'')?>" data-search="<?=strtolower(htmlspecialchars(($p['payment_id']??'').' '.($p['booking_id']??'').' '.($p['payment_method']??'').' '.($p['authorization_code']??'')))?>">
              <td class="mono td-muted">#<?=$p['payment_id']??'—'?></td>
              <td class="mono td-muted"><?=$p['booking_id']??'—'?></td>
              <td><span class="chip"><?=htmlspecialchars($p['payment_method']??'—')?></span></td>
              <td><span class="badge <?=$sc?>"><?=htmlspecialchars($p['payment_status']??'—')?></span></td>
              <td class="td-amt">₱<?=$amt?></td>
              <td class="td-muted"><?=htmlspecialchars($p['payment_gateway']??'—')?></td>
              <td class="mono td-muted"><?=htmlspecialchars($p['authorization_code']??'—')?></td>
              <td class="mono td-muted" style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=htmlspecialchars($p['transaction_reference']??'—')?></td>
              <td class="td-muted"><?=$dt?></td>
              <td>
                <div style="display:flex;gap:5px">
                  <button class="tbl-action" onclick="viewPayment(<?=$p['payment_id']?>)" title="View Details"><?=ico($iInfo,'#4A5568',13)?>View</button>
                  <?php if(($p['payment_status']??'') === 'Captured'): ?>
                  <button class="tbl-action tbl-action-danger" onclick="refundPayment(<?=$p['payment_id']?>,<?=$p['booking_id']??0?>,<?=(float)($p['amount']??0)?>)" title="Process Refund"><?=ico($iRepeat,'#E84040',13)?>Refund</button>
                  <?php endif; ?>
                  <?php if(($p['payment_status']??'') === 'Pending'): ?>
                  <button class="tbl-action tbl-action-success" onclick="verifyPayment(<?=$p['payment_id']?>)" title="Verify/Capture"><?=ico($iCheck,'#00A86B',13)?>Verify</button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="grid2">

      <div class="panel">
        <div class="panel-head">
          <div class="panel-title">
            <?=ico($iBar,'#00A86B',16)?>
            Fare Computation
            <span class="panel-count"><?=count($fares)?></span>
          </div>
        </div>
        <div class="tbl-wrap">
          <table>
            <thead>
              <tr>
                <th>Fare ID</th>
                <th>Booking</th>
                <th>Base</th>
                <th>Dist</th>
                <th>Rate/km</th>
                <th>Surge</th>
                <th>Disc.</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              <?php if(empty($fares)): ?>
              <tr class="empty-row"><td colspan="8">No fare records</td></tr>
              <?php else: foreach($fares as $f): ?>
              <tr>
                <td class="mono td-muted">#<?=$f['fare_id']??'—'?></td>
                <td class="mono td-muted"><?=$f['booking_id']??'—'?></td>
                <td class="td-normal">₱<?=number_format((float)($f['base_fare']??0),2)?></td>
                <td class="td-muted"><?=isset($f['distance_km']) ? number_format((float)$f['distance_km'],1).'km' : '—'?></td>
                <td class="td-muted">₱<?=number_format((float)($f['distance_rate']??0),2)?></td>
                <td class="td-muted"><?=number_format((float)($f['surge_multiplier']??1),2)?>×</td>
                <td class="td-muted"><?=isset($f['discount']) && $f['discount']>0 ? '-₱'.number_format((float)$f['discount'],2) : '—'?></td>
                <td class="td-amt">₱<?=number_format((float)($f['total_fare']??0),2)?></td>
              </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="panel">
        <div class="panel-head">
          <div class="panel-title">
            <?=ico($iRepeat,'#8B6FE8',16)?>
            Transaction Processing
            <span class="panel-count"><?=count($transactions)?></span>
          </div>
        </div>
        <div class="tbl-wrap">
          <table>
            <thead>
              <tr>
                <th>Txn ID</th>
                <th>Payment</th>
                <th>Booking</th>
                <th>Type</th>
                <th>Status</th>
                <th>Amount</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php if(empty($transactions)): ?>
              <tr class="empty-row"><td colspan="7">No transactions</td></tr>
              <?php else: foreach($transactions as $t):
                $sc = txBadge($t['transaction_status'] ?? 'Initiated');
                $dt = isset($t['transaction_time']) ? date('M d, Y', strtotime($t['transaction_time'])) : '—';
              ?>
              <tr>
                <td class="mono td-muted">#<?=$t['transaction_id']??'—'?></td>
                <td class="mono td-muted"><?=$t['payment_id']??'—'?></td>
                <td class="mono td-muted"><?=$t['booking_id']??'—'?></td>
                <td><span class="chip"><?=htmlspecialchars($t['transaction_type']??'—')?></span></td>
                <td><span class="badge <?=$sc?>"><?=htmlspecialchars($t['transaction_status']??'—')?></span></td>
                <td class="td-amt">₱<?=number_format((float)($t['amount']??0),2)?></td>
                <td class="td-muted"><?=$dt?></td>
              </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>

    <div class="panel">
      <div class="panel-head">
        <div class="panel-title">
          <?=ico($iEdit,'#F07830',16)?>
          Service Pricing
          <span class="panel-count"><?=count($services)?> services</span>
        </div>
        <div class="panel-actions">
          <span style="font-size:11.5px;color:var(--txt3)">Base fares from core2_services</span>
        </div>
      </div>
      <div class="tbl-wrap">
        <table>
          <thead>
            <tr>
              <th>Service ID</th>
              <th>Service Name</th>
              <th>Unit Price</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php if(empty($services)): ?>
            <tr class="empty-row"><td colspan="4">No services configured</td></tr>
            <?php else: foreach($services as $s): ?>
            <tr>
              <td class="mono td-muted">#<?=$s['service_id']?></td>
              <td class="td-normal" style="font-weight:600"><?=htmlspecialchars($s['service_name'])?></td>
              <td class="td-amt">₱<?=number_format((float)($s['unit_price']??0),2)?></td>
              <td><span class="badge <?=$s['status']==='Active' ? 'badge-green' : 'badge-red'?>"><?=htmlspecialchars($s['status']??'—')?></span></td>
            </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>

<header class="mob-header">
  <button class="mh-back" onclick="location.href='dashboard.php'"><?=ico($iBack,'currentColor',16)?></button>
  <div class="mh-title">Payment &amp; Fares</div>
  <button class="mh-btn" onclick="location.reload()"><?=ico($iRefresh,'currentColor',16)?></button>
</header>

<div class="mob-body">
  <div class="m-hero">
    <div class="mh-t">Payment &amp; Fares</div>
    <div class="mh-s">Revenue monitoring &amp; fare management</div>
    <div class="mh-stats">
      <div class="mhst">
        <div class="mhst-v" style="color:#00D084">₱<?=number_format($total_captured/1000,1)?>K</div>
        <div class="mhst-l">Total Revenue</div>
      </div>
      <div class="mhst">
        <div class="mhst-v"><?=count($payments)?></div>
        <div class="mhst-l">Total Payments</div>
      </div>
    </div>
  </div>

  <div class="m-kpis">
    <div class="mkpi">
      <div class="mkpi-ico" style="background:rgba(232,160,32,.1)"><?=ico($iPay,'#E8A020',18)?></div>
      <div class="mkpi-v"><?=$count_pending?></div>
      <div class="mkpi-l">Pending</div>
    </div>
    <div class="mkpi">
      <div class="mkpi-ico" style="background:rgba(232,64,64,.08)"><?=ico($iX,'#E84040',18)?></div>
      <div class="mkpi-v"><?=$count_failed?></div>
      <div class="mkpi-l">Failed</div>
    </div>
    <div class="mkpi">
      <div class="mkpi-ico" style="background:rgba(139,111,232,.1)"><?=ico($iRepeat,'#8B6FE8',18)?></div>
      <div class="mkpi-v"><?=$count_refunded?></div>
      <div class="mkpi-l">Refunded</div>
    </div>
    <div class="mkpi">
      <div class="mkpi-ico" style="background:rgba(59,142,240,.1)"><?=ico($iBar,'#3B8EF0',18)?></div>
      <div class="mkpi-v">₱<?=number_format($avg_fare,0)?></div>
      <div class="mkpi-l">Avg. Fare</div>
    </div>
  </div>

  <div class="m-fare-config">
    <div class="mfc-title">Configure Fares</div>
    <div class="mfc-sub">Update pricing structure for all services</div>
    <div class="mfc-row">
      <div class="mfc-field">
        <div class="mfc-label">Base Fare (₱)</div>
        <input type="number" class="mfc-input" id="m_conf_base" value="<?=!empty($services) ? number_format((float)$services[0]['unit_price'],2,'.','') : '50.00'?>" step="0.50">
      </div>
      <div class="mfc-field">
        <div class="mfc-label">Rate /km (₱)</div>
        <input type="number" class="mfc-input" id="m_conf_rate" value="<?=!empty($fares) ? number_format((float)$fares[0]['distance_rate'],2,'.','') : '12.00'?>" step="0.50">
      </div>
    </div>
    <div class="mfc-row">
      <div class="mfc-field">
        <div class="mfc-label">Surge Multiplier</div>
        <input type="number" class="mfc-input" id="m_conf_surge" value="<?=!empty($fares) ? number_format((float)$fares[0]['surge_multiplier'],2,'.','') : '1.00'?>" step="0.10" min="1" max="5">
      </div>
    </div>
    <button class="mfc-btn" onclick="saveFareConfigMobile()">Apply Fare Configuration</button>
  </div>

  <div class="m-card">
    <div class="mc-head">
      <div class="mc-title">Recent Payments</div>
      <div class="mc-cnt"><?=count($payments)?> total</div>
    </div>
    <?php
    $mcolors=[['rgba(0,208,132,.12)','#00A86B'],['rgba(59,142,240,.1)','#3B8EF0'],['rgba(232,160,32,.1)','#E8A020'],['rgba(139,111,232,.1)','#8B6FE8'],['rgba(232,64,64,.08)','#E84040']];
    foreach(array_slice($payments,0,8) as $i=>$p):
      $sc=payBadge($p['payment_status']??'');
      [$bg,$stroke]=$mcolors[$i%5];
    ?>
    <div class="m-pay-row">
      <div class="mpr-ico" style="background:<?=$bg?>"><?=ico($iPay,$stroke,16)?></div>
      <div class="mpr-info">
        <div class="mpr-name"><?=htmlspecialchars($p['payment_method']??'—')?></div>
        <div class="mpr-sub">
          Booking #<?=$p['booking_id']??'—'?>
          <span class="badge <?=$sc?>"><?=htmlspecialchars($p['payment_status']??'—')?></span>
        </div>
      </div>
      <div class="mpr-amt">₱<?=number_format((float)($p['amount']??0),0)?></div>
    </div>
    <?php endforeach; ?>
    <?php if(empty($payments)): ?>
    <div class="m-pay-row"><div class="mpr-info"><div class="mpr-name" style="color:var(--txt3)">No payment records found</div></div></div>
    <?php endif; ?>
  </div>
</div>

<nav class="mob-nav">
  <button class="mn" onclick="location.href='dashboard.php'"><div class="mn-ico"><?=ico($iHome,'currentColor',22)?></div><span class="mn-lbl">Home</span></button>
  <button class="mn" onclick="location.href='booking_system.php'"><div class="mn-ico"><?=ico($iTruck,'currentColor',22)?></div><span class="mn-lbl">Bookings</span></button>
  <button class="mn active"><div class="mn-ico"><?=ico($iPay,'currentColor',22)?></div><span class="mn-lbl">Payments</span></button>
  <button class="mn" onclick="location.href='gps_tracking.php'"><div class="mn-ico"><?=ico($iGps,'currentColor',22)?></div><span class="mn-lbl">GPS</span></button>
</nav>

<div id="payDetailModal" class="modal">
  <div class="modal-box">
    <div class="modal-hdr">
      <div class="modal-title">Payment Detail</div>
      <button class="modal-close" onclick="closeModal('payDetailModal')"><?=ico($iX,'#4A5568',14)?></button>
    </div>
    <div class="modal-body" id="payDetailContent"></div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('payDetailModal')">Close</button>
      <div id="payDetailActions"></div>
    </div>
  </div>
</div>

<div id="fareModal" class="modal">
  <div class="modal-box">
    <div class="modal-hdr">
      <div class="modal-title">Fare Configuration</div>
      <button class="modal-close" onclick="closeModal('fareModal')"><?=ico($iX,'#4A5568',14)?></button>
    </div>
    <div class="modal-body">
      <p style="font-size:13px;color:var(--txt3);margin-bottom:18px">Configure the fare pricing structure. Changes apply to all new bookings immediately.</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
        <div>
          <div class="section-label">Base Fare (₱)</div>
          <input type="number" id="m_base_fare" class="fc-input" style="width:100%;background:var(--surf2);color:var(--txt);border-color:var(--bdr)" value="<?=!empty($services) ? number_format((float)$services[0]['unit_price'],2,'.','') : '50.00'?>" step="0.50" min="0">
        </div>
        <div>
          <div class="section-label">Distance Rate (₱/km)</div>
          <input type="number" id="m_dist_rate" class="fc-input" style="width:100%;background:var(--surf2);color:var(--txt);border-color:var(--bdr)" value="<?=!empty($fares) ? number_format((float)$fares[0]['distance_rate'],2,'.','') : '12.00'?>" step="0.50" min="0">
        </div>
        <div>
          <div class="section-label">Surge Multiplier</div>
          <input type="number" id="m_surge" class="fc-input" style="width:100%;background:var(--surf2);color:var(--txt);border-color:var(--bdr)" value="<?=!empty($fares) ? number_format((float)$fares[0]['surge_multiplier'],2,'.','') : '1.00'?>" step="0.10" min="1" max="5">
        </div>
        <div>
          <div class="section-label">Fare Preview</div>
          <div id="farePreview" style="padding:10px 12px;background:var(--surf3);border-radius:9px;font-size:13px;color:var(--gd);font-weight:700;border:1px solid var(--bdr)">₱—</div>
        </div>
      </div>
      <div style="background:rgba(0,208,132,.06);border:1px solid rgba(0,208,132,.15);border-radius:10px;padding:12px 14px;font-size:12.5px;color:var(--gd)">
        <?=ico($iInfo,'#00A86B',14)?> <strong>Formula:</strong> Total = (Base Fare + Distance × Rate) × Surge Multiplier
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('fareModal')">Cancel</button>
      <button class="btn btn-primary" onclick="saveFareConfigModal()"><?=ico($iCheck,'#fff',14)?> Save Configuration</button>
    </div>
  </div>
</div>

<div id="refundModal" class="modal">
  <div class="modal-box">
    <div class="modal-hdr">
      <div class="modal-title">Process Refund</div>
      <button class="modal-close" onclick="closeModal('refundModal')"><?=ico($iX,'#4A5568',14)?></button>
    </div>
    <div class="modal-body">
      <p style="font-size:13px;color:var(--txt2);margin-bottom:16px">You are about to process a refund for the following payment:</p>
      <div id="refundDetails"></div>
      <div style="background:rgba(232,64,64,.06);border:1px solid rgba(232,64,64,.15);border-radius:10px;padding:12px 14px;font-size:12.5px;color:var(--red);margin-top:16px">
        <?=ico($iInfo,'#E84040',14)?> This action will mark the payment as <strong>Refunded</strong> and create a reversal transaction. This cannot be undone.
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('refundModal')">Cancel</button>
      <button class="btn btn-danger" id="confirmRefundBtn"><?=ico($iRepeat,'#fff',14)?> Confirm Refund</button>
    </div>
  </div>
</div>

<div id="loading" class="loading">
  <div class="spin-box">
    <div class="spinner"></div>
    <p style="font-size:13px;font-weight:600;color:var(--txt)">Processing…</p>
  </div>
</div>
<div class="toast" id="toastCont"></div>
<div class="mob-toast" id="mobToastCont"></div>

<script>

const allPayments = <?=json_encode(array_values($payments))?>;
let currentFilter = 'all';

function toast(msg, type='success') {
    ['toastCont','mobToastCont'].forEach(id => {
        const c = document.getElementById(id);
        if (!c) return;
        const el = document.createElement('div');
        el.className = `toast-item ${type}`;
        el.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${type==='success'?'<polyline points="20 6 9 17 4 12"/>':'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>'}</svg>${msg}`;
        c.appendChild(el);
        setTimeout(() => { el.style.animation='toastOut .3s ease forwards'; setTimeout(()=>el.remove(),300); }, 3500);
    });
}

const setLoading = v => document.getElementById('loading').classList.toggle('show', v);

function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal').forEach(m => m.addEventListener('click', e => { if(e.target===m) m.classList.remove('open'); }));

async function post(data) {
    const fd = new FormData();
    Object.entries(data).forEach(([k,v]) => fd.append(k,v));
    const r = await fetch('payment_fares.php', {method:'POST', body:fd});
    return r.json();
}

function filterPayments(status, el) {
    currentFilter = status;
    document.querySelectorAll('.tabs-bar .tab-btn').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    applyPaymentFilter();
}

function searchPayments(q) {
    applyPaymentFilter(q.toLowerCase());
}

function applyPaymentFilter(q='') {
    const rows = document.querySelectorAll('#payTbody tr');
    rows.forEach(row => {
        if (row.classList.contains('empty-row')) return;
        const statusMatch = currentFilter === 'all' || row.dataset.status === currentFilter;
        const searchMatch = !q || row.dataset.search.includes(q);
        row.style.display = statusMatch && searchMatch ? '' : 'none';
    });
}

async function viewPayment(pid) {
    setLoading(true);
    try {
        const res = await post({action:'get_payment_detail', payment_id:pid});
        if (!res.success) { toast(res.message||'Error','error'); setLoading(false); return; }
        const p = res.payment, txns = res.transactions||[];
        document.getElementById('payDetailContent').innerHTML = `
          <div class="section-label">Payment Info</div>
          <div class="d-row"><div class="d-label">Payment ID</div><div class="d-val mono">#${p.payment_id}</div></div>
          <div class="d-row"><div class="d-label">Booking Ref</div><div class="d-val">${p.booking_reference||'—'}</div></div>
          <div class="d-row"><div class="d-label">Customer</div><div class="d-val">${p.customer_name||'—'} ${p.customer_phone?'· '+p.customer_phone:''}</div></div>
          <div class="d-row"><div class="d-label">Method</div><div class="d-val"><span class="chip">${p.payment_method||'—'}</span></div></div>
          <div class="d-row"><div class="d-label">Status</div><div class="d-val"><span class="badge ${p.payment_status?'badge-'+({'Captured':'green','Authorized':'blue','Pending':'yellow','Failed':'red','Refunded':'purple'}[p.payment_status]||'yellow'):'badge-yellow'}">${p.payment_status||'—'}</span></div></div>
          <div class="d-row"><div class="d-label">Amount</div><div class="d-val" style="font-weight:800;font-size:18px;color:var(--gd)">₱${parseFloat(p.amount||0).toFixed(2)}</div></div>
          <div class="d-row"><div class="d-label">Gateway</div><div class="d-val">${p.payment_gateway||'—'}</div></div>
          <div class="d-row"><div class="d-label">Auth Code</div><div class="d-val mono">${p.authorization_code||'—'}</div></div>
          <div class="d-row"><div class="d-label">Txn Reference</div><div class="d-val mono" style="font-size:11px;word-break:break-all">${p.transaction_reference||'—'}</div></div>
          <div class="d-row"><div class="d-label">Created</div><div class="d-val">${p.created_at ? new Date(p.created_at).toLocaleString() : '—'}</div></div>
          ${txns.length?`
          <div class="section-label" style="margin-top:14px">Linked Transactions (${txns.length})</div>
          ${txns.map(t=>`
            <div style="display:flex;align-items:center;gap:10px;padding:9px;background:var(--surf2);border-radius:9px;margin-bottom:6px">
              <div style="flex:1"><div style="font-size:12.5px;font-weight:600">${t.transaction_type} <span class="badge ${txBadge(t.transaction_status)}">${t.transaction_status}</span></div><div style="font-size:11px;color:var(--txt3)">${t.transaction_time?new Date(t.transaction_time).toLocaleString():'—'}</div></div>
              <div style="font-weight:700;color:var(--gd)">₱${parseFloat(t.amount||0).toFixed(2)}</div>
            </div>`).join('')}`:''
          }`;
        document.getElementById('payDetailActions').innerHTML = p.payment_status==='Captured'
          ? `<button class="btn btn-danger" onclick="closeModal('payDetailModal');refundPayment(${p.payment_id},${p.booking_id||0},${parseFloat(p.amount||0)})">${ico($iRepeat,'#fff',14)} Refund</button>`
          : (p.payment_status==='Pending' ? `<button class="btn btn-primary" onclick="closeModal('payDetailModal');verifyPayment(${p.payment_id})">${ico($iCheck,'#fff',14)} Verify</button>` : '');
        openModal('payDetailModal');
    } catch(e){ toast('Error: '+e.message,'error'); }
    setLoading(false);
}

function txBadge(s){ return {Completed:'badge-green',Processing:'badge-blue',Initiated:'badge-yellow',Failed:'badge-red',Reversed:'badge-purple'}[s]||'badge-yellow'; }

async function verifyPayment(pid) {
    if (!confirm('Mark this payment as Captured/Verified?')) return;
    setLoading(true);
    try {
        const res = await post({action:'update_payment_status', payment_id:pid, status:'Captured'});
        toast(res.message, res.success?'success':'error');
        if (res.success) setTimeout(()=>location.reload(),1200);
    } catch(e){ toast('Error: '+e.message,'error'); }
    setLoading(false);
}

let pendingRefund = null;
function refundPayment(pid, bid, amount) {
    pendingRefund = {pid, bid, amount};
    document.getElementById('refundDetails').innerHTML = `
      <div class="d-row"><div class="d-label">Payment ID</div><div class="d-val mono">#${pid}</div></div>
      <div class="d-row"><div class="d-label">Booking ID</div><div class="d-val">${bid}</div></div>
      <div class="d-row"><div class="d-label">Refund Amount</div><div class="d-val" style="font-weight:800;font-size:18px;color:var(--red)">₱${parseFloat(amount).toFixed(2)}</div></div>`;
    openModal('refundModal');
}
document.getElementById('confirmRefundBtn').onclick = async () => {
    if (!pendingRefund) return;
    closeModal('refundModal');
    setLoading(true);
    try {
        const res = await post({action:'process_refund', payment_id:pendingRefund.pid, booking_id:pendingRefund.bid, amount:pendingRefund.amount});
        toast(res.message, res.success?'success':'error');
        if (res.success) setTimeout(()=>location.reload(),1500);
    } catch(e){ toast('Error: '+e.message,'error'); }
    setLoading(false);
    pendingRefund = null;
};

function openFareModal() { openModal('fareModal'); updateFarePreview(); }

function updateFarePreview() {
    const base  = parseFloat(document.getElementById('m_base_fare')?.value||0);
    const rate  = parseFloat(document.getElementById('m_dist_rate')?.value||0);
    const surge = parseFloat(document.getElementById('m_surge')?.value||1);
    const sample = (base + 5 * rate) * surge;
    const el = document.getElementById('farePreview');
    if (el) el.textContent = '₱'+sample.toFixed(2)+' (5km sample)';
}
['m_base_fare','m_dist_rate','m_surge'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', updateFarePreview);
});

async function saveFareConfig() {
    const base  = parseFloat(document.getElementById('conf_base').value||0);
    const rate  = parseFloat(document.getElementById('conf_rate').value||0);
    const surge = parseFloat(document.getElementById('conf_surge').value||1);
    setLoading(true);
    try {
        const res = await post({action:'update_fare_config', base_fare:base, distance_rate:rate, surge_multiplier:surge});
        toast(res.message, res.success?'success':'error');
    } catch(e){ toast('Error: '+e.message,'error'); }
    setLoading(false);
}
async function saveFareConfigModal() {
    const base  = parseFloat(document.getElementById('m_base_fare').value||0);
    const rate  = parseFloat(document.getElementById('m_dist_rate').value||0);
    const surge = parseFloat(document.getElementById('m_surge').value||1);
    closeModal('fareModal');
    setLoading(true);
    try {
        const res = await post({action:'update_fare_config', base_fare:base, distance_rate:rate, surge_multiplier:surge});
        toast(res.message, res.success?'success':'error');
        if (res.success) { document.getElementById('conf_base').value=base; document.getElementById('conf_rate').value=rate; document.getElementById('conf_surge').value=surge; }
    } catch(e){ toast('Error: '+e.message,'error'); }
    setLoading(false);
}
async function saveFareConfigMobile() {
    const base  = parseFloat(document.getElementById('m_conf_base').value||0);
    const rate  = parseFloat(document.getElementById('m_conf_rate').value||0);
    const surge = parseFloat(document.getElementById('m_conf_surge').value||1);
    setLoading(true);
    try {
        const res = await post({action:'update_fare_config', base_fare:base, distance_rate:rate, surge_multiplier:surge});
        toast(res.message, res.success?'success':'error');
    } catch(e){ toast('Error: '+e.message,'error'); }
    setLoading(false);
}

function exportCSV() {
    const rows = [['Payment ID','Booking ID','Method','Status','Amount','Gateway','Auth Code','Date']];
    allPayments.forEach(p => rows.push([p.payment_id,p.booking_id,p.payment_method,p.payment_status,p.amount,p.payment_gateway,p.authorization_code,p.created_at]));
    const csv = rows.map(r=>r.map(c=>`"${(c||'').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'payments_'+new Date().toISOString().slice(0,10)+'.csv';
    a.click();
}
</script>
<?php include __DIR__ . '/chat_widget.php'; ?>
</body>
</html>