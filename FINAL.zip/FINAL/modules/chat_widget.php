<?php

$chatAdminId   = $_SESSION['admin_uuid'] ?? $_SESSION['admin_id'] ?? $_SESSION['user_id'] ?? $_SESSION['id'] ?? '';
$chatAdminName = htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['display_name'] ?? $_SESSION['name'] ?? 'Admin');
?>

<style>

:root {
  --ch-red:     #B91C1C;
  --ch-red2:    #DC2626;
  --ch-surf:    #FFFFFF;
  --ch-bg:      #F3F4F6;
  --ch-bdr:     #E5E7EB;
  --ch-txt:     #111827;
  --ch-sub:     #6B7280;
  --ch-mine:    #B91C1C;
  --ch-their:   #F3F4F6;
  --ch-shadow:  0 20px 60px rgba(0,0,0,.18), 0 4px 20px rgba(0,0,0,.12);
  --ch-radius:  16px;
  --ch-z:       9000;
}

#ch-bubble {
  position: fixed;
  bottom: 28px; right: 28px;
  width: 56px; height: 56px;
  border-radius: 50%;
  background: linear-gradient(135deg, #B91C1C, #7F1D1D);
  box-shadow: 0 8px 24px rgba(185,28,28,.45);
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  z-index: var(--ch-z);
  transition: transform .2s, box-shadow .2s;
  border: none;
}
#ch-bubble:hover { transform: scale(1.08); box-shadow: 0 12px 32px rgba(185,28,28,.55); }
#ch-bubble svg   { width: 26px; height: 26px; fill: #fff; }

#ch-badge {
  position: absolute;
  top: -4px; right: -4px;
  min-width: 20px; height: 20px;
  background: #EF4444;
  color: #fff; font-size: 11px; font-weight: 700;
  border-radius: 10px; display: none;
  align-items: center; justify-content: center;
  padding: 0 4px; border: 2px solid #fff;
}

#ch-panel {
  position: fixed;
  bottom: 96px; right: 28px;
  width: 360px;
  height: 520px;
  background: var(--ch-surf);
  border-radius: var(--ch-radius);
  box-shadow: var(--ch-shadow);
  display: none; flex-direction: column;
  overflow: hidden;
  z-index: var(--ch-z);
  border: 1px solid var(--ch-bdr);
  font-family: 'Inter', system-ui, sans-serif;
}
#ch-panel.visible { display: flex; }

.ch-ph {
  background: linear-gradient(135deg, #7F1D1D 0%, #B91C1C 100%);
  padding: 14px 16px;
  display: flex; align-items: center; gap: 10px;
  flex-shrink: 0;
}
.ch-ph-title { color: #fff; font-size: 15px; font-weight: 700; flex: 1; }
.ch-ph-actions { display: flex; gap: 6px; }
.ch-ph-btn {
  width: 30px; height: 30px; border-radius: 8px;
  background: rgba(255,255,255,.15); border: none;
  color: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center;
  transition: background .15s;
}
.ch-ph-btn:hover { background: rgba(255,255,255,.28); }
.ch-ph-btn svg { width: 16px; height: 16px; fill: #fff; }

.ch-tabs {
  display: flex; border-bottom: 1px solid var(--ch-bdr);
  flex-shrink: 0;
}
.ch-tab {
  flex: 1; padding: 10px; text-align: center;
  font-size: 12px; font-weight: 600; color: var(--ch-sub);
  cursor: pointer; transition: all .15s; border: none; background: none;
  border-bottom: 2px solid transparent;
}
.ch-tab.active { color: var(--ch-red); border-bottom-color: var(--ch-red); }

#ch-conv-list {
  flex: 1; overflow-y: auto; padding: 8px;
  display: flex; flex-direction: column; gap: 2px;
}
.ch-conv-item {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 10px; border-radius: 10px; cursor: pointer;
  transition: background .13s; text-decoration: none; color: inherit;
}
.ch-conv-item:hover { background: var(--ch-bg); }
.ch-conv-av {
  width: 40px; height: 40px; border-radius: 50%; flex-shrink: 0;
  background: linear-gradient(135deg, #B91C1C, #7F1D1D);
  display: flex; align-items: center; justify-content: center;
  font-size: 15px; font-weight: 700; color: #fff;
}
.ch-conv-info { flex: 1; min-width: 0; }
.ch-conv-name { font-size: 13px; font-weight: 600; color: var(--ch-txt); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.ch-conv-preview { font-size: 12px; color: var(--ch-sub); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px; }
.ch-conv-meta { text-align: right; flex-shrink: 0; }
.ch-conv-time { font-size: 11px; color: var(--ch-sub); }
.ch-conv-unread {
  display: inline-block; background: var(--ch-red); color: #fff;
  font-size: 11px; font-weight: 700; min-width: 18px; height: 18px;
  border-radius: 9px; padding: 0 5px; line-height: 18px; text-align: center;
  margin-top: 4px;
}

#ch-people-list {
  flex: 1; overflow-y: auto; padding: 8px;
  display: none; flex-direction: column; gap: 2px;
}
.ch-person-item {
  display: flex; align-items: center; gap: 10px;
  padding: 10px; border-radius: 10px; cursor: pointer;
  transition: background .13s;
}
.ch-person-item:hover { background: var(--ch-bg); }

.ch-empty {
  flex: 1; display: flex; flex-direction: column;
  align-items: center; justify-content: center; gap: 8px;
  color: var(--ch-sub); font-size: 13px; padding: 20px;
}
.ch-empty svg { width: 48px; height: 48px; opacity: .3; }

.ch-loading {
  flex: 1; display: flex; align-items: center; justify-content: center;
}
.ch-spinner {
  width: 28px; height: 28px; border: 3px solid var(--ch-bdr);
  border-top-color: var(--ch-red); border-radius: 50%;
  animation: chSpin .7s linear infinite;
}
@keyframes chSpin { to { transform: rotate(360deg); } }

#ch-thread {
  display: none; flex-direction: column; flex: 1; overflow: hidden;
}
.ch-thread-hd {
  display: flex; align-items: center; gap: 10px;
  padding: 12px 14px; border-bottom: 1px solid var(--ch-bdr);
  flex-shrink: 0;
}
.ch-back {
  width: 28px; height: 28px; border-radius: 8px; border: none;
  background: var(--ch-bg); cursor: pointer; display: flex;
  align-items: center; justify-content: center;
}
.ch-back svg { width: 14px; height: 14px; fill: var(--ch-txt); }
.ch-thread-name { font-size: 14px; font-weight: 700; flex: 1; color: var(--ch-txt); }
.ch-thread-status { font-size: 11px; color: #10B981; font-weight: 500; }

.ch-fullscreen-btn {
  width: 28px; height: 28px; border-radius: 8px; border: none;
  background: var(--ch-bg); cursor: pointer; display: flex;
  align-items: center; justify-content: center;
}
.ch-fullscreen-btn svg { width: 14px; height: 14px; fill: var(--ch-txt); }

.ch-msgs {
  flex: 1; overflow-y: auto; padding: 14px; display: flex;
  flex-direction: column; gap: 8px;
}
.ch-msg-group { display: flex; flex-direction: column; gap: 3px; }
.ch-msg-group.mine { align-items: flex-end; }
.ch-msg-group.theirs { align-items: flex-start; }

.ch-sender-name {
  font-size: 11px; color: var(--ch-sub); font-weight: 600;
  padding: 0 12px; margin-bottom: 2px;
}
.ch-bubble {
  max-width: 78%; padding: 9px 14px; border-radius: 18px;
  font-size: 13px; line-height: 1.5; word-break: break-word;
}
.mine .ch-bubble {
  background: var(--ch-mine); color: #fff;
  border-bottom-right-radius: 4px;
}
.theirs .ch-bubble {
  background: var(--ch-their); color: var(--ch-txt);
  border-bottom-left-radius: 4px;
}
.ch-msg-time {
  font-size: 10px; color: var(--ch-sub);
  padding: 0 12px; margin-top: 2px;
}

.ch-input-bar {
  display: flex; align-items: center; gap: 8px;
  padding: 10px 12px; border-top: 1px solid var(--ch-bdr);
  flex-shrink: 0; background: var(--ch-surf);
}
.ch-input {
  flex: 1; border: 1px solid var(--ch-bdr); border-radius: 22px;
  padding: 9px 16px; font-size: 13px; outline: none;
  font-family: inherit; resize: none; max-height: 100px; line-height: 1.4;
  transition: border-color .15s;
  background: var(--ch-bg);
}
.ch-input:focus { border-color: var(--ch-red); background: #fff; }
.ch-send {
  width: 36px; height: 36px; border-radius: 50%; border: none;
  background: linear-gradient(135deg, #B91C1C, #7F1D1D);
  color: #fff; cursor: pointer; display: flex;
  align-items: center; justify-content: center; flex-shrink: 0;
  transition: transform .15s, box-shadow .15s;
}
.ch-send:hover { transform: scale(1.08); box-shadow: 0 4px 12px rgba(185,28,28,.4); }
.ch-send svg { width: 16px; height: 16px; fill: #fff; }

#ch-fullscreen {
  display: none;
  position: fixed;

  top: 64px;       
  left: 240px;     
  right: 0;
  bottom: 0;
  background: var(--ch-surf);
  z-index: 8500;   
  flex-direction: row;
  border-left: 1px solid var(--ch-bdr);
  font-family: 'Inter', system-ui, sans-serif;
  animation: chSlideIn .22s ease;
}
@keyframes chSlideIn {
  from { opacity: 0; transform: translateX(24px); }
  to   { opacity: 1; transform: translateX(0); }
}
#ch-fullscreen.visible { display: flex; }

.chfs-sidebar {
  width: 300px; flex-shrink: 0;
  border-right: 1px solid var(--ch-bdr);
  display: flex; flex-direction: column;
  overflow: hidden;
  background: var(--ch-surf);
}
.chfs-sidebar-hd {
  padding: 16px 18px; border-bottom: 1px solid var(--ch-bdr);
  display: flex; align-items: center; gap: 10px; flex-shrink: 0;
}
.chfs-sidebar-hd h2 { font-size: 18px; font-weight: 800; flex: 1; color: var(--ch-txt); }
.chfs-close {
  width: 32px; height: 32px; border-radius: 8px; border: none;
  background: #FEF2F2; color: var(--ch-red); cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  font-size: 20px; line-height: 1; font-weight: 700;
}
.chfs-close:hover { background: #FEE2E2; }

.chfs-search {
  padding: 10px 14px; border-bottom: 1px solid var(--ch-bdr); flex-shrink: 0;
}
.chfs-search input {
  width: 100%; padding: 8px 14px; border: 1px solid var(--ch-bdr);
  border-radius: 22px; font-size: 13px; outline: none; background: var(--ch-bg);
}
.chfs-search input:focus { border-color: var(--ch-red); }

.chfs-conv-list {
  flex: 1; overflow-y: auto; padding: 8px; display: flex; flex-direction: column; gap: 2px;
}

.chfs-new-chat {
  margin: 0 14px 10px; padding: 10px; border-radius: 10px;
  background: #FEF2F2; border: 1px dashed var(--ch-red);
  color: var(--ch-red); font-size: 13px; font-weight: 600;
  cursor: pointer; text-align: center; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center; gap: 6px;
}
.chfs-new-chat:hover { background: #FEE2E2; }

.chfs-main {
  flex: 1; display: flex; flex-direction: column; overflow: hidden;
}

.chfs-thread-hd {
  padding: 16px 20px; border-bottom: 1px solid var(--ch-bdr);
  display: flex; align-items: center; gap: 12px; flex-shrink: 0;
  background: var(--ch-surf);
}
.chfs-av {
  width: 44px; height: 44px; border-radius: 50%;
  background: linear-gradient(135deg, #B91C1C, #7F1D1D);
  display: flex; align-items: center; justify-content: center;
  font-size: 18px; font-weight: 700; color: #fff; flex-shrink: 0;
}
.chfs-name { font-size: 16px; font-weight: 700; color: var(--ch-txt); }
.chfs-status { font-size: 12px; color: #10B981; font-weight: 500; margin-top: 2px; }

.chfs-empty {
  flex: 1; display: flex; flex-direction: column;
  align-items: center; justify-content: center; gap: 12px;
  color: var(--ch-sub); background: var(--ch-bg);
}
.chfs-empty-icon { font-size: 48px; opacity: .4; }
.chfs-empty h3 { font-size: 18px; font-weight: 700; color: var(--ch-txt); }
.chfs-empty p  { font-size: 13px; max-width: 260px; text-align: center; }

#ch-facility-panel {
  display: none;
  flex: 1; flex-direction: column; overflow: hidden; background: var(--ch-bg);
}
#ch-facility-panel.visible { display: flex; }

.chfs-facility-hd {
  padding: 16px 20px; border-bottom: 1px solid var(--ch-bdr);
  display: flex; align-items: center; gap: 12px;
  background: var(--ch-surf); flex-shrink: 0;
}
.chfs-facility-hd h3 { font-size: 15px; font-weight: 700; flex: 1; color: var(--ch-txt); }

.chfs-facility-body {
  flex: 1; overflow-y: auto; padding: 20px;
  display: flex; flex-direction: column; gap: 14px;
}

.ch-form-group { display: flex; flex-direction: column; gap: 5px; }
.ch-form-label { font-size: 12px; font-weight: 600; color: var(--ch-sub); text-transform: uppercase; letter-spacing: .4px; }
.ch-form-input {
  padding: 10px 14px; border: 1px solid var(--ch-bdr); border-radius: 10px;
  font-size: 14px; font-family: inherit; outline: none; background: var(--ch-surf);
}
.ch-form-input:focus { border-color: var(--ch-red); }
.ch-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.ch-form-btn {
  padding: 12px 24px; background: linear-gradient(135deg, #B91C1C, #7F1D1D);
  color: #fff; border: none; border-radius: 10px; font-size: 14px; font-weight: 600;
  cursor: pointer; transition: opacity .15s; font-family: inherit;
}
.ch-form-btn:hover { opacity: .9; }
.ch-form-btn.secondary {
  background: var(--ch-bg); color: var(--ch-txt); border: 1px solid var(--ch-bdr);
}

#ch-toast {
  position: fixed; bottom: 100px; left: 50%; transform: translateX(-50%);
  background: #111; color: #fff; padding: 10px 20px; border-radius: 24px;
  font-size: 13px; font-weight: 500; z-index: 10000;
  opacity: 0; transition: opacity .3s; pointer-events: none; white-space: nowrap;
}
#ch-toast.show { opacity: 1; }

@media (max-width: 768px) {
  #ch-fullscreen {
    top: 0 !important; left: 0 !important;
    z-index: 9500;
  }
  .chfs-sidebar { width: 100%; }
  .chfs-main    { display: none; }
  #ch-fullscreen.visible .chfs-main.show { display: flex; }

  #ch-bubble { bottom: 80px; right: 16px; }
  #ch-panel  { bottom: 144px; right: 8px; width: calc(100vw - 16px); }
}

.ch-msgs::-webkit-scrollbar,
.chfs-conv-list::-webkit-scrollbar,
#ch-conv-list::-webkit-scrollbar { width: 4px; }
.ch-msgs::-webkit-scrollbar-thumb,
.chfs-conv-list::-webkit-scrollbar-thumb,
#ch-conv-list::-webkit-scrollbar-thumb { background: #D1D5DB; border-radius: 2px; }

.ch-date-divider {
  text-align: center; font-size: 11px; color: var(--ch-sub);
  font-weight: 500; margin: 8px 0;
  display: flex; align-items: center; gap: 8px;
}
.ch-date-divider::before,
.ch-date-divider::after { content:''; flex:1; height:1px; background:var(--ch-bdr); }

.ch-typing {
  display: flex; gap: 4px; align-items: center; padding: 6px 12px;
  background: var(--ch-their); border-radius: 18px; border-bottom-left-radius: 4px;
  width: fit-content;
}
.ch-typing span {
  width: 6px; height: 6px; background: var(--ch-sub);
  border-radius: 50%; animation: chTyping 1.2s infinite;
}
.ch-typing span:nth-child(2) { animation-delay: .2s; }
.ch-typing span:nth-child(3) { animation-delay: .4s; }
@keyframes chTyping {
  0%, 60%, 100% { transform: translateY(0); }
  30%            { transform: translateY(-6px); }
}
</style>

<button id="ch-bubble" title="Admin Chat" onclick="chatTogglePanel()">
  <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>
  <div id="ch-badge"></div>
</button>

<div id="ch-panel">
  <div class="ch-ph">
    <span class="ch-ph-title">💬 Admin Chat</span>
    <div class="ch-ph-actions">

      <button class="ch-ph-btn" title="Full Screen" onclick="chatOpenFullscreen()">
        <svg viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>
      </button>

      <button class="ch-ph-btn" title="Close" onclick="chatClosePanel()">
        <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
      </button>
    </div>
  </div>

  <div class="ch-tabs">
    <button class="ch-tab active" id="ch-tab-chats"  onclick="chatSwitchTab('chats')">Chats</button>
    <button class="ch-tab"        id="ch-tab-people" onclick="chatSwitchTab('people')">New Chat</button>
  </div>

  <div id="ch-conv-list">
    <div class="ch-loading"><div class="ch-spinner"></div></div>
  </div>

  <div id="ch-people-list"></div>

  <div id="ch-thread">
    <div class="ch-thread-hd">
      <button class="ch-back" onclick="chatCloseThread()">
        <svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
      </button>
      <div style="flex:1">
        <div class="ch-thread-name" id="ch-thread-name">Chat</div>
        <div class="ch-thread-status">Admin</div>
      </div>
      <button class="ch-fullscreen-btn" title="Full Screen" onclick="chatOpenFullscreen()">
        <svg viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>
      </button>
    </div>
    <div class="ch-msgs" id="ch-msgs"></div>
    <div class="ch-input-bar">
      <textarea class="ch-input" id="ch-input" placeholder="Type a message…" rows="1"
        onkeydown="chatInputKeydown(event)" oninput="chatAutoResize(this)"></textarea>
      <button class="ch-send" onclick="chatSendMessage()">
        <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
      </button>
    </div>
  </div>
</div>

<div id="ch-fullscreen">

  <div class="chfs-sidebar">
    <div class="chfs-sidebar-hd">
      <h2>Messages</h2>
      <button class="chfs-close" onclick="chatCloseFullscreen()" title="Close">✕</button>
    </div>
    <div class="chfs-search">
      <input type="text" id="chfs-search" placeholder="🔍  Search conversations…" oninput="chatFilterConvs(this.value)">
    </div>
    <div class="chfs-conv-list" id="chfs-conv-list">
      <div class="ch-loading"><div class="ch-spinner"></div></div>
    </div>
    <div class="chfs-new-chat" onclick="chatShowPeople(true)">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/></svg>
      New Conversation
    </div>
  </div>

  <div class="chfs-main" id="chfs-main">

    <div class="chfs-empty" id="chfs-empty">
      <div class="chfs-empty-icon">💬</div>
      <h3>Admin Messaging</h3>
      <p>Select a conversation or start a new chat. Messages are visible only to admins.</p>
    </div>

    <div id="chfs-thread" style="display:none;flex-direction:column;flex:1;overflow:hidden;">
      <div class="chfs-thread-hd">
        <div class="chfs-av" id="chfs-av">?</div>
        <div style="flex:1">
          <div class="chfs-name" id="chfs-name">Admin</div>
          <div class="chfs-status">● Online</div>
        </div>

        <button onclick="chatShowFacilityForm()" style="padding:8px 14px;border-radius:8px;border:1px solid var(--ch-bdr);background:var(--ch-bg);font-size:12px;font-weight:600;cursor:pointer;color:var(--ch-txt);">
          📅 Facility Request
        </button>
      </div>
      <div class="ch-msgs" id="chfs-msgs"></div>
      <div class="ch-input-bar">
        <textarea class="ch-input" id="chfs-input" placeholder="Type a message…" rows="1"
          onkeydown="chatFsInputKeydown(event)" oninput="chatAutoResize(this)"></textarea>
        <button class="ch-send" onclick="chatFsSendMessage()">
          <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
        </button>
      </div>
    </div>

    <div id="chfs-people" style="display:none;flex-direction:column;flex:1;overflow:hidden;">
      <div class="chfs-thread-hd">
        <button class="ch-back" onclick="chatHidePeople()">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
        </button>
        <div class="chfs-name">Start a New Chat</div>
      </div>
      <div style="flex:1;overflow-y:auto;padding:10px;" id="chfs-people-list"></div>
    </div>

    <div id="ch-facility-panel">
      <div class="chfs-facility-hd">
        <button class="ch-back" onclick="chatHideFacilityForm()">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
        </button>
        <h3>📅 Facility Reservation Request</h3>
      </div>
      <div class="chfs-facility-body">
        <p style="font-size:13px;color:var(--ch-sub);">Fill in the details below. This will be sent as a message in the current chat thread for admin review.</p>
        <div class="ch-form-row">
          <div class="ch-form-group">
            <label class="ch-form-label">Date</label>
            <input type="date" class="ch-form-input" id="fac-date">
          </div>
          <div class="ch-form-group">
            <label class="ch-form-label">Time</label>
            <input type="time" class="ch-form-input" id="fac-time">
          </div>
        </div>
        <div class="ch-form-group">
          <label class="ch-form-label">Participants (names or count)</label>
          <input type="text" class="ch-form-input" id="fac-participants" placeholder="e.g. HR Team, 8 people">
        </div>
        <div class="ch-form-group">
          <label class="ch-form-label">Equipment Needed</label>
          <input type="text" class="ch-form-input" id="fac-equipment" placeholder="e.g. Projector, Whiteboard">
        </div>
        <div class="ch-form-group">
          <label class="ch-form-label">Purpose / Agenda</label>
          <textarea class="ch-form-input" id="fac-purpose" rows="3" placeholder="Describe the purpose of this reservation…"></textarea>
        </div>
        <div style="display:flex;gap:10px;margin-top:4px;">
          <button class="ch-form-btn secondary" onclick="chatHideFacilityForm()">Cancel</button>
          <button class="ch-form-btn" onclick="chatSendFacilityRequest()">Send Request</button>
        </div>
      </div>
    </div>

  </div>
</div>

<div id="ch-toast"></div>

<script>
(function() {
  'use strict';

  const CHAT_API = 'chat_system.php';
  let state = {
    panelOpen:      false,
    fullscreen:     false,
    activeConvId:   null,
    activeConvName: '',
    conversations:  [],
    lastMsgTime:    null,
    pollInterval:   null,
    badgeInterval:  null,
    tab:            'chats',   
  };

  const $  = id => document.getElementById(id);
  const el = (tag, cls, html='') => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html) e.innerHTML = html;
    return e;
  };

  async function api(params) {
    const fd = new FormData();
    Object.entries(params).forEach(([k,v]) => fd.append(k, v));
    try {
      const r = await fetch(CHAT_API, { method:'POST', body: fd });
      return await r.json();
    } catch (e) {
      console.error('Chat API error', e);
      return { success: false };
    }
  }

  function toast(msg) {
    const t = $('ch-toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2800);
  }

  function fmtTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const now = new Date();
    const isToday = d.toDateString() === now.toDateString();
    if (isToday) return d.toLocaleTimeString('en-PH',{hour:'2-digit',minute:'2-digit'});
    return d.toLocaleDateString('en-PH',{month:'short',day:'numeric'});
  }

  function fmtFullTime(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleTimeString('en-PH',{hour:'2-digit',minute:'2-digit'});
  }

  function fmtDateDivider(iso) {
    const d = new Date(iso);
    const now = new Date();
    if (d.toDateString() === now.toDateString()) return 'Today';
    const yest = new Date(); yest.setDate(yest.getDate()-1);
    if (d.toDateString() === yest.toDateString()) return 'Yesterday';
    return d.toLocaleDateString('en-PH',{weekday:'short',month:'short',day:'numeric'});
  }

  function initial(name) {
    return (name || '?')[0].toUpperCase();
  }

  function renderConvItem(conv, container, onClick) {
    const names = (conv.members || []).join(', ') || 'Unknown';
    const item = el('div', 'ch-conv-item');
    item.innerHTML = `
      <div class="ch-conv-av">${initial(names)}</div>
      <div class="ch-conv-info">
        <div class="ch-conv-name">${names}</div>
        <div class="ch-conv-preview">${conv.last_message ? escHtml(conv.last_message.substring(0,40)) : 'No messages yet'}</div>
      </div>
      <div class="ch-conv-meta">
        <div class="ch-conv-time">${fmtTime(conv.last_time)}</div>
        ${conv.unread > 0 ? `<div class="ch-conv-unread">${conv.unread}</div>` : ''}
      </div>`;
    item.onclick = () => onClick(conv);
    container.appendChild(item);
  }

  function escHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
  }

  async function loadConversations() {
    const res = await api({ action: 'get_conversations' });
    if (!res.success) return;
    state.conversations = res.data || [];
    renderConvList();
    renderFsConvList();
  }

  function renderConvList() {
    const container = $('ch-conv-list');
    container.innerHTML = '';
    if (state.conversations.length === 0) {
      container.innerHTML = `<div class="ch-empty">
        <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
        <div>No conversations yet.<br>Use "New Chat" to start one.</div>
      </div>`;
      return;
    }
    state.conversations.forEach(c => renderConvItem(c, container, cv => chatOpenThread(cv.id, (cv.members||[]).join(', ') || 'Admin')));
  }

  function renderFsConvList(filter='') {
    const container = $('chfs-conv-list');
    container.innerHTML = '';
    const filtered = filter
      ? state.conversations.filter(c => (c.members||[]).join(' ').toLowerCase().includes(filter.toLowerCase()))
      : state.conversations;

    if (filtered.length === 0) {
      container.innerHTML = `<div style="padding:20px;text-align:center;color:var(--ch-sub);font-size:13px;">No conversations found.</div>`;
      return;
    }
    filtered.forEach(c => renderConvItem(c, container, cv => {
      chatOpenFsThread(cv.id, (cv.members||[]).join(', ') || 'Admin');
    }));
  }

  async function loadMessages(convId, container, isNew = false) {
    const params = { action: 'get_messages', conversation_id: convId };
    if (!isNew && state.lastMsgTime) params.since = state.lastMsgTime;

    const res = await api(params);

    if (isNew) {
      container.innerHTML = '';
      if (!res.success) {
        container.innerHTML = '<div class="ch-empty"><div>Could not load messages.</div></div>';
        return;
      }
      if (!res.data || !res.data.length) {
        container.innerHTML = '<div class="ch-empty"><div style="font-size:13px;color:var(--ch-sub)">No messages yet.<br>Say hello! 👋</div></div>';
        return;
      }
    } else {

      if (!res.success || !res.data || !res.data.length) return;
    }

    let lastDate = null;
    res.data.forEach(msg => {
      const msgDate = fmtDateDivider(msg.created_at);
      if (msgDate !== lastDate) {
        lastDate = msgDate;
        const divider = el('div', 'ch-date-divider', msgDate);
        container.appendChild(divider);
      }
      appendMessage(msg, container);
      state.lastMsgTime = msg.created_at;
    });

    container.scrollTop = container.scrollHeight;
  }

  function appendMessage(msg, container) {
    const group = el('div', 'ch-msg-group ' + (msg.is_mine ? 'mine' : 'theirs'));
    if (!msg.is_mine) {
      const senderEl = el('div', 'ch-sender-name', escHtml(msg.sender_name || 'Admin'));
      group.appendChild(senderEl);
    }
    const bubble = el('div', 'ch-bubble', escHtml(msg.content));
    const time   = el('div', 'ch-msg-time', fmtFullTime(msg.created_at));
    group.appendChild(bubble);
    group.appendChild(time);
    container.appendChild(group);
  }

  function startPoll() {
    stopPoll();
    state.pollInterval = setInterval(async () => {
      if (!state.activeConvId) return;

      const msgs   = $('ch-msgs');
      const thread = $('ch-thread');
      if (msgs && thread && thread.style.display !== 'none') {
        await loadMessages(state.activeConvId, msgs, false);
      }

      const fsMsgs   = $('chfs-msgs');
      const fsThread = $('chfs-thread');
      if (fsMsgs && fsThread && fsThread.style.display !== 'none') {
        await loadMessages(state.activeConvId, fsMsgs, false);
      }
    }, 3000);
  }

  function stopPoll() {
    if (state.pollInterval) clearInterval(state.pollInterval);
    state.pollInterval = null;
  }

  function startBadgePoll() {
    updateBadge();
    state.badgeInterval = setInterval(updateBadge, 15000);
  }

  async function updateBadge() {
    const res = await api({ action: 'get_unread_count' });
    if (!res.success) return;
    const badge = $('ch-badge');
    if (res.count > 0) {
      badge.textContent = res.count > 99 ? '99+' : res.count;
      badge.style.display = 'flex';
    } else {
      badge.style.display = 'none';
    }
  }

  window.chatTogglePanel = function() {
    if (state.fullscreen) { chatCloseFullscreen(); return; }
    state.panelOpen = !state.panelOpen;
    $('ch-panel').classList.toggle('visible', state.panelOpen);
    if (state.panelOpen) {
      loadConversations();
      chatSwitchTab('chats');
    }
  };

  window.chatClosePanel = function() {
    state.panelOpen = false;
    $('ch-panel').classList.remove('visible');
    chatCloseThread();
  };

  window.chatSwitchTab = function(tab) {
    state.tab = tab;
    $('ch-tab-chats').classList.toggle('active', tab === 'chats');
    $('ch-tab-people').classList.toggle('active', tab === 'people');
    $('ch-conv-list').style.display  = tab === 'chats'  ? 'flex' : 'none';
    $('ch-people-list').style.display= tab === 'people' ? 'flex' : 'none';
    $('ch-thread').style.display     = 'none';
    if (tab === 'people') loadPeople(false);
  };

  async function loadPeople(isFullscreen) {
    const res = await api({ action: 'get_admins' });
    if (!res.success) return;
    const container = isFullscreen ? $('chfs-people-list') : $('ch-people-list');
    container.innerHTML = '';
    if (!res.data.length) {
      container.innerHTML = '<div style="padding:20px;text-align:center;color:var(--ch-sub);font-size:13px;">No other admins found.</div>';
      return;
    }
    res.data.forEach(admin => {
      const item = el('div', 'ch-person-item');
      item.innerHTML = `
        <div class="ch-conv-av">${initial(admin.display_name)}</div>
        <div class="ch-conv-info">
          <div class="ch-conv-name">${escHtml(admin.display_name)}</div>
          <div class="ch-conv-preview">${escHtml(admin.email || admin.role || '')}</div>
        </div>`;
      item.onclick = async () => {
        const r = await api({ action: 'start_conversation', target_admin_id: admin.id });
        if (r.success) {
          await loadConversations();
          if (isFullscreen) {
            chatHidePeople();
            chatOpenFsThread(r.conversation_id, admin.display_name);
          } else {
            chatOpenThread(r.conversation_id, admin.display_name);
          }
        } else {
          toast('Failed to start conversation');
        }
      };
      container.appendChild(item);
    });
  }

  window.chatOpenThread = async function(convId, name) {
    state.activeConvId   = convId;
    state.activeConvName = name;
    state.lastMsgTime    = null;

    $('ch-thread-name').textContent = name || 'Chat';
    $('ch-conv-list').style.display  = 'none';
    $('ch-people-list').style.display= 'none';
    $('ch-tabs').style.display       = 'none';
    $('ch-thread').style.display     = 'flex';
    $('ch-msgs').innerHTML           = '<div class="ch-loading"><div class="ch-spinner"></div></div>';

    await loadMessages(convId, $('ch-msgs'), true);
    startPoll();
  };

  window.chatCloseThread = function() {
    $('ch-thread').style.display    = 'none';
    $('ch-tabs').style.display      = 'flex';
    $('ch-conv-list').style.display = 'flex';
    stopPoll();
    state.activeConvId = null;
  };

  window.chatOpenFsThread = async function(convId, name) {
    state.activeConvId   = convId;
    state.activeConvName = name;
    state.lastMsgTime    = null;

    $('chfs-empty').style.display   = 'none';
    $('chfs-thread').style.display  = 'flex';
    $('chfs-people').style.display  = 'none';
    $('ch-facility-panel').style.display = 'none';
    $('ch-facility-panel').classList.remove('visible');

    $('chfs-name').textContent = name || 'Admin';
    $('chfs-av').textContent   = initial(name);
    $('chfs-msgs').innerHTML   = '<div class="ch-loading"><div class="ch-spinner"></div></div>';

    await loadMessages(convId, $('chfs-msgs'), true);
    startPoll();

    document.querySelectorAll('#chfs-conv-list .ch-conv-item').forEach(el => el.style.background = '');
  };

  window.chatOpenFullscreen = function() {

    const sidebar = document.querySelector('.sidebar');
    const topbar  = document.querySelector('.topbar') || document.querySelector('header.topbar');
    const fs      = $('ch-fullscreen');

    if (sidebar) {
      const sRect = sidebar.getBoundingClientRect();
      fs.style.left = sRect.width + 'px';
    }
    if (topbar) {
      const tRect = topbar.getBoundingClientRect();
      fs.style.top = (tRect.top + tRect.height) + 'px';
    }

    state.fullscreen = true;
    fs.classList.add('visible');
    $('ch-panel').classList.remove('visible');
    state.panelOpen = false;

    loadConversations();

    if (state.activeConvId) {
      chatOpenFsThread(state.activeConvId, state.activeConvName);
    }
  };

  window.chatCloseFullscreen = function() {
    state.fullscreen = false;
    $('ch-fullscreen').classList.remove('visible');
    stopPoll();
    state.activeConvId = null;
  };

  window.chatShowPeople = function(fs=false) {
    if (fs) {
      $('chfs-empty').style.display  = 'none';
      $('chfs-thread').style.display = 'none';
      $('chfs-people').style.display = 'flex';
      loadPeople(true);
    }
  };

  window.chatHidePeople = function() {
    $('chfs-people').style.display  = 'none';
    $('chfs-empty').style.display   = 'flex';
  };

  window.chatSendMessage = async function() {
    const input = $('ch-input');
    const content = input.value.trim();
    if (!content || !state.activeConvId) return;
    input.value = '';
    input.style.height = 'auto';

    const res = await api({ action: 'send_message', conversation_id: state.activeConvId, content });
    if (res.success) {
      const msg = res.data;
      msg.is_mine = true;
      const msgsEl = $('ch-msgs');
      appendMessage(msg, msgsEl);
      msgsEl.scrollTop = msgsEl.scrollHeight;
    } else {
      toast('Failed to send message');
      input.value = content;
    }
  };

  window.chatInputKeydown = function(e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); chatSendMessage(); }
  };

  window.chatFsSendMessage = async function() {
    const input = $('chfs-input');
    const content = input.value.trim();
    if (!content || !state.activeConvId) return;
    input.value = '';
    input.style.height = 'auto';

    const res = await api({ action: 'send_message', conversation_id: state.activeConvId, content });
    if (res.success) {
      const msg = res.data;
      msg.is_mine = true;
      const msgsEl = $('chfs-msgs');
      appendMessage(msg, msgsEl);
      msgsEl.scrollTop = msgsEl.scrollHeight;
    } else {
      toast('Failed to send message');
      input.value = content;
    }
  };

  window.chatFsInputKeydown = function(e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); chatFsSendMessage(); }
  };

  window.chatAutoResize = function(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 100) + 'px';
  };

  window.chatFilterConvs = function(val) {
    renderFsConvList(val);
  };

  window.chatShowFacilityForm = function() {
    $('chfs-thread').style.display        = 'none';
    $('ch-facility-panel').style.display  = 'flex';
    $('ch-facility-panel').classList.add('visible');

    $('fac-date').value = new Date().toISOString().split('T')[0];
  };

  window.chatHideFacilityForm = function() {
    $('ch-facility-panel').style.display  = 'none';
    $('ch-facility-panel').classList.remove('visible');
    if (state.activeConvId) {
      $('chfs-thread').style.display = 'flex';
    }
  };

  window.chatSendFacilityRequest = async function() {
    const date         = $('fac-date').value;
    const time         = $('fac-time').value;
    const participants = $('fac-participants').value.trim();
    const equipment    = $('fac-equipment').value.trim();
    const purpose      = $('fac-purpose').value.trim();

    if (!date || !time || !purpose) {
      toast('Please fill in Date, Time, and Purpose');
      return;
    }
    if (!state.activeConvId) {
      toast('Please select a conversation first');
      return;
    }

    const msg = `📅 FACILITY RESERVATION REQUEST\n`
      + `──────────────────────\n`
      + `Date:         ${date}\n`
      + `Time:         ${time}\n`
      + `Participants: ${participants || '—'}\n`
      + `Equipment:    ${equipment || '—'}\n`
      + `Purpose:      ${purpose}`;

    const res = await api({ action: 'send_message', conversation_id: state.activeConvId, content: msg });
    if (res.success) {
      toast('✅ Facility request sent!');

      ['fac-date','fac-time','fac-participants','fac-equipment','fac-purpose'].forEach(id => { const el = $(id); if (el) el.value = ''; });
      chatHideFacilityForm();

      await loadMessages(state.activeConvId, $('chfs-msgs'), true);
    } else {
      toast('Failed to send request');
    }
  };

  document.addEventListener('click', function(e) {
    const panel  = $('ch-panel');
    const bubble = $('ch-bubble');
    const fs     = $('ch-fullscreen');
    if (!panel || !bubble) return;
    if (!panel.contains(e.target) && !bubble.contains(e.target) && !fs.contains(e.target)) {
      if (state.panelOpen) chatClosePanel();
    }
  });

  document.addEventListener('DOMContentLoaded', function() {
    startBadgePoll();

    window.addEventListener('resize', function() {
      if (state.fullscreen) chatOpenFullscreen();
    });
  });

  window._chatState = state;

})();
</script>