<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit;
}

define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json']]);
    $resp = curl_exec($ch); curl_close($ch);
    $data = json_decode($resp, true);
    return is_array($data) ? $data : [];
}

function sb_post(string $table, array $body): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($body),CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json','Prefer: return=representation']]);
    $resp = curl_exec($ch); curl_close($ch);
    $data = json_decode($resp, true);
    return is_array($data) ? $data : [];
}

function sb_patch(string $table, array $filters, array $body): bool {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'PATCH',CURLOPT_POSTFIELDS=>json_encode($body),CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json','Prefer: return=minimal']]);
    $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return $code >= 200 && $code < 300;
}

$today = date('Y-m-d');
$last30Days = date('Y-m-d', strtotime('-30 days'));
$last7Days = date('Y-m-d', strtotime('-7 days'));

$reports_raw = sb_get('core2_reports', [
    'select' => 'report_id,report_type,severity,status,description,reported_at,resolved_at,driver_id,customer_id,ride_id,booking_id',
    'order' => 'reported_at.desc',
    'limit' => '500'
]);

$customer_ids = array_filter(array_unique(array_column($reports_raw, 'customer_id')));
$customer_map = [];
if (!empty($customer_ids)) {
    $customers = sb_get('core2_customers', [
        'select' => 'customer_id,name,email,phone',
        'customer_id' => 'in.(' . implode(',', array_map('intval', $customer_ids)) . ')'
    ]);
    foreach ($customers as $c) {
        $customer_map[(int)$c['customer_id']] = $c;
    }
}

$driver_ids = array_filter(array_unique(array_column($reports_raw, 'driver_id')));
$driver_map = [];
if (!empty($driver_ids)) {
    $drivers = sb_get('core2_drivers', [
        'select' => 'driver_id,full_name,license_number,contact_number,email',
        'driver_id' => 'in.(' . implode(',', array_map('intval', $driver_ids)) . ')'
    ]);
    foreach ($drivers as $d) {
        $driver_map[(int)$d['driver_id']] = $d;
    }
}

$booking_ids = array_filter(array_unique(array_column($reports_raw, 'booking_id')));
$booking_map = [];
if (!empty($booking_ids)) {
    $bookings = sb_get('core2_bookings', [
        'select' => 'booking_id,booking_reference,booking_status',
        'booking_id' => 'in.(' . implode(',', array_map('intval', $booking_ids)) . ')'
    ]);
    foreach ($bookings as $b) {
        $booking_map[(int)$b['booking_id']] = $b;
    }
}

$reports = [];
$critical_count = $open_count = $resolved_count = $pending_review_count = 0;
$severity_counts = ['Critical' => 0, 'High' => 0, 'Medium' => 0, 'Low' => 0];
$type_counts = [];

foreach ($reports_raw as $r) {
    $status = $r['status'] ?? 'Open';
    $severity = $r['severity'] ?? 'Medium';
    $report_type = $r['report_type'] ?? 'Other';

    if ($severity === 'Critical') $critical_count++;
    if (in_array($status, ['Open', 'Under Review'])) $open_count++;
    if (in_array($status, ['Resolved', 'Closed'])) $resolved_count++;
    if ($status === 'Under Review') $pending_review_count++;

    $severity_counts[$severity] = ($severity_counts[$severity] ?? 0) + 1;
    $type_counts[$report_type] = ($type_counts[$report_type] ?? 0) + 1;

    $reports[] = [
        'report_id' => $r['report_id'],
        'report_type' => $report_type,
        'severity' => $severity,
        'status' => $status,
        'description' => $r['description'] ?? '',
        'reported_at' => $r['reported_at'],
        'resolved_at' => $r['resolved_at'] ?? null,
        'driver_name' => $driver_map[(int)($r['driver_id'] ?? 0)]['full_name'] ?? 'Unknown Driver',
        'driver_license' => $driver_map[(int)($r['driver_id'] ?? 0)]['license_number'] ?? '',
        'customer_name' => $customer_map[(int)($r['customer_id'] ?? 0)]['name'] ?? 'Unknown Customer',
        'customer_email' => $customer_map[(int)($r['customer_id'] ?? 0)]['email'] ?? '',
        'booking_ref' => $booking_map[(int)($r['booking_id'] ?? 0)]['booking_reference'] ?? null
    ];
}

$total_reports = count($reports);
$compliance_score = $total_reports > 0 
    ? round(100 - (($open_count / $total_reports) * 100), 1) 
    : 100;

$resolved_reports = array_filter($reports, fn($r) => !empty($r['resolved_at']));
$avg_resolution_days = 0;
if (!empty($resolved_reports)) {
    $total_days = 0;
    foreach ($resolved_reports as $r) {
        $reported = strtotime($r['reported_at']);
        $resolved = strtotime($r['resolved_at']);
        $total_days += max(0, ($resolved - $reported) / 86400);
    }
    $avg_resolution_days = round($total_days / count($resolved_reports), 1);
}

$trend_data = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $count = 0;
    foreach ($reports as $r) {
        if (substr($r['reported_at'], 0, 10) === $date) {
            $count++;
        }
    }
    $trend_data[] = ['date' => $date, 'count' => $count];
}

$userName = htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin');
$userInitial = strtoupper(substr($userName, 0, 1));

function ico($path, $stroke = '#4A5568', $size = 18) {
    return "<svg width='$size' height='$size' viewBox='0 0 24 24' fill='none' stroke='$stroke' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>$path</svg>";
}

$iHome = "<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>";
$iBook = "<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>";
$iPay = "<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iCrm = "<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iGps = "<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/>";
$iBar = "<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>";
$iDoc = "<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/><line x1='16' y1='13' x2='8' y2='13'/><line x1='16' y1='17' x2='8' y2='17'/>";
$iOut = "<path d='M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'/><polyline points='16 17 21 12 16 7'/><line x1='21' y1='12' x2='9' y2='12'/>";
$iCheck = "<polyline points='20 6 9 17 4 12'/>";
$iX = "<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>";
$iInfo = "<circle cx='12' cy='12' r='10'/><line x1='12' y1='8' x2='12' y2='12'/><line x1='12' y1='16' x2='12.01' y2='16'/>";
$iEdit = "<path d='M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7'/><path d='M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z'/>";
$iRefresh = "<path d='M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2'/>";
$iSearch = "<circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/>";
$iDownload = "<path d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'/><polyline points='7 10 12 15 17 10'/><line x1='12' y1='15' x2='12' y2='3'/>";
$iFilter = "<polygon points='22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3'/>";
$iClock = "<circle cx='12' cy='12' r='10'/><polyline points='12 6 12 12 16 14'/>";
$iAlert = "<path d='M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9'/><path d='M13.73 21a2 2 0 0 1-3.46 0'/>";
$iShield = "<path d='M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z'/>";
$iUser = "<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>";
$iTruck = "<rect x='1' y='3' width='15' height='13'/><polygon points='16 8 20 8 23 11 23 16 16 16 16 8'/><circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/>";
$iBack = "<path d='M19 12H5M12 19l-7-7 7-7'/>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SOP Compliance & Audit Logs</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%}
:root{
  --g:#00D084;--gd:#00A86B;--gx:#005A38;--gg:rgba(0,208,132,.1);
  --bg:#F0F4F2;--surf:#fff;--surf2:#F7FAF8;--surf3:#EEF5F1;
  --bdr:#DDE8E2;--bdr2:#C8DDD5;
  --txt:#0D1F18;--txt2:#3A5248;--txt3:#7A9A8E;--txt4:#B0C8BC;
  --blue:#3B8EF0;--purple:#8B6FE8;--orange:#F07830;--red:#E84040;--yellow:#E8A020;
  --sb-bg:#991B1B;--sb-txt:#FECACA;--sb-txt2:#FCA5A5;
  --sb-bdr:rgba(255,255,255,.1);--sb-hover:rgba(255,255,255,.09);
  --sb-active:rgba(255,255,255,.16);--sb-active-bdr:rgba(255,255,255,.28);
  --sw:248px;--th:58px;--r:16px;--rs:10px;
  --shadow:0 1px 3px rgba(0,0,0,.04),0 4px 16px rgba(0,0,0,.06);
  --shadow-md:0 2px 8px rgba(0,0,0,.05),0 8px 28px rgba(0,0,0,.09);
}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--txt);-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit}
.trunc{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mono{font-family:'DM Mono',monospace}
.badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:3px 8px;border-radius:5px;text-transform:uppercase;letter-spacing:.4px}
.badge::before{content:'';width:5px;height:5px;border-radius:50%;flex-shrink:0}
.badge-green{background:rgba(0,208,132,.12);color:#008A58}.badge-green::before{background:#00A86B}
.badge-blue{background:rgba(59,142,240,.1);color:#1966C2}.badge-blue::before{background:#3B8EF0}
.badge-yellow{background:rgba(232,160,32,.12);color:#9A6A00}.badge-yellow::before{background:#E8A020}
.badge-red{background:rgba(232,64,64,.1);color:#C22020}.badge-red::before{background:#E84040}
.badge-purple{background:rgba(139,111,232,.1);color:#5A3FBB}.badge-purple::before{background:#8B6FE8}
.badge-critical{background:rgba(232,64,64,.1);color:#C22020}.badge-critical::before{background:#E84040}
.badge-high{background:rgba(240,120,48,.1);color:#B84D1A}.badge-high::before{background:#F07830}
.badge-medium{background:rgba(232,160,32,.1);color:#9A6A00}.badge-medium::before{background:#E8A020}
.badge-low{background:rgba(0,208,132,.1);color:#008A58}.badge-low::before{background:#00A86B}

@media(min-width:900px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}
  .sidebar{width:var(--sw);flex-shrink:0;height:100vh;display:flex;flex-direction:column;background:var(--sb-bg);overflow:hidden;box-shadow:3px 0 18px rgba(153,27,27,.22)}
  .sb-logo{height:var(--th);display:flex;align-items:center;gap:10px;padding:0 18px;border-bottom:1px solid var(--sb-bdr);flex-shrink:0}
  .sb-logo img{height:26px;filter:brightness(0) invert(1)}
  .sb-brand{font-size:16px;font-weight:800;letter-spacing:-.3px;color:#fff}.sb-brand span{color:#FCA5A5}
  .sb-nav{flex:1;overflow-y:auto;padding:12px 10px;display:flex;flex-direction:column;gap:1px}
  .sb-label{font-size:9.5px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:var(--sb-txt2);padding:14px 10px 5px}
  .sb-item{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:9px;cursor:pointer;color:rgba(255,255,255,.75);font-size:13px;font-weight:500;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover);color:#fff}
  .sb-item.active{background:var(--sb-active);color:#fff;border-color:var(--sb-active-bdr);font-weight:600}
  .sb-ico{width:30px;height:30px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item:hover .sb-ico,.sb-item.active .sb-ico{background:rgba(255,255,255,.16)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-foot{padding:12px 10px;border-top:1px solid var(--sb-bdr);flex-shrink:0;display:flex;gap:8px;align-items:center}
  .sb-av{width:34px;height:34px;border-radius:9px;flex-shrink:0;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;border:1px solid rgba(255,255,255,.28)}
  .sb-uname{font-size:12.5px;font-weight:600;color:#fff}
  .sb-urole{font-size:11px;color:var(--sb-txt2)}
  .sb-out{margin-left:auto;width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s}
  .sb-out:hover{background:rgba(239,68,68,.3)}
  .sb-out svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:var(--th);flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 24px;gap:12px}
  .tb-title{flex:1;font-size:16px;font-weight:800;letter-spacing:-.2px}
  .tb-date{font-size:12px;color:var(--txt3);font-weight:500}
  .tb-sep{width:1px;height:18px;background:var(--bdr)}
  .tb-btn{height:34px;padding:0 14px;border-radius:8px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12.5px;font-weight:600;color:var(--txt2);transition:all .15s}
  .tb-btn:hover{background:var(--bg)}
  .tb-btn svg{stroke:var(--txt3)!important}
  .scroll{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:16px}
  .scroll::-webkit-scrollbar{width:0px;background:transparent}
  .scroll{scrollbar-width:none;-ms-overflow-style:none}

  .kpi-row{display:grid;grid-template-columns:repeat(6,1fr);gap:11px}
  .kpi{background:var(--surf);border-radius:14px;padding:14px 16px;border:1px solid var(--bdr);transition:all .2s;animation:fadeUp .3s ease both}
  .kpi:hover{box-shadow:var(--shadow);transform:translateY(-1px)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
  .kpi-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-num{font-size:10px;font-weight:700;padding:2px 7px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:26px;font-weight:800;line-height:1;margin-bottom:3px;letter-spacing:-.5px}
  .kpi-val .sign{font-size:14px;font-weight:600;vertical-align:top;margin-top:4px;display:inline-block}
  .kpi-lbl{font-size:11px;color:var(--txt3);font-weight:500}

  .tool-bar{display:flex;align-items:center;gap:10px;background:var(--surf);border-radius:14px;padding:12px 16px;border:1px solid var(--bdr);flex-wrap:wrap}
  .search-wrap{position:relative;flex:1;max-width:320px}
  .search-ico{position:absolute;left:10px;top:50%;transform:translateY(-50%);pointer-events:none}
  .search-box{width:100%;height:34px;padding:0 12px 0 34px;border-radius:8px;border:1px solid var(--bdr);background:var(--surf2);font-size:12.5px;font-family:'DM Sans',sans-serif;color:var(--txt);transition:all .2s}
  .search-box:focus{outline:none;border-color:var(--g);background:var(--surf)}
  .tabs-bar{display:flex;gap:2px;background:var(--surf2);border-radius:9px;padding:3px;border:1px solid var(--bdr);overflow-x:auto}
  .tab-btn{padding:6px 14px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s;white-space:nowrap;display:flex;align-items:center;gap:5px}
  .tab-btn.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .tab-badge{font-size:10px;background:rgba(0,0,0,.08);color:var(--txt3);padding:1px 6px;border-radius:10px;font-weight:700}
  .tab-btn.active .tab-badge{background:rgba(0,208,132,.15);color:var(--gd)}
  .filter-sep{width:1px;height:20px;background:var(--bdr)}

  .panel{background:var(--surf);border-radius:var(--r);border:1px solid var(--bdr);overflow:hidden;animation:fadeUp .35s ease}
  .tbl-wrap{overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 280px)}
  table{width:100%;border-collapse:collapse;font-size:12.5px}
  thead tr{background:var(--surf2);position:sticky;top:0;z-index:2}
  thead th{padding:9px 14px;text-align:left;font-size:10.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  tbody tr{border-bottom:1px solid var(--bdr);transition:background .12s;cursor:pointer}
  tbody tr:last-child{border-bottom:none}
  tbody tr:hover{background:var(--surf2)}
  tbody td{padding:10px 14px;vertical-align:middle}
  .td-muted{color:var(--txt3);font-size:11.5px}
  .td-ref{font-weight:700;font-size:13px;color:var(--txt)}
  .td-customer{font-weight:600;font-size:12.5px}
  .td-sub{font-size:11px;color:var(--txt3);margin-top:1px}
  .empty-row td{text-align:center;padding:48px;color:var(--txt3)}

  .card-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:12px;padding:16px}
  .report-card{background:var(--surf);border-radius:14px;border:1px solid var(--bdr);overflow:hidden;transition:all .2s;cursor:pointer}
  .report-card:hover{box-shadow:var(--shadow);border-color:var(--bdr2);transform:translateY(-1px)}
  .rc-head{padding:12px 14px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .rc-ref{font-size:13px;font-weight:800;font-family:'DM Mono',monospace}
  .rc-body{padding:12px 14px}
  .rc-row{display:flex;gap:8px;align-items:flex-start;margin-bottom:7px;font-size:12.5px}
  .rc-row:last-child{margin:0}
  .rc-lbl{width:62px;font-size:11px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .rc-val{color:var(--txt2);font-weight:500;flex:1}
  .rc-foot{padding:10px 14px;border-top:1px solid var(--bdr);display:flex;gap:6px;flex-wrap:wrap}

  .btn{padding:7px 13px;border-radius:8px;font-size:11.5px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
  .btn:active{transform:scale(.97)}
  .btn-sm{padding:6px 11px;font-size:11px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-success:hover{box-shadow:0 4px 12px rgba(0,208,132,.3)}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-info:hover{box-shadow:0 4px 12px rgba(96,165,250,.25)}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-danger:hover{box-shadow:0 4px 12px rgba(232,64,64,.3)}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-ghost:hover{background:var(--bg)}
  .btn svg{pointer-events:none}

  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(4px);z-index:1000;align-items:center;justify-content:center;padding:20px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:20px;max-width:580px;width:100%;max-height:86vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:var(--shadow-md)}
  .modal-wide{max-width:720px}
  .modal-hdr{padding:18px 22px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s}
  .modal-close:hover{background:var(--bg)}
  .modal-body{padding:20px 22px;overflow-y:auto;flex:1}
  .modal-foot{padding:14px 22px;border-top:1px solid var(--bdr);display:flex;gap:8px;flex-shrink:0}
  .form-group{margin-bottom:14px}
  .form-label{display:block;font-size:11.5px;font-weight:600;color:var(--txt2);margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:10px 13px;font-size:13px;border:1.5px solid var(--bdr);border-radius:9px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif;transition:all .2s}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:var(--g);background:var(--surf);box-shadow:0 0 0 3px rgba(0,208,132,.08)}
  .form-textarea{resize:vertical;min-height:80px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .section-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:10px}
  .d-row{display:flex;align-items:flex-start;padding:8px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:130px;font-size:11.5px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .d-val{font-size:13px;color:var(--txt);font-weight:500;flex:1}

  .toast{position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:#0D5F3A;color:#fff;padding:11px 16px;border-radius:10px;font-size:13px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:9px;animation:toastIn .3s ease;max-width:320px}
  .toast-item.error{background:#5F1313;border-left:3px solid var(--red)}
  .toast-item.success{border-left:3px solid var(--g)}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  @keyframes toastOut{from{opacity:1}to{opacity:0;transform:translateX(20px)}}

  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:16px;padding:26px 34px;text-align:center;box-shadow:var(--shadow-md)}
  .spinner{width:42px;height:42px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
  .kpi:nth-child(1){animation-delay:.03s}
  .kpi:nth-child(2){animation-delay:.06s}
  .kpi:nth-child(3){animation-delay:.09s}
  .kpi:nth-child(4){animation-delay:.12s}
  .kpi:nth-child(5){animation-delay:.15s}
  .kpi:nth-child(6){animation-delay:.18s}
}
.view-toggle-container {
    display: flex;
    justify-content: flex-end;
    margin-top: 16px;
    margin-bottom: 4px;
}

.view-toggle {
    display: inline-flex;
    background: var(--surf2);
    border-radius: 10px;
    padding: 3px;
    border: 1px solid var(--bdr);
    box-shadow: 0 1px 3px rgba(0,0,0,.02);
}

.view-btn {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 12.5px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    background: transparent;
    color: var(--txt3);
    transition: all 0.15s ease;
    white-space: nowrap;
}

.view-btn svg {
    stroke: var(--txt3);
    transition: all 0.15s ease;
}

.view-btn:hover {
    color: var(--txt2);
    background: rgba(0,0,0,.02);
}

.view-btn:hover svg {
    stroke: var(--txt2);
}

.view-btn.active {
    background: var(--surf);
    color: var(--txt);
    box-shadow: 0 1px 4px rgba(0,0,0,.06), 0 0 0 1px rgba(0,208,132,.1);
}

.view-btn.active svg {
    stroke: var(--g);
}

@media (max-width: 767px) {
    .view-toggle-container {
        justify-content: stretch;
        margin: 12px 14px 4px;
    }

    .view-toggle {
        width: 100%;
    }

    .view-btn {
        flex: 1;
        justify-content: center;
        padding: 10px 12px;
        font-size: 13px;
    }
}

@media (min-width: 768px) and (max-width: 899px) {
    .view-toggle-container {
        margin-top: 14px;
    }

    .view-btn {
        padding: 7px 14px;
    }
}

@media(min-width:768px) and (max-width:899px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}
  .sidebar{width:58px;height:100vh;background:var(--sb-bg);display:flex;flex-direction:column;align-items:center;padding:10px 0;gap:3px;flex-shrink:0}
  .sb-logo{width:100%;height:52px;display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--sb-bdr);margin-bottom:6px}
  .sb-logo img{height:24px;filter:brightness(0) invert(1)}
  .sb-brand,.sb-label{display:none}
  .sb-nav{flex:1;width:100%;padding:4px 6px;display:flex;flex-direction:column;align-items:center;gap:2px}
  .sb-item{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover)}
  .sb-item.active{background:var(--sb-active);border-color:var(--sb-active-bdr)}
  .sb-ico{width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-item.active .sb-ico{background:rgba(255,255,255,.18)}
  .sb-foot{padding:8px 6px;border-top:1px solid var(--sb-bdr);width:100%;display:flex;flex-direction:column;align-items:center;gap:5px}
  .sb-av{width:32px;height:32px;border-radius:8px;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:#fff}
  .sb-uname,.sb-urole{display:none}
  .sb-out{width:28px;height:28px;border-radius:7px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .sb-out svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:52px;flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 16px;gap:10px}
  .tb-title{flex:1;font-size:15px;font-weight:800}
  .tb-date{font-size:11px;color:var(--txt3)}
  .tb-sep{width:1px;height:16px;background:var(--bdr)}
  .tb-btn{height:30px;padding:0 11px;border-radius:7px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:5px;cursor:pointer;font-size:11.5px;font-weight:600;color:var(--txt2)}
  .scroll{flex:1;overflow-y:auto;padding:12px 14px;display:flex;flex-direction:column;gap:12px}
  .kpi-row{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .kpi{background:var(--surf);border-radius:12px;padding:13px 15px;border:1px solid var(--bdr)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:9px}
  .kpi-ico{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-num{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:22px;font-weight:800;line-height:1;margin-bottom:3px;letter-spacing:-.4px}
  .kpi-val .sign{font-size:13px;font-weight:600;vertical-align:top;margin-top:3px;display:inline-block}
  .kpi-lbl{font-size:10.5px;color:var(--txt3)}
  .tool-bar{display:flex;align-items:center;gap:8px;background:var(--surf);border-radius:12px;padding:10px 13px;border:1px solid var(--bdr);flex-wrap:wrap}
  .search-wrap{position:relative;flex:1}
  .search-ico{position:absolute;left:9px;top:50%;transform:translateY(-50%);pointer-events:none}
  .search-box{width:100%;height:32px;padding:0 10px 0 30px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);font-size:12px;font-family:'DM Sans',sans-serif;color:var(--txt)}
  .search-box:focus{outline:none;border-color:var(--g)}
  .tabs-bar{display:flex;gap:2px;background:var(--surf2);border-radius:8px;padding:2px;border:1px solid var(--bdr);overflow-x:auto}
  .tab-btn{padding:5px 11px;border-radius:6px;font-size:11.5px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s;display:flex;align-items:center;gap:4px}
  .tab-btn.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.07)}
  .tab-badge{font-size:9.5px;background:rgba(0,0,0,.07);color:var(--txt3);padding:1px 5px;border-radius:10px;font-weight:700}
  .tab-btn.active .tab-badge{background:rgba(0,208,132,.12);color:var(--gd)}
  .filter-sep{width:1px;height:18px;background:var(--bdr)}
  .panel{background:var(--surf);border-radius:13px;border:1px solid var(--bdr);overflow:hidden}
  .tbl-wrap{overflow-x:auto}
  table{width:100%;border-collapse:collapse;font-size:12px}
  thead tr{background:var(--surf2)}
  thead th{padding:8px 12px;text-align:left;font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  tbody tr{border-bottom:1px solid var(--bdr);transition:background .12s;cursor:pointer}
  tbody tr:last-child{border-bottom:none}
  tbody tr:hover{background:var(--surf2)}
  tbody td{padding:9px 12px;vertical-align:middle}
  .td-muted{color:var(--txt3);font-size:11px}
  .td-ref{font-weight:700;font-size:12.5px}
  .td-customer{font-weight:600;font-size:12px}
  .td-sub{font-size:10.5px;color:var(--txt3);margin-top:1px}
  .empty-row td{text-align:center;padding:36px;color:var(--txt3)}
  .card-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:12px}
  .report-card{background:var(--surf);border-radius:12px;border:1px solid var(--bdr);overflow:hidden;transition:all .2s;cursor:pointer}
  .report-card:hover{box-shadow:var(--shadow)}
  .rc-head{padding:10px 12px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .rc-ref{font-size:12.5px;font-weight:800}
  .rc-body{padding:10px 12px}
  .rc-row{display:flex;gap:6px;align-items:flex-start;margin-bottom:6px;font-size:12px}
  .rc-row:last-child{margin:0}
  .rc-lbl{width:55px;font-size:10.5px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .rc-val{color:var(--txt2);font-weight:500;flex:1;font-size:11.5px}
  .rc-foot{padding:8px 12px;border-top:1px solid var(--bdr);display:flex;gap:5px;flex-wrap:wrap}
  .btn{padding:6px 11px;border-radius:7px;font-size:11px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:4px}
  .btn-sm{padding:5px 9px;font-size:10.5px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);z-index:1000;align-items:center;justify-content:center;padding:16px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:17px;max-width:540px;width:100%;max-height:86vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide{max-width:680px}
  .modal-hdr{padding:16px 20px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:14px;font-weight:800}
  .modal-close{width:27px;height:27px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:18px 20px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 20px;border-top:1px solid var(--bdr);display:flex;gap:7px}
  .form-group{margin-bottom:12px}
  .form-label{display:block;font-size:11px;font-weight:600;color:var(--txt2);margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:9px 12px;font-size:12.5px;border:1.5px solid var(--bdr);border-radius:8px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif;transition:all .2s}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:var(--g)}
  .form-textarea{resize:vertical;min-height:75px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .section-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:8px}
  .d-row{display:flex;align-items:flex-start;padding:7px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:120px;font-size:11px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .d-val{font-size:12.5px;color:var(--txt);font-weight:500;flex:1}
  .toast{position:fixed;bottom:18px;right:18px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:#0D5F3A;color:#fff;padding:10px 14px;border-radius:9px;font-size:12.5px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:8px;animation:toastIn .3s ease;max-width:280px}
  .toast-item.error{background:#5F1313}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:13px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  .filter-sep{display:none}
}

@media(max-width:767px){
  .sidebar,.desk-wrap{display:none!important}
  body{background:#EFF5F2;padding-bottom:80px}
  .mob-header{position:sticky;top:0;z-index:100;background:rgba(255,255,255,.9);backdrop-filter:blur(16px);border-bottom:1px solid rgba(0,0,0,.06);padding:12px 16px;display:flex;align-items:center;gap:10px}
  .mh-back{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mh-title{flex:1;font-size:16px;font-weight:800;text-align:center}
  .mh-btn{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mob-body{padding:14px 14px 18px;display:flex;flex-direction:column;gap:12px}
  .m-kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
  .mkpi{background:#fff;border-radius:13px;padding:12px 10px;border:1px solid #DDE8E2;text-align:center}
  .mkpi-v{font-size:22px;font-weight:800;line-height:1;color:#0D1F18}
  .mkpi-l{font-size:10.5px;color:#7A9A8E;margin-top:3px}
  .m-filters{display:flex;gap:6px;overflow-x:auto;padding-bottom:4px}
  .m-filter-btn{padding:7px 14px;border-radius:20px;font-size:12px;font-weight:600;border:1.5px solid #DDE8E2;background:#fff;white-space:nowrap;cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:5px}
  .m-filter-btn.active{background:rgba(0,208,132,.1);border-color:rgba(0,208,132,.3);color:#008A58}
  .m-search{position:relative}
  .m-search input{width:100%;height:38px;padding:0 14px 0 36px;border-radius:12px;border:1.5px solid #DDE8E2;background:#fff;font-size:13px;font-family:'DM Sans',sans-serif;color:#0D1F18}
  .m-search input:focus{outline:none;border-color:#00D084}
  .m-search svg{position:absolute;left:10px;top:50%;transform:translateY(-50%);pointer-events:none}
  .m-reports{display:flex;flex-direction:column;gap:10px}
  .m-report{background:#fff;border-radius:16px;border:1.5px solid #DDE8E2;overflow:hidden}
  .mr-head{padding:11px 14px;border-bottom:1px solid #EEF5F1;display:flex;align-items:center;justify-content:space-between}
  .mr-ref{font-size:13.5px;font-weight:800;font-family:'DM Mono',monospace;color:#0D1F18}
  .mr-body{padding:11px 14px;display:flex;flex-direction:column;gap:5px}
  .mr-row{display:flex;gap:6px;font-size:12.5px}
  .mr-lbl{font-size:11px;font-weight:600;color:#7A9A8E;width:55px;flex-shrink:0;padding-top:1px}
  .mr-val{color:#3A5248;font-weight:500;flex:1}
  .mr-foot{padding:9px 14px;border-top:1px solid #EEF5F1;display:flex;gap:6px;flex-wrap:wrap}
  .btn{padding:8px 13px;border-radius:9px;font-size:12px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:5px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:rgba(0,0,0,.04);color:#3A5248}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1000;align-items:flex-end;justify-content:center}
  .modal.open{display:flex}
  .modal-box{background:#fff;border-radius:22px 22px 0 0;width:100%;max-height:85vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide{max-height:92vh}
  .modal-hdr{padding:16px 18px;border-bottom:1px solid #DDE8E2;display:flex;align-items:center;justify-content:space-between}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid #DDE8E2;background:#F7FAF8;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:16px 18px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 18px;border-top:1px solid #DDE8E2;display:flex;gap:8px}
  .form-group{margin-bottom:13px}
  .form-label{display:block;font-size:11.5px;font-weight:600;color:#3A5248;margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:11px 13px;font-size:14px;border:1.5px solid #DDE8E2;border-radius:11px;background:#F7FAF8;color:#0D1F18;font-family:'DM Sans',sans-serif}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:#00D084}
  .form-textarea{resize:vertical;min-height:80px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .d-row{display:flex;padding:7px 0;border-bottom:1px solid #DDE8E2}
  .d-row:last-child{border:none}
  .d-label{width:110px;font-size:11.5px;font-weight:600;color:#7A9A8E;flex-shrink:0}
  .d-val{font-size:13px;color:#0D1F18;font-weight:500;flex:1}
  .section-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#7A9A8E;margin-bottom:8px}
  .mob-nav{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.96);backdrop-filter:blur(20px);border-top:1px solid rgba(0,0,0,.06);padding:8px 0 16px;display:grid;grid-template-columns:repeat(4,1fr);z-index:99}
  .mn{display:flex;flex-direction:column;align-items:center;gap:2px;padding:5px;cursor:pointer;border:none;background:none}
  .mn-ico{width:40px;height:26px;display:flex;align-items:center;justify-content:center}
  .mn-ico svg{stroke:#718096;opacity:.5}
  .mn.active .mn-ico svg{stroke:#00D084;opacity:1}
  .mn-lbl{font-size:10px;font-weight:600;color:#718096;opacity:.7}
  .mn.active .mn-lbl{color:#00D084;opacity:1}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:#fff;border-radius:16px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid #DDE8E2;border-top-color:#00D084;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  .mob-toast{position:fixed;bottom:88px;left:14px;right:14px;z-index:9999;display:flex;flex-direction:column;gap:8px}
  .mob-toast-item{background:#0D5F3A;color:#fff;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px;animation:toastIn .3s ease}
  .mob-toast-item.error{background:#5F1313}
  @keyframes toastIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  .m-empty{text-align:center;padding:44px 20px;background:#fff;border-radius:16px;border:1px solid #DDE8E2}
  .m-empty svg{margin:0 auto 12px;opacity:.2}
  .m-empty p{font-size:13px;color:#7A9A8E}
}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <img src="../images/envirocab_logo.png" alt="EC" onerror="this.style.display='none'">
  </div>
  <nav class="sb-nav">
    <div class="sb-label">Core 2</div>
    <a href="dashboard.php" class="sb-item"><div class="sb-ico"><?=ico($iHome)?></div><span>Dashboard</span></a>
    <a href="booking_system.php" class="sb-item"><div class="sb-ico"><?=ico($iBook)?></div><span>Booking System</span></a>
    <a href="payment_fares.php" class="sb-item"><div class="sb-ico"><?=ico($iPay)?></div><span>Payment &amp; Fares</span></a>
    <a href="crm_system.php" class="sb-item"><div class="sb-ico"><?=ico($iCrm)?></div><span>CRM</span></a>
    <a href="gps_tracking.php" class="sb-item"><div class="sb-ico"><?=ico($iGps)?></div><span>GPS Tracking</span></a>
    <div class="sb-label">Analytics</div>
    <a href="transport_analytics.php" class="sb-item"><div class="sb-ico"><?=ico($iBar)?></div><span>Analytics &amp; KPIs</span></a>
    <a href="sop_compliance.php" class="sb-item active"><div class="sb-ico"><?=ico($iShield)?></div><span>SOP Compliance</span></a>
  </nav>
  <div class="sb-foot">
    <div class="sb-av"><?=$userInitial?></div>
    <div style="flex:1;min-width:0">
      <div class="sb-uname trunc"><?=$userName?></div>
      <div class="sb-urole">Compliance Officer</div>
    </div>
    <button class="sb-out" onclick="if(confirm('Logout?'))location.href='../auth/logout.php'" title="Logout"><?=ico($iOut,'#EF4444',14)?></button>
  </div>
</aside>

<div class="desk-wrap">
  <header class="topbar">
    <div class="tb-title">SOP Compliance & Audit Logs</div>
    <div class="tb-date"><?=date('D, M j, Y')?></div>
    <div class="tb-sep"></div>
    <button class="tb-btn" onclick="exportComplianceReport()"><?=ico($iDownload,'#4A5568',13)?> Export Report</button>
    <button class="tb-btn" onclick="location.reload()"><?=ico($iRefresh,'#4A5568',13)?> Refresh</button>
  </header>

  <div class="scroll">

    <div class="kpi-row">
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iShield,'#00A86B',17)?></div>
          <div class="kpi-num">compliance</div>
        </div>
        <div class="kpi-val"><?=$compliance_score?>%</div>
        <div class="kpi-lbl">Overall SOP Score</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(232,160,32,.1)"><?=ico($iDoc,'#E8A020',17)?></div>
          <div class="kpi-num">reports</div>
        </div>
        <div class="kpi-val"><?=$total_reports?></div>
        <div class="kpi-lbl">Total Reports</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(232,64,64,.1)"><?=ico($iAlert,'#E84040',17)?></div>
          <div class="kpi-num">critical</div>
        </div>
        <div class="kpi-val"><?=$critical_count?></div>
        <div class="kpi-lbl">Critical Issues</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(59,142,240,.1)"><?=ico($iInfo,'#3B8EF0',17)?></div>
          <div class="kpi-num">open</div>
        </div>
        <div class="kpi-val"><?=$open_count?></div>
        <div class="kpi-lbl">Open Cases</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iCheck,'#00A86B',17)?></div>
          <div class="kpi-num">resolved</div>
        </div>
        <div class="kpi-val"><?=$resolved_count?></div>
        <div class="kpi-lbl">Resolved</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(139,111,232,.1)"><?=ico($iClock,'#8B6FE8',17)?></div>
          <div class="kpi-num">avg days</div>
        </div>
        <div class="kpi-val"><?=$avg_resolution_days?>d</div>
        <div class="kpi-lbl">Resolution Time</div>
      </div>
    </div>

    <div class="tool-bar">
      <div class="search-wrap">
        <div class="search-ico"><?=ico($iSearch,'#7A9A8E',13)?></div>
        <input type="text" class="search-box" id="complianceSearch" placeholder="Search reports, drivers, customers…" oninput="searchReports(this.value)">
      </div>
      <div class="filter-sep"></div>
      <div class="tabs-bar" id="filterTabs">
        <button class="tab-btn active" onclick="setFilter('all',this)">All <span class="tab-badge" id="badge-all"><?=$total_reports?></span></button>
        <button class="tab-btn" onclick="setFilter('Critical',this)">Critical <span class="tab-badge" id="badge-Critical"><?=$severity_counts['Critical']?></span></button>
        <button class="tab-btn" onclick="setFilter('High',this)">High <span class="tab-badge" id="badge-High"><?=$severity_counts['High']?></span></button>
        <button class="tab-btn" onclick="setFilter('Medium',this)">Medium <span class="tab-badge" id="badge-Medium"><?=$severity_counts['Medium']?></span></button>
        <button class="tab-btn" onclick="setFilter('Low',this)">Low <span class="tab-badge" id="badge-Low"><?=$severity_counts['Low']?></span></button>
        <button class="tab-btn" onclick="setFilter('Open',this)">Open <span class="tab-badge" id="badge-Open"><?=$open_count?></span></button>
        <button class="tab-btn" onclick="setFilter('Under Review',this)">Under Review <span class="tab-badge" id="badge-UnderReview"><?=$pending_review_count?></span></button>
      </div>
    </div>

    <div class="panel" id="tableView">
      <div class="tbl-wrap">
        <table>
          <thead>
            <tr>
              <th>Report ID</th>
              <th>Date</th>
              <th>Type</th>
              <th>Severity</th>
              <th>Status</th>
              <th>Driver</th>
              <th>Customer</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="reportTbody">
            <?php if (empty($reports)): ?>
            <tr class="empty-row"><td colspan="9" style="text-align:center;padding:48px;color:var(--txt3)">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 12px;display:block;opacity:.25"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              <p>No compliance reports found</p>
            </td></tr>
            <?php else: foreach ($reports as $r): ?>
            <tr onclick="showReportDetails(<?=$r['report_id']?>)" data-id="<?=$r['report_id']?>">
              <td><div class="td-ref mono">RPT-<?=str_pad($r['report_id'],5,'0',STR_PAD_LEFT)?></div></td>
              <td class="td-muted"><?=date('M d, Y', strtotime($r['reported_at']))?></td>
              <td class="td-muted"><?=htmlspecialchars($r['report_type'])?></td>
              <td><span class="badge badge-<?=strtolower($r['severity'])?>"><?=htmlspecialchars($r['severity'])?></span></td>
              <td><span class="badge <?php 
                $status = $r['status'];
                if ($status == 'Open') echo 'badge-red';
                elseif ($status == 'Under Review') echo 'badge-yellow';
                elseif ($status == 'Resolved') echo 'badge-green';
                elseif ($status == 'Closed') echo 'badge-blue';
              ?>"><?=htmlspecialchars($status)?></span></td>
              <td><div class="td-customer"><?=htmlspecialchars($r['driver_name'])?></div></td>
              <td><div class="td-customer"><?=htmlspecialchars($r['customer_name'])?></div></td>
              <td class="td-muted" style="max-width:200px"><?=htmlspecialchars(mb_substr($r['description'], 0, 50))?><?=strlen($r['description']) > 50 ? '…' : ''?></td>
              <td onclick="event.stopPropagation()">
                <div style="display:flex;gap:5px">
                  <button class="btn btn-sm btn-ghost" onclick="showReportDetails(<?=$r['report_id']?>)">View</button>
                  <?php if ($r['status'] == 'Under Review'): ?>
                  <button class="btn btn-sm btn-success" onclick="resolveReport(<?=$r['report_id']?>)">Resolve</button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card-grid" id="cardView" style="display:none">
      <?php foreach ($reports as $r): ?>
      <div class="report-card" onclick="showReportDetails(<?=$r['report_id']?>)">
        <div class="rc-head">
          <div class="rc-ref mono">RPT-<?=str_pad($r['report_id'],5,'0',STR_PAD_LEFT)?></div>
          <span class="badge badge-<?=strtolower($r['severity'])?>"><?=htmlspecialchars($r['severity'])?></span>
        </div>
        <div class="rc-body">
          <div class="rc-row"><div class="rc-lbl">Date</div><div class="rc-val"><?=date('M d, Y', strtotime($r['reported_at']))?></div></div>
          <div class="rc-row"><div class="rc-lbl">Type</div><div class="rc-val"><?=htmlspecialchars($r['report_type'])?></div></div>
          <div class="rc-row"><div class="rc-lbl">Driver</div><div class="rc-val"><?=htmlspecialchars($r['driver_name'])?></div></div>
          <div class="rc-row"><div class="rc-lbl">Customer</div><div class="rc-val"><?=htmlspecialchars($r['customer_name'])?></div></div>
          <div class="rc-row"><div class="rc-lbl">Status</div><div class="rc-val">
            <span class="badge <?php 
              $status = $r['status'];
              if ($status == 'Open') echo 'badge-red';
              elseif ($status == 'Under Review') echo 'badge-yellow';
              elseif ($status == 'Resolved') echo 'badge-green';
              elseif ($status == 'Closed') echo 'badge-blue';
            ?>"><?=htmlspecialchars($status)?></span>
          </div></div>
        </div>
        <div class="rc-foot">
          <button class="btn btn-sm btn-ghost" onclick="event.stopPropagation();showReportDetails(<?=$r['report_id']?>)">View Details</button>
          <?php if ($r['status'] == 'Under Review'): ?>
          <button class="btn btn-sm btn-success" onclick="event.stopPropagation();resolveReport(<?=$r['report_id']?>)">Resolve</button>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

<div class="view-toggle-container">
    <div class="view-toggle">
        <button class="view-btn active" id="tblViewBtn" onclick="setView('table')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="8" y1="6" x2="21" y2="6"/>
                <line x1="8" y1="12" x2="21" y2="12"/>
                <line x1="8" y1="18" x2="21" y2="18"/>
                <line x1="3" y1="6" x2="3.01" y2="6"/>
                <line x1="3" y1="12" x2="3.01" y2="12"/>
                <line x1="3" y1="18" x2="3.01" y2="18"/>
            </svg>
            Table
        </button>
        <button class="view-btn" id="cardViewBtn" onclick="setView('card')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="7" height="7"/>
                <rect x="14" y="3" width="7" height="7"/>
                <rect x="14" y="14" width="7" height="7"/>
                <rect x="3" y="14" width="7" height="7"/>
            </svg>
            Cards
        </button>
    </div>
</div>

<header class="mob-header">
  <button class="mh-back" onclick="location.href='dashboard.php'"><?=ico("<path d='M19 12H5'/><path d='M12 19l-7-7 7-7'/>", 'currentColor', 16)?></button>
  <div class="mh-title">SOP Compliance</div>
  <button class="mh-btn" onclick="location.reload()"><?=ico($iRefresh, 'currentColor', 16)?></button>
</header>

<div class="mob-body">
  <div class="m-kpis">
    <div class="mkpi">
      <div class="mkpi-v" style="color:#00A86B"><?=$compliance_score?>%</div>
      <div class="mkpi-l">Compliance</div>
    </div>
    <div class="mkpi">
      <div class="mkpi-v" style="color:#E84040"><?=$critical_count?></div>
      <div class="mkpi-l">Critical</div>
    </div>
    <div class="mkpi">
      <div class="mkpi-v" style="color:#E8A020"><?=$open_count?></div>
      <div class="mkpi-l">Open</div>
    </div>
  </div>

  <div class="m-search">
    <?=ico($iSearch, '#7A9A8E', 16)?>
    <input type="text" id="mSearchBox" placeholder="Search reports…" oninput="searchReports(this.value)">
  </div>

  <div class="m-filters" id="mFilters">
    <button class="m-filter-btn active" onclick="setFilter('all',this,true)">All <span id="mbadge-all"><?=$total_reports?></span></button>
    <button class="m-filter-btn" onclick="setFilter('Critical',this,true)"><?=ico($iAlert,'currentColor',11)?> Critical</button>
    <button class="m-filter-btn" onclick="setFilter('High',this,true)">High</button>
    <button class="m-filter-btn" onclick="setFilter('Medium',this,true)">Medium</button>
    <button class="m-filter-btn" onclick="setFilter('Low',this,true)">Low</button>
    <button class="m-filter-btn" onclick="setFilter('Open',this,true)">Open</button>
  </div>

  <div class="m-reports" id="mReportList">
    <?php foreach ($reports as $r): ?>
    <div class="m-report" onclick="showReportDetails(<?=$r['report_id']?>)">
      <div class="mr-head">
        <div class="mr-ref mono">RPT-<?=str_pad($r['report_id'],5,'0',STR_PAD_LEFT)?></div>
        <span class="badge badge-<?=strtolower($r['severity'])?>"><?=htmlspecialchars($r['severity'])?></span>
      </div>
      <div class="mr-body">
        <div class="mr-row"><div class="mr-lbl">Date</div><div class="mr-val"><?=date('M d, Y', strtotime($r['reported_at']))?></div></div>
        <div class="mr-row"><div class="mr-lbl">Type</div><div class="mr-val"><?=htmlspecialchars($r['report_type'])?></div></div>
        <div class="mr-row"><div class="mr-lbl">Driver</div><div class="mr-val"><?=htmlspecialchars($r['driver_name'])?></div></div>
        <div class="mr-row"><div class="mr-lbl">Status</div><div class="mr-val">
          <span class="badge <?php 
            $status = $r['status'];
            if ($status == 'Open') echo 'badge-red';
            elseif ($status == 'Under Review') echo 'badge-yellow';
            elseif ($status == 'Resolved') echo 'badge-green';
            elseif ($status == 'Closed') echo 'badge-blue';
          ?>"><?=htmlspecialchars($status)?></span>
        </div></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<nav class="mob-nav">
  <button class="mn" onclick="location.href='dashboard.php'"><div class="mn-ico"><?=ico($iHome,'currentColor',22)?></div><span class="mn-lbl">Home</span></button>
  <button class="mn" onclick="location.href='booking_system.php'"><div class="mn-ico"><?=ico($iBook,'currentColor',22)?></div><span class="mn-lbl">Bookings</span></button>
  <button class="mn active"><div class="mn-ico"><?=ico($iShield,'currentColor',22)?></div><span class="mn-lbl">SOP</span></button>
  <button class="mn" onclick="location.href='gps_tracking.php'"><div class="mn-ico"><?=ico($iGps,'currentColor',22)?></div><span class="mn-lbl">GPS</span></button>
</nav>

<div id="detailsModal" class="modal">
  <div class="modal-box modal-wide">
    <div class="modal-hdr">
      <div class="modal-title">Report Details</div>
      <button class="modal-close" onclick="closeModal('detailsModal')"><?=ico($iX,'#4A5568',14)?></button>
    </div>
    <div class="modal-body" id="detailsContent"></div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('detailsModal')">Close</button>
      <div id="detailsActions" style="display:flex;gap:8px"></div>
    </div>
  </div>
</div>

<div id="notifyModal" class="modal">
  <div class="modal-box">
    <div class="modal-hdr">
      <div class="modal-title">Notify Customer</div>
      <button class="modal-close" onclick="closeModal('notifyModal')"><?=ico($iX,'#4A5568',14)?></button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Notification Message</label>
        <textarea id="notifyMessage" class="form-textarea" rows="4" placeholder="Enter your response to the customer..."></textarea>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('notifyModal')">Cancel</button>
      <button class="btn btn-success" id="sendNotifyBtn">Send Notification</button>
    </div>
  </div>
</div>

<div id="loading" class="loading">
  <div class="spin-box">
    <div class="spinner"></div>
    <p style="font-size:13px;font-weight:600">Processing…</p>
  </div>
</div>

<div class="toast" id="toastCont"></div>
<div class="mob-toast" id="mobToastCont"></div>

<script>
let allReportsData = <?=json_encode(array_values($reports))?>;
let currentFilter = 'all';
let currentSearch = '';
let currentViewMode = 'table';
let currentReportId = null;

const setLoading = v => document.getElementById('loading').classList.toggle('show', v);

function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});

function toast(msg, type = 'success') {
    ['toastCont', 'mobToastCont'].forEach(id => {
        const c = document.getElementById(id);
        if (!c) return;
        const el = document.createElement('div');
        el.className = id === 'toastCont' ? `toast-item ${type}` : `mob-toast-item ${type}`;
        const ico = type === 'success' ? '<polyline points="20 6 9 17 4 12"/>' : '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>';
        el.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${ico}</svg>${msg}`;
        c.appendChild(el);
        setTimeout(() => {
            el.style.animation = 'toastOut .3s ease forwards';
            setTimeout(() => el.remove(), 300);
        }, 3500);
    });
}

async function api(data) {
    const fd = new FormData();
    Object.entries(data).forEach(([k, v]) => fd.append(k, v));
    const r = await fetch('sop_compliance.php', { method: 'POST', body: fd });
    return r.json();
}

function setFilter(f, el, isMobile = false) {
    currentFilter = f;
    const sel = isMobile ? '#mFilters .m-filter-btn' : '#filterTabs .tab-btn';
    document.querySelectorAll(sel).forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    renderAll();
}

function searchReports(q) {
    currentSearch = q.toLowerCase();
    renderAll();
}

function getFiltered() {
    return allReportsData.filter(r => {
        let matchesFilter = false;
        if (currentFilter === 'all') {
            matchesFilter = true;
        } else if (['Critical', 'High', 'Medium', 'Low'].includes(currentFilter)) {
            matchesFilter = r.severity === currentFilter;
        } else {
            matchesFilter = r.status === currentFilter;
        }

        const matchesSearch = !currentSearch || 
            (r.report_id?.toString().includes(currentSearch)) ||
            (r.report_type?.toLowerCase().includes(currentSearch)) ||
            (r.driver_name?.toLowerCase().includes(currentSearch)) ||
            (r.customer_name?.toLowerCase().includes(currentSearch)) ||
            (r.description?.toLowerCase().includes(currentSearch));

        return matchesFilter && matchesSearch;
    });
}

function renderTable(reports) {
    const tb = document.getElementById('reportTbody');
    if (!tb) return;

    if (!reports.length) {
        tb.innerHTML = `<tr class="empty-row"><td colspan="9" style="text-align:center;padding:48px;color:var(--txt3)">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 12px;display:block;opacity:.25"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <p>No reports found</p></td></tr>`;
        return;
    }

    tb.innerHTML = reports.map(r => {
        const statusClass = {
            'Open': 'badge-red',
            'Under Review': 'badge-yellow',
            'Resolved': 'badge-green',
            'Closed': 'badge-blue'
        }[r.status] || 'badge-blue';

        return `<tr onclick="showReportDetails(${r.report_id})" data-id="${r.report_id}">
            <td><div class="td-ref mono">RPT-${String(r.report_id).padStart(5,'0')}</div></td>
            <td class="td-muted">${new Date(r.reported_at).toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'})}</td>
            <td class="td-muted">${escapeHtml(r.report_type)}</td>
            <td><span class="badge badge-${r.severity.toLowerCase()}">${escapeHtml(r.severity)}</span></td>
            <td><span class="badge ${statusClass}">${escapeHtml(r.status)}</span></td>
            <td><div class="td-customer">${escapeHtml(r.driver_name)}</div></td>
            <td><div class="td-customer">${escapeHtml(r.customer_name)}</div></td>
            <td class="td-muted" style="max-width:200px">${escapeHtml(r.description.substring(0,50))}${r.description.length > 50 ? '…' : ''}</td>
            <td onclick="event.stopPropagation()">
                <div style="display:flex;gap:5px">
                    <button class="btn btn-sm btn-ghost" onclick="showReportDetails(${r.report_id})">View</button>
                    ${r.status === 'Under Review' ? `<button class="btn btn-sm btn-success" onclick="resolveReport(${r.report_id})">Resolve</button>` : ''}
                </div>
            </td>
        </tr>`;
    }).join('');
}

function renderCards(reports) {
    const cv = document.getElementById('cardView');
    if (!cv) return;

    if (!reports.length) {
        cv.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:48px;background:var(--surf);border-radius:var(--r);border:1px solid var(--bdr);color:var(--txt3)">No reports found</div>`;
        return;
    }

    cv.innerHTML = reports.map(r => {
        const statusClass = {
            'Open': 'badge-red',
            'Under Review': 'badge-yellow',
            'Resolved': 'badge-green',
            'Closed': 'badge-blue'
        }[r.status] || 'badge-blue';

        return `<div class="report-card" onclick="showReportDetails(${r.report_id})">
            <div class="rc-head">
                <div class="rc-ref mono">RPT-${String(r.report_id).padStart(5,'0')}</div>
                <span class="badge badge-${r.severity.toLowerCase()}">${escapeHtml(r.severity)}</span>
            </div>
            <div class="rc-body">
                <div class="rc-row"><div class="rc-lbl">Date</div><div class="rc-val">${new Date(r.reported_at).toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'})}</div></div>
                <div class="rc-row"><div class="rc-lbl">Type</div><div class="rc-val">${escapeHtml(r.report_type)}</div></div>
                <div class="rc-row"><div class="rc-lbl">Driver</div><div class="rc-val">${escapeHtml(r.driver_name)}</div></div>
                <div class="rc-row"><div class="rc-lbl">Customer</div><div class="rc-val">${escapeHtml(r.customer_name)}</div></div>
                <div class="rc-row"><div class="rc-lbl">Status</div><div class="rc-val">
                    <span class="badge ${statusClass}">${escapeHtml(r.status)}</span>
                </div></div>
            </div>
            <div class="rc-foot">
                <button class="btn btn-sm btn-ghost" onclick="event.stopPropagation();showReportDetails(${r.report_id})">View Details</button>
                ${r.status === 'Under Review' ? `<button class="btn btn-sm btn-success" onclick="event.stopPropagation();resolveReport(${r.report_id})">Resolve</button>` : ''}
            </div>
        </div>`;
    }).join('');
}

function renderMobile(reports) {
    const ml = document.getElementById('mReportList');
    if (!ml) return;

    if (!reports.length) {
        ml.innerHTML = `<div class="m-empty"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p>No reports found</p></div>`;
        return;
    }

    ml.innerHTML = reports.map(r => {
        const statusClass = {
            'Open': 'badge-red',
            'Under Review': 'badge-yellow',
            'Resolved': 'badge-green',
            'Closed': 'badge-blue'
        }[r.status] || 'badge-blue';

        return `<div class="m-report" onclick="showReportDetails(${r.report_id})">
            <div class="mr-head">
                <div class="mr-ref mono">RPT-${String(r.report_id).padStart(5,'0')}</div>
                <span class="badge badge-${r.severity.toLowerCase()}">${escapeHtml(r.severity)}</span>
            </div>
            <div class="mr-body">
                <div class="mr-row"><div class="mr-lbl">Date</div><div class="mr-val">${new Date(r.reported_at).toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'})}</div></div>
                <div class="mr-row"><div class="mr-lbl">Type</div><div class="mr-val">${escapeHtml(r.report_type)}</div></div>
                <div class="mr-row"><div class="mr-lbl">Driver</div><div class="mr-val">${escapeHtml(r.driver_name)}</div></div>
                <div class="mr-row"><div class="mr-lbl">Status</div><div class="mr-val">
                    <span class="badge ${statusClass}">${escapeHtml(r.status)}</span>
                </div></div>
            </div>
        </div>`;
    }).join('');
}

function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function renderAll() {
    const filtered = getFiltered();
    renderTable(filtered);
    renderCards(filtered);
    renderMobile(filtered);
}

function setView(mode) {
    currentViewMode = mode;
    const tv = document.getElementById('tableView');
    const cv = document.getElementById('cardView');
    const tblBtn = document.getElementById('tblViewBtn');
    const cardBtn = document.getElementById('cardViewBtn');

    if (mode === 'table') {
        tv.style.display = 'block';
        cv.style.display = 'none';
        tblBtn.classList.add('active');
        cardBtn.classList.remove('active');
    } else {
        tv.style.display = 'none';
        cv.style.display = 'grid';
        cardBtn.classList.add('active');
        tblBtn.classList.remove('active');
    }
}

async function showReportDetails(id) {
    setLoading(true);
    try {
        const report = allReportsData.find(r => r.report_id === id);
        if (!report) {
            toast('Report not found', 'error');
            return;
        }

        const statusClass = {
            'Open': 'badge-red',
            'Under Review': 'badge-yellow',
            'Resolved': 'badge-green',
            'Closed': 'badge-blue'
        }[report.status] || 'badge-blue';

        const reportedDate = new Date(report.reported_at).toLocaleString();
        const resolvedDate = report.resolved_at ? new Date(report.resolved_at).toLocaleString() : 'Not resolved';

        document.getElementById('detailsContent').innerHTML = `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px">
                <div>
                    <div class="section-label">Report Information</div>
                    <div class="d-row"><div class="d-label">Report ID</div><div class="d-val mono" style="font-weight:800">RPT-${String(report.report_id).padStart(5,'0')}</div></div>
                    <div class="d-row"><div class="d-label">Type</div><div class="d-val">${escapeHtml(report.report_type)}</div></div>
                    <div class="d-row"><div class="d-label">Severity</div><div class="d-val"><span class="badge badge-${report.severity.toLowerCase()}">${escapeHtml(report.severity)}</span></div></div>
                    <div class="d-row"><div class="d-label">Status</div><div class="d-val"><span class="badge ${statusClass}">${escapeHtml(report.status)}</span></div></div>
                    <div class="d-row"><div class="d-label">Reported At</div><div class="d-val">${reportedDate}</div></div>
                    <div class="d-row"><div class="d-label">Resolved At</div><div class="d-val">${resolvedDate}</div></div>
                </div>
                <div>
                    <div class="section-label">Parties Involved</div>
                    <div class="d-row"><div class="d-label">Driver</div><div class="d-val" style="font-weight:600">${escapeHtml(report.driver_name)}</div></div>
                    ${report.driver_license ? `<div class="d-row"><div class="d-label">License</div><div class="d-val">${escapeHtml(report.driver_license)}</div></div>` : ''}
                    <div class="d-row"><div class="d-label">Customer</div><div class="d-val">${escapeHtml(report.customer_name)}</div></div>
                    ${report.customer_email ? `<div class="d-row"><div class="d-label">Customer Email</div><div class="d-val">${escapeHtml(report.customer_email)}</div></div>` : ''}
                    ${report.booking_ref ? `<div class="d-row"><div class="d-label">Booking Ref</div><div class="d-val">${escapeHtml(report.booking_ref)}</div></div>` : ''}
                </div>
            </div>
            <div class="section-label">Description</div>
            <div style="background:var(--surf2);border-radius:9px;padding:14px;border:1px solid var(--bdr);margin-bottom:18px;font-size:13px;line-height:1.6">
                ${escapeHtml(report.description)}
            </div>
        `;

        const da = document.getElementById('detailsActions');
        da.innerHTML = '';

        if (report.status === 'Under Review') {
            da.innerHTML += `<button class="btn btn-success" onclick="closeModal('detailsModal');resolveReport(${report.report_id})">${svgCheck}Resolve Report</button>`;
        }

        if (report.customer_email) {
            da.innerHTML += `<button class="btn btn-info" onclick="closeModal('detailsModal');showNotifyModal(${report.report_id})">${svgBell}Notify Customer</button>`;
        }

        openModal('detailsModal');
    } catch (e) {
        toast('Error: ' + e.message, 'error');
    }
    setLoading(false);
}

function showNotifyModal(id) {
    currentReportId = id;
    document.getElementById('notifyMessage').value = '';
    openModal('notifyModal');
}

document.getElementById('sendNotifyBtn').onclick = async () => {
    const message = document.getElementById('notifyMessage').value.trim();
    if (!message) {
        toast('Please enter a message', 'error');
        return;
    }

    closeModal('notifyModal');
    setLoading(true);

    try {

        await new Promise(resolve => setTimeout(resolve, 1000)); 
        toast(`Notification sent to customer for report #${currentReportId}`, 'success');
    } catch (e) {
        toast('Error sending notification: ' + e.message, 'error');
    }

    setLoading(false);
    currentReportId = null;
};

async function resolveReport(id) {
    if (!confirm('Mark this report as resolved?')) return;

    setLoading(true);
    try {

        await new Promise(resolve => setTimeout(resolve, 1000)); 

        const report = allReportsData.find(r => r.report_id === id);
        if (report) {
            report.status = 'Resolved';
            report.resolved_at = new Date().toISOString();
        }

        renderAll();
        toast(`Report #${id} has been resolved`, 'success');
    } catch (e) {
        toast('Error resolving report: ' + e.message, 'error');
    }
    setLoading(false);
}

function exportComplianceReport() {
    const filtered = getFiltered();
    const rows = [
        ['Report ID', 'Date', 'Type', 'Severity', 'Status', 'Driver', 'Customer', 'Description', 'Resolved At']
    ];

    filtered.forEach(r => {
        rows.push([
            `RPT-${String(r.report_id).padStart(5,'0')}`,
            new Date(r.reported_at).toLocaleString(),
            r.report_type,
            r.severity,
            r.status,
            r.driver_name,
            r.customer_name,
            r.description,
            r.resolved_at ? new Date(r.resolved_at).toLocaleString() : ''
        ]);
    });

    const csv = rows.map(row => row.map(cell => `"${(cell || '').toString().replace(/"/g, '""')}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'compliance_report_' + new Date().toISOString().slice(0,10) + '.csv';
    a.click();
}

const svgCheck = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
const svgBell = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>`;

window.addEventListener('load', () => {
    document.getElementById('tableView').style.display = 'block';
    document.getElementById('cardView').style.display = 'none';
    renderAll();
});
</script>

<?php include __DIR__ . '/chat_widget.php'; ?>
</body>
</html>