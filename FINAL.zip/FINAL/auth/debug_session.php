<?php
session_start();

$db_host = 'localhost';
$db_name = 'coretransaction2';
$db_user = 'root';
$db_pass = '';

$error = '';
$debug = [];

$debug[] = "1. Script started";
$debug[] = "2. Session ID: " . session_id();
$debug[] = "3. Request method: " . $_SERVER['REQUEST_METHOD'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $debug[] = "4. POST request received";

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $debug[] = "5. Username: $username";
    $debug[] = "6. Password length: " . strlen($password);

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
        $debug[] = "7. ERROR: Empty credentials";
    } else {
        $debug[] = "7. Credentials provided, connecting to DB...";

        try {
            $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $debug[] = "8. Database connected";

            $stmt = $pdo->prepare("SELECT * FROM core_users WHERE username = :username AND status = 'Active' LIMIT 1");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $debug[] = "9. User NOT found in database";
                $error = 'Invalid username or password';
            } else {
                $debug[] = "9. User found: " . $user['username'];
                $debug[] = "10. DB password: " . $user['password'];
                $debug[] = "11. Input password: $password";
                $debug[] = "12. Passwords match: " . ($password === $user['password'] ? 'YES' : 'NO');

                if ($password === $user['password']) {
                    $debug[] = "13. Login successful! Setting session variables...";

                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['logged_in'] = true;
                    $_SESSION['login_time'] = time();

                    $debug[] = "14. Session variables set";
                    $debug[] = "15. Session content: " . print_r($_SESSION, true);

                    $debug[] = "16. Writing session to disk...";
                    session_write_close();
                    $debug[] = "17. Session written";

                    session_start();
                    $debug[] = "18. Session restarted";
                    $debug[] = "19. Session after restart: " . print_r($_SESSION, true);

                    ?>
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Login Debug</title>
                        <style>
                            body { font-family: Arial; padding: 20px; }
                            .success { background: #d4edda; color: #155724; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
                            .debug { background: #f8f9fa; padding: 15px; border-radius: 8px; font-family: monospace; font-size: 12px; }
                            .debug-item { margin: 5px 0; padding: 5px; background: white; border-left: 3px solid #007bff; }
                        </style>
                    </head>
                    <body>
                        <div class="success">
                            <h2>✅ LOGIN SUCCESSFUL!</h2>
                            <p>User: <?php echo htmlspecialchars($_SESSION['username']); ?></p>
                            <p>User ID: <?php echo $_SESSION['user_id']; ?></p>
                        </div>

                        <h3>Debug Log:</h3>
                        <div class="debug">
                            <?php foreach ($debug as $item): ?>
                                <div class="debug-item"><?php echo htmlspecialchars($item); ?></div>
                            <?php endforeach; ?>
                        </div>

                        <br>
                        <p><strong>Now check if session persists:</strong></p>
                        <p><a href="debug_session.php" style="padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; display: inline-block;">Check Session Debug</a></p>
                        <p><a href="dashboard.php" style="padding: 10px 20px; background: #00D084; color: white; text-decoration: none; border-radius: 4px; display: inline-block;">Go to Dashboard</a></p>
                    </body>
                    </html>
                    <?php
                    exit;
                } else {
                    $debug[] = "13. Password mismatch!";
                    $error = 'Invalid username or password';
                }
            }
        } catch (PDOException $e) {
            $debug[] = "ERROR: " . $e->getMessage();
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login Debug</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #00D084;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
        }
        .error {
            background: #fee;
            color: #c00;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .debug {
            background: #f0f0f0;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
            font-family: monospace;
            font-size: 12px;
        }
        .debug-item {
            margin: 3px 0;
            padding: 3px;
        }
    </style>
</head>
<body>
    <h2>🔬 Login Diagnostic</h2>

    <?php if ($error): ?>
        <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" value="admin" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" value="admin123" required>
        </div>

        <button type="submit" name="login">Login & Debug</button>
    </form>

    <?php if (!empty($debug)): ?>
        <div class="debug">
            <strong>Debug Log:</strong><br>
            <?php foreach ($debug as $item): ?>
                <div class="debug-item"><?php echo htmlspecialchars($item); ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</body>
</html>