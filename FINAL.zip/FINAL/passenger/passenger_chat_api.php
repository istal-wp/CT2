<?php
session_start();
header('Content-Type: application/json');
error_reporting(0);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in'], $_SESSION['customer_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

define('PCH_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('PCH_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

$CUST_ID   = (int)$_SESSION['customer_id'];
$CUST_NAME = $_SESSION['name'] ?? $_SESSION['username'] ?? 'Passenger';

function pch_get(string $table, array $params = []): array {
    $qs = '';
    if ($params) {
        $parts = [];
        foreach ($params as $k => $v) {
            $parts[] = rawurlencode($k) . '=' . str_replace(
                ['%2C','%3A','%2E','%28','%29'],
                [',',   ':',  '.',  '(',  ')'],
                rawurlencode($v)
            );
        }
        $qs = '?' . implode('&', $parts);
    }
    $ch = curl_init(PCH_URL . '/rest/v1/' . $table . $qs);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . PCH_KEY,
            'Authorization: Bearer ' . PCH_KEY,
            'Accept: application/json',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 400) return [];
    $d = json_decode($res, true);
    return is_array($d) ? $d : [];
}

function pch_patch(string $table, string $filter, array $body): bool {
    $ch = curl_init(PCH_URL . '/rest/v1/' . $table . '?' . $filter);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($body),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . PCH_KEY,
            'Authorization: Bearer ' . PCH_KEY,
            'Content-Type: application/json',
            'Prefer: return=minimal',
        ],
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 300;
}

function pch_post(string $table, array $body): bool {
    $ch = curl_init(PCH_URL . '/rest/v1/' . $table);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'POST',
        CURLOPT_POSTFIELDS     => json_encode($body),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . PCH_KEY,
            'Authorization: Bearer ' . PCH_KEY,
            'Content-Type: application/json',
            'Prefer: return=minimal',
        ],
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 300;
}

function pch_uuid(): string {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

$action = $_POST['action'] ?? '';

switch ($action) {

    case 'get_or_create_conversation':
        $rows = pch_get('core2_passenger_conversations', [
            'customer_id' => 'eq.' . $CUST_ID,
            'select'      => 'id,customer_id,customer_name,status,created_at',
            'order'       => 'created_at.desc',
            'limit'       => '1',
        ]);
        if (!empty($rows[0])) {
            echo json_encode(['success' => true, 'conversation' => $rows[0]]);
            break;
        }
        $id = pch_uuid();
        $ok = pch_post('core2_passenger_conversations', [
            'id'            => $id,
            'customer_id'   => $CUST_ID,
            'customer_name' => $CUST_NAME,
            'status'        => 'open',
        ]);
        echo json_encode([
            'success'      => $ok,
            'conversation' => $ok ? [
                'id'            => $id,
                'customer_id'   => $CUST_ID,
                'customer_name' => $CUST_NAME,
                'status'        => 'open',
                'created_at'    => gmdate('Y-m-d\TH:i:s\Z'),
            ] : null,
        ]);
        break;

    case 'get_messages':
        $conv_id = $_POST['conversation_id'] ?? '';
        $since   = $_POST['since'] ?? null;
        if (!$conv_id) {
            echo json_encode(['success' => false, 'message' => 'Missing conversation_id']);
            break;
        }
        $p = [
            'conversation_id' => 'eq.' . $conv_id,
            'select'          => 'id,sender_type,sender_name,content,created_at',
            'order'           => 'created_at.asc',
            'limit'           => '200',
        ];
        if ($since) $p['created_at'] = 'gt.' . $since;
        $msgs = pch_get('core2_passenger_messages', $p);
        echo json_encode(['success' => true, 'messages' => $msgs]);
        break;

    case 'send_message':
        $conv_id = $_POST['conversation_id'] ?? '';
        $content = trim($_POST['content'] ?? '');
        if (!$conv_id || !$content) {
            echo json_encode(['success' => false, 'message' => 'Missing data']);
            break;
        }
        $id  = pch_uuid();
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $ok  = pch_post('core2_passenger_messages', [
            'id'              => $id,
            'conversation_id' => $conv_id,
            'sender_type'     => 'passenger',
            'sender_name'     => $CUST_NAME,
            'content'         => $content,
        ]);
        if ($ok) {
            pch_patch('core2_passenger_conversations', 'id=eq.' . $conv_id, [
                'updated_at' => $now,
            ]);
        }
        echo json_encode([
            'success' => $ok,
            'message' => $ok ? [
                'id'              => $id,
                'conversation_id' => $conv_id,
                'sender_type'     => 'passenger',
                'sender_name'     => $CUST_NAME,
                'content'         => $content,
                'created_at'      => $now,
            ] : null,
            'error' => $ok ? null : 'Failed to save message',
        ]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Unknown action']);
}