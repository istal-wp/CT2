<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || !isset($_SESSION['customer_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

define('SUPABASE_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function supabase_get($table, $params = []) {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY
        ],
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode >= 200 && $httpCode < 300) return json_decode($response, true) ?: [];
    error_log("Supabase GET Error ({$table}): HTTP {$httpCode} - {$response}");
    return [];
}

$customer_id = $_SESSION['customer_id'];
$today = (new DateTime('now', new DateTimeZone('Asia/Manila')))->format('Y-m-d');

$customer = supabase_get('core2_customers', [
    'customer_id' => 'eq.' . $customer_id,
    'select' => '*'
]);
$customerName = $customer[0]['name'] ?? $_SESSION['name'] ?? 'Passenger';

$activeBookings = supabase_get('core2_bookings', [
    'customer_id'    => 'eq.' . $customer_id,
    'booking_status' => 'in.(Pending,Confirmed,In Progress)',
    'select'         => 'booking_id,booking_reference,booking_date,booking_status,total_amount',
    'order'          => 'created_at.desc',
]);
$bookingCount = count($activeBookings);

$latestActive = $activeBookings[0] ?? null;

if ($latestActive) {
    $syncBid = (int)$latestActive['booking_id'];

    $syncRides = supabase_get('core2_rides', [
        'booking_id' => 'eq.' . $syncBid,
        'select'     => 'ride_id,ride_status,driver_id,start_time',
        'limit'      => '1',
    ]);
    $syncRide = $syncRides[0] ?? [];
    $syncRideStatus = $syncRide['ride_status'] ?? '';
    $syncRideId     = $syncRide['ride_id']     ?? null;
    $syncDriverId   = $syncRide['driver_id']   ?? null;

    if (
        ($latestActive['booking_status'] ?? '') === 'Pending' &&
        $syncRideStatus === 'Cancelled' &&
        empty($syncDriverId)
    ) {
        $sbPatch('core2_bookings', 'booking_id=eq.'.$syncBid, ['booking_status'=>'Cancelled','updated_at'=>date('c')]);
        $latestActive = null; 
    }

    $syncDriverStatus  = '';
    $syncCore1DriverId = null;
    if ($syncDriverId) {
        $drvRows = supabase_get('core1_drivers', [
            'core2_driver_id' => 'eq.' . (int)$syncDriverId,
            'select'          => 'id,status',
            'limit'           => '1',
        ]);
        if (!empty($drvRows)) {
            $syncDriverStatus  = strtolower($drvRows[0]['status'] ?? '');
            $syncCore1DriverId = $drvRows[0]['id'] ?? null;
        }
    }

    $sbPatch = function(string $table, string $filter, array $data) {
        $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . $filter;
        $ch  = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => 'PATCH',
            CURLOPT_POSTFIELDS     => json_encode($data),
            CURLOPT_HTTPHEADER     => [
                'apikey: ' . SUPABASE_ANON_KEY,
                'Authorization: Bearer ' . SUPABASE_ANON_KEY,
                'Content-Type: application/json',
            ],
        ]);
        curl_exec($ch); curl_close($ch);
    };

    $nowCompleted = false;

    if ($syncRideId && !in_array($syncRideStatus, ['Completed','Cancelled'])) {
        $c1 = supabase_get('core1_trips', ['ride_id'=>'eq.'.(int)$syncRideId,'status'=>'eq.COMPLETED','select'=>'id','limit'=>'1']);
        if (!empty($c1)) $nowCompleted = true;
    }

    if (!$nowCompleted && $syncCore1DriverId && !in_array($syncRideStatus, ['Completed','Cancelled']) && !empty($syncRide['start_time'])) {
        $anchor = (new DateTime($syncRide['start_time'], new DateTimeZone('UTC')))->modify('-5 minutes')->format('c');
        $c1b = supabase_get('core1_trips', ['driver_id'=>'eq.'.(int)$syncCore1DriverId,'status'=>'eq.COMPLETED','created_at'=>'gte.'.$anchor,'select'=>'id','order'=>'created_at.desc','limit'=>'1']);
        if (!empty($c1b)) $nowCompleted = true;
    }

    if ($nowCompleted) {
        if ($syncRideId) $sbPatch('core2_rides', 'ride_id=eq.'.(int)$syncRideId, ['ride_status'=>'Completed','end_time'=>date('c')]);
        $sbPatch('core2_bookings', 'booking_id=eq.'.$syncBid, ['booking_status'=>'Completed','payment_status'=>'Paid','updated_at'=>date('c')]);
        $sbPatch('core2_payment_authorization', 'booking_id=eq.'.$syncBid, ['payment_status'=>'Captured']);
        $latestActive = null;
        $bookingCount = max(0, $bookingCount - 1);
    } else {

        if ($syncRideStatus === 'Accepted' && ($latestActive['booking_status'] ?? '') === 'Pending') {
            $sbPatch('core2_bookings', 'booking_id=eq.'.$syncBid, ['booking_status'=>'Confirmed','updated_at'=>date('c')]);
            $latestActive['booking_status'] = 'Confirmed';
        }
        if ($syncRideStatus === 'In Progress' && in_array($latestActive['booking_status'] ?? '', ['Pending','Confirmed'])) {
            $sbPatch('core2_bookings', 'booking_id=eq.'.$syncBid, ['booking_status'=>'In Progress','updated_at'=>date('c')]);
            $latestActive['booking_status'] = 'In Progress';
        }

        $driverOnTrip = in_array($syncDriverStatus, [
            'on_trip','in_trip','in_progress','in progress','busy','driving','on trip','in trip'
        ]);
        if ($driverOnTrip && in_array($latestActive['booking_status'] ?? '', ['Pending','Confirmed'])) {
            $sbPatch('core2_bookings', 'booking_id=eq.'.$syncBid, ['booking_status'=>'In Progress','updated_at'=>date('c')]);
            $latestActive['booking_status'] = 'In Progress';
        }
    }
}

$todayRides = supabase_get('core2_rides', [
    'customer_id' => 'eq.' . $customer_id,
    'ride_status' => 'eq.Completed',
    'start_time'  => 'gte.' . $today . 'T00:00:00Z',
    'select'      => 'ride_id'
]);
$todayRidesCount = count($todayRides);

$paidBookings = supabase_get('core2_bookings', [
    'customer_id'    => 'eq.' . $customer_id,
    'payment_status' => 'eq.Paid',
    'select'         => 'total_amount'
]);
$totalSpent = array_sum(array_column($paidBookings, 'total_amount'));

$todayBookings = supabase_get('core2_bookings', [
    'customer_id'    => 'eq.' . $customer_id,
    'booking_date'   => 'eq.' . $today,
    'payment_status' => 'in.(Paid,Partial)',
    'select'         => 'total_amount'
]);
$todaySpending = array_sum(array_column($todayBookings, 'total_amount'));

$recentRides = supabase_get('core2_rides', [
    'customer_id' => 'eq.' . $customer_id,
    'order'       => 'start_time.desc',
    'limit'       => '5',
    'select'      => 'ride_id,start_time,end_time,start_location,end_location,ride_status'
]);

$ratings = supabase_get('core2_ratings', [
    'customer_id' => 'eq.' . $customer_id,
    'select'      => 'rating_value'
]);
$avgRating = !empty($ratings) ? round(array_sum(array_column($ratings, 'rating_value')) / count($ratings), 1) : 0;

$pendingPayments = supabase_get('core2_bookings', [
    'customer_id'    => 'eq.' . $customer_id,
    'payment_status' => 'in.(Unpaid,Partial)',
    'booking_status' => 'neq.Cancelled',
    'select'         => 'booking_id,total_amount'
]);
$pendingPaymentsCount = count($pendingPayments);
$pendingAmount = array_sum(array_column($pendingPayments, 'total_amount'));

$hour = (int)(new DateTime('now', new DateTimeZone('Asia/Manila')))->format('H');
$greeting = $hour < 12 ? 'Good Morning' : ($hour < 18 ? 'Good Afternoon' : 'Good Evening');
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<title>EnviroCab – Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root,
[data-theme="light"] {
    --primary-green:   #00D084;
    --dark-green:      #00A86B;
    --bg-gradient:     linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
    --card-bg:         #FFFFFF;
    --card-border:     #E2E8F0;
    --header-bg:       rgba(255,255,255,0.85);
    --header-border:   rgba(255,255,255,0.5);
    --text-dark:       #1A202C;
    --text-medium:     #4A5568;
    --text-light:      #718096;
    --input-bg:        #FAFAFA;
    --input-border:    #E2E8F0;
    --row-border:      rgba(0,0,0,0.04);
    --nav-bg:          rgba(255,255,255,0.95);
    --icon-btn-bg:     rgba(255,255,255,0.9);
    --icon-btn-border: rgba(0,0,0,0.05);
    --shadow-card:     0 2px 8px rgba(0,0,0,0.04);
    --shadow-hero:     0 8px 32px rgba(0,208,132,0.2);
    --shadow-nav:      0 -4px 24px rgba(0,0,0,0.05);
    --stripe-bg:       rgba(0,0,0,0.025);
    --action-border:   #E2E8F0;
}
[data-theme="dark"] {
    --primary-green:   #00D084;
    --dark-green:      #00A86B;
    --bg-gradient:     linear-gradient(135deg, #0D1F1A 0%, #0F172A 100%);
    --card-bg:         #1A2820;
    --card-border:     #263330;
    --header-bg:       rgba(15,24,18,0.94);
    --header-border:   rgba(0,208,132,0.1);
    --text-dark:       #E8F5F1;
    --text-medium:     #9FC4AE;
    --text-light:      #607D6B;
    --input-bg:        #111E18;
    --input-border:    #263330;
    --row-border:      rgba(255,255,255,0.05);
    --nav-bg:          rgba(15,24,18,0.97);
    --icon-btn-bg:     rgba(255,255,255,0.06);
    --icon-btn-border: rgba(255,255,255,0.08);
    --shadow-card:     0 2px 12px rgba(0,0,0,0.35);
    --shadow-hero:     0 8px 40px rgba(0,208,132,0.12);
    --shadow-nav:      0 -4px 24px rgba(0,0,0,0.5);
    --stripe-bg:       rgba(255,255,255,0.025);
    --action-border:   #263330;
}

*::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
*, *::before, *::after {
    transition: background-color .3s ease, border-color .25s ease, color .2s ease, box-shadow .3s ease;
}
input, button, svg, img { transition: none; }
.icon-btn, .theme-btn, .nav-item, .action-btn, .stat-card {
    transition: background .2s, transform .15s, opacity .2s, border-color .2s, box-shadow .2s !important;
}
.t-sun, .t-moon {
    transition: opacity .35s ease, transform .4s cubic-bezier(.34,1.56,.64,1) !important;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--bg-gradient);
    color: var(--text-dark);
    min-height: 100vh;
    padding-bottom: 100px;
    -webkit-font-smoothing: antialiased;
    transition:opacity .15s ease;
}

.header {
    background: var(--header-bg);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    padding: 16px 20px;
    position: sticky; top: 0; z-index: 100;
    border-bottom: 1px solid var(--header-border);
}
.header-content { display:flex; justify-content:space-between; align-items:center; }
.logo-img { height:28px; width:auto; }
.header-right { display:flex; align-items:center; gap:10px; }

.icon-btn {
    width:36px; height:36px; border-radius:12px;
    background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
    display:flex; align-items:center; justify-content:center; cursor:pointer;
}
.icon-btn svg { stroke:var(--text-medium); }
.icon-btn:active { transform:scale(0.93); }
.logout-btn { background:rgba(239,68,68,0.12) !important; border-color:rgba(239,68,68,0.2) !important; }
.logout-btn svg { stroke:#EF4444 !important; }

.theme-btn {
    width:36px; height:36px; border-radius:12px;
    background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
    display:flex; align-items:center; justify-content:center; cursor:pointer;
    position:relative; overflow:hidden;
}
.theme-btn:active { transform:scale(0.93); }
.t-sun, .t-moon { position:absolute; }
[data-theme="light"] .t-sun  { opacity:1;  transform:rotate(0deg)   scale(1);  }
[data-theme="light"] .t-moon { opacity:0;  transform:rotate(90deg)  scale(.6); }
[data-theme="dark"]  .t-sun  { opacity:0;  transform:rotate(-90deg) scale(.6); }
[data-theme="dark"]  .t-moon { opacity:1;  transform:rotate(0deg)   scale(1);  }

.main-content { padding:20px; }

.hero-card {
    background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
    border-radius:24px; padding:28px 24px; color:white;
    margin-bottom:20px; box-shadow:var(--shadow-hero);
    position:relative; overflow:hidden;
}
.hero-card::before {
    content:''; position:absolute; top:-50%; right:-20%;
    width:200px; height:200px; background:rgba(255,255,255,0.1); border-radius:50%;
}
.hero-card::after {
    content:''; position:absolute; bottom:-30%; left:-10%;
    width:150px; height:150px; background:rgba(255,255,255,0.06); border-radius:50%;
}
.hero-greeting { font-size:14px; opacity:.9; margin-bottom:4px; position:relative; }
.hero-title    { font-size:24px; font-weight:800; margin-bottom:8px; position:relative; }
.hero-amount   { font-size:42px; font-weight:900; letter-spacing:-1px; margin-bottom:4px; position:relative; }
.hero-label    { font-size:13px; opacity:.85; position:relative; }
.hero-stats    { display:flex; gap:12px; margin-top:24px; position:relative; }
.hero-stat {
    flex:1; background:rgba(255,255,255,0.15);
    backdrop-filter:blur(10px); padding:12px; border-radius:16px; text-align:center;
}
.hero-stat-value { font-size:20px; font-weight:700; margin-bottom:4px; }
.hero-stat-label { font-size:11px; opacity:.85; }

.stats-grid {
    display:grid; grid-template-columns:repeat(2,1fr);
    gap:12px; margin-bottom:20px;
}
.stat-card {
    background:var(--card-bg); border-radius:20px; padding:20px;
    border:1px solid var(--card-border); box-shadow:var(--shadow-card);
}
.stat-card:active { transform:scale(0.98); }
.stat-icon {
    width:44px; height:44px; border-radius:14px;
    background:rgba(0,208,132,0.1);
    display:flex; align-items:center; justify-content:center; margin-bottom:12px;
}
.stat-icon svg { stroke:var(--primary-green); }
.stat-value { font-size:28px; font-weight:800; color:var(--text-dark); margin-bottom:4px; line-height:1; }
.stat-label { font-size:12px; color:var(--text-light); font-weight:500; }

.section-label {
    font-size:12px; font-weight:700; color:var(--text-light);
    text-transform:uppercase; letter-spacing:.08em; margin:24px 0 12px;
}

.quick-grid {
    display:grid; grid-template-columns:repeat(3,1fr);
    gap:10px; margin-bottom:20px;
}
.action-btn {
    background:var(--card-bg); border:1.5px solid var(--action-border);
    padding:16px 10px; border-radius:20px; cursor:pointer;
    text-align:center; text-decoration:none; color:var(--text-dark);
    display:flex; flex-direction:column; align-items:center; gap:8px;
}
.action-btn:active { transform:scale(0.97); border-color:var(--primary-green); }
.action-icon {
    width:44px; height:44px; border-radius:14px;
    background:rgba(0,208,132,0.1);
    display:flex; align-items:center; justify-content:center;
}
.action-icon svg { stroke:var(--primary-green); }
.action-label { font-size:12px; font-weight:700; color:var(--text-dark); }

.tracking-banner {
    background:linear-gradient(135deg,var(--primary-green),var(--dark-green));
    border-radius:20px; padding:16px 20px; margin-bottom:16px;
    display:flex; align-items:center; gap:14px;
    box-shadow:0 6px 24px rgba(0,208,132,0.25); text-decoration:none;
    animation:slideUp .4s ease forwards;
}
.tracking-banner:active { transform:scale(0.98); }
.tb-icon {
    width:48px; height:48px; background:rgba(255,255,255,0.2); border-radius:16px;
    display:flex; align-items:center; justify-content:center; flex-shrink:0;
}
.tb-content { flex:1; }
.tb-label { font-size:12px; color:rgba(255,255,255,0.85); font-weight:600; margin-bottom:2px; }
.tb-title { font-size:15px; font-weight:800; color:white; }
.tb-status { font-size:12px; color:rgba(255,255,255,0.85); margin-top:2px; }
.tb-arrow { color:rgba(255,255,255,0.8); }
.live-pill {
    display:inline-flex; align-items:center; gap:5px;
    background:rgba(255,255,255,0.2); border-radius:12px;
    padding:3px 10px; font-size:11px; font-weight:700; color:white; margin-top:5px;
}
.live-dot-sm {
    width:6px; height:6px; background:white; border-radius:50%;
    animation:livePulse 1.5s ease-in-out infinite;
}
@keyframes livePulse {
    0%,100%{box-shadow:0 0 0 2px rgba(255,255,255,0.3);}
    50%{box-shadow:0 0 0 4px rgba(255,255,255,0.1);}
}

.notif-dot {
    display:inline-flex; align-items:center; justify-content:center;
    background:#EF4444; color:white;
    font-size:10px; font-weight:700;
    width:18px; height:18px; border-radius:50%;
    margin-left:4px; vertical-align:middle;
}

.form-card {
    background:var(--card-bg); border-radius:20px; padding:20px;
    border:1px solid var(--card-border); box-shadow:var(--shadow-card); margin-bottom:16px;
}
.form-card-header { display:flex; align-items:center; gap:12px; margin-bottom:16px; }
.form-card-icon {
    width:44px; height:44px; border-radius:14px;
    display:flex; align-items:center; justify-content:center; flex-shrink:0;
}
.form-card-title    { font-size:16px; font-weight:700; color:var(--text-dark); }
.form-card-subtitle { font-size:12px; color:var(--text-light); margin-top:2px; }

.info-row {
    display:flex; align-items:center; justify-content:space-between;
    padding:12px 0; border-bottom:1px solid var(--row-border);
}
.info-row:last-child { border-bottom:none; padding-bottom:0; }
.info-left  { display:flex; align-items:center; gap:10px; }
.info-icon  { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; }
.info-key   { font-size:12px; color:var(--text-light); margin-bottom:2px; }
.info-value { font-size:14px; font-weight:600; color:var(--text-dark); }

.ride-item {
    padding:12px 0; border-bottom:1px solid var(--row-border);
}
.ride-item:last-child { border-bottom:none; padding-bottom:0; }
.ride-route { font-size:13px; font-weight:600; color:var(--text-dark); margin-bottom:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.ride-meta  { font-size:11px; color:var(--text-light); margin-bottom:5px; }
.ride-badge {
    display:inline-flex; align-items:center; gap:4px;
    padding:3px 9px; border-radius:7px; font-size:11px; font-weight:700;
}
.status-completed   { background:rgba(16,185,129,0.12);  color:#10B981; }
.status-cancelled   { background:rgba(239,68,68,0.1);    color:#EF4444; }
.status-pending     { background:rgba(245,158,11,0.12);  color:#F59E0B; }
.status-confirmed   { background:rgba(96,165,250,0.12);  color:#3B82F6; }
.status-in-progress { background:rgba(0,208,132,0.12);   color:#065F46; }
[data-theme="dark"] .status-completed { background:rgba(16,185,129,0.2); color:#34D399; }
[data-theme="dark"] .status-in-progress { color:var(--primary-green); }

.empty-state {
    text-align:center; padding:40px 20px;
}
.empty-icon { margin-bottom:12px; display:flex; align-items:center; justify-content:center; opacity:.4; }
.empty-text { font-size:13px; color:var(--text-light); }

.alert-card {
    background:rgba(245,158,11,0.07);
    border:1.5px solid rgba(245,158,11,0.25);
    border-radius:20px; padding:20px; margin-bottom:16px;
}
.alert-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
.alert-title {
    font-size:15px; font-weight:700; color:#B45309;
    display:flex; align-items:center; gap:8px;
}
.alert-title svg { stroke:#F59E0B; }
[data-theme="dark"] .alert-title { color:#FBBF24; }
.alert-link { color:var(--primary-green); text-decoration:none; font-size:13px; font-weight:600; }
.alert-sub  { font-size:13px; color:var(--text-medium); margin-bottom:6px; }
.alert-amount { font-size:20px; font-weight:800; color:var(--text-dark); }

.bottom-nav {
    position:fixed; bottom:0; left:0; right:0;
    background:var(--nav-bg);
    backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
    border-top:1px solid var(--card-border);
    padding:12px 0 20px;
    display:grid; grid-template-columns:repeat(4,1fr);
    z-index:99; box-shadow:var(--shadow-nav);
}
.nav-item {
    display:flex; flex-direction:column; align-items:center; gap:4px;
    padding:8px; cursor:pointer; border:none; background:none;
}
.nav-item:active { transform:scale(0.95); }
.nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
.nav-icon svg { stroke:var(--text-light); opacity:.5; }
.nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
.nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:.7; }
.nav-item.active .nav-label { color:var(--primary-green); opacity:1; }

@media (min-width:768px) {
    body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,0.12); }
    .bottom-nav { max-width:480px; left:50%; transform:translateX(-50%); }
}
@keyframes slideUp {
    from { opacity:0; transform:translateY(20px); }
    to   { opacity:1; transform:translateY(0); }
}
.hero-card, .stat-card, .form-card, .action-btn, .alert-card { animation:slideUp .4s ease forwards; }

    .notif-panel-wrap{position:relative;}
    .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:310px;max-height:400px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.15);z-index:999;display:none;flex-direction:column;overflow:hidden;}
    .notif-panel.open{display:flex;}
    .notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);flex-shrink:0;}
    .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
    .notif-mark-read{font-size:11px;font-weight:600;color:var(--dark-green);background:none;border:none;cursor:pointer;padding:0;}
    .notif-list{overflow-y:auto;flex:1;padding:4px 0;}
    .notif-item{display:flex;align-items:flex-start;gap:10px;padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--row-border);transition:background .15s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,208,132,0.06);}
    .notif-item.unread{background:rgba(0,208,132,0.04);}
    .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
    .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
    .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
    .notif-item-body{flex:1;min-width:0;}
    .notif-item-title{font-size:12px;font-weight:700;color:var(--text-dark);margin-bottom:2px;}
    .notif-item-sub{font-size:11px;color:var(--text-light);line-height:1.4;}
    .notif-item-time{font-size:10px;color:var(--text-light);margin-top:3px;}
    .notif-empty{padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;}
    .notif-spinner{width:20px;height:20px;border:2px solid var(--card-border);border-top-color:#00D084;border-radius:50%;animation:nspin .7s linear infinite;margin:16px auto;}
    @keyframes nspin{to{transform:rotate(360deg);}}
    .notif-count-badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 3px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:9px;font-weight:800;color:#fff;display:none;align-items:center;justify-content:center;line-height:1;}

    .logout-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center;padding:24px;}
    .logout-overlay.open{display:flex;}
    .logout-modal{background:var(--card-bg);border-radius:24px;padding:28px 24px 24px;width:100%;max-width:320px;box-shadow:0 16px 48px rgba(0,0,0,0.18);animation:lmodalIn .25s cubic-bezier(.34,1.56,.64,1);}
    @keyframes lmodalIn{from{transform:scale(.88);opacity:0;}to{transform:scale(1);opacity:1;}}
    .logout-modal-icon{width:52px;height:52px;border-radius:16px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
    .logout-modal-title{font-size:17px;font-weight:800;color:var(--text-dark);text-align:center;margin-bottom:6px;}
    .logout-modal-sub{font-size:13px;color:var(--text-light);text-align:center;line-height:1.5;margin-bottom:22px;}
    .logout-modal-btns{display:flex;gap:10px;}
    .logout-cancel-btn{flex:1;padding:13px;border-radius:14px;background:var(--input-bg);border:1px solid var(--card-border);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;}
    .logout-confirm-btn{flex:1;padding:13px;border-radius:14px;background:#EF4444;border:none;font-size:14px;font-weight:700;color:#fff;cursor:pointer;}
</style>
</head>
<body>

<script>
(function(){
    var t = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>

<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img"
             onerror="this.style.display='none'">
        <div class="header-right">

            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none"
                     stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="5"/>
                    <line x1="12" y1="1"  x2="12" y2="3"/>
                    <line x1="12" y1="21" x2="12" y2="23"/>
                    <line x1="4.22"  y1="4.22"  x2="5.64"  y2="5.64"/>
                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
                    <line x1="1"  y1="12" x2="3"  y2="12"/>
                    <line x1="21" y1="12" x2="23" y2="12"/>
                    <line x1="4.22"  y1="19.78" x2="5.64"  y2="18.36"/>
                    <line x1="18.36" y1="5.64"  x2="19.78" y2="4.22"/>
                </svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none"
                     stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                </svg>
            </button>

            <div class="notif-panel-wrap">
                <button class="icon-btn" id="notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications" style="position:relative;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                    <span class="notif-count-badge" id="notif-count-badge"></span>
                </button>
                <div class="notif-panel" id="notif-panel">
                    <div class="notif-panel-head">
                        <span class="notif-panel-title">Notifications</span>
                        <button class="notif-mark-read" onclick="markAllRead()">Mark all read</button>
                    </div>
                    <div class="notif-list" id="notif-list"><div class="notif-spinner"></div></div>
                </div>
            </div>

            <button class="icon-btn logout-btn" onclick="openLogout()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                    <polyline points="16 17 21 12 16 7"/>
                    <line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

    <div class="hero-card">
        <div class="hero-greeting"><?= $greeting ?>, <?= htmlspecialchars($customerName) ?>!</div>
        <div class="hero-title">Today's Spending</div>
        <div class="hero-amount">&#8369;<?= number_format($todaySpending, 2) ?></div>
        <div class="hero-label">Total Travel Cost Today</div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $bookingCount ?></div>
                <div class="hero-stat-label">Active</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $todayRidesCount ?></div>
                <div class="hero-stat-label">Rides Today</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $avgRating > 0 ? $avgRating : '—' ?></div>
                <div class="hero-stat-label">Avg Rating</div>
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="16" y1="13" x2="8" y2="13"/>
                    <line x1="16" y1="17" x2="8" y2="17"/>
                </svg>
            </div>
            <div class="stat-value"><?= $bookingCount ?></div>
            <div class="stat-label">Active Bookings</div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="1" y="3" width="15" height="13"/>
                    <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/>
                    <circle cx="5.5" cy="18.5" r="2.5"/>
                    <circle cx="18.5" cy="18.5" r="2.5"/>
                </svg>
            </div>
            <div class="stat-value"><?= $todayRidesCount ?></div>
            <div class="stat-label">Rides Today</div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="12" y1="1" x2="12" y2="23"/>
                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                </svg>
            </div>
            <div class="stat-value">&#8369;<?= number_format($totalSpent / 1000, 1) ?>K</div>
            <div class="stat-label">Total Spent</div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                </svg>
            </div>
            <div class="stat-value"><?= $avgRating > 0 ? $avgRating : '—' ?></div>
            <div class="stat-label">Avg Rating</div>
        </div>
    </div>

    <div class="section-label">Quick Actions</div>

    <?php if ($latestActive): ?>
    <?php
        $tbStatus = $latestActive['booking_status'];
        $tbRef    = $latestActive['booking_reference'];
        $tbId     = (int)$latestActive['booking_id'];
        $tbIsLive = in_array($tbStatus, ['Confirmed', 'In Progress']);
    ?>
    <a href="passenger_tracking.php?booking_id=<?= $tbId ?>" class="tracking-banner">
        <div class="tb-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>
            </svg>
        </div>
        <div class="tb-content">
            <div class="tb-label"><?= $tbIsLive ? 'Ride Active — Tap to Track' : 'Booking Pending' ?></div>
            <div class="tb-title"><?= htmlspecialchars($tbRef) ?></div>
            <?php if ($tbIsLive): ?>
            <div class="live-pill"><div class="live-dot-sm"></div> LIVE</div>
            <?php else: ?>
            <div class="tb-status">Waiting for driver…</div>
            <?php endif; ?>
        </div>
        <div class="tb-arrow">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
    </a>
    <?php endif; ?>

    <div class="quick-grid">
        <a href="passenger_booking.php" class="action-btn">
            <div class="action-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="1" y="3" width="15" height="13"/>
                    <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/>
                    <circle cx="5.5" cy="18.5" r="2.5"/>
                    <circle cx="18.5" cy="18.5" r="2.5"/>
                </svg>
            </div>
            <div class="action-label">Book Ride</div>
        </a>

        <a href="passenger_tracking.php" class="action-btn">
            <div class="action-icon" style="background:<?= $latestActive ? 'rgba(0,208,132,0.15)' : 'rgba(0,208,132,0.1)' ?>;">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>
                </svg>
            </div>
            <div class="action-label">
                Track
                <?php if ($latestActive && in_array($latestActive['booking_status'], ['Confirmed','In Progress'])): ?>
                <span style="display:inline-block;width:8px;height:8px;background:var(--primary-green);border-radius:50%;margin-left:3px;vertical-align:middle;box-shadow:0 0 0 2px rgba(0,208,132,0.3);animation:livePulse 1.5s ease-in-out infinite;"></span>
                <?php endif; ?>
            </div>
        </a>

        <a href="passenger_trips.php" class="action-btn">
            <div class="action-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                    <line x1="16" y1="2" x2="16" y2="6"/>
                    <line x1="8"  y1="2" x2="8"  y2="6"/>
                    <line x1="3"  y1="10" x2="21" y2="10"/>
                </svg>
            </div>
            <div class="action-label">My Trips</div>
        </a>

        <a href="passenger_payments.php" class="action-btn">
            <div class="action-icon" style="background:rgba(0,208,132,0.1);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                     style="stroke:var(--primary-green)">
                    <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                    <line x1="1" y1="10" x2="23" y2="10"/>
                </svg>
            </div>
            <div class="action-label">
                Payments

            </div>
        </a>

        <a href="passenger_history.php" class="action-btn">
            <div class="action-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 3v5h5"/>
                    <path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/>
                    <polyline points="12 7 12 12 15 15"/>
                </svg>
            </div>
            <div class="action-label">History</div>
        </a>

        <a href="my_rated_drivers.php" class="action-btn">
            <div class="action-icon" style="background:rgba(245,158,11,0.1);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                </svg>
            </div>
            <div class="action-label">My Ratings</div>
        </a>

        <a href="passenger_profile.php" class="action-btn">
            <div class="action-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </div>
            <div class="action-label">Profile</div>
        </a>

        <a href="passenger_feedback.php" class="action-btn">
            <div class="action-icon" style="background:rgba(139,92,246,0.1);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                    <line x1="8" y1="10" x2="16" y2="10"/>
                    <line x1="8" y1="14" x2="12" y2="14"/>
                </svg>
            </div>
            <div class="action-label">Feedback</div>
        </a>
    </div>

    <a href="passenger_feedback.php" style="text-decoration:none;">
        <div style="
            background:linear-gradient(135deg,#8B5CF6 0%,#6D28D9 100%);
            border-radius:20px; padding:18px 20px; margin-bottom:16px;
            display:flex; align-items:center; gap:14px;
            box-shadow:0 6px 20px rgba(139,92,246,0.25);
            cursor:pointer; position:relative; overflow:hidden;
        ">
            <div style="position:absolute;top:-30px;right:-20px;width:120px;height:120px;background:rgba(255,255,255,0.07);border-radius:50%;"></div>
            <div style="width:48px;height:48px;background:rgba(255,255,255,0.18);border-radius:16px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                    <line x1="8" y1="10" x2="16" y2="10"/>
                    <line x1="8" y1="14" x2="12" y2="14"/>
                </svg>
            </div>
            <div style="flex:1;min-width:0;position:relative;">
                <div style="font-size:15px;font-weight:800;color:white;margin-bottom:3px;">Rate Your Trip</div>
                <div style="font-size:12px;color:rgba(255,255,255,0.85);line-height:1.5;">Share your experience & help us improve EnviroCab.</div>
            </div>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.7)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;position:relative;">
                <polyline points="9 18 15 12 9 6"/>
            </svg>
        </div>
    </a>

    <?php if ($pendingPaymentsCount > 0): ?>
    <div class="alert-card">
        <div class="alert-header">
            <div class="alert-title">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                    <line x1="12" y1="9"  x2="12" y2="13"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>
                Pending Payments
            </div>
            <a href="passenger_payments.php" class="alert-link">View Details</a>
        </div>
        <div class="alert-sub">You have <?= $pendingPaymentsCount ?> booking(s) awaiting driver payment confirmation</div>
        <div class="alert-amount">Total Due: &#8369;<?= number_format($pendingAmount, 2) ?></div>
    </div>
    <?php endif; ?>

    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:rgba(0,208,132,0.1);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                </svg>
            </div>
            <div>
                <div class="form-card-title">Recent Rides</div>
                <div class="form-card-subtitle">Your latest trips</div>
            </div>
            <a href="passenger_trips.php" style="margin-left:auto; color:var(--primary-green); text-decoration:none; font-size:13px; font-weight:600;">
                View All
            </a>
        </div>

        <?php if (!empty($recentRides)): ?>
            <?php foreach ($recentRides as $ride):
                $statusKey = 'status-' . strtolower(str_replace(' ', '-', $ride['ride_status']));
            ?>
            <div class="ride-item">
                <div class="ride-route">
                    <?= htmlspecialchars($ride['start_location']) ?> &rarr; <?= htmlspecialchars($ride['end_location'] ?? 'In Progress') ?>
                </div>
                <div class="ride-meta"><?= (new DateTime($ride['start_time'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M d, Y g:i A') ?></div>
                <span class="ride-badge <?= $statusKey ?>">
                    <svg width="6" height="6" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
                    <?= htmlspecialchars($ride['ride_status']) ?>
                </span>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
        <div class="empty-state">
            <div class="empty-icon">
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="1" y="3" width="15" height="13"/>
                    <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/>
                    <circle cx="5.5" cy="18.5" r="2.5"/>
                    <circle cx="18.5" cy="18.5" r="2.5"/>
                </svg>
            </div>
            <div class="empty-text">No rides yet. Book your first ride!</div>
        </div>
        <?php endif; ?>
    </div>

</div>

<div class="bottom-nav">
    <button class="nav-item active">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="location.href='passenger_booking.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div>
        <span class="nav-label">Book</span>
    </button>
    <button class="nav-item" onclick="location.href='passenger_trips.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item" onclick="location.href='passenger_profile.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <span class="nav-label">Profile</span>
    </button>
</div>

<script>
function toggleTheme() {
    var html = document.documentElement;
    var next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('envirocab_theme', next);
}
<?php if ($latestActive): ?>
(function(){
    var BID = <?= (int)$latestActive['booking_id'] ?>;
    var timer = setInterval(poll, 10000); poll();
    async function poll() {
        try {
            var res = await fetch('passenger_booking.php?ajax_action=booking_status&booking_id='+BID);
            var d = await res.json();
            if (d.status === 'Completed') {
                clearInterval(timer);
                var bn = document.querySelector('.tracking-banner');
                if (bn) { bn.style.transition='opacity .4s'; bn.style.opacity='0'; setTimeout(function(){ bn.style.display='none'; }, 400); }
                showToast(d);
                setTimeout(function(){ window.location.reload(); }, 4000);
            } else if (d.status === 'Cancelled') {
                clearInterval(timer); setTimeout(function(){ window.location.reload(); }, 2000);
            }
        } catch(e) {}
    }
    function showToast(d) {
        var peso = String.fromCharCode(8369);
        var fare = d.total_amount ? peso+parseFloat(d.total_amount).toLocaleString('en-PH',{minimumFractionDigits:2}) : '';
        var t = document.createElement('div');
        t.style.cssText = 'position:fixed;bottom:90px;left:50%;transform:translateX(-50%) translateY(20px);background:linear-gradient(135deg,#00D084,#00A86B);color:white;border-radius:20px;padding:14px 22px;display:flex;align-items:center;gap:10px;box-shadow:0 8px 28px rgba(0,208,132,.4);z-index:9999;font-weight:700;font-size:14px;opacity:0;transition:opacity .3s,transform .3s;white-space:nowrap;';
        t.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg><span>Trip completed!'+(fare?' &mdash; '+fare:'')+'</span>';
        document.body.appendChild(t);
        setTimeout(function(){ t.style.opacity='1'; t.style.transform='translateX(-50%) translateY(0)'; }, 50);
        setTimeout(function(){ t.style.opacity='0'; t.style.transform='translateX(-50%) translateY(20px)'; setTimeout(function(){ t.remove(); }, 300); }, 3500);
    }
})();
<?php endif; ?>
</script>
<script>
const CUSTOMER_ID = <?= (int)$customer_id ?>;

const SB_URL = 'https://kyhndwabhbkduoaxeunq.supabase.co';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
let _notifOpen = false, _notifData = [], _notifTimer = null;
let _seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');

const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};

function toggleNotifPanel(e) {
    e.stopPropagation();
    _notifOpen = !_notifOpen;
    document.getElementById('notif-panel').classList.toggle('open', _notifOpen);
    if (_notifOpen) { fetchNotifs(); _notifTimer = setInterval(fetchNotifs, 8000); }
    else clearInterval(_notifTimer);
}

async function fetchNotifs() {
    try {
        const r = await fetch(SB_URL + '/rest/v1/core2_bookings?customer_id=eq.' + CUSTOMER_ID +
            '&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=15',
            {headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        _notifData = await r.json();
        renderNotifs();
        updateBadge();
    } catch(e) {}
}

function renderNotifs() {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!_notifData.length) { list.innerHTML = '<div class="notif-empty">No notifications yet.</div>'; return; }
    list.innerHTML = _notifData.map(b => {
        const cfg = STATUS_CFG[b.booking_status] || {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key = b.booking_id + '_' + b.booking_status;
        const unread = !_seen.includes(key);
        const amt = '\u20B1' + parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t = timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
}

function updateBadge() {
    const cnt = _notifData.filter(b => !_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    const el = document.getElementById('notif-count-badge');
    if (!el) return;
    if (cnt > 0) { el.textContent = cnt > 9 ? '9+' : cnt; el.style.display = 'flex'; }
    else el.style.display = 'none';
}

function goNotif(page, bid, key) {
    if (!_seen.includes(key)) { _seen.push(key); localStorage.setItem(SEEN_KEY, JSON.stringify(_seen)); }
    window.location.href = page + '?booking_id=' + bid;
}

function markAllRead() {
    _seen = _notifData.map(b => b.booking_id+'_'+b.booking_status);
    localStorage.setItem(SEEN_KEY, JSON.stringify(_seen));
    renderNotifs(); updateBadge();
}

function timeAgo(iso) {
    if (!iso) return '';
    const s = Math.floor((Date.now() - new Date(iso))/1000);
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s/60)+'m ago';
    if (s < 86400) return Math.floor(s/3600)+'h ago';
    return Math.floor(s/86400)+'d ago';
}

function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function openLogout() { document.getElementById('logout-overlay').classList.add('open'); }

document.addEventListener('click', function(e) {
    const panel = document.getElementById('notif-panel');
    const btn   = document.getElementById('notif-bell-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        _notifOpen = false; panel.classList.remove('open'); clearInterval(_notifTimer);
    }
});

document.addEventListener('DOMContentLoaded', () => { if (CUSTOMER_ID) fetchNotifs(); });
</script>

<div class="logout-overlay" id="logout-overlay" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="logout-modal">
        <div class="logout-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </div>
        <div class="logout-modal-title">Log out?</div>
        <div class="logout-modal-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-modal-btns">
            <button class="logout-cancel-btn" onclick="document.getElementById('logout-overlay').classList.remove('open')">Cancel</button>
            <button class="logout-confirm-btn" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{ once:true });
      a.addEventListener('touchstart',function(){ prerender(href); },{ once:true, passive:true });
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{ once:true });
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
<?php include 'passenger_chat_widget.php'; ?>
</body>
</html>