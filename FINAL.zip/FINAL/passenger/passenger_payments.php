<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['customer_id'])) {
    header('Location: ../auth/passenger_login.php');
    exit;
}

define('SUPABASE_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get($table, $params = []) {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) return json_decode($res, true) ?: [];
    error_log("SB GET {$table} HTTP {$code}: {$res}");
    return [];
}

$customer_id  = $_SESSION['customer_id'];
$pendingCount = 0;

$filter_status = $_GET['filter'] ?? 'all';
$search_ref    = trim($_GET['search'] ?? '');
$view_booking  = isset($_GET['booking_id']) ? (int)$_GET['booking_id'] : 0;

$all_bookings = sb_get('core2_bookings', [
    'customer_id' => 'eq.' . $customer_id,
    'select'      => 'booking_id,booking_reference,booking_date,total_amount,booking_status,payment_status,created_at',
    'order'       => 'created_at.desc',
]);

$summary   = ['total_paid' => 0, 'total_unpaid' => 0, 'total_refunded' => 0, 'count_paid' => 0, 'count_unpaid' => 0, 'month_spent' => 0];
$this_month = (new DateTime('now', new DateTimeZone('Asia/Manila')))->format('Y-m');
foreach ($all_bookings as $b) {
    $amt = (float)($b['total_amount'] ?? 0);
    if ($b['payment_status'] === 'Paid')     { $summary['total_paid']     += $amt; $summary['count_paid']++; }
    if ($b['payment_status'] === 'Unpaid' && ($b['booking_status'] ?? '') !== 'Cancelled')   { $summary['total_unpaid']   += $amt; $summary['count_unpaid']++; }
    if ($b['payment_status'] === 'Refunded') { $summary['total_refunded'] += $amt; }
    if ($b['payment_status'] === 'Paid' && strpos((string)($b['booking_date'] ?? ''), $this_month) === 0) {
        $summary['month_spent'] += $amt;
    }
}

$payments = [];

// ── BULK FETCH: collect all booking IDs that pass filters first ───────────────
$filtered_bookings = [];
foreach ($all_bookings as $b) {
    if ($filter_status !== 'all' && strtolower($b['payment_status'] ?? '') !== strtolower($filter_status)) continue;
    if ($search_ref !== '' && stripos($b['booking_reference'] ?? '', $search_ref) === false) continue;
    $filtered_bookings[] = $b;
}

if (!empty($filtered_bookings)) {
    $fBids = array_column($filtered_bookings, 'booking_id');
    $bidList = implode(',', array_map('intval', $fBids));

    // 1. Payment authorizations
    $payMap = [];
    foreach (sb_get('core2_payment_authorization', [
        'booking_id' => 'in.(' . $bidList . ')',
        'select'     => 'booking_id,payment_id,payment_method,authorization_code,transaction_reference,payment_gateway,authorized_at',
    ]) as $p) { $payMap[$p['booking_id']] = $p; }

    // 2. Fare computations
    $fareMap = [];
    foreach (sb_get('core2_fare_computation', [
        'booking_id' => 'in.(' . $bidList . ')',
        'select'     => 'booking_id,base_fare,distance_km,distance_rate,surge_multiplier,additional_charges,discount',
    ]) as $f) { $fareMap[$f['booking_id']] = $f; }

    // 3. Transactions (latest per booking — fetch all then keep latest in PHP)
    $txMap = [];
    foreach (sb_get('core2_transaction_processing', [
        'booking_id' => 'in.(' . $bidList . ')',
        'select'     => 'booking_id,transaction_id,transaction_status,transaction_time',
        'order'      => 'transaction_time.desc',
    ]) as $tx) {
        // Only keep the first (latest) row per booking since we order desc
        if (!isset($txMap[$tx['booking_id']])) $txMap[$tx['booking_id']] = $tx;
    }

    // 4. Rides → driver_id
    $ridesMap = [];
    foreach (sb_get('core2_rides', [
        'booking_id' => 'in.(' . $bidList . ')',
        'select'     => 'booking_id,driver_id',
    ]) as $r) {
        if (!isset($ridesMap[$r['booking_id']])) $ridesMap[$r['booking_id']] = $r;
    }

    // 5. Drivers (by core2_driver_id)
    $c2DriverIds = array_filter(array_unique(array_column($ridesMap, 'driver_id')));
    $driverNameMap = [];
    if (!empty($c2DriverIds)) {
        foreach (sb_get('core1_drivers', [
            'core2_driver_id' => 'in.(' . implode(',', array_map('intval', $c2DriverIds)) . ')',
            'select'          => 'driver_name,core2_driver_id',
        ]) as $d) { $driverNameMap[(int)($d['core2_driver_id'])] = $d['driver_name']; }
    }

    // Merge everything
    foreach ($filtered_bookings as $b) {
        $bid         = $b['booking_id'];
        $rideRow     = $ridesMap[$bid] ?? [];
        $driverName  = isset($rideRow['driver_id']) ? ($driverNameMap[(int)$rideRow['driver_id']] ?? null) : null;
        $payments[]  = array_merge(
            $b,
            $payMap[$bid]  ?? [],
            $fareMap[$bid] ?? [],
            $txMap[$bid]   ?? [],
            ['driver_name' => $driverName]
        );
    }
}
// ── END BULK FETCH ────────────────────────────────────────────────────────────

$detail_booking = null;
if ($view_booking > 0) {
    foreach ($payments as $p) { if ((int)$p['booking_id'] === $view_booking) { $detail_booking = $p; break; } }
}

$toast_success = $_SESSION['pay_success'] ?? null;
$toast_error   = $_SESSION['pay_error']   ?? null;
unset($_SESSION['pay_success'], $_SESSION['pay_error']);

$currentHour = (int)(new DateTime('now', new DateTimeZone('Asia/Manila')))->format('H');
$greeting    = $currentHour < 12 ? 'Good Morning' : ($currentHour < 18 ? 'Good Afternoon' : 'Good Evening');
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>EnviroCab – Payments & Receipts</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>

        :root,
        [data-theme="light"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --card-bg:         #FFFFFF;
            --card-border:     #E2E8F0;
            --header-bg:       rgba(255,255,255,0.85);
            --header-border:   rgba(255,255,255,0.5);
            --text-dark:       #1A202C;
            --text-medium:     #4A5568;
            --text-light:      #718096;
            --input-bg:        #FAFAFA;
            --input-border:    #E2E8F0;
            --nav-bg:          rgba(255,255,255,0.95);
            --icon-btn-bg:     rgba(255,255,255,0.9);
            --icon-btn-border: rgba(0,0,0,0.05);
            --shadow-card:     0 2px 8px rgba(0,0,0,0.04);
            --shadow-hero:     0 8px 32px rgba(0,208,132,0.2);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.05);
            --overlay-bg:      rgba(0,0,0,0.45);
            --sheet-bg:        #FFFFFF;
            --meta-chip-bg:    rgba(0,0,0,0.04);
            --filter-bg:       #FFFFFF;
            --search-bg:       #FFFFFF;
        }

        [data-theme="dark"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #0D1F1A 0%, #0F172A 100%);
            --card-bg:         #1A2820;
            --card-border:     #263330;
            --header-bg:       rgba(15,24,18,0.94);
            --header-border:   rgba(0,208,132,0.1);
            --text-dark:       #E8F5F1;
            --text-medium:     #9FC4AE;
            --text-light:      #607D6B;
            --input-bg:        #111E18;
            --input-border:    #263330;
            --nav-bg:          rgba(15,24,18,0.97);
            --icon-btn-bg:     rgba(255,255,255,0.06);
            --icon-btn-border: rgba(255,255,255,0.08);
            --shadow-card:     0 2px 12px rgba(0,0,0,0.35);
            --shadow-hero:     0 8px 40px rgba(0,208,132,0.12);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.5);
            --overlay-bg:      rgba(0,0,0,0.72);
            --sheet-bg:        #1A2820;
            --meta-chip-bg:    rgba(255,255,255,0.06);
            --filter-bg:       #1A2820;
            --search-bg:       #111E18;
        }

        *::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        *, *::before, *::after {
            transition: background-color .3s ease, border-color .25s ease, color .2s ease, box-shadow .3s ease;
        }
        input, button, svg, img { transition: none; }
        input:focus { transition: border-color .15s, box-shadow .15s; }
        .icon-btn, .nav-item, .view-receipt-btn, .filter-chip, .payment-card {
            transition: background .2s, transform .15s, opacity .2s, border-color .2s, box-shadow .2s;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 100px;
            -webkit-font-smoothing: antialiased;
            transition:opacity .15s ease;
        }

        .header {
            background: var(--header-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky; top: 0; z-index: 100;
            border-bottom: 1px solid var(--header-border);
        }
        .header-content { display:flex; justify-content:space-between; align-items:center; }
        .logo-img { height:28px; width:auto; }
        .header-right { display:flex; align-items:center; gap:10px; }

        .icon-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
            position:relative;
        }
        .icon-btn svg { stroke:var(--text-medium); }
        .icon-btn:active { transform:scale(0.93); }
        .logout-btn {
            background:rgba(239,68,68,0.12) !important;
            border-color:rgba(239,68,68,0.2) !important;
        }
        .logout-btn svg { stroke:#EF4444 !important; }
        .notification-badge {
            position:absolute; top:6px; right:6px;
            width:6px; height:6px; background:#EF4444;
            border-radius:50%; border:2px solid var(--card-bg);
        }

        .theme-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
            position:relative; overflow:hidden;
        }
        .theme-btn:active { transform:scale(0.93); }
        .t-sun, .t-moon {
            position:absolute;
            transition: opacity .35s ease, transform .4s cubic-bezier(.34,1.56,.64,1) !important;
        }
        [data-theme="light"] .t-sun  { opacity:1; transform:rotate(0deg) scale(1); }
        [data-theme="light"] .t-moon { opacity:0; transform:rotate(90deg) scale(.6); }
        [data-theme="dark"]  .t-sun  { opacity:0; transform:rotate(-90deg) scale(.6); }
        [data-theme="dark"]  .t-moon { opacity:1; transform:rotate(0deg) scale(1); }

        .main-content { padding:20px; }

        .hero-card {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
            border-radius:24px; padding:28px 24px; color:white;
            margin-bottom:20px; box-shadow:var(--shadow-hero);
            position:relative; overflow:hidden;
        }
        .hero-card::before {
            content:''; position:absolute; top:-50%; right:-20%;
            width:200px; height:200px; background:rgba(255,255,255,0.1); border-radius:50%;
        }
        .hero-card::after {
            content:''; position:absolute; bottom:-30%; left:-10%;
            width:150px; height:150px; background:rgba(255,255,255,0.06); border-radius:50%;
        }
        .hero-greeting { font-size:14px; opacity:.9; margin-bottom:4px; position:relative; }
        .hero-title    { font-size:24px; font-weight:800; margin-bottom:8px; position:relative; }
        .hero-amount   { font-size:42px; font-weight:900; letter-spacing:-1px; margin-bottom:4px; position:relative; }
        .hero-label    { font-size:13px; opacity:.85; position:relative; }
        .hero-stats    { display:flex; gap:12px; margin-top:24px; position:relative; }
        .hero-stat {
            flex:1; background:rgba(255,255,255,0.15);
            backdrop-filter:blur(10px); padding:12px;
            border-radius:16px; text-align:center;
        }
        .hero-stat-value { font-size:20px; font-weight:700; margin-bottom:4px; }
        .hero-stat-label { font-size:11px; opacity:.85; }

        .filter-bar {
            display:flex; gap:8px; overflow-x:auto;
            padding-bottom:4px; margin-bottom:20px;
            scrollbar-width:none;
        }
        .filter-bar::-webkit-scrollbar { display:none; }
        .filter-chip {
            flex-shrink:0; padding:8px 16px; border-radius:50px;
            font-size:13px; font-weight:600; cursor:pointer;
            border:1.5px solid var(--card-border);
            background:var(--filter-bg); color:var(--text-medium);
            white-space:nowrap; text-decoration:none; display:inline-block;
        }
        .filter-chip.active {
            background:var(--primary-green);
            border-color:var(--primary-green); color:white;
        }

        .search-wrap { position:relative; margin-bottom:20px; }
        .search-input {
            width:100%; padding:12px 16px 12px 44px;
            border-radius:16px; border:1.5px solid var(--input-border);
            background:var(--search-bg); font-size:14px; color:var(--text-dark);
            outline:none; font-family:inherit;
        }
        .search-input:focus { border-color:var(--primary-green); box-shadow:0 0 0 3px rgba(0,208,132,0.12); }
        .search-input::placeholder { color:var(--text-light); }
        .search-icon {
            position:absolute; left:14px; top:50%; transform:translateY(-50%);
            stroke:var(--text-light);
        }

        .section-label {
            font-size:12px; font-weight:700; color:var(--text-light);
            text-transform:uppercase; letter-spacing:.08em; margin:0 0 10px;
        }

        .payment-list { display:flex; flex-direction:column; gap:12px; margin-bottom:20px; }

        .payment-card {
            background:var(--card-bg); border-radius:20px;
            border:1px solid var(--card-border);
            box-shadow:var(--shadow-card);
            overflow:hidden;
            animation:slideUp .4s ease forwards;
        }
        .payment-card-header { display:flex; align-items:center; gap:14px; padding:16px; }
        .payment-icon-wrap {
            width:48px; height:48px; border-radius:16px;
            display:flex; align-items:center; justify-content:center; flex-shrink:0;
        }
        .payment-card-info { flex:1; min-width:0; }
        .payment-ref   { font-size:15px; font-weight:700; color:var(--text-dark); }
        .payment-date  { font-size:12px; color:var(--text-light); margin-top:2px; }
        .payment-right { text-align:right; flex-shrink:0; }
        .payment-amount { font-size:17px; font-weight:800; color:var(--text-dark); }

        .status-badge {
            display:inline-block; margin-top:4px;
            padding:3px 10px; border-radius:8px;
            font-size:11px; font-weight:700;
        }
        .badge-paid     { background:rgba(16,185,129,.15); color:#10B981; }
        .badge-unpaid   { background:rgba(239,68,68,.12);  color:#EF4444; }
        .badge-partial  { background:rgba(251,191,36,.15); color:#D97706; }
        .badge-refunded { background:rgba(96,165,250,.15); color:#3B82F6; }
        [data-theme="dark"] .badge-paid     { background:rgba(16,185,129,.2); color:#34D399; }
        [data-theme="dark"] .badge-unpaid   { background:rgba(239,68,68,.2);  color:#FCA5A5; }
        [data-theme="dark"] .badge-partial  { background:rgba(251,191,36,.2); color:#FBBF24; }
        [data-theme="dark"] .badge-refunded { background:rgba(96,165,250,.2); color:#60A5FA; }

        .payment-card-body {
            border-top:1px solid var(--card-border);
            padding:12px 16px;
            display:flex; flex-wrap:wrap; gap:8px;
            align-items:center; justify-content:space-between;
        }
        .card-meta { display:flex; flex-wrap:wrap; gap:8px; }
        .meta-chip {
            font-size:12px; font-weight:500; color:var(--text-medium);
            background:var(--meta-chip-bg); padding:4px 10px; border-radius:8px;
            display:flex; align-items:center; gap:5px;
        }
        .meta-chip svg { stroke:var(--text-light); }

        .driver-pays-notice {
            display:flex; align-items:center; gap:6px;
            font-size:12px; font-weight:600; color:var(--text-light);
            background:var(--meta-chip-bg); padding:7px 12px;
            border-radius:10px; border:1px dashed var(--card-border);
        }
        .driver-pays-notice svg { stroke:var(--text-light); flex-shrink:0; }
        .view-receipt-btn {
            padding:8px 18px; border-radius:12px; border:none;
            background:rgba(96,165,250,.12); color:#3B82F6;
            font-size:13px; font-weight:700;
            cursor:pointer; font-family:inherit;
        }
        .view-receipt-btn:active { transform:scale(.97); }

        .empty-state {
            text-align:center; padding:40px 20px;
            background:var(--card-bg); border-radius:20px;
            border:1px solid var(--card-border);
        }
        .empty-icon  { margin-bottom:12px; display:flex; justify-content:center; }
        .empty-title { font-size:16px; font-weight:700; color:var(--text-dark); margin-bottom:6px; }
        .empty-sub   { font-size:13px; color:var(--text-light); }

        .modal-overlay {
            position:fixed; inset:0; background:var(--overlay-bg);
            backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px);
            z-index:200;
            display:flex; align-items:center; justify-content:center;
            padding:20px; opacity:0; pointer-events:none;
        }
        .modal-overlay.open { opacity:1; pointer-events:auto; }
        .modal-sheet {
            background:var(--sheet-bg); width:100%; max-width:440px;
            border-radius:24px; padding:0 0 28px;
            transform:translateY(20px) scale(0.97);
            max-height:90vh; overflow-y:auto;
        }
        .modal-overlay.open .modal-sheet { transform:translateY(0) scale(1); }
        .modal-header {
            padding:20px 20px 0;
            display:flex; justify-content:space-between; align-items:center;
        }
        .modal-title { font-size:20px; font-weight:800; color:var(--text-dark); }
        .modal-close {
            width:32px; height:32px; border-radius:10px;
            background:var(--meta-chip-bg); border:none;
            font-size:18px; cursor:pointer; display:flex;
            align-items:center; justify-content:center; color:var(--text-medium);
        }
        .modal-body { padding:20px; }

        .receipt-header {
            background:linear-gradient(135deg,var(--primary-green),var(--dark-green));
            border-radius:16px; padding:20px; color:white; text-align:center; margin-bottom:20px;
        }
        .receipt-icon { margin-bottom:8px; display:flex; justify-content:center; }
        .receipt-ref  { font-size:18px; font-weight:800; margin-bottom:4px; }
        .receipt-date { font-size:13px; opacity:.9; }
        .receipt-rows { display:flex; flex-direction:column; gap:0; }
        .receipt-row  {
            display:flex; justify-content:space-between; align-items:center;
            padding:12px 0; border-bottom:1px dashed var(--card-border);
        }
        .receipt-row:last-child { border-bottom:none; }
        .receipt-label { font-size:13px; color:var(--text-light); }
        .receipt-val   { font-size:14px; font-weight:600; color:var(--text-dark); }
        .receipt-total-row {
            display:flex; justify-content:space-between; align-items:center; padding:14px 0 0;
        }
        .receipt-total-label { font-size:15px; font-weight:700; color:var(--text-dark); }
        .receipt-total-val   { font-size:20px; font-weight:900; color:var(--primary-green); }
        .auth-code-box {
            background:rgba(0,208,132,.08); border:1.5px dashed var(--primary-green);
            border-radius:14px; padding:14px; text-align:center; margin-top:16px;
        }
        .auth-label { font-size:12px; color:var(--text-light); margin-bottom:4px; }
        .auth-code  { font-size:18px; font-weight:800; color:var(--primary-green); letter-spacing:2px; }

        .form-label { font-size:14px; font-weight:600; color:var(--text-dark); margin-bottom:10px; display:block; }

        .toast {
            position:fixed; bottom:100px; left:50%; transform:translateX(-50%) translateY(20px);
            background:var(--text-dark); color:white; padding:12px 22px;
            border-radius:50px; font-size:14px; font-weight:600;
            opacity:0; z-index:300; white-space:nowrap;
            max-width:90vw; text-align:center;
        }
        .toast.toast-success { background:var(--dark-green); }
        .toast.toast-error   { background:#EF4444; }
        .toast.show { opacity:1; transform:translateX(-50%) translateY(0); }

        .bottom-nav {
            position:fixed; bottom:0; left:0; right:0;
            background:var(--nav-bg);
            backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
            border-top:1px solid var(--card-border);
            padding:12px 0 20px;
            display:grid; grid-template-columns:repeat(4,1fr);
            z-index:99; box-shadow:var(--shadow-nav);
        }
        .nav-item {
            display:flex; flex-direction:column; align-items:center; gap:4px;
            padding:8px; cursor:pointer; border:none; background:none;
        }
        .nav-item:active { transform:scale(0.95); }
        .nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
        .nav-icon svg { stroke:var(--text-light); opacity:.5; }
        .nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
        .nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:.7; }
        .nav-item.active .nav-label { color:var(--primary-green); opacity:1; }

        @media(min-width:768px){
            body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,.12); }
            .bottom-nav { max-width:480px; left:50%; transform:translateX(-50%); }
        }
        @keyframes slideUp {
            from { opacity:0; transform:translateY(20px); }
            to   { opacity:1; transform:translateY(0); }
        }
        .hero-card, .payment-card { animation:slideUp .4s ease forwards; }

        .notif-panel-wrap{position:relative;}
        .notif-badge{position:absolute;top:6px;right:6px;min-width:16px;height:16px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:10px;font-weight:700;color:#fff;display:flex;align-items:center;justify-content:center;pointer-events:none;}
        .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:320px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,.14);z-index:500;display:none;overflow:hidden;}
        .notif-panel.open{display:block;}
        .notif-panel-head{display:flex;justify-content:space-between;align-items:center;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);}
        .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
        .notif-mark-all{font-size:12px;font-weight:600;color:var(--primary-green);background:none;border:none;cursor:pointer;padding:0;}
        .notif-list{max-height:320px;overflow-y:auto;padding:8px;}
        .notif-empty{padding:24px 16px;text-align:center;font-size:13px;color:var(--text-light);}
        .notif-item{display:flex;align-items:flex-start;gap:10px;padding:10px 8px;border-radius:12px;cursor:pointer;transition:background .15s;}
        .notif-item:hover{background:var(--meta-chip-bg);}
        .notif-item.unread{background:rgba(0,208,132,.06);}
        .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
        .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
        .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
        [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
        .notif-item-body{flex:1;min-width:0;}
        .notif-item-title{font-size:13px;font-weight:600;color:var(--text-dark);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .notif-item-sub{font-size:12px;color:var(--text-light);margin-top:2px;}
        .notif-item-time{font-size:11px;color:var(--text-light);margin-top:3px;}
        .logout-overlay{position:fixed;inset:0;background:var(--overlay-bg);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);z-index:600;display:flex;align-items:center;justify-content:center;padding:24px;opacity:0;pointer-events:none;transition:opacity .2s;}
        .logout-overlay.open{opacity:1;pointer-events:auto;}
        .logout-card{background:var(--sheet-bg);border-radius:24px;padding:28px 24px;width:100%;max-width:320px;text-align:center;transform:scale(.95);transition:transform .2s;}
        .logout-overlay.open .logout-card{transform:scale(1);}
        .logout-icon{width:56px;height:56px;border-radius:18px;background:rgba(239,68,68,.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
        .logout-title{font-size:18px;font-weight:800;color:var(--text-dark);margin-bottom:8px;}
        .logout-sub{font-size:14px;color:var(--text-light);margin-bottom:24px;}
        .logout-actions{display:flex;gap:10px;}
        .logout-cancel{flex:1;padding:13px;border-radius:14px;border:1.5px solid var(--card-border);background:var(--meta-chip-bg);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;font-family:inherit;}
        .logout-confirm{flex:1;padding:13px;border-radius:14px;border:none;background:#EF4444;font-size:14px;font-weight:700;color:#fff;cursor:pointer;font-family:inherit;}

        </style>
</head>
<body>

<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img"
             onerror="this.style.display='none'">
        <div class="header-right">

            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none"
                     stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="5"/>
                    <line x1="12" y1="1"  x2="12" y2="3"/>
                    <line x1="12" y1="21" x2="12" y2="23"/>
                    <line x1="4.22"  y1="4.22"  x2="5.64"  y2="5.64"/>
                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
                    <line x1="1"  y1="12" x2="3"  y2="12"/>
                    <line x1="21" y1="12" x2="23" y2="12"/>
                    <line x1="4.22"  y1="19.78" x2="5.64"  y2="18.36"/>
                    <line x1="18.36" y1="5.64"  x2="19.78" y2="4.22"/>
                </svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none"
                     stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                </svg>
            </button>

            <button class="icon-btn" onclick="window.location.href='dashboard.php'" title="Home">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                    <polyline points="9 22 9 12 15 12 15 22"/>
                </svg>
            </button>

            <div class="notif-panel-wrap" style="position:relative;">
                <button class="icon-btn notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                        <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                    </svg>
                    <span class="notif-badge" id="notifBadge" style="display:none;"></span>
                </button>
                <div class="notif-panel" id="notifPanel">
                    <div class="notif-panel-head">
                        <span class="notif-panel-title">Notifications</span>
                        <button class="notif-mark-all" onclick="markAllRead()">Mark all read</button>
                    </div>
                    <div class="notif-list" id="notif-list"><div class="notif-empty">Loading…</div></div>
                </div>
            </div>

            <button class="icon-btn logout-btn" onclick="openLogout()" title="Logout">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                    <polyline points="16 17 21 12 16 7"/>
                    <line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

    <div class="hero-card">
        <div class="hero-greeting"><?php echo $greeting; ?>, <?php echo htmlspecialchars($_SESSION['name'] ?? $_SESSION['username'] ?? 'Passenger'); ?>!</div>
        <div class="hero-title">Payments &amp; Receipts</div>
        <div class="hero-amount">₱<?php echo number_format($summary['month_spent'], 2); ?></div>
        <div class="hero-label">This Month's Total Spending</div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-value"><?php echo $summary['count_paid']; ?></div>
                <div class="hero-stat-label">Paid</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?php echo $summary['count_unpaid']; ?></div>
                <div class="hero-stat-label">Pending</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value">₱<?php echo number_format($summary['total_unpaid'], 0); ?></div>
                <div class="hero-stat-label">Balance Due</div>
            </div>
        </div>
    </div>

    <div class="filter-bar">
        <?php
        $chips = ['all'=>'All','unpaid'=>'Unpaid','paid'=>'Paid','refunded'=>'Refunded'];
        foreach ($chips as $key => $label):
            $active = ($filter_status === $key) ? 'active' : '';
        ?>
        <a href="?filter=<?php echo $key; ?>&search=<?php echo urlencode($search_ref); ?>"
           class="filter-chip <?php echo $active; ?>"><?php echo $label; ?></a>
        <?php endforeach; ?>
    </div>

    <form method="GET" class="search-wrap">
        <input type="hidden" name="filter" value="<?php echo htmlspecialchars($filter_status); ?>">
        <svg class="search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input type="text" name="search" class="search-input"
               placeholder="Search booking reference…"
               value="<?php echo htmlspecialchars($search_ref); ?>">
    </form>

    <div class="section-label">Transaction History</div>

    <?php if (empty($payments)): ?>
    <div class="empty-state">
        <div class="empty-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                <line x1="1" y1="10" x2="23" y2="10"/>
            </svg>
        </div>
        <div class="empty-title">No transactions found</div>
        <div class="empty-sub">Your payment history will appear here once you make bookings.</div>
    </div>
    <?php else: ?>
    <div class="payment-list">
        <?php foreach ($payments as $p):
            $isPaid      = $p['payment_status'] === 'Paid';
            $isRefunded  = $p['payment_status'] === 'Refunded';
            $isUnpaid    = in_array($p['payment_status'], ['Unpaid','Partial']);
            $isCancelled = $p['booking_status'] === 'Cancelled';

            if ($isPaid)          { $badge = '<span class="status-badge badge-paid">Paid</span>'; }
            elseif ($isRefunded)  { $badge = '<span class="status-badge badge-refunded">Refunded</span>'; }
            elseif ($isCancelled) { $badge = '<span class="status-badge badge-refunded">Cancelled</span>'; }
            else                  { $badge = '<span class="status-badge badge-unpaid">Unpaid</span>'; }

            if ($isPaid) {
                $iconBg = 'background:rgba(16,185,129,.15)';
                $icon = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';
            } elseif ($isRefunded) {
                $iconBg = 'background:rgba(96,165,250,.15)';
                $icon = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 .49-4.36"></path></svg>';
            } elseif ($isCancelled) {
                $iconBg = 'background:rgba(113,128,150,.1)';
                $icon = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#718096" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>';
            } else {
                $iconBg = 'background:rgba(239,68,68,.1)';
                $icon = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>';
            }

            $method      = $p['payment_method'] ?? 'Cash';
            $methodLabel = ($method === 'E-Wallet') ? 'GCash' : 'Cash';
            $driverLabel = $p['driver_name'] ?? 'Unassigned';
        ?>
        <div class="payment-card">
            <div class="payment-card-header">
                <div class="payment-icon-wrap" style="<?php echo $iconBg; ?>"><?php echo $icon; ?></div>
                <div class="payment-card-info">
                    <div class="payment-ref"><?php echo htmlspecialchars($p['booking_reference']); ?></div>
                    <div class="payment-date"><?php echo (new DateTime($p['booking_date'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M d, Y • h:i A'); ?></div>
                </div>
                <div class="payment-right">
                    <div class="payment-amount">₱<?php echo number_format($p['total_amount'], 2); ?></div>
                    <?php echo $badge; ?>
                </div>
            </div>
            <div class="payment-card-body">
                <div class="card-meta">
                    <span class="meta-chip">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        <?php echo htmlspecialchars($driverLabel); ?>
                    </span>
                    <span class="meta-chip">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
                        <?php echo $methodLabel; ?>
                    </span>
                    <?php if ($p['booking_status']): ?>
                    <span class="meta-chip">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
                        <?php echo $p['booking_status']; ?>
                    </span>
                    <?php endif; ?>
                </div>
                <?php if ($isUnpaid && !$isCancelled): ?>
                <div class="driver-pays-notice">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    Awaiting driver payment confirmation
                </div>
                <?php elseif ($isPaid): ?>
                <button class="view-receipt-btn" onclick="openReceiptModal(<?php echo htmlspecialchars(json_encode($p), ENT_QUOTES); ?>)">
                    View Receipt
                </button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

</div>

<div class="modal-overlay" id="receiptModal">
    <div class="modal-sheet">
        <div class="modal-header">
            <div class="modal-title">Receipt</div>
            <button class="modal-close" onclick="closeReceiptModal()">✕</button>
        </div>
        <div class="modal-body" id="receiptBody"></div>
    </div>
</div>

<div class="toast" id="toastEl"></div>

<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
        </div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="16"/>
                <line x1="8" y1="12" x2="16" y2="12"/>
            </svg>
        </div>
        <span class="nav-label">Book</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_trips.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                <line x1="16" y1="2" x2="16" y2="6"/>
                <line x1="8" y1="2" x2="8" y2="6"/>
                <line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
        </div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_profile.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
            </svg>
        </div>
        <span class="nav-label">Profile</span>
    </button>
</div>

<script>

(function () {
    var saved = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
})();

function toggleTheme() {
    var html    = document.documentElement;
    var current = html.getAttribute('data-theme');
    var next    = current === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('envirocab_theme', next);
}

function openReceiptModal(p) {
    if(typeof p === 'string') p = JSON.parse(p);

    var method      = p.payment_method || 'Cash';
    var methodLabel = (method === 'E-Wallet') ? 'GCash' : 'Cash';
    var authCode    = p.authorization_code || '—';
    var txRef       = p.transaction_reference || '—';
    var dateStr     = p.authorized_at ? new Date(p.authorized_at).toLocaleString('en-PH',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Manila'}) : (p.booking_date || '—');

    var baseFare = p.base_fare      != null ? '₱' + parseFloat(p.base_fare).toFixed(2)      : '—';
    var distKm   = p.distance_km    != null ? parseFloat(p.distance_km).toFixed(2) + ' km'   : '—';
    var distRate = p.distance_rate  != null ? '₱' + parseFloat(p.distance_rate).toFixed(2) + '/km' : '—';
    var surge    = p.surge_multiplier != null ? 'x' + parseFloat(p.surge_multiplier).toFixed(2) : '1.00';
    var extra    = p.additional_charges != null ? '₱' + parseFloat(p.additional_charges).toFixed(2) : '₱0.00';
    var discount = p.discount       != null ? '₱' + parseFloat(p.discount).toFixed(2)        : '₱0.00';
    var total    = p.total_amount   != null ? '₱' + parseFloat(p.total_amount).toLocaleString('en-PH',{minimumFractionDigits:2}) : '₱0.00';

    var html = `
      <div class="receipt-header">
        <div class="receipt-icon">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.9)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
            </svg>
        </div>
        <div class="receipt-ref">${escHtml(p.booking_reference || '')}</div>
        <div class="receipt-date">${dateStr}</div>
      </div>
      <div class="receipt-rows">
        <div class="receipt-row"><span class="receipt-label">Driver</span><span class="receipt-val">${escHtml(p.driver_name || 'N/A')}</span></div>
        <div class="receipt-row"><span class="receipt-label">Booking Status</span><span class="receipt-val">${escHtml(p.booking_status || '')}</span></div>
        <div class="receipt-row"><span class="receipt-label">Payment Method</span><span class="receipt-val">${methodLabel}</span></div>
        ${method==='E-Wallet' && txRef!=='—' ? `<div class="receipt-row"><span class="receipt-label">GCash Reference</span><span class="receipt-val">${escHtml(txRef)}</span></div>` : ''}
        <div class="receipt-row"><span class="receipt-label">Base Fare</span><span class="receipt-val">${baseFare}</span></div>
        <div class="receipt-row"><span class="receipt-label">Distance</span><span class="receipt-val">${distKm}</span></div>
        <div class="receipt-row"><span class="receipt-label">Rate per km</span><span class="receipt-val">${distRate}</span></div>
        <div class="receipt-row"><span class="receipt-label">Surge Multiplier</span><span class="receipt-val">${surge}</span></div>
        <div class="receipt-row"><span class="receipt-label">Additional Charges</span><span class="receipt-val">${extra}</span></div>
        <div class="receipt-row"><span class="receipt-label">Discount</span><span class="receipt-val">- ${discount}</span></div>
      </div>
      <div class="receipt-total-row">
        <span class="receipt-total-label">Total Paid</span>
        <span class="receipt-total-val">${total}</span>
      </div>
      ${authCode !== '—' ? `<div class="auth-code-box"><div class="auth-label">Authorization Code</div><div class="auth-code">${escHtml(authCode)}</div></div>` : ''}
    `;

    document.getElementById('receiptBody').innerHTML = html;
    document.getElementById('receiptModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeReceiptModal() {
    document.getElementById('receiptModal').classList.remove('open');
    document.body.style.overflow = '';
}
document.getElementById('receiptModal').addEventListener('click', function(e){ if(e.target===this) closeReceiptModal(); });

function escHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showToast(msg, type) {
    var el = document.getElementById('toastEl');
    el.textContent = msg;
    el.className   = 'toast toast-' + type + ' show';
    setTimeout(function(){ el.classList.remove('show'); }, 3500);
}

<?php if ($toast_success): ?>
showToast(<?php echo json_encode($toast_success); ?>, 'success');
<?php endif; ?>
<?php if ($toast_error): ?>
showToast(<?php echo json_encode($toast_error); ?>, 'error');
<?php endif; ?>

const CUSTOMER_ID = <?= (int)$customer_id ?>;
const SB_URL = 'https://kyhndwabhbkduoaxeunq.supabase.co';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};
let _notifData=[], _seen=JSON.parse(localStorage.getItem(SEEN_KEY)||'[]');
function escH(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function timeAgo(iso){
    var d=Math.floor((Date.now()-new Date(iso))/1000);
    if(d<60) return 'Just now';
    if(d<3600) return Math.floor(d/60)+'m ago';
    if(d<86400) return Math.floor(d/3600)+'h ago';
    return Math.floor(d/86400)+'d ago';
}
function renderNotifs(){
    const list=document.getElementById('notif-list');
    if(!list) return;
    if(!_notifData.length){list.innerHTML='<div class="notif-empty">No notifications yet.</div>';return;}
    list.innerHTML=_notifData.map(b=>{
        const cfg=STATUS_CFG[b.booking_status]||{icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key=b.booking_id+'_'+b.booking_status;
        const unread=!_seen.includes(key);
        const amt='\u20B1'+parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t=timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
    const badge=document.getElementById('notifBadge');
    const unreadCount=_notifData.filter(b=>!_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    if(badge){badge.textContent=unreadCount>9?'9+':unreadCount;badge.style.display=unreadCount?'flex':'none';}
}
async function fetchNotifs(){
    try{
        const r=await fetch(`${SB_URL}/rest/v1/core2_bookings?customer_id=eq.${CUSTOMER_ID}&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=20`,{headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        if(r.ok){_notifData=await r.json();renderNotifs();}
    }catch(e){}
}
function toggleNotifPanel(e){
    e.stopPropagation();
    const p=document.getElementById('notifPanel');
    p.classList.toggle('open');
    if(p.classList.contains('open')) fetchNotifs();
}
function goNotif(page,bid,key){
    if(!_seen.includes(key)){_seen.push(key);localStorage.setItem(SEEN_KEY,JSON.stringify(_seen));}
    window.location.href=page+'?booking_id='+bid;
}
function markAllRead(){
    _notifData.forEach(b=>{const k=b.booking_id+'_'+b.booking_status;if(!_seen.includes(k))_seen.push(k);});
    localStorage.setItem(SEEN_KEY,JSON.stringify(_seen));renderNotifs();
}
document.addEventListener('click',function(e){const p=document.getElementById('notifPanel');if(p&&p.classList.contains('open')&&!p.closest('.notif-panel-wrap').contains(e.target))p.classList.remove('open');});
setInterval(fetchNotifs,8000);
fetchNotifs();
function openLogout(){document.getElementById('logout-overlay').classList.add('open');}
function closeLogout(){document.getElementById('logout-overlay').classList.remove('open');}
document.getElementById('logout-overlay').addEventListener('click',function(e){if(e.target===this)closeLogout();});
</script>

<div class="logout-overlay" id="logout-overlay">
    <div class="logout-card">
        <div class="logout-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                <polyline points="16 17 21 12 16 7"/>
                <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
        </div>
        <div class="logout-title">Log out?</div>
        <div class="logout-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-actions">
            <button class="logout-cancel" onclick="closeLogout()">Cancel</button>
            <button class="logout-confirm" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{once:true});
      a.addEventListener('touchstart',function(){ prerender(href); },{once:true,passive:true});
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{once:true});
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
<?php include 'passenger_chat_widget.php'; ?>
</body>
</html>