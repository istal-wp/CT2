<?php
session_start();
if (!isset($_SESSION['logged_in'], $_SESSION['customer_id']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../auth/passenger_login.php');
    exit;
}

define('SUPABASE_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code >= 200 && $code < 300) ? (json_decode($res, true) ?: []) : [];
}

$customerId = (int)$_SESSION['customer_id'];
$hour       = (int)(new DateTime('now', new DateTimeZone('Asia/Manila')))->format('H');
$greeting   = match(true) { $hour >= 18 => 'Good Evening', $hour >= 12 => 'Good Afternoon', default => 'Good Morning' };

$ratings = sb_get('core2_ratings', [
    'customer_id' => 'eq.' . $customerId,
    'select'      => 'rating_id,driver_id,ride_id,rating_value,comment,created_at',
    'order'       => 'created_at.desc',
]);

$driverIds = array_unique(array_filter(array_column($ratings, 'driver_id')));

$driverMap = [];
if (!empty($driverIds)) {
    $drvRows = sb_get('core1_drivers', [
        'id'     => 'in.(' . implode(',', $driverIds) . ')',
        'select' => 'id,driver_name,phone,status',
    ]);
    foreach ($drvRows as $d) {
        $driverMap[$d['id']] = $d;
    }
}

$rideIds = array_unique(array_filter(array_column($ratings, 'ride_id')));
$rideMap = [];
if (!empty($rideIds)) {
    $rideRows = sb_get('core2_rides', [
        'ride_id' => 'in.(' . implode(',', $rideIds) . ')',
        'select'  => 'ride_id,start_location,end_location',
    ]);
    foreach ($rideRows as $r) {
        $rideMap[$r['ride_id']] = $r;
    }
}

$entries = [];
foreach ($ratings as $r) {
    $driver = $driverMap[$r['driver_id']] ?? null;
    $ride   = $rideMap[$r['ride_id']]     ?? null;
    $entries[] = [
        'rating_id'    => $r['rating_id'],
        'rating_value' => (int)$r['rating_value'],
        'comment'      => $r['comment'] ?? '',
        'created_at'   => $r['created_at'],
        'driver_name'  => $driver['driver_name'] ?? 'Unknown Driver',
        'driver_phone' => $driver['phone']        ?? null,
        'driver_status'=> $driver['status']       ?? null,
        'from'         => $ride['start_location'] ?? null,
        'to'           => $ride['end_location']   ?? null,
    ];
}

$totalRatings = count($entries);
$avgRating    = $totalRatings > 0
    ? round(array_sum(array_column($entries, 'rating_value')) / $totalRatings, 1)
    : 0;

$STAR_LABELS = ['', '😞 Poor', '😐 Fair', '🙂 Good', '😊 Great', '🤩 Excellent!'];
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>EnviroCab – My Rated Drivers</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root,
[data-theme="light"] {
    --primary-green:   #00D084;
    --dark-green:      #00A86B;
    --bg-gradient:     linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
    --card-bg:         #FFFFFF;
    --card-border:     #E2E8F0;
    --header-bg:       rgba(255,255,255,0.85);
    --header-border:   rgba(255,255,255,0.5);
    --text-dark:       #1A202C;
    --text-medium:     #4A5568;
    --text-light:      #718096;
    --input-bg:        #FAFAFA;
    --row-border:      rgba(0,0,0,0.04);
    --nav-bg:          rgba(255,255,255,0.95);
    --icon-btn-bg:     rgba(255,255,255,0.9);
    --icon-btn-border: rgba(0,0,0,0.05);
    --shadow-card:     0 2px 8px rgba(0,0,0,0.04);
    --shadow-hero:     0 8px 32px rgba(0,208,132,0.2);
    --shadow-nav:      0 -4px 24px rgba(0,0,0,0.05);
}
[data-theme="dark"] {
    --primary-green:   #00D084;
    --dark-green:      #00A86B;
    --bg-gradient:     linear-gradient(135deg, #0D1F1A 0%, #0F172A 100%);
    --card-bg:         #1A2820;
    --card-border:     #263330;
    --header-bg:       rgba(15,24,18,0.94);
    --header-border:   rgba(0,208,132,0.1);
    --text-dark:       #E8F5F1;
    --text-medium:     #9FC4AE;
    --text-light:      #607D6B;
    --input-bg:        #111E18;
    --row-border:      rgba(255,255,255,0.05);
    --nav-bg:          rgba(15,24,18,0.97);
    --icon-btn-bg:     rgba(255,255,255,0.06);
    --icon-btn-border: rgba(255,255,255,0.08);
    --shadow-card:     0 2px 12px rgba(0,0,0,0.35);
    --shadow-hero:     0 8px 40px rgba(0,208,132,0.12);
    --shadow-nav:      0 -4px 24px rgba(0,0,0,0.5);
}

*::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
*, *::before, *::after { transition: background-color .3s ease, border-color .25s ease, color .2s ease, box-shadow .3s ease; }
input, button, svg, img { transition: none; }

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--bg-gradient);
    color: var(--text-dark);
    min-height: 100vh;
    padding-bottom: 100px;
    -webkit-font-smoothing: antialiased;
    transition:opacity .15s ease;
}

.header {
    background: var(--header-bg);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    padding: 16px 20px;
    position: sticky; top: 0; z-index: 100;
    border-bottom: 1px solid var(--header-border);
}
.header-content { display:flex; justify-content:space-between; align-items:center; }
.logo-img { height:28px; width:auto; }
.header-right { display:flex; align-items:center; gap:10px; }
.icon-btn {
    width:36px; height:36px; border-radius:12px;
    background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
    display:flex; align-items:center; justify-content:center; cursor:pointer;
}
.icon-btn svg { stroke:var(--text-medium); }
.icon-btn:active { transform:scale(0.93); }
.theme-btn {
    width:36px; height:36px; border-radius:12px;
    background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
    display:flex; align-items:center; justify-content:center; cursor:pointer;
    position:relative; overflow:hidden;
}
.theme-btn:active { transform:scale(0.93); }
.t-sun, .t-moon { position:absolute; transition: opacity .35s ease, transform .4s cubic-bezier(.34,1.56,.64,1) !important; }
[data-theme="light"] .t-sun  { opacity:1;  transform:rotate(0deg)   scale(1);  }
[data-theme="light"] .t-moon { opacity:0;  transform:rotate(90deg)  scale(.6); }
[data-theme="dark"]  .t-sun  { opacity:0;  transform:rotate(-90deg) scale(.6); }
[data-theme="dark"]  .t-moon { opacity:1;  transform:rotate(0deg)   scale(1);  }

.main-content { padding:20px; }

.hero-card {
    background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
    border-radius:24px; padding:28px 24px; color:white;
    margin-bottom:20px; box-shadow:var(--shadow-hero);
    position:relative; overflow:hidden;
}
.hero-card::before {
    content:''; position:absolute; top:-50%; right:-20%;
    width:200px; height:200px; background:rgba(255,255,255,0.1); border-radius:50%;
}
.hero-card::after {
    content:''; position:absolute; bottom:-30%; left:-10%;
    width:150px; height:150px; background:rgba(255,255,255,0.06); border-radius:50%;
}
.hero-greeting { font-size:14px; opacity:.9; margin-bottom:4px; position:relative; }
.hero-title    { font-size:22px; font-weight:800; margin-bottom:8px; position:relative; }
.hero-sub      { font-size:13px; opacity:.85; position:relative; }
.hero-stats    { display:flex; gap:12px; margin-top:20px; position:relative; }
.hero-stat {
    flex:1; background:rgba(255,255,255,0.15);
    backdrop-filter:blur(10px); padding:12px; border-radius:16px; text-align:center;
}
.hero-stat-value { font-size:20px; font-weight:700; margin-bottom:4px; }
.hero-stat-label { font-size:11px; opacity:.85; }

.stars-display { display:inline-flex; gap:2px; align-items:center; }
.star-filled  { color:#F59E0B; font-size:15px; }
.star-empty   { color:rgba(255,255,255,0.3); font-size:15px; }
.stars-display-sm .star-filled { color:#F59E0B; font-size:13px; }
.stars-display-sm .star-empty  { color:var(--card-border); font-size:13px; }

.section-label {
    font-size:12px; font-weight:700; color:var(--text-light);
    text-transform:uppercase; letter-spacing:.08em; margin:0 0 12px;
}

.cards-list { display:flex; flex-direction:column; gap:12px; }

.driver-card {
    background:var(--card-bg); border-radius:20px;
    border:1px solid var(--card-border); box-shadow:var(--shadow-card);
    overflow:hidden; animation:slideUp .4s ease forwards;
}

.driver-card-top {
    padding:16px 16px 12px;
    display:flex; align-items:center; gap:14px;
    border-bottom:1px solid var(--row-border);
}
.driver-avatar {
    width:52px; height:52px; border-radius:50%; flex-shrink:0;
    background:linear-gradient(135deg, var(--primary-green), var(--dark-green));
    display:flex; align-items:center; justify-content:center;
    font-size:20px; font-weight:800; color:white;
    box-shadow:0 4px 14px rgba(0,208,132,0.3);
}
.driver-info { flex:1; min-width:0; }
.driver-name { font-size:15px; font-weight:700; color:var(--text-dark); margin-bottom:4px; }
.driver-rating-row { display:flex; align-items:center; gap:8px; }
.rating-label {
    font-size:11px; font-weight:700; color:#B45309;
    background:rgba(245,158,11,0.12); border-radius:8px;
    padding:2px 8px;
}
.rating-date { font-size:11px; color:var(--text-light); }

.driver-card-body { padding:12px 16px; }

.route-row {
    display:flex; align-items:flex-start; gap:10px; margin-bottom:10px;
}
.route-spine-mini {
    display:flex; flex-direction:column; align-items:center; gap:0; flex-shrink:0; padding-top:4px;
}
.dot-start { width:8px; height:8px; border-radius:50%; background:var(--primary-green); }
.route-line-mini { width:2px; flex:1; min-height:18px; background:var(--card-border); margin:3px 0; }
.dot-end { width:8px; height:8px; border-radius:50%; background:#EF4444; }
.route-text { flex:1; min-width:0; }
.route-from { font-size:12px; color:var(--text-medium); font-weight:500; margin-bottom:14px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.route-to   { font-size:12px; color:var(--text-medium); font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

.comment-box {
    background:var(--input-bg); border:1px solid var(--card-border);
    border-radius:12px; padding:10px 12px;
    font-size:12px; color:var(--text-medium); font-style:italic; line-height:1.5;
    display:flex; gap:8px; align-items:flex-start;
}
.comment-box svg { flex-shrink:0; margin-top:1px; }

.empty-state {
    text-align:center; padding:60px 20px;
    background:var(--card-bg); border-radius:20px;
    border:1px solid var(--card-border); box-shadow:var(--shadow-card);
}
.empty-icon { margin-bottom:16px; opacity:.35; display:flex; align-items:center; justify-content:center; }
.empty-title { font-size:17px; font-weight:700; color:var(--text-dark); margin-bottom:6px; }
.empty-sub { font-size:13px; color:var(--text-light); margin-bottom:24px; line-height:1.5; }
.empty-cta {
    display:inline-flex; align-items:center; gap:8px;
    background:linear-gradient(135deg, var(--primary-green), var(--dark-green));
    color:white; border:none; border-radius:14px;
    padding:13px 24px; font-size:14px; font-weight:700;
    cursor:pointer; font-family:inherit; text-decoration:none;
}
.empty-cta:active { transform:scale(0.97); }

.bottom-nav {
    position:fixed; bottom:0; left:0; right:0;
    background:var(--nav-bg);
    backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
    border-top:1px solid var(--card-border);
    padding:12px 0 20px;
    display:grid; grid-template-columns:repeat(4,1fr);
    z-index:99; box-shadow:var(--shadow-nav);
}
.nav-item {
    display:flex; flex-direction:column; align-items:center; gap:4px;
    padding:8px; cursor:pointer; border:none; background:none;
}
.nav-item:active { transform:scale(0.95); }
.nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
.nav-icon svg { stroke:var(--text-light); opacity:.5; }
.nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
.nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:.7; }
.nav-item.active .nav-label { color:var(--primary-green); opacity:1; }

@media(min-width:768px){
    body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,.12); }
    .bottom-nav { max-width:480px; left:50%; transform:translateX(-50%); }
}
@keyframes slideUp {
    from { opacity:0; transform:translateY(16px); }
    to   { opacity:1; transform:translateY(0); }
}

    .notif-panel-wrap{position:relative;}
    .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:310px;max-height:400px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.15);z-index:999;display:none;flex-direction:column;overflow:hidden;}
    .notif-panel.open{display:flex;}
    .notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);flex-shrink:0;}
    .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
    .notif-mark-read{font-size:11px;font-weight:600;color:var(--dark-green);background:none;border:none;cursor:pointer;padding:0;}
    .notif-list{overflow-y:auto;flex:1;padding:4px 0;}
    .notif-item{display:flex;align-items:flex-start;gap:10px;padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--row-border);transition:background .15s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,208,132,0.06);}
    .notif-item.unread{background:rgba(0,208,132,0.04);}
    .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
    .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
    .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
    .notif-item-body{flex:1;min-width:0;}
    .notif-item-title{font-size:12px;font-weight:700;color:var(--text-dark);margin-bottom:2px;}
    .notif-item-sub{font-size:11px;color:var(--text-light);line-height:1.4;}
    .notif-item-time{font-size:10px;color:var(--text-light);margin-top:3px;}
    .notif-empty{padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;}
    .notif-spinner{width:20px;height:20px;border:2px solid var(--card-border);border-top-color:#00D084;border-radius:50%;animation:nspin .7s linear infinite;margin:16px auto;}
    @keyframes nspin{to{transform:rotate(360deg);}}
    .notif-count-badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 3px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:9px;font-weight:800;color:#fff;display:none;align-items:center;justify-content:center;line-height:1;}

    .logout-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center;padding:24px;}
    .logout-overlay.open{display:flex;}
    .logout-modal{background:var(--card-bg);border-radius:24px;padding:28px 24px 24px;width:100%;max-width:320px;box-shadow:0 16px 48px rgba(0,0,0,0.18);animation:lmodalIn .25s cubic-bezier(.34,1.56,.64,1);}
    @keyframes lmodalIn{from{transform:scale(.88);opacity:0;}to{transform:scale(1);opacity:1;}}
    .logout-modal-icon{width:52px;height:52px;border-radius:16px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
    .logout-modal-title{font-size:17px;font-weight:800;color:var(--text-dark);text-align:center;margin-bottom:6px;}
    .logout-modal-sub{font-size:13px;color:var(--text-light);text-align:center;line-height:1.5;margin-bottom:22px;}
    .logout-modal-btns{display:flex;gap:10px;}
    .logout-cancel-btn{flex:1;padding:13px;border-radius:14px;background:var(--input-bg);border:1px solid var(--card-border);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;}
    .logout-confirm-btn{flex:1;padding:13px;border-radius:14px;background:#EF4444;border:none;font-size:14px;font-weight:700;color:#fff;cursor:pointer;}
</style>
</head>
<body>

<script>(function(){var t=localStorage.getItem('envirocab_theme')||'light';document.documentElement.setAttribute('data-theme',t);})();</script>

<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img" onerror="this.style.display='none'">
                        <div class="header-right">
            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            </button>
            <button class="icon-btn" onclick="window.location.href='dashboard.php'" title="Home">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </button>
            <div class="notif-panel-wrap">
            <button class="icon-btn" id="notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications" style="position:relative;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <span class="notif-count-badge" id="notif-count-badge"></span>
            </button>
            <div class="notif-panel" id="notif-panel">
                <div class="notif-panel-head">
                    <span class="notif-panel-title">Notifications</span>
                    <button class="notif-mark-read" onclick="markAllRead()">Mark all read</button>
                </div>
                <div class="notif-list" id="notif-list"><div class="notif-spinner"></div></div>
            </div>
        </div>
            <button class="icon-btn logout-btn" onclick="openLogout()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

    <div class="hero-card">
        <div class="hero-greeting"><?= $greeting ?></div>
        <div class="hero-title">My Rated Drivers</div>
        <div class="hero-sub">All the drivers you've reviewed</div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $totalRatings ?></div>
                <div class="hero-stat-label">Total Ratings</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $avgRating > 0 ? $avgRating : '—' ?></div>
                <div class="hero-stat-label">Avg Given</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value">
                    <?php
                        $fiveStars = count(array_filter($entries, fn($e) => $e['rating_value'] === 5));
                        echo $fiveStars;
                    ?>
                </div>
                <div class="hero-stat-label">5-Star Rides</div>
            </div>
        </div>
    </div>

    <?php if (empty($entries)): ?>
    <div class="empty-state">
        <div class="empty-icon">
            <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
            </svg>
        </div>
        <div class="empty-title">No ratings yet</div>
        <div class="empty-sub">Complete a trip and rate your driver — your reviews will appear here.</div>
        <a href="passenger_booking.php" class="empty-cta">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
            Book a Ride
        </a>
    </div>

    <?php else: ?>

    <div class="section-label"><?= $totalRatings ?> Rating<?= $totalRatings !== 1 ? 's' : '' ?></div>

    <div class="cards-list">
        <?php foreach ($entries as $idx => $e):
            $initial  = strtoupper(substr($e['driver_name'], 0, 1));
            $stars    = (int)$e['rating_value'];
            $dateStr  = $e['created_at'] ? (new DateTime($e['created_at'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M j, Y') : '';
            $label    = ['', '😞 Poor', '😐 Fair', '🙂 Good', '😊 Great', '🤩 Excellent!'][$stars] ?? '';
            $delay    = min($idx * 0.06, 0.4);
        ?>
        <div class="driver-card" style="animation-delay:<?= $delay ?>s;">

            <div class="driver-card-top">
                <div class="driver-avatar"><?= $initial ?></div>
                <div class="driver-info">
                    <div class="driver-name"><?= htmlspecialchars($e['driver_name']) ?></div>
                    <div class="driver-rating-row">
                        <span class="stars-display stars-display-sm">
                            <?php for ($s = 1; $s <= 5; $s++): ?>
                                <span class="<?= $s <= $stars ? 'star-filled' : 'star-empty' ?>">★</span>
                            <?php endfor; ?>
                        </span>
                        <span class="rating-label"><?= $label ?></span>
                        <span class="rating-date"><?= $dateStr ?></span>
                    </div>
                </div>
            </div>

            <div class="driver-card-body">
                <?php if ($e['from'] || $e['to']): ?>
                <div class="route-row">
                    <div class="route-spine-mini">
                        <div class="dot-start"></div>
                        <div class="route-line-mini"></div>
                        <div class="dot-end"></div>
                    </div>
                    <div class="route-text">
                        <div class="route-from"><?= htmlspecialchars($e['from'] ?? '—') ?></div>
                        <div class="route-to"><?= htmlspecialchars($e['to']   ?? '—') ?></div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($e['comment']): ?>
                <div class="comment-box">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    <?= htmlspecialchars($e['comment']) ?>
                </div>
                <?php endif; ?>
            </div>

        </div>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>

</div>

<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_trips.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_trips.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="location.href='passenger_booking.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div>
        <span class="nav-label">Book</span>
    </button>
    <button class="nav-item" onclick="location.href='passenger_trips.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item" onclick="location.href='passenger_profile.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <span class="nav-label">Profile</span>
    </button>
</div>

<script>
function toggleTheme(){
    var h=document.documentElement,n=h.getAttribute('data-theme')==='dark'?'light':'dark';
    h.setAttribute('data-theme',n);localStorage.setItem('envirocab_theme',n);
}
</script>
<script>
const CUSTOMER_ID = <?= (int)$customerId ?>;

const SB_URL = 'https://kyhndwabhbkduoaxeunq.supabase.co';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
let _notifOpen = false, _notifData = [], _notifTimer = null;
let _seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');

const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};

function toggleNotifPanel(e) {
    e.stopPropagation();
    _notifOpen = !_notifOpen;
    document.getElementById('notif-panel').classList.toggle('open', _notifOpen);
    if (_notifOpen) { fetchNotifs(); _notifTimer = setInterval(fetchNotifs, 8000); }
    else clearInterval(_notifTimer);
}

async function fetchNotifs() {
    try {
        const r = await fetch(SB_URL + '/rest/v1/core2_bookings?customer_id=eq.' + CUSTOMER_ID +
            '&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=15',
            {headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        _notifData = await r.json();
        renderNotifs();
        updateBadge();
    } catch(e) {}
}

function renderNotifs() {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!_notifData.length) { list.innerHTML = '<div class="notif-empty">No notifications yet.</div>'; return; }
    list.innerHTML = _notifData.map(b => {
        const cfg = STATUS_CFG[b.booking_status] || {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key = b.booking_id + '_' + b.booking_status;
        const unread = !_seen.includes(key);
        const amt = '\u20B1' + parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t = timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
}

function updateBadge() {
    const cnt = _notifData.filter(b => !_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    const el = document.getElementById('notif-count-badge');
    if (!el) return;
    if (cnt > 0) { el.textContent = cnt > 9 ? '9+' : cnt; el.style.display = 'flex'; }
    else el.style.display = 'none';
}

function goNotif(page, bid, key) {
    if (!_seen.includes(key)) { _seen.push(key); localStorage.setItem(SEEN_KEY, JSON.stringify(_seen)); }
    window.location.href = page + '?booking_id=' + bid;
}

function markAllRead() {
    _seen = _notifData.map(b => b.booking_id+'_'+b.booking_status);
    localStorage.setItem(SEEN_KEY, JSON.stringify(_seen));
    renderNotifs(); updateBadge();
}

function timeAgo(iso) {
    if (!iso) return '';
    const s = Math.floor((Date.now() - new Date(iso))/1000);
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s/60)+'m ago';
    if (s < 86400) return Math.floor(s/3600)+'h ago';
    return Math.floor(s/86400)+'d ago';
}

function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function openLogout() { document.getElementById('logout-overlay').classList.add('open'); }

document.addEventListener('click', function(e) {
    const panel = document.getElementById('notif-panel');
    const btn   = document.getElementById('notif-bell-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        _notifOpen = false; panel.classList.remove('open'); clearInterval(_notifTimer);
    }
});

document.addEventListener('DOMContentLoaded', () => { if (CUSTOMER_ID) fetchNotifs(); });
</script>

<div class="logout-overlay" id="logout-overlay" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="logout-modal">
        <div class="logout-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </div>
        <div class="logout-modal-title">Log out?</div>
        <div class="logout-modal-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-modal-btns">
            <button class="logout-cancel-btn" onclick="document.getElementById('logout-overlay').classList.remove('open')">Cancel</button>
            <button class="logout-confirm-btn" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{ once:true });
      a.addEventListener('touchstart',function(){ prerender(href); },{ once:true, passive:true });
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{ once:true });
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
<?php include 'passenger_chat_widget.php'; ?>
</body>
</html>