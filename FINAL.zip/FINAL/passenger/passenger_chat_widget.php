<?php

if (!isset($_SESSION['customer_id'])) return;
$_pch_cid  = (int)$_SESSION['customer_id'];
$_pch_name = htmlspecialchars($_SESSION['name'] ?? $_SESSION['username'] ?? 'Passenger', ENT_QUOTES);
?>
<style>

#pch-fab {
    position: fixed;
    bottom: 52px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 400;
    width: 54px;
    height: 54px;
    border-radius: 50%;
    background: linear-gradient(135deg, #00D084, #00A86B);
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 20px rgba(0, 168, 107, .45);
    transition: box-shadow .2s;
    -webkit-tap-highlight-color: transparent;
}
#pch-fab:hover  { box-shadow: 0 6px 26px rgba(0,168,107,.6); }
#pch-fab:active { opacity: .85; }

#pch-badge {
    position: absolute;
    top: -3px;
    right: -3px;
    min-width: 18px;
    height: 18px;
    padding: 0 4px;
    border-radius: 9px;
    background: #E84040;
    color: #fff;
    font-size: 9px;
    font-weight: 800;
    display: none;
    align-items: center;
    justify-content: center;
    border: 2px solid var(--nav-bg, #fff);
    font-family: inherit;
}

#pch-panel {
    position: fixed;
    bottom: 118px;
    left: 50%;
    transform: translateX(-50%) translateY(12px);
    z-index: 401;
    width: min(340px, calc(100vw - 36px));
    height: 460px;
    background: var(--card-bg, #fff);
    border-radius: 20px;
    box-shadow: 0 8px 40px rgba(0,0,0,.18);
    border: 1px solid var(--card-border, #E2E8F0);
    display: none;
    flex-direction: column;
    overflow: hidden;
    transform: translateY(12px);
    opacity: 0;
    transition: transform .22s cubic-bezier(.4,0,.2,1), opacity .22s ease;
}
#pch-panel.pch-open {
    display: flex;
    transform: translateX(-50%) translateY(0);
    opacity: 1;
}

#pch-fullscreen {
    position: fixed;
    inset: 0;
    z-index: 1200;
    background: var(--card-bg, #fff);
    display: none;
    flex-direction: column;
}
#pch-fullscreen.pch-open { display: flex; }

.pch-hdr {
    padding: 13px 15px;
    background: linear-gradient(135deg, #00D084, #00A86B);
    display: flex;
    align-items: center;
    gap: 10px;
    flex-shrink: 0;
}
.pch-av {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: rgba(255,255,255,.22);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    font-weight: 800;
    color: #fff;
    flex-shrink: 0;
    font-family: inherit;
}
.pch-hdr-info { flex: 1; min-width: 0; }
.pch-hdr-name {
    font-size: 13.5px;
    font-weight: 800;
    color: #fff;
    font-family: inherit;
}
.pch-hdr-sub {
    font-size: 11px;
    color: rgba(255,255,255,.78);
    margin-top: 1px;
    font-family: inherit;
}
.pch-hdr-btns { display: flex; gap: 6px; }
.pch-hbtn {
    width: 30px;
    height: 30px;
    border-radius: 8px;
    background: rgba(255,255,255,.2);
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background .15s;
    -webkit-tap-highlight-color: transparent;
}
.pch-hbtn:hover { background: rgba(255,255,255,.32); }
.pch-hbtn svg   { stroke: #fff; }

.pch-msgs {
    flex: 1;
    overflow-y: auto;
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    background: var(--input-bg, #FAFAFA);
    scrollbar-width: none;
}
.pch-msgs::-webkit-scrollbar { display: none; }

.pch-row { display: flex; align-items: flex-end; gap: 7px; }
.pch-row.pch-me { flex-direction: row-reverse; }

.pch-bubble {
    max-width: 74%;
    padding: 9px 12px;
    border-radius: 14px;
    font-size: 13px;
    line-height: 1.45;
    word-break: break-word;
    font-family: inherit;
}
.pch-bubble.pch-admin {
    background: var(--card-bg, #fff);
    border: 1px solid var(--card-border, #E2E8F0);
    color: var(--text-dark, #1A202C);
    border-radius: 14px 14px 14px 4px;
}
.pch-bubble.pch-me-b {
    background: linear-gradient(135deg, #00D084, #00A86B);
    color: #fff;
    border-radius: 14px 14px 4px 14px;
}
.pch-time {
    font-size: 9.5px;
    margin-top: 3px;
    color: var(--text-light, #718096);
    font-family: inherit;
}
.pch-bubble.pch-me-b .pch-time { color: rgba(255,255,255,.7); }

.pch-empty {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: var(--text-light, #718096);
    text-align: center;
    padding: 24px;
    gap: 10px;
}
.pch-empty p { font-size: 12.5px; margin: 0; line-height: 1.5; font-family: inherit; }

.pch-bar {
    padding: 10px 13px;
    border-top: 1px solid var(--card-border, #E2E8F0);
    background: var(--card-bg, #fff);
    display: flex;
    gap: 8px;
    align-items: flex-end;
    flex-shrink: 0;
}
.pch-bar textarea {
    flex: 1;
    border: 1.5px solid var(--input-border, #E2E8F0);
    border-radius: 11px;
    padding: 9px 12px;
    font-size: 13px;
    font-family: inherit;
    color: var(--text-dark, #1A202C);
    background: var(--input-bg, #FAFAFA);
    resize: none;
    min-height: 40px;
    max-height: 110px;
    transition: border-color .2s;
    outline: none;
}
.pch-bar textarea:focus { border-color: #00D084; }
.pch-bar textarea::placeholder { color: var(--text-light, #718096); }
.pch-send {
    width: 40px;
    height: 40px;
    border-radius: 11px;
    background: linear-gradient(135deg, #00D084, #00A86B);
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: opacity .15s;
    -webkit-tap-highlight-color: transparent;
}
.pch-send:hover    { opacity: .88; }
.pch-send:disabled { opacity: .38; cursor: default; }
.pch-send svg { stroke: #fff; }
</style>

<button id="pch-fab" onclick="pchToggle()" title="Chat with Support" aria-label="Chat with Support">
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2"
         stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
    </svg>
    <span id="pch-badge"></span>
</button>

<div id="pch-panel" role="dialog" aria-label="Support Chat">
    <div class="pch-hdr">
        <div class="pch-av">S</div>
        <div class="pch-hdr-info">
            <div class="pch-hdr-name">EnviroCab Support</div>
            <div class="pch-hdr-sub" id="pch-sub-mini">Connecting…</div>
        </div>
        <div class="pch-hdr-btns">
            <button class="pch-hbtn" onclick="pchGoFullscreen()" title="Open fullscreen">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2.2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>
                </svg>
            </button>
            <button class="pch-hbtn" onclick="pchClose()" title="Close">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2.5"
                     stroke-linecap="round">
                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        </div>
    </div>
    <div class="pch-msgs" id="pch-msgs-mini"></div>
    <div class="pch-bar">
        <textarea id="pch-ta-mini" placeholder="Type a message…" rows="1"
            onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();pchSend()}"></textarea>
        <button class="pch-send" id="pch-btn-mini" onclick="pchSend()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke-width="2.2"
                 stroke-linecap="round" stroke-linejoin="round">
                <line x1="22" y1="2" x2="11" y2="13"/>
                <polygon points="22 2 15 22 11 13 2 9 22 2"/>
            </svg>
        </button>
    </div>
</div>

<div id="pch-fullscreen" role="dialog" aria-label="Support Chat Fullscreen">
    <div class="pch-hdr">
        <div class="pch-av">S</div>
        <div class="pch-hdr-info">
            <div class="pch-hdr-name">EnviroCab Support</div>
            <div class="pch-hdr-sub" id="pch-sub-fs">Online</div>
        </div>
        <div class="pch-hdr-btns">
            <button class="pch-hbtn" onclick="pchExitFullscreen()" title="Exit fullscreen">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2.2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/>
                </svg>
            </button>
            <button class="pch-hbtn" onclick="pchClose()" title="Close">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2.5"
                     stroke-linecap="round">
                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        </div>
    </div>
    <div class="pch-msgs" id="pch-msgs-fs"></div>
    <div class="pch-bar">
        <textarea id="pch-ta-fs" placeholder="Type a message…" rows="1"
            onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();pchSend()}"></textarea>
        <button class="pch-send" id="pch-btn-fs" onclick="pchSend()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke-width="2.2"
                 stroke-linecap="round" stroke-linejoin="round">
                <line x1="22" y1="2" x2="11" y2="13"/>
                <polygon points="22 2 15 22 11 13 2 9 22 2"/>
            </svg>
        </button>
    </div>
</div>

<script>
(function () {
    var API      = 'passenger_chat_api.php';
    var convId   = null;
    var messages = [];
    var lastTime = null;
    var pollTmr  = null;
    var isFs     = false;
    var isOpen   = false;
    var unread   = 0;
    var sending  = false;

    
    function esc(s) {
        var d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }
    function fmt(iso) {
        if (!iso) return '';
        var d = new Date(iso);
        return d.toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit' });
    }
    async function api(action, body) {
        body = body || {};
        var fd = new FormData();
        fd.append('action', action);
        for (var k in body) fd.append(k, body[k]);
        var r = await fetch(API, { method: 'POST', body: fd });
        return r.json();
    }

    
    function setStatus(txt) {
        var a = document.getElementById('pch-sub-mini');
        var b = document.getElementById('pch-sub-fs');
        if (a) a.textContent = txt;
        if (b) b.textContent = txt;
    }

    
    function refreshBadge() {
        var el = document.getElementById('pch-badge');
        if (!el) return;
        if (unread > 0) {
            el.style.display   = 'flex';
            el.textContent     = unread > 9 ? '9+' : String(unread);
        } else {
            el.style.display   = 'none';
        }
    }

    
    function render() {
        var html;
        if (!messages.length) {
            html = '<div class="pch-empty">' +
                '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
                'stroke-width="1.5" style="opacity:.2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>' +
                '<p>No messages yet.<br>Say hi to our support team!</p></div>';
        } else {
            html = messages.map(function (m) {
                var isMe = m.sender_type === 'passenger';
                return '<div class="pch-row' + (isMe ? ' pch-me' : '') + '">' +
                    '<div class="pch-bubble ' + (isMe ? 'pch-me-b' : 'pch-admin') + '">' +
                    esc(m.content) +
                    '<div class="pch-time">' + fmt(m.created_at) + '</div>' +
                    '</div></div>';
            }).join('');
        }

        var mini = document.getElementById('pch-msgs-mini');
        var fs   = document.getElementById('pch-msgs-fs');
        if (mini) { mini.innerHTML = html; mini.scrollTop = mini.scrollHeight; }
        if (fs)   { fs.innerHTML   = html; fs.scrollTop   = fs.scrollHeight; }
    }

    
    async function loadMessages(initial) {
        if (!convId) return;
        var body = { conversation_id: convId };
        if (!initial && lastTime) body.since = lastTime;

        var r = await api('get_messages', body);
        if (!r.success) return;

        var newMsgs = r.messages || [];
        if (initial) {
            messages = newMsgs;
        } else {
            var ids = {};
            messages.forEach(function (m) { ids[m.id] = true; });
            var added = newMsgs.filter(function (m) { return !ids[m.id]; });
            if (!added.length) return;
            messages = messages.concat(added);
            if (!isOpen) {
                var adminNew = added.filter(function (m) { return m.sender_type === 'admin'; }).length;
                unread += adminNew;
                refreshBadge();
            }
        }
        if (messages.length) lastTime = messages[messages.length - 1].created_at;
        render();
    }

    
    async function init() {
        setStatus('Connecting…');
        var r = await api('get_or_create_conversation');
        if (!r.success || !r.conversation) { setStatus('Offline'); return; }
        convId = r.conversation.id;
        setStatus('Online');
        await loadMessages(true);
        if (pollTmr) clearInterval(pollTmr);
        pollTmr = setInterval(function () { loadMessages(false); }, 4000);
    }

    
    window.pchToggle = function () {
        if (isOpen && !isFs) { pchClose(); return; }
        var panel = document.getElementById('pch-panel');
        panel.style.display  = 'flex';
        setTimeout(function () { panel.classList.add('pch-open'); }, 10);
        isOpen = true;
        isFs   = false;
        unread = 0;
        refreshBadge();
        if (!convId) init();
        else render();
        setTimeout(function () {
            var ta = document.getElementById('pch-ta-mini');
            if (ta) ta.focus();
        }, 250);
    };

    window.pchClose = function () {
        var panel = document.getElementById('pch-panel');
        var fs    = document.getElementById('pch-fullscreen');
        panel.classList.remove('pch-open');
        fs.classList.remove('pch-open');
        setTimeout(function () { panel.style.display = 'none'; }, 230);
        isOpen = false;
        isFs   = false;
    };

    window.pchGoFullscreen = function () {
        var panel = document.getElementById('pch-panel');
        var fs    = document.getElementById('pch-fullscreen');
        panel.classList.remove('pch-open');
        setTimeout(function () { panel.style.display = 'none'; }, 230);
        fs.classList.add('pch-open');
        isFs   = true;
        isOpen = true;
        unread = 0;
        refreshBadge();
        render();
        setTimeout(function () {
            var ta = document.getElementById('pch-ta-fs');
            if (ta) ta.focus();
        }, 200);
    };

    window.pchExitFullscreen = function () {
        var panel = document.getElementById('pch-panel');
        var fs    = document.getElementById('pch-fullscreen');
        fs.classList.remove('pch-open');
        panel.style.display = 'flex';
        setTimeout(function () { panel.classList.add('pch-open'); }, 10);
        isFs   = false;
        isOpen = true;
        render();
    };

    window.pchSend = async function () {
        if (sending || !convId) return;
        var taId  = isFs ? 'pch-ta-fs'   : 'pch-ta-mini';
        var btnId = isFs ? 'pch-btn-fs'  : 'pch-btn-mini';
        var ta    = document.getElementById(taId);
        var btn   = document.getElementById(btnId);
        var text  = ta ? ta.value.trim() : '';
        if (!text) return;

        sending     = true;
        ta.value    = '';
        ta.style.height = '';
        if (btn) btn.disabled = true;

        var r = await api('send_message', { conversation_id: convId, content: text });
        sending = false;
        if (btn) btn.disabled = false;

        if (r.success && r.message) {
            messages.push(r.message);
            lastTime = r.message.created_at;
            render();
        }
    };

    
    ['pch-ta-mini', 'pch-ta-fs'].forEach(function (id) {
        var ta = document.getElementById(id);
        if (!ta) return;
        ta.addEventListener('input', function () {
            this.style.height = '';
            this.style.height = Math.min(this.scrollHeight, 110) + 'px';
        });
    });

    
    init();
})();
</script>