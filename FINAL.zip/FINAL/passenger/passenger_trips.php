<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in'], $_SESSION['customer_id']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../auth/passenger_login.php');
    exit;
}

define('SUPABASE_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '        . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) return json_decode($res, true) ?: [];
    error_log("SB GET {$table} HTTP {$code}: {$res}");
    return [];
}

function sb_patch(string $table, array $filters, array $data): bool {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code < 200 || $code >= 300) { error_log("SB PATCH {$table} HTTP {$code}: {$res}"); return false; }
    return true;
}

function getStatusStyle(string $status): array {
    return match ($status) {
        'Pending'     => ['strip' => '#F59E0B', 'bg' => 'rgba(245,158,11,0.12)',  'color' => '#B45309', 'dot' => '#F59E0B'],
        'Confirmed'   => ['strip' => '#60A5FA', 'bg' => 'rgba(96,165,250,0.12)',  'color' => '#1D4ED8', 'dot' => '#60A5FA'],
        'In Progress' => ['strip' => '#00D084', 'bg' => 'rgba(0,208,132,0.12)',   'color' => '#065F46', 'dot' => '#00D084'],
        'Completed'   => ['strip' => '#10B981', 'bg' => 'rgba(16,185,129,0.12)',  'color' => '#065F46', 'dot' => '#10B981'],
        'Cancelled'   => ['strip' => '#EF4444', 'bg' => 'rgba(239,68,68,0.10)',   'color' => '#B91C1C', 'dot' => '#EF4444'],
        default       => ['strip' => '#CBD5E0', 'bg' => 'rgba(0,0,0,0.05)',       'color' => '#718096', 'dot' => '#CBD5E0'],
    };
}
function getPaymentStyle(string $status): array {
    return match ($status) {
        'Paid'     => ['bg' => 'rgba(16,185,129,0.12)',  'color' => '#065F46'],
        'Unpaid'   => ['bg' => 'rgba(239,68,68,0.10)',   'color' => '#B91C1C'],
        'Partial'  => ['bg' => 'rgba(245,158,11,0.12)',  'color' => '#B45309'],
        'Refunded' => ['bg' => 'rgba(96,165,250,0.12)',  'color' => '#1D4ED8'],
        default    => ['bg' => 'rgba(0,0,0,0.05)',       'color' => '#718096'],
    };
}

$customerId   = (int) $_SESSION['customer_id'];
$customerName = htmlspecialchars($_SESSION['name'] ?? $_SESSION['username'] ?? '');
$hour         = (int) (new DateTime('now', new DateTimeZone('Asia/Manila')))->format('H');
$greeting     = match (true) { $hour >= 18 => 'Good Evening', $hour >= 12 => 'Good Afternoon', default => 'Good Morning' };

define('SUPABASE_SERVICE_KEY', getenv('SUPABASE_SERVICE_KEY') ?: 'YOUR_SERVICE_ROLE_KEY_HERE');

function sb_patch_service(string $table, array $filters, array $data): bool {
    $key = (SUPABASE_SERVICE_KEY !== 'YOUR_SERVICE_ROLE_KEY_HERE') ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . $key,
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code < 200 || $code >= 300) { error_log("SB PATCH svc {$table} HTTP {$code}: {$res}"); return false; }
    return true;
}

function sb_post_service(string $table, array $data): ?array {
    $key = (SUPABASE_SERVICE_KEY !== 'YOUR_SERVICE_ROLE_KEY_HERE') ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . $key,
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) { $r = json_decode($res, true); return is_array($r) ? ($r[0] ?? null) : null; }
    error_log("SB POST svc {$table} HTTP {$code}: {$res}");
    return null;
}

if (($_POST['ajax_action'] ?? '') === 'cancel_booking') {
    header('Content-Type: application/json; charset=utf-8');
    $booking_id = (int)($_POST['booking_id'] ?? 0);
    if (!$booking_id) { echo json_encode(['success' => false, 'message' => 'Missing booking_id']); exit; }

    $b_rows = sb_get('core2_bookings', [
        'booking_id'  => 'eq.' . $booking_id,
        'customer_id' => 'eq.' . $customerId,
        'select'      => 'booking_id,booking_status',
    ]);
    $bk = $b_rows[0] ?? null;
    if (!$bk) { echo json_encode(['success' => false, 'message' => 'Booking not found.']); exit; }
    if (!in_array($bk['booking_status'], ['Pending', 'Confirmed', 'In Progress'])) {
        echo json_encode(['success' => false, 'message' => 'Booking cannot be cancelled (status: ' . $bk['booking_status'] . ').']); exit;
    }
    $oldStatus = $bk['booking_status'];

    $patched = sb_patch_service('core2_bookings', ['booking_id' => 'eq.' . $booking_id], [
        'booking_status' => 'Cancelled',
        'cancelled_by'   => (int)$customerId,
        'cancelled_at'   => date('c'),
        'updated_at'     => date('c'),
    ]);
    if (!$patched) { echo json_encode(['success' => false, 'message' => 'Failed to cancel. Please try again.']); exit; }

    sb_patch_service('core2_rides', ['booking_id' => 'eq.' . $booking_id], ['ride_status' => 'Cancelled']);
    sb_post_service('core2_booking_history', [
        'booking_id'    => $booking_id,
        'change_type'   => 'Cancelled',
        'field_changed' => 'booking_status',
        'old_value'     => $oldStatus,
        'new_value'     => 'Cancelled',
        'changed_by'    => (int)$customerId,
        'notes'         => 'Cancelled by passenger',
    ]);
    echo json_encode(['success' => true, 'message' => 'Booking cancelled.']);
    exit;
}

if (($_POST['ajax_action'] ?? '') === 'submit_rating') {
    header('Content-Type: application/json; charset=utf-8');

    $ride_id      = (int)($_POST['ride_id']      ?? 0);
    $driver_id    = (int)($_POST['driver_id']    ?? 0);
    $rating_value = (int)($_POST['rating_value'] ?? 0);
    $comment      = trim($_POST['comment']        ?? '');

    if (!$ride_id || $rating_value < 1 || $rating_value > 5) {
        echo json_encode(['success' => false, 'message' => 'Please select a star rating.']); exit;
    }

    $rideRows = sb_get('core2_rides', [
        'ride_id'     => 'eq.' . $ride_id,
        'customer_id' => 'eq.' . $customerId,
        'select'      => 'ride_id,driver_id',
        'limit'       => '1',
    ]);
    if (empty($rideRows)) {
        echo json_encode(['success' => false, 'message' => 'Ride not found for your account.']); exit;
    }

    if (!$driver_id) {
        $c1Trip = sb_get('core1_trips', ['ride_id' => 'eq.' . $ride_id, 'select' => 'driver_id', 'limit' => '1']);
        if (!empty($c1Trip[0]['driver_id'])) {
            $driver_id = (int)$c1Trip[0]['driver_id'];
        }
    }
    if (!$driver_id) {
        echo json_encode(['success' => false, 'message' => 'Driver not found for this trip. Cannot submit rating.']); exit;
    }

    $dupCheck = sb_get('core2_ratings', ['ride_id' => 'eq.' . $ride_id, 'select' => 'rating_id', 'limit' => '1']);
    if (!empty($dupCheck)) {
        echo json_encode(['success' => false, 'message' => 'You already rated this trip.']); exit;
    }

    $useKey = (defined('SUPABASE_SERVICE_KEY') && SUPABASE_SERVICE_KEY !== 'YOUR_SERVICE_ROLE_KEY_HERE')
              ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;

    $payload = json_encode([
        'ride_id'      => $ride_id,
        'driver_id'    => $driver_id,
        'customer_id'  => (int)$customerId,
        'rating_value' => $rating_value,
        'comment'      => $comment ?: null,
        'rating_type'  => 'Driver Rating',
    ]);

    $ch = curl_init(SUPABASE_URL . '/rest/v1/core2_ratings');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . $useKey,
            'Authorization: Bearer ' . $useKey,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $rawRes   = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($httpCode >= 200 && $httpCode < 300) {
        $inserted = json_decode($rawRes, true);
        echo json_encode([
            'success'   => true,
            'message'   => 'Rating submitted — thank you!',
            'rating_id' => $inserted[0]['rating_id'] ?? null,
        ]);
    } else {
        $sbErr  = json_decode($rawRes, true);
        $errMsg = $sbErr['message'] ?? ($sbErr['error'] ?? $rawRes);
        echo json_encode([
            'success'    => false,
            'message'    => 'DB error (' . $httpCode . '): ' . $errMsg,
            'http_code'  => $httpCode,
            'curl_error' => $curlErr,
            'sent'       => json_decode($payload, true),
        ]);
    }
    exit;
}

if (($_GET['ajax_action'] ?? '') === 'trips_poll') {
    header('Content-Type: application/json; charset=utf-8');
    $cid = (int)$_SESSION['customer_id'];
    $active = sb_get('core2_bookings', [
        'customer_id'    => 'eq.' . $cid,
        'booking_status' => 'in.(Pending,Confirmed,In Progress)',
        'select'         => 'booking_id,booking_status,payment_status',
        'order'          => 'created_at.desc',
    ]);
    // ── BULK FETCH for poll ───────────────────────────────────────────────────
    $pollBids = array_column($active, 'booking_id');
    $pollRidesMap = []; $pollDriversMap = []; $pollC1TripsMap = [];

    if (!empty($pollBids)) {
        $bidList = implode(',', array_map('intval', $pollBids));
        foreach (sb_get('core2_rides', ['booking_id'=>'in.('.$bidList.')','select'=>'ride_id,booking_id,ride_status,driver_id']) as $r) {
            if (!isset($pollRidesMap[$r['booking_id']])) $pollRidesMap[$r['booking_id']] = $r;
        }
        $pollC2Dids = array_filter(array_unique(array_column($pollRidesMap, 'driver_id')));
        if (!empty($pollC2Dids)) {
            $didList = implode(',', array_map('intval', $pollC2Dids));
            foreach (sb_get('core1_drivers', ['core2_driver_id'=>'in.('.$didList.')','select'=>'id,driver_name,phone,status,core2_driver_id']) as $d) {
                $pollDriversMap[(int)($d['core2_driver_id'] ?? $d['id'])] = $d;
            }
        }
        $pollRideIds = array_filter(array_unique(array_column($pollRidesMap, 'ride_id')));
        if (!empty($pollRideIds)) {
            $ridList = implode(',', array_map('intval', $pollRideIds));
            foreach (sb_get('core1_trips', ['ride_id'=>'in.('.$ridList.')','status'=>'eq.COMPLETED','select'=>'id,ride_id']) as $t) {
                $pollC1TripsMap[(int)$t['ride_id']] = $t;
            }
        }
    }
    // ─────────────────────────────────────────────────────────────────────────

    $results = [];
    foreach ($active as $b) {
        $bid = $b['booking_id'];
        $bookingStatus = $b['booking_status'];
        $paymentStatus = $b['payment_status'];

        $ride       = $pollRidesMap[$bid] ?? [];
        $rideStatus = $ride['ride_status'] ?? '';
        $rideId     = $ride['ride_id']     ?? null;
        $driverId   = $ride['driver_id']   ?? null;

        $driverName = null; $driverContact = null; $driverStatus = '';
        if ($driverId && isset($pollDriversMap[(int)$driverId])) {
            $drv = $pollDriversMap[(int)$driverId];
            $driverName    = $drv['driver_name'] ?? null;
            $driverContact = $drv['phone']       ?? null;
            $driverStatus  = strtolower($drv['status'] ?? '');
        }

        $tripDone = null;
        if ($rideId && !in_array($rideStatus, ['Completed','Cancelled'])) {
            if (isset($pollC1TripsMap[(int)$rideId])) $tripDone = $pollC1TripsMap[(int)$rideId];

            if ($tripDone) {
                sb_patch('core2_rides',    ['ride_id'   =>'eq.'.(int)$rideId], ['ride_status'=>'Completed','end_time'=>date('c')]);
                sb_patch('core2_bookings', ['booking_id'=>'eq.'.$bid],          ['booking_status'=>'Completed','payment_status'=>'Paid','updated_at'=>date('c')]);
                sb_patch('core2_payment_authorization', ['booking_id'=>'eq.'.$bid], ['payment_status'=>'Captured']);
                $rideStatus='Completed'; $bookingStatus='Completed'; $paymentStatus='Paid';
            }
        }

        if (!$tripDone && $rideId && $rideStatus === 'Completed' && !in_array($bookingStatus, ['Completed','Cancelled'])) {
            sb_patch('core2_bookings', ['booking_id'=>'eq.'.$bid], ['booking_status'=>'Completed','payment_status'=>'Paid','updated_at'=>date('c')]);
            sb_patch('core2_payment_authorization', ['booking_id'=>'eq.'.$bid], ['payment_status'=>'Captured']);
            $bookingStatus='Completed'; $paymentStatus='Paid'; $tripDone=true;
        }

        if (!$tripDone && !in_array($rideStatus, ['Completed','Cancelled']) && $driverStatus !== '') {
            $driverOnTrip = in_array($driverStatus, ['in progress','in_progress','on_trip','in_trip','busy','driving','on trip','in trip']);
            if ($driverOnTrip) $rideStatus = 'In Progress';
        }

        if ($rideStatus==='Accepted' && $bookingStatus==='Pending') {
            sb_patch('core2_bookings', ['booking_id'=>'eq.'.$bid], ['booking_status'=>'Confirmed','updated_at'=>date('c')]);
            $bookingStatus='Confirmed';
        }
        if ($rideStatus==='In Progress' && in_array($bookingStatus, ['Pending','Confirmed'])) {
            sb_patch('core2_bookings', ['booking_id'=>'eq.'.$bid], ['booking_status'=>'In Progress','updated_at'=>date('c')]);
            $bookingStatus='In Progress';
        }
        $results[] = ['booking_id'=>$bid,'booking_status'=>$bookingStatus,'payment_status'=>$paymentStatus,'driver_name'=>$driverName,'driver_contact'=>$driverContact,'ride_id'=>$rideId];
    }
    echo json_encode(['ok'=>true,'bookings'=>$results]);
    exit;
}

$allowedFilters = ['all', 'pending', 'confirmed', 'in_progress', 'completed', 'cancelled'];
$filter       = in_array($_GET['filter'] ?? '', $allowedFilters, true) ? $_GET['filter'] : 'all';
$filterLabels = ['all' => 'All', 'pending' => 'Pending', 'confirmed' => 'Confirmed', 'in_progress' => 'In Progress', 'completed' => 'Completed', 'cancelled' => 'Cancelled'];
$dbStatusMap  = ['pending' => 'Pending', 'confirmed' => 'Confirmed', 'in_progress' => 'In Progress', 'completed' => 'Completed', 'cancelled' => 'Cancelled'];

$allBookings = sb_get('core2_bookings', [
    'customer_id' => 'eq.' . $customerId,
    'select'      => 'booking_id,booking_reference,booking_date,booking_time,booking_status,payment_status,total_amount,special_requirements,created_at,confirmed_at,cancellation_reason,cancelled_by',
    'order'       => 'created_at.desc',
]);

$counts = array_fill_keys(array_keys($filterLabels), 0);
$totalSpentMonth = 0;
$totalCompleted  = 0;
$currentMonth    = date('Y-m');

foreach ($allBookings as $b) {
    $key = strtolower(str_replace(' ', '_', $b['booking_status'] ?? ''));
    if (isset($counts[$key])) $counts[$key]++;
    $counts['all']++;
    if (($b['booking_status'] ?? '') === 'Completed') $totalCompleted++;
    if (
        ($b['payment_status'] ?? '') === 'Paid' &&
        isset($b['booking_date']) &&
        str_starts_with($b['booking_date'], $currentMonth)
    ) {
        $totalSpentMonth += (float)($b['total_amount'] ?? 0);
    }
}
$pendingCount = $counts['pending'];
$activeCount  = $pendingCount + $counts['confirmed'] + $counts['in_progress'];

if ($filter !== 'all') {
    $targetStatus = $dbStatusMap[$filter];
    $allBookings  = array_filter($allBookings, fn($b) => ($b['booking_status'] ?? '') === $targetStatus);
    $allBookings  = array_values($allBookings);
}

// ── BULK FETCH: replace N×5 per-booking queries with 5 batch queries ─────────
$allBookingIds = array_column($allBookings, 'booking_id');

// Map: booking_id => booking row (already have this from $allBookings)
$bookingsById = [];
foreach ($allBookings as $b) { $bookingsById[$b['booking_id']] = $b; }

// 1. Rides (one row per booking)
$ridesMap = [];
if (!empty($allBookingIds)) {
    $bidList = implode(',', array_map('intval', $allBookingIds));
    foreach (sb_get('core2_rides', [
        'booking_id' => 'in.(' . $bidList . ')',
        'select'     => 'ride_id,booking_id,start_location,end_location,ride_status,driver_id,end_time',
        'order'      => 'ride_id.asc',
    ]) as $r) {
        // Keep the first (oldest) ride per booking
        if (!isset($ridesMap[$r['booking_id']])) {
            $ridesMap[$r['booking_id']] = $r;
        }
    }
}

// Collect unique core2_driver_ids and ride_ids from rides
$c2DriverIds = array_filter(array_unique(array_column($ridesMap, 'driver_id')));
$rideIds     = array_filter(array_unique(array_column($ridesMap, 'ride_id')));

// 2. Drivers by core2_driver_id
$driversMap = [];
if (!empty($c2DriverIds)) {
    $didList = implode(',', array_map('intval', $c2DriverIds));
    foreach (sb_get('core1_drivers', [
        'core2_driver_id' => 'in.(' . $didList . ')',
        'select'          => 'id,driver_name,phone,status,core2_driver_id',
    ]) as $d) {
        $driversMap[(int)($d['core2_driver_id'] ?? $d['id'])] = $d;
    }
}

// 3. core1_trips for rides that have no driver yet (fallback) + completion check
$core1TripsByRide = [];
if (!empty($rideIds)) {
    $ridList = implode(',', array_map('intval', $rideIds));
    foreach (sb_get('core1_trips', [
        'ride_id' => 'in.(' . $ridList . ')',
        'select'  => 'id,ride_id,driver_id,status',
    ]) as $t) {
        $core1TripsByRide[(int)$t['ride_id']] = $t;   // keep latest/only row
    }
}

// 4. Payment methods
$paymentMethodMap = [];
if (!empty($allBookingIds)) {
    $bidList = implode(',', array_map('intval', $allBookingIds));
    foreach (sb_get('core2_payment_authorization', [
        'booking_id' => 'in.(' . $bidList . ')',
        'select'     => 'booking_id,payment_method',
    ]) as $p) {
        $paymentMethodMap[$p['booking_id']] = $p['payment_method'];
    }
}

// 5. Fares
$faresMap = [];
if (!empty($allBookingIds)) {
    $bidList = implode(',', array_map('intval', $allBookingIds));
    foreach (sb_get('core2_fare_computation', [
        'booking_id' => 'in.(' . $bidList . ')',
        'select'     => 'booking_id,distance_km,distance_rate,base_fare,surge_multiplier',
    ]) as $f) {
        $faresMap[$f['booking_id']] = $f;
    }
}

// 6. Ratings (has passenger already rated each ride?)
$ratedRideIds = [];
if (!empty($rideIds)) {
    $ridList = implode(',', array_map('intval', $rideIds));
    foreach (sb_get('core2_ratings', [
        'ride_id'     => 'in.(' . $ridList . ')',
        'customer_id' => 'eq.' . $customerId,
        'select'      => 'ride_id',
    ]) as $rt) {
        $ratedRideIds[(int)$rt['ride_id']] = true;
    }
}
// ── END BULK FETCH ────────────────────────────────────────────────────────────

$bookings = [];
foreach ($allBookings as $b) {
    $bookingId = $b['booking_id'];

    $ride          = $ridesMap[$bookingId] ?? [];
    $fare          = $faresMap[$bookingId] ?? [];
    $paymentMethod = $paymentMethodMap[$bookingId] ?? null;

    $driverName        = null;
    $driverContact     = null;
    $driverVehicle     = null;
    $pageDriverStatus  = '';
    $pageCore1DriverId = null;

    // Resolve driver from bulk-fetched driversMap
    if (!empty($ride['driver_id'])) {
        $drv = $driversMap[(int)$ride['driver_id']] ?? null;
        if ($drv) {
            $driverName        = $drv['driver_name'] ?? null;
            $driverContact     = $drv['phone']       ?? null;
            $pageDriverStatus  = strtolower($drv['status'] ?? '');
            $pageCore1DriverId = $drv['id']          ?? null;
        }
    }

    // Fallback: resolve driver via core1_trips (already bulk-fetched)
    if (empty($driverName) && !empty($ride['ride_id'])) {
        $c1Trip = $core1TripsByRide[(int)$ride['ride_id']] ?? null;
        if (!empty($c1Trip['driver_id'])) {
            // Try to find the driver by core1 id in our map
            $drvFb = null;
            foreach ($driversMap as $d) {
                if ((int)$d['id'] === (int)$c1Trip['driver_id']) { $drvFb = $d; break; }
            }
            if ($drvFb) {
                $driverName        = $drvFb['driver_name'] ?? null;
                $driverContact     = $drvFb['phone']       ?? null;
                $pageDriverStatus  = strtolower($drvFb['status'] ?? '');
                $pageCore1DriverId = $drvFb['id']          ?? null;

                if (!empty($drvFb['core2_driver_id']) && empty($ride['driver_id'])) {
                    $ride['driver_id'] = (int)$drvFb['core2_driver_id'];
                    sb_patch('core2_rides', ['ride_id' => 'eq.' . (int)$ride['ride_id']], ['driver_id' => (int)$drvFb['core2_driver_id']]);
                }
            }
        }
    }

    $hasRating = isset($ratedRideIds[(int)($ride['ride_id'] ?? 0)]);

    if (!empty($ride['ride_id'])) {
        $rideStatusCheck = $ride['ride_status'] ?? '';

        if ($rideStatusCheck === 'Completed' && !in_array($b['booking_status'] ?? '', ['Completed','Cancelled'])) {
            sb_patch('core2_bookings', ['booking_id' => 'eq.' . $bookingId], ['booking_status' => 'Completed', 'payment_status' => 'Paid', 'updated_at' => date('c')]);
            sb_patch('core2_payment_authorization', ['booking_id' => 'eq.' . $bookingId], ['payment_status' => 'Captured']);
            $b['booking_status'] = 'Completed';
            $b['payment_status'] = 'Paid';
        }

        if (!in_array($rideStatusCheck, ['Completed', 'Cancelled'])) {
            $c1Done = $core1TripsByRide[(int)$ride['ride_id']] ?? null;
            if (!empty($c1Done) && strtoupper($c1Done['status'] ?? '') === 'COMPLETED') {
                sb_patch('core2_rides',    ['ride_id'    => 'eq.' . (int)$ride['ride_id']], ['ride_status' => 'Completed', 'end_time' => date('c')]);
                sb_patch('core2_bookings', ['booking_id' => 'eq.' . $bookingId],           ['booking_status' => 'Completed', 'payment_status' => 'Paid', 'updated_at' => date('c')]);
                sb_patch('core2_payment_authorization', ['booking_id' => 'eq.' . $bookingId], ['payment_status' => 'Captured']);
                $ride['ride_status'] = 'Completed';
                $b['booking_status'] = 'Completed';
                $b['payment_status'] = 'Paid';
                $rideStatusCheck     = 'Completed';
            }
        }

        if (!in_array($rideStatusCheck, ['Completed','Cancelled']) && $pageDriverStatus !== '') {
            $pgOnTrip   = in_array($pageDriverStatus, ['in progress','in_progress','on_trip','in_trip','busy','driving','on trip','in trip']);
            $pgAccepted = ($pageDriverStatus === 'in progress');
            if ($rideStatusCheck === 'Requested' && ($pgAccepted || $pgOnTrip)) $rideStatusCheck = 'Accepted';
            if ($pgOnTrip) $rideStatusCheck = 'In Progress';
        }

        if ($rideStatusCheck === 'Accepted' && ($b['booking_status'] ?? '') === 'Pending') {
            sb_patch('core2_bookings', ['booking_id' => 'eq.' . $bookingId], ['booking_status' => 'Confirmed', 'updated_at' => date('c')]);
            $b['booking_status'] = 'Confirmed';
        }
        if ($rideStatusCheck === 'In Progress' && in_array($b['booking_status'] ?? '', ['Pending','Confirmed'])) {
            sb_patch('core2_bookings', ['booking_id' => 'eq.' . $bookingId], ['booking_status' => 'In Progress', 'updated_at' => date('c')]);
            $b['booking_status'] = 'In Progress';
        }
    }

    $bookings[] = array_merge($b, [
        'ride_id'             => $ride['ride_id']        ?? null,
        'start_location'      => $ride['start_location'] ?? null,
        'end_location'        => $ride['end_location']   ?? null,
        'ride_status'         => $ride['ride_status']    ?? null,
        'driver_id'           => $ride['driver_id']      ?? null,
        'core1_driver_id'     => $pageCore1DriverId,
        'end_time'            => $ride['end_time']        ?? null,
        'driver_name'         => $driverName,
        'driver_contact'      => $driverContact,
        'driver_vehicle_info' => $driverVehicle,
        'payment_method'      => $paymentMethod,
        'distance_km'         => $fare['distance_km']       ?? null,
        'distance_rate'       => $fare['distance_rate']     ?? null,
        'base_fare'           => $fare['base_fare']         ?? null,
        'surge_multiplier'    => $fare['surge_multiplier']  ?? 1,
        'has_rating'          => $hasRating,

        'rejected_by_driver'  => (
            ($b['booking_status'] ?? '') === 'Cancelled' &&
            ($ride['ride_status'] ?? '') === 'Cancelled' &&
            empty($ride['driver_id']) &&
            (empty($b['cancelled_by']) || (int)$b['cancelled_by'] !== $customerId)
        ),
    ]);
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>EnviroCab – My Trips</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
    :root,[data-theme="light"]{--primary-green:#00D084;--dark-green:#00A86B;--bg-gradient:linear-gradient(135deg,#E8F5F1 0%,#F0F9FF 100%);--card-bg:#FFFFFF;--card-border:#E2E8F0;--header-bg:rgba(255,255,255,0.85);--header-border:rgba(255,255,255,0.5);--text-dark:#1A202C;--text-medium:#4A5568;--text-light:#718096;--input-bg:#FAFAFA;--input-border:#E2E8F0;--row-border:rgba(0,0,0,0.04);--nav-bg:rgba(255,255,255,0.95);--icon-btn-bg:rgba(255,255,255,0.9);--icon-btn-border:rgba(0,0,0,0.05);--toggle-track:#E2E8F0;--shadow-card:0 2px 8px rgba(0,0,0,0.04);--shadow-hero:0 8px 32px rgba(0,208,132,0.2);--shadow-nav:0 -4px 24px rgba(0,0,0,0.05);--overlay-bg:rgba(0,0,0,0.45);--sheet-bg:#FFFFFF;--cancel-btn-bg:#F1F5F9;--cancel-btn-color:#4A5568;}
    [data-theme="dark"]{--primary-green:#00D084;--dark-green:#00A86B;--bg-gradient:linear-gradient(135deg,#0D1F1A 0%,#0F172A 100%);--card-bg:#1A2820;--card-border:#263330;--header-bg:rgba(15,24,18,0.94);--header-border:rgba(0,208,132,0.1);--text-dark:#E8F5F1;--text-medium:#9FC4AE;--text-light:#607D6B;--input-bg:#111E18;--input-border:#263330;--row-border:rgba(255,255,255,0.05);--nav-bg:rgba(15,24,18,0.97);--icon-btn-bg:rgba(255,255,255,0.06);--icon-btn-border:rgba(255,255,255,0.08);--toggle-track:#263330;--shadow-card:0 2px 12px rgba(0,0,0,0.35);--shadow-hero:0 8px 40px rgba(0,208,132,0.12);--shadow-nav:0 -4px 24px rgba(0,0,0,0.5);--overlay-bg:rgba(0,0,0,0.72);--sheet-bg:#1A2820;--cancel-btn-bg:#263330;--cancel-btn-color:#9FC4AE;}
    *::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
    *,*::before,*::after{transition:background-color .3s ease,border-color .25s ease,color .2s ease,box-shadow .3s ease;}
    input,button,svg,img{transition:none;}input:focus{transition:border-color .15s,box-shadow .15s;}
    .btn-primary,.btn-outline,.icon-btn,.nav-item,.form-card,.trip-card{transition:background .2s,transform .15s,opacity .2s,border-color .2s,box-shadow .2s;}
    body{font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;background:var(--bg-gradient);color:var(--text-dark);min-height:100vh;padding-bottom:100px;-webkit-font-smoothing:antialiased;    transition:opacity .15s ease;
}

    .header{background:var(--header-bg);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);padding:16px 20px;position:sticky;top:0;z-index:100;border-bottom:1px solid var(--header-border);}
    .header-content{display:flex;justify-content:space-between;align-items:center;}
    .logo-img{height:28px;width:auto;}
    .header-right{display:flex;align-items:center;gap:10px;}
    .icon-btn{width:36px;height:36px;border-radius:12px;background:var(--icon-btn-bg);border:1px solid var(--icon-btn-border);display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative;}
    .icon-btn svg{stroke:var(--text-medium);}
    .icon-btn:active{transform:scale(0.93);}
    .logout-btn{background:rgba(239,68,68,0.12)!important;border-color:rgba(239,68,68,0.2)!important;}
    .logout-btn svg{stroke:#EF4444!important;}
    .theme-btn{width:36px;height:36px;border-radius:12px;background:var(--icon-btn-bg);border:1px solid var(--icon-btn-border);display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative;overflow:hidden;}
    .theme-btn:active{transform:scale(0.93);}
    .t-sun,.t-moon{position:absolute;transition:opacity .35s ease,transform .4s cubic-bezier(.34,1.56,.64,1)!important;}
    [data-theme="light"] .t-sun{opacity:1;transform:rotate(0deg) scale(1);}[data-theme="light"] .t-moon{opacity:0;transform:rotate(90deg) scale(.6);}
    [data-theme="dark"] .t-sun{opacity:0;transform:rotate(-90deg) scale(.6);}[data-theme="dark"] .t-moon{opacity:1;transform:rotate(0deg) scale(1);}
    .notification-badge{position:absolute;top:6px;right:6px;width:6px;height:6px;background:#EF4444;border-radius:50%;border:2px solid var(--card-bg);}

    .main-content{padding:20px;}
    @keyframes slideUp{from{opacity:0;transform:translateY(20px);}to{opacity:1;transform:translateY(0);}}

    .hero-card{background:linear-gradient(135deg,var(--primary-green) 0%,var(--dark-green) 100%);border-radius:24px;padding:28px 24px;color:white;margin-bottom:20px;box-shadow:var(--shadow-hero);position:relative;overflow:hidden;animation:slideUp .4s ease forwards;}
    .hero-card::before{content:'';position:absolute;top:-50%;right:-20%;width:200px;height:200px;background:rgba(255,255,255,0.1);border-radius:50%;}
    .hero-card::after{content:'';position:absolute;bottom:-30%;left:-10%;width:150px;height:150px;background:rgba(255,255,255,0.06);border-radius:50%;}
    .hero-greeting{font-size:14px;opacity:.9;margin-bottom:4px;position:relative;}
    .hero-title{font-size:26px;font-weight:800;margin-bottom:6px;position:relative;}
    .hero-amount{font-size:42px;font-weight:900;letter-spacing:-1px;margin-bottom:4px;position:relative;}
    .hero-label{font-size:13px;opacity:.85;position:relative;}
    .hero-stats{display:flex;gap:12px;margin-top:24px;position:relative;}
    .hero-stat{flex:1;background:rgba(255,255,255,0.15);backdrop-filter:blur(10px);padding:12px;border-radius:16px;text-align:center;}
    .hero-stat-value{font-size:20px;font-weight:700;margin-bottom:4px;}
    .hero-stat-label{font-size:11px;opacity:.85;}

    .stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px;}
    .stat-card{background:var(--card-bg);border-radius:16px;padding:14px 10px;border:1px solid var(--card-border);box-shadow:var(--shadow-card);text-align:center;}
    .stat-card-icon{width:40px;height:40px;border-radius:12px;margin:0 auto 8px;display:flex;align-items:center;justify-content:center;}
    .stat-card-value{font-size:18px;font-weight:800;color:var(--text-dark);}
    .stat-card-label{font-size:10px;font-weight:600;color:var(--text-light);margin-top:2px;}

    .section-label{font-size:12px;font-weight:700;color:var(--text-light);text-transform:uppercase;letter-spacing:.08em;margin:24px 0 10px;}

    .filter-scroll{overflow-x:auto;margin-bottom:20px;scrollbar-width:none;-webkit-overflow-scrolling:touch;}
    .filter-scroll::-webkit-scrollbar{display:none;}
    .filter-tabs{display:flex;gap:8px;padding-bottom:4px;min-width:max-content;}
    .filter-tab{padding:8px 16px;border-radius:50px;font-size:13px;font-weight:600;cursor:pointer;border:1.5px solid var(--card-border);background:var(--card-bg);color:var(--text-medium);white-space:nowrap;text-decoration:none;display:inline-flex;align-items:center;gap:6px;}
    .filter-tab.active{background:var(--primary-green);border-color:var(--primary-green);color:white;}
    .filter-tab-badge{font-size:11px;font-weight:800;padding:2px 7px;border-radius:6px;background:rgba(0,0,0,.08);}
    .filter-tab.active .filter-tab-badge{background:rgba(255,255,255,.25);}

    .form-card{background:var(--card-bg);border-radius:20px;padding:20px;border:1px solid var(--card-border);box-shadow:var(--shadow-card);margin-bottom:16px;}
    .form-card-header{display:flex;align-items:center;gap:12px;margin-bottom:4px;}
    .form-card-icon{width:44px;height:44px;border-radius:14px;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .form-card-title{font-size:16px;font-weight:700;color:var(--text-dark);}
    .form-card-subtitle{font-size:12px;color:var(--text-light);margin-top:2px;}

    .trip-card{background:var(--card-bg);border-radius:20px;border:1px solid var(--card-border);box-shadow:var(--shadow-card);margin-bottom:12px;overflow:hidden;animation:slideUp .4s ease forwards;}
    .trip-card-strip{height:4px;}
    .trip-card-head{display:flex;align-items:flex-start;justify-content:space-between;padding:16px 16px 12px;}
    .trip-ref{font-size:15px;font-weight:700;color:var(--text-dark);}
    .trip-meta{font-size:12px;color:var(--text-light);margin-top:2px;}
    .status-pill{display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border-radius:50px;font-size:11px;font-weight:700;flex-shrink:0;}
    .status-pill-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;}

    .trip-route{display:flex;gap:12px;padding:0 16px 14px;}
    .route-spine{display:flex;flex-direction:column;align-items:center;padding-top:3px;flex-shrink:0;}
    .route-spine-dot-start{width:10px;height:10px;border-radius:50%;background:var(--primary-green);border:2px solid white;box-shadow:0 0 0 2px var(--primary-green);}
    .route-spine-line{width:2px;flex:1;background:var(--input-border);margin:3px 0;}
    .route-spine-dot-end{width:10px;height:10px;border-radius:50%;background:#EF4444;border:2px solid white;box-shadow:0 0 0 2px #EF4444;}
    .route-labels{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px;}
    .route-label-heading{font-size:10px;font-weight:600;color:var(--text-light);text-transform:uppercase;letter-spacing:.04em;}
    .route-label-value{font-size:13px;font-weight:600;color:var(--text-dark);line-height:1.4;}

    .trip-divider{height:1px;background:var(--row-border);margin:0 16px;}

    .chip-row{display:flex;flex-wrap:wrap;gap:6px;padding:12px 16px;}
    .chip{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:10px;background:rgba(0,0,0,0.04);font-size:12px;font-weight:600;color:var(--text-medium);}
    [data-theme="dark"] .chip{background:rgba(255,255,255,0.06);}
    .chip-surge{background:rgba(245,158,11,0.10);color:#B45309;}
    [data-theme="dark"] .chip-surge{background:rgba(245,158,11,0.15);color:#FBBF24;}

    .fare-row{padding:4px 16px 12px;display:flex;align-items:center;justify-content:space-between;}
    .fare-amount{font-size:22px;font-weight:900;color:var(--dark-green);}
    .payment-pill{padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;}

    .driver-row{margin:0 16px 12px;display:flex;flex-direction:column;align-items:center;gap:8px;background:linear-gradient(135deg,rgba(0,208,132,0.06),rgba(96,165,250,0.04));border:1.5px solid rgba(0,208,132,0.15);border-radius:14px;padding:14px 13px;}
    .driver-row-searching{background:rgba(245,158,11,0.06);border-color:rgba(245,158,11,0.20);}
    .driver-avatar{width:48px;height:48px;border-radius:50%;flex-shrink:0;background:linear-gradient(135deg,var(--primary-green),var(--dark-green));display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:white;}
    .driver-avatar-pending{background:linear-gradient(135deg,#F59E0B,#D97706);}
    .driver-info{flex:1;min-width:0;text-align:center;}
    .driver-name{font-size:13px;font-weight:700;color:var(--text-dark);}
    .driver-sub{font-size:11px;color:var(--text-light);margin-top:1px;}
    .driver-phone{justify-content:center;}
    .driver-phone{font-size:12px;font-weight:700;color:var(--dark-green);display:flex;align-items:center;gap:4px;flex-shrink:0;}
    .blink-dot{width:8px;height:8px;background:#F59E0B;border-radius:50%;flex-shrink:0;animation:blink 1s infinite;}
    @keyframes blink{0%,100%{opacity:1;}50%{opacity:.2;}}

    .action-row{padding:0 16px 15px;display:flex;gap:8px;}
    .btn-action{flex:1;padding:10px 8px;border-radius:14px;font-size:13px;font-weight:700;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;font-family:inherit;}
    .btn-action:active{transform:scale(0.97);}
    .btn-action-primary{background:linear-gradient(135deg,var(--primary-green),var(--dark-green));color:white;box-shadow:0 3px 12px rgba(0,208,132,0.25);}
    .btn-action-outline{background:var(--card-bg);color:var(--text-medium);border:1.5px solid var(--card-border)!important;}
    .btn-action-danger{background:rgba(239,68,68,0.06);color:#EF4444;border:1.5px solid rgba(239,68,68,0.20)!important;}
    .btn-action-star{background:rgba(245,158,11,0.10);color:#B45309;border:1.5px solid rgba(245,158,11,0.25)!important;}

    .empty-state{padding:48px 24px;text-align:center;}
    .empty-icon{width:72px;height:72px;margin:0 auto 16px;background:rgba(0,208,132,0.08);border-radius:50%;display:flex;align-items:center;justify-content:center;}
    .empty-title{font-size:18px;font-weight:700;color:var(--text-dark);margin-bottom:8px;}
    .empty-sub{font-size:14px;color:var(--text-light);margin-bottom:24px;line-height:1.6;}
    .empty-cta{display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,var(--primary-green),var(--dark-green));color:white;padding:14px 28px;border-radius:16px;border:none;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 16px rgba(0,208,132,.3);font-family:inherit;}

    .bottom-nav{position:fixed;bottom:0;left:0;right:0;background:var(--nav-bg);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-top:1px solid var(--card-border);padding:12px 0 20px;display:grid;grid-template-columns:repeat(4,1fr);z-index:99;box-shadow:var(--shadow-nav);}
    .nav-item{display:flex;flex-direction:column;align-items:center;gap:4px;padding:8px;cursor:pointer;border:none;background:none;}
    .nav-item:active{transform:scale(0.95);}
    .nav-icon{width:48px;height:32px;display:flex;align-items:center;justify-content:center;}
    .nav-icon svg{stroke:var(--text-light);opacity:.5;}
    .nav-item.active .nav-icon svg{stroke:var(--primary-green);opacity:1;}
    .nav-label{font-size:11px;font-weight:600;color:var(--text-light);opacity:.7;}
    .nav-item.active .nav-label{color:var(--primary-green);opacity:1;}

    .modal-overlay{display:none;position:fixed;inset:0;background:var(--overlay-bg);backdrop-filter:blur(5px);-webkit-backdrop-filter:blur(5px);z-index:200;align-items:center;justify-content:center;padding:24px;}
    .modal-overlay.open{display:flex;}
    .modal-sheet{background:var(--sheet-bg);border-radius:28px;padding:28px 24px 28px;width:100%;max-width:400px;animation:slideUp .3s ease;}
    .modal-handle{display:none;}
    .modal-title{font-size:18px;font-weight:800;color:var(--text-dark);margin-bottom:6px;}
    .modal-sub{font-size:14px;color:var(--text-light);margin-bottom:24px;line-height:1.5;}
    .modal-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
    .modal-btn{padding:13px;border-radius:14px;font-size:14px;font-weight:700;border:none;cursor:pointer;font-family:inherit;}
    .modal-btn-danger{background:rgba(239,68,68,0.1);color:#EF4444;border:1.5px solid rgba(239,68,68,0.25)!important;}
    .modal-btn-keep{background:linear-gradient(135deg,var(--primary-green),var(--dark-green));color:white;}
    .modal-btn-skip{background:var(--cancel-btn-bg);color:var(--cancel-btn-color);}

    .star-row{display:flex;justify-content:center;gap:8px;margin-bottom:24px;}
    .star-btn{font-size:36px;background:none;border:none;cursor:pointer;color:var(--card-border);transition:transform .15s,color .15s!important;}
    .btn-action-rate{background:linear-gradient(135deg,#F59E0B,#D97706);color:white;border:none;font-weight:700;}
    .btn-action-rate:active{transform:scale(0.96);}
    .btn-action-rated{background:rgba(16,185,129,0.1);color:#065F46;border:1.5px solid rgba(16,185,129,0.3);font-weight:700;display:inline-flex;align-items:center;gap:5px;padding:9px 16px;border-radius:50px;font-size:12px;cursor:default;}

    @media(min-width:768px){body{max-width:480px;margin:0 auto;box-shadow:0 0 40px rgba(0,0,0,.12);}.bottom-nav{max-width:480px;left:50%;transform:translateX(-50%);}}

    .notif-panel-wrap{position:relative;}
    .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:310px;max-height:400px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.15);z-index:999;display:none;flex-direction:column;overflow:hidden;}
    .notif-panel.open{display:flex;}
    .notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);flex-shrink:0;}
    .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
    .notif-mark-read{font-size:11px;font-weight:600;color:var(--dark-green);background:none;border:none;cursor:pointer;padding:0;}
    .notif-list{overflow-y:auto;flex:1;padding:4px 0;}
    .notif-item{display:flex;align-items:flex-start;gap:10px;padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--row-border);transition:background .15s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,208,132,0.06);}
    .notif-item.unread{background:rgba(0,208,132,0.04);}
    .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
    .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
    .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
    .notif-item-body{flex:1;min-width:0;}
    .notif-item-title{font-size:12px;font-weight:700;color:var(--text-dark);margin-bottom:2px;}
    .notif-item-sub{font-size:11px;color:var(--text-light);line-height:1.4;}
    .notif-item-time{font-size:10px;color:var(--text-light);margin-top:3px;}
    .notif-empty{padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;}
    .notif-spinner{width:20px;height:20px;border:2px solid var(--card-border);border-top-color:#00D084;border-radius:50%;animation:nspin .7s linear infinite;margin:16px auto;}
    @keyframes nspin{to{transform:rotate(360deg);}}
    .notif-count-badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 3px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:9px;font-weight:800;color:#fff;display:none;align-items:center;justify-content:center;line-height:1;}

    .logout-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center;padding:24px;}
    .logout-overlay.open{display:flex;}
    .logout-modal{background:var(--card-bg);border-radius:24px;padding:28px 24px 24px;width:100%;max-width:320px;box-shadow:0 16px 48px rgba(0,0,0,0.18);animation:lmodalIn .25s cubic-bezier(.34,1.56,.64,1);}
    @keyframes lmodalIn{from{transform:scale(.88);opacity:0;}to{transform:scale(1);opacity:1;}}
    .logout-modal-icon{width:52px;height:52px;border-radius:16px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
    .logout-modal-title{font-size:17px;font-weight:800;color:var(--text-dark);text-align:center;margin-bottom:6px;}
    .logout-modal-sub{font-size:13px;color:var(--text-light);text-align:center;line-height:1.5;margin-bottom:22px;}
    .logout-modal-btns{display:flex;gap:10px;}
    .logout-cancel-btn{flex:1;padding:13px;border-radius:14px;background:var(--input-bg);border:1px solid var(--card-border);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;}
    .logout-confirm-btn{flex:1;padding:13px;border-radius:14px;background:#EF4444;border:none;font-size:14px;font-weight:700;color:#fff;cursor:pointer;}
</style>
</head>
<body>

<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img" onerror="this.style.display='none'">
        <div class="header-right">
            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            </button>
            <button class="icon-btn" onclick="window.location.href='dashboard.php'" title="Home">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </button>
            <div class="notif-panel-wrap">
            <button class="icon-btn" id="notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications" style="position:relative;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <span class="notif-count-badge" id="notif-count-badge"></span>
            </button>
            <div class="notif-panel" id="notif-panel">
                <div class="notif-panel-head">
                    <span class="notif-panel-title">Notifications</span>
                    <button class="notif-mark-read" onclick="markAllRead()">Mark all read</button>
                </div>
                <div class="notif-list" id="notif-list"><div class="notif-spinner"></div></div>
            </div>
        </div>
            <button class="icon-btn logout-btn" onclick="openLogout()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

    <div class="hero-card">
        <div class="hero-greeting"><?= $greeting ?>, <?= $customerName ?>!</div>
        <div class="hero-title">My Trips</div>
        <div class="hero-amount">&#8369;<?= number_format($totalSpentMonth, 2) ?></div>
        <div class="hero-label">Spent This Month</div>
        <div class="hero-stats">
            <div class="hero-stat"><div class="hero-stat-value"><?= $counts['all'] ?></div><div class="hero-stat-label">All Bookings</div></div>
            <div class="hero-stat"><div class="hero-stat-value"><?= $activeCount ?></div><div class="hero-stat-label">Active</div></div>
            <div class="hero-stat"><div class="hero-stat-value"><?= $totalCompleted ?></div><div class="hero-stat-label">Completed</div></div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-card-icon" style="background:rgba(245,158,11,0.15);"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><div class="stat-card-value"><?= $counts['pending'] ?></div><div class="stat-card-label">Pending</div></div>
        <div class="stat-card"><div class="stat-card-icon" style="background:rgba(96,165,250,0.15);"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div><div class="stat-card-value"><?= $counts['confirmed'] ?></div><div class="stat-card-label">Confirmed</div></div>
        <div class="stat-card"><div class="stat-card-icon" style="background:rgba(16,185,129,0.15);"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div><div class="stat-card-value"><?= $totalCompleted ?></div><div class="stat-card-label">Completed</div></div>
        <div class="stat-card"><div class="stat-card-icon" style="background:rgba(239,68,68,0.12);"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg></div><div class="stat-card-value"><?= $counts['cancelled'] ?></div><div class="stat-card-label">Cancelled</div></div>
    </div>

    <div class="filter-scroll">
        <div class="filter-tabs">
            <?php foreach ($filterLabels as $key => $label): ?>
            <a href="?filter=<?= $key ?>" class="filter-tab <?= $filter === $key ? 'active' : '' ?>">
                <?= $label ?>
                <?php if ($counts[$key] > 0): ?><span class="filter-tab-badge"><?= $counts[$key] ?></span><?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="section-label"><?= $filterLabels[$filter] ?? 'Trips' ?> (<?= count($bookings) ?>)</div>
    <div class="form-card" style="padding:0;overflow:hidden;">
        <?php if (empty($bookings)): ?>
        <div class="empty-state">
            <div class="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--dark-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg></div>
            <div class="empty-title">No trips found</div>
            <div class="empty-sub"><?= $filter === 'all' ? "You haven't made any bookings yet.<br>Book your first trip now!" : "No " . htmlspecialchars(strtolower($filterLabels[$filter] ?? '')) . " trips to show." ?></div>
            <button class="empty-cta" onclick="window.location.href='passenger_booking.php'"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>Book a Trip</button>
        </div>
        <?php else: ?>
        <?php foreach ($bookings as $idx => $booking):
            $isRejected  = !empty($booking['rejected_by_driver']);
            $ss = $isRejected
                ? ['strip' => '#F59E0B', 'bg' => 'rgba(245,158,11,0.12)', 'color' => '#92400E', 'dot' => '#F59E0B']
                : getStatusStyle($booking['booking_status']);
            $ps = getPaymentStyle($booking['payment_status']);
            $isPending   = $booking['booking_status'] === 'Pending';
            $isConfirmed = $booking['booking_status'] === 'Confirmed';
            $isInProg    = $booking['booking_status'] === 'In Progress';
            $isDone      = $booking['booking_status'] === 'Completed';
            $driverName  = $booking['driver_name'] ?? null;
            $statusLabel = $isRejected ? 'Rejected by Driver' : htmlspecialchars($booking['booking_status']);
            $delay       = min($idx * 0.05, 0.35);
        ?>
        <div class="trip-card" data-booking-id="<?= (int)$booking['booking_id'] ?>" data-status="<?= htmlspecialchars($booking['booking_status']) ?>" data-ride-id="<?= (int)($booking['ride_id'] ?? 0) ?>" data-driver-id="<?= (int)($booking['driver_id'] ?? 0) ?>" data-driver-name="<?= htmlspecialchars($booking['driver_name'] ?? '') ?>" style="animation-delay:<?= $delay ?>s;border-radius:0;border-left:none;border-right:none;border-top:<?= $idx>0?'1px solid var(--card-border)':'none' ?>;border-bottom:none;margin-bottom:0;box-shadow:none;">
            <div class="trip-card-strip" id="sstrip-<?= (int)$booking['booking_id'] ?>" style="background:<?= $ss['strip'] ?>;"></div>
            <div class="trip-card-head">
                <div>
                    <div class="trip-ref"><?= htmlspecialchars($booking['booking_reference']) ?></div>
                    <div class="trip-meta"><?= (new DateTime($booking['booking_date'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M j, Y') ?><?= $booking['booking_time'] ? ' · ' . (new DateTime($booking['booking_time'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('g:i A') : '' ?></div>
                </div>
                <div class="status-pill" id="spill-<?= (int)$booking['booking_id'] ?>" style="background:<?= $ss['bg'] ?>;color:<?= $ss['color'] ?>;"><span class="status-pill-dot" id="sdot-<?= (int)$booking['booking_id'] ?>" style="background:<?= $ss['dot'] ?>;"></span><span id="stxt-<?= (int)$booking['booking_id'] ?>"><?= $statusLabel ?></span></div>
            </div>
            <?php if ($isRejected): ?>
            <div style="margin:0 16px 10px;padding:9px 14px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);border-radius:12px;font-size:12px;color:#92400E;font-weight:600;display:flex;align-items:center;gap:8px;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                No driver accepted this booking. You can book a new trip anytime.
            </div>
            <?php endif; ?>
            <div class="trip-route">
                <div class="route-spine"><div class="route-spine-dot-start"></div><div class="route-spine-line"></div><div class="route-spine-dot-end"></div></div>
                <div class="route-labels">
                    <div><div class="route-label-heading">Pickup</div><div class="route-label-value"><?= htmlspecialchars($booking['start_location'] ?? '—') ?></div></div>
                    <div style="height:8px;"></div>
                    <div><div class="route-label-heading">Destination</div><div class="route-label-value"><?= htmlspecialchars($booking['end_location'] ?? '—') ?></div></div>
                </div>
            </div>
            <div class="trip-divider"></div>
            <div class="chip-row">
                <?php if ($booking['distance_km']): ?><div class="chip"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg><?= number_format($booking['distance_km'], 1) ?> km</div><?php endif; ?>
                <?php if ($booking['payment_method']): ?><div class="chip"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg><?= htmlspecialchars($booking['payment_method']) ?></div><?php endif; ?>
                <?php if ($booking['surge_multiplier'] > 1): ?><div class="chip chip-surge"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>Surge &times;<?= $booking['surge_multiplier'] ?></div><?php endif; ?>
                <?php if ($booking['distance_rate']): ?><div class="chip">&#8369;<?= number_format($booking['distance_rate'], 0) ?>/km</div><?php endif; ?>
            </div>
            <div class="fare-row">
                <div class="fare-amount">&#8369;<?= number_format($booking['total_amount'], 2) ?></div>
                <div class="payment-pill" style="background:<?= $ps['bg'] ?>;color:<?= $ps['color'] ?>;"><?= htmlspecialchars($booking['payment_status']) ?></div>
            </div>
            <?php if ($driverName): ?>
            <div class="driver-row">
                <div class="driver-avatar"><?= strtoupper(substr($driverName, 0, 1)) ?></div>
                <div class="driver-info"><div class="driver-name"><?= htmlspecialchars($driverName) ?></div><div class="driver-sub"><?= htmlspecialchars($booking['driver_vehicle_info'] ?? 'Vehicle details pending') ?></div></div>
                <?php if ($booking['driver_contact']): ?><div class="driver-phone" style="display:flex;justify-content:center;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.56 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg><?= htmlspecialchars($booking['driver_contact']) ?></div><?php endif; ?>
            </div>
            <?php elseif ($isPending): ?>
            <div class="driver-row driver-row-searching" id="drow-<?= (int)$booking['booking_id'] ?>">
                <div class="driver-avatar driver-avatar-pending" id="davatar-<?= (int)$booking['booking_id'] ?>">?</div>
                <div class="driver-info"><div class="driver-name" id="dname-<?= (int)$booking['booking_id'] ?>" style="color:#B45309;">Searching for driver…</div><div class="driver-sub">A nearby driver will be assigned shortly</div></div>
                <div class="blink-dot"></div>
            </div>
            <?php endif; ?>
            <div class="action-row" id="arow-<?= (int)$booking['booking_id'] ?>">
                <?php if ($isPending): ?>
                <button class="btn-action btn-action-outline" onclick="window.location.href='passenger_booking.php'"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>View Status</button>
                <button class="btn-action btn-action-danger" onclick="openCancel(<?= $booking['booking_id'] ?>, '<?= htmlspecialchars($booking['booking_reference']) ?>')">Cancel</button>
                <?php elseif ($isConfirmed || $isInProg): ?>
                <button class="btn-action btn-action-primary" onclick="window.location.href='passenger_booking.php'"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>Track Driver</button>
                <?php elseif ($isDone): ?>
                <button class="btn-action btn-action-primary" onclick="window.location.href='passenger_booking.php'"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>Book Again</button>
                <?php if (!empty($booking['ride_id']) && !$booking['has_rating']): ?>
                <button class="btn-action btn-action-rate" onclick="openRating(<?= (int)$booking['ride_id'] ?>, <?= (int)($booking['core1_driver_id'] ?? 0) ?>, <?= htmlspecialchars(json_encode($booking['driver_name'] ?? '', JSON_HEX_APOS | JSON_HEX_TAG | JSON_INVALID_UTF8_SUBSTITUTE), ENT_QUOTES, 'UTF-8') ?>)">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    Rate Driver
                </button>
                <?php elseif (!empty($booking['ride_id']) && $booking['has_rating']): ?>
                <div class="btn-action btn-action-rated">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    Rated ✓
                </div>
                <?php endif; ?>
                <?php else: ?>
                <button class="btn-action btn-action-primary" onclick="window.location.href='passenger_booking.php'">Book New Trip</button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

</div>

<div class="modal-overlay" id="cancelModal">
    <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="modal-title">Cancel Booking?</div>
        <div class="modal-sub" id="cancelModalSub">This action cannot be undone.</div>
        <div class="modal-actions">
            <button class="modal-btn modal-btn-danger" id="cancelConfirmBtn" onclick="doCancel()">Yes, Cancel It</button>
            <button class="modal-btn modal-btn-keep" onclick="closeCancel()">Keep Booking</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="ratingModal" style="align-items:center;padding:24px;">
    <div class="modal-sheet" style="border-radius:28px;padding:28px 24px 28px;width:100%;max-width:400px;animation:slideUp .3s ease;text-align:center;">
        <div class="modal-handle"></div>

        <div style="text-align:center;margin-bottom:20px;">
            <div id="ratingDriverAvatar" style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,#00D084,#00A86B);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:26px;font-weight:800;color:white;box-shadow:0 6px 20px rgba(0,208,132,0.35);">?</div>
            <div class="modal-title" style="margin-bottom:4px;">Rate Your Driver</div>
            <div id="ratingDriverName" style="font-size:14px;color:var(--dark-green);font-weight:700;">Loading…</div>
        </div>

        <div id="starLabel" style="text-align:center;font-size:13px;color:var(--text-light);margin-bottom:10px;font-weight:600;min-height:18px;"></div>

        <div class="star-row">
            <?php for ($s = 1; $s <= 5; $s++): ?>
            <button type="button" class="star-btn" id="star<?= $s ?>" onclick="setStar(<?= $s ?>)">&#9733;</button>
            <?php endfor; ?>
        </div>

        <div id="suggestionChips" style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-bottom:14px;"></div>

        <div style="margin-bottom:20px;">
            <textarea id="ratingComment" rows="3" placeholder="Leave a comment for your driver (optional)…" style="width:100%;padding:12px 14px;border-radius:14px;border:1.5px solid var(--card-border);background:var(--input-bg);color:var(--text-dark);font-family:'Inter',sans-serif;font-size:13px;resize:none;outline:none;transition:border-color .15s;" onfocus="this.style.borderColor='var(--primary-green)'" onblur="this.style.borderColor='var(--card-border)'"></textarea>
        </div>
        <div class="modal-actions">
            <button class="modal-btn modal-btn-keep" id="submitRatingBtn" onclick="submitRating()">
                <span id="submitRatingText">Submit Rating</span>
            </button>
            <button class="modal-btn modal-btn-skip" onclick="closeRating()">Skip</button>
        </div>
    </div>
</div>

<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_profile.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div>

<script>
(function(){const s=localStorage.getItem('envirocab_theme')||'light';document.documentElement.setAttribute('data-theme',s);})();
function toggleTheme(){const h=document.documentElement,c=h.getAttribute('data-theme'),n=c==='dark'?'light':'dark';h.setAttribute('data-theme',n);localStorage.setItem('envirocab_theme',n);}
let _cancelId=null;
function openCancel(id,ref){_cancelId=id;document.getElementById('cancelModalSub').textContent='Cancel booking '+ref+'? This cannot be undone.';document.getElementById('cancelModal').classList.add('open');}
function closeCancel(){document.getElementById('cancelModal').classList.remove('open');_cancelId=null;}
async function doCancel(){
    if(!_cancelId)return;
    const idToCancel=_cancelId; 
    const btn=document.getElementById('cancelConfirmBtn');
    btn.textContent='Cancelling…';btn.disabled=true;
    closeCancel();

    let ov=document.getElementById('cancellingOverlay');
    if(!ov){
        ov=document.createElement('div');ov.id='cancellingOverlay';
        ov.style.cssText='position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,0.65);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:24px;';
        ov.innerHTML=`<div style="background:var(--sheet-bg,#fff);border-radius:24px;padding:36px 28px;text-align:center;max-width:300px;width:100%;box-shadow:0 24px 60px rgba(0,0,0,.3);">
            <div id="covIconWrap" style="width:64px;height:64px;border-radius:50%;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
            </div>
            <div id="covMsg" style="font-size:17px;font-weight:800;color:var(--text-dark,#1A202C);margin-bottom:8px;">Cancelling Booking…</div>
            <div id="covDots" style="display:flex;justify-content:center;gap:6px;margin-top:4px;">
                <span style="width:8px;height:8px;background:#EF4444;border-radius:50%;display:inline-block;animation:dotB 1.2s infinite 0s"></span>
                <span style="width:8px;height:8px;background:#EF4444;border-radius:50%;display:inline-block;animation:dotB 1.2s infinite .2s"></span>
                <span style="width:8px;height:8px;background:#EF4444;border-radius:50%;display:inline-block;animation:dotB 1.2s infinite .4s"></span>
            </div>
        </div>`;
        document.body.appendChild(ov);
        const st=document.createElement('style');st.textContent='@keyframes dotB{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-10px)}}';document.head.appendChild(st);
    }
    ov.style.display='flex';
    document.getElementById('covIconWrap').style.background='rgba(239,68,68,0.1)';
    document.getElementById('covIconWrap').innerHTML='<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>';
    document.getElementById('covMsg').textContent='Cancelling Booking…';
    document.getElementById('covDots').style.display='flex';
    try{
        const res=await fetch('passenger_trips.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'ajax_action=cancel_booking&booking_id='+idToCancel});
        const data=await res.json();
        if(data.success){
            const id=idToCancel;
            document.getElementById('covIconWrap').style.background='rgba(16,185,129,0.1)';
            document.getElementById('covIconWrap').innerHTML='<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
            document.getElementById('covMsg').textContent='Booking Cancelled';
            document.getElementById('covDots').style.display='none';
            setTimeout(()=>{ov.style.display='none';applyStatusUpdate(id,'Cancelled',null,null);showTripsToast('Booking cancelled.','#EF4444');btn.textContent='Yes, Cancel It';btn.disabled=false;},1300);
        }else{
            ov.style.display='none';btn.textContent='Yes, Cancel It';btn.disabled=false;
            showTripsToast(data.message||'Could not cancel booking.','#EF4444');
        }
    }catch(err){ov.style.display='none';btn.textContent='Yes, Cancel It';btn.disabled=false;showTripsToast('Network error. Please try again.','#EF4444');}
}
document.getElementById('cancelModal').addEventListener('click',e=>{if(e.target===document.getElementById('cancelModal'))closeCancel();});
let _rideId=null,_driverId=null,_driverName=null,_stars=0;
const STAR_LABELS=['','😞 Poor','😐 Fair','🙂 Good','😊 Great','🤩 Excellent!'];
const SUGGESTIONS={
    1:['Rude behavior','Very late','Wrong route','Unsafe driving','Bad attitude'],
    2:['A bit late','Could improve','Not very friendly','Needed GPS help','Car not clean'],
    3:['Okay driver','Decent trip','Average service','Gets the job done','Nothing special'],
    4:['Good driver','Very friendly','On time','Smooth ride','Clean vehicle'],
    5:['Amazing driver!','Super friendly','Very punctual','Excellent service','Would ride again!']
};
function renderSuggestions(n){
    const wrap=document.getElementById('suggestionChips');
    if(!wrap)return;
    if(!n){wrap.innerHTML='';return;}
    const chips=(SUGGESTIONS[n]||[]).map(s=>{
        const active=document.getElementById('ratingComment').value===s;
        return `<button type="button" onclick="applySuggestion(this,'${s.replace(/'/g,"\\'")}')" style="padding:6px 13px;border-radius:50px;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s;border:1.5px solid rgba(0,208,132,0.35);background:rgba(0,208,132,0.08);color:var(--dark-green);">${s}</button>`;
    }).join('');
    wrap.innerHTML=chips;
}
function applySuggestion(btn,text){
    const ta=document.getElementById('ratingComment');
    const alreadySelected=ta.value===text;
    ta.value=alreadySelected?'':text;

    document.querySelectorAll('#suggestionChips button').forEach(b=>{
        const isThis=b===btn&&!alreadySelected;
        b.style.background=isThis?'rgba(0,208,132,0.22)':'rgba(0,208,132,0.08)';
        b.style.borderColor=isThis?'var(--primary-green)':'rgba(0,208,132,0.35)';
        b.style.color=isThis?'var(--dark-green)':'var(--dark-green)';
    });
}
function openRating(rideId,driverId,driverName){
    _rideId=rideId;_driverId=driverId;_driverName=driverName||'Your Driver';_stars=0;
    renderStars(0);
    document.getElementById('starLabel').textContent='Tap a star to rate';
    document.getElementById('ratingComment').value='';
    document.getElementById('submitRatingText').textContent='Submit Rating';
    document.getElementById('submitRatingBtn').disabled=false;
    renderSuggestions(0);

    const initial=(_driverName||'?').charAt(0).toUpperCase();
    document.getElementById('ratingDriverAvatar').textContent=initial;
    document.getElementById('ratingDriverName').textContent=_driverName;
    document.getElementById('ratingModal').classList.add('open');
}
function closeRating(){document.getElementById('ratingModal').classList.remove('open');}
function setStar(n){_stars=n;renderStars(n);document.getElementById('starLabel').textContent=STAR_LABELS[n]||'';renderSuggestions(n);}
function renderStars(n){
    for(let i=1;i<=5;i++){
        const el=document.getElementById('star'+i);
        if(i<=n){el.style.color='#F59E0B';el.style.transform='scale(1.25)';}
        else{el.style.color='var(--card-border)';el.style.transform='scale(1)';}
    }
}
async function submitRating(){
    if(!_stars){
        document.getElementById('starLabel').textContent='⚠️ Please choose a star rating first';
        document.getElementById('starLabel').style.color='#EF4444';
        setTimeout(()=>{document.getElementById('starLabel').style.color='';document.getElementById('starLabel').textContent='Tap a star to rate';},2000);
        return;
    }
    const btn=document.getElementById('submitRatingBtn');
    btn.disabled=true;
    document.getElementById('submitRatingText').textContent='Submitting…';
    const comment=document.getElementById('ratingComment').value.trim();
    try{
        const res=await fetch('passenger_trips.php',{
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'ajax_action=submit_rating&ride_id='+_rideId+'&driver_id='+_driverId+'&rating_value='+_stars+'&comment='+encodeURIComponent(comment)
        });
        const data=await res.json();
        if(data.success){
            closeRating();

            const ratedCard=document.querySelector('[data-ride-id="'+_rideId+'"]');
            if(ratedCard){
                const rateBtn=ratedCard.querySelector('.btn-action-rate');
                if(rateBtn) rateBtn.outerHTML='<div class="btn-action btn-action-rated"><svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>Rated ✓</div>';
            }
            showTripsToast('⭐ Rating submitted — thank you!','#00A86B');
        }else{
            btn.disabled=false;
            document.getElementById('submitRatingText').textContent='Submit Rating';
            showTripsToast(data.message||'Could not submit rating.','#EF4444');
        }
    }catch(err){
        btn.disabled=false;
        document.getElementById('submitRatingText').textContent='Submit Rating';
        showTripsToast('Network error. Please try again.','#EF4444');
    }
}
document.getElementById('ratingModal').addEventListener('click',e=>{if(e.target===document.getElementById('ratingModal'))closeRating();});
function showTripsToast(msg,color){
    let t=document.getElementById('trips-rt-toast');
    if(!t){t=document.createElement('div');t.id='trips-rt-toast';t.style.cssText='position:fixed;bottom:88px;left:50%;transform:translateX(-50%) translateY(6px);padding:11px 20px;border-radius:20px;font-size:13px;font-weight:700;color:#fff;z-index:9000;opacity:0;transition:opacity .25s,transform .25s;pointer-events:none;white-space:nowrap;box-shadow:0 4px 18px rgba(0,0,0,.22);';document.body.appendChild(t);}
    t.textContent=msg;t.style.background=color||'#00A86B';t.style.opacity='1';t.style.transform='translateX(-50%) translateY(0)';
    clearTimeout(t._tmr);t._tmr=setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(-50%) translateY(6px)';},2800);
}
const SS={'Pending':{strip:'#F59E0B',bg:'rgba(245,158,11,0.12)',color:'#B45309',dot:'#F59E0B'},'Confirmed':{strip:'#60A5FA',bg:'rgba(96,165,250,0.12)',color:'#1D4ED8',dot:'#60A5FA'},'In Progress':{strip:'#00D084',bg:'rgba(0,208,132,0.12)',color:'#065F46',dot:'#00D084'},'Completed':{strip:'#10B981',bg:'rgba(16,185,129,0.12)',color:'#065F46',dot:'#10B981'},'Cancelled':{strip:'#EF4444',bg:'rgba(239,68,68,0.10)',color:'#B91C1C',dot:'#EF4444'}};
function _goBook(){location.href='passenger_booking.php';}

function applyStatusUpdate(bid,newStatus,driverName,driverContact){
    const card=document.querySelector('[data-booking-id="'+bid+'"]');
    if(!card)return;
    const oldStatus=card.dataset.status;
    if(oldStatus===newStatus&&!driverName)return;
    const ss=SS[newStatus]||SS['Pending'];
    card.dataset.status=newStatus;
    const strip=document.getElementById('sstrip-'+bid);if(strip)strip.style.background=ss.strip;
    const pill=document.getElementById('spill-'+bid);const dot=document.getElementById('sdot-'+bid);const txt=document.getElementById('stxt-'+bid);
    if(pill){pill.style.background=ss.bg;pill.style.color=ss.color;}if(dot)dot.style.background=ss.dot;if(txt)txt.textContent=newStatus;
    if(driverName){
        const drow=document.getElementById('drow-'+bid);const davatar=document.getElementById('davatar-'+bid);const dname=document.getElementById('dname-'+bid);
        if(drow&&drow.classList.contains('driver-row-searching')){
            drow.classList.remove('driver-row-searching');
            const bd=drow.querySelector('.blink-dot');if(bd)bd.remove();
            if(davatar){davatar.classList.remove('driver-avatar-pending');davatar.textContent=driverName.charAt(0).toUpperCase();}
            if(dname){dname.style.color='';dname.textContent=driverName;}
        }
    }
    const arow=document.getElementById('arow-'+bid);
    if(arow){
        if(newStatus==='Confirmed'||newStatus==='In Progress'){arow.innerHTML='<button class="btn-action btn-action-primary" onclick="_goBook()"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>Track Driver</button>';}
        else if(newStatus==='Completed'){arow.innerHTML='<button class="btn-action btn-action-primary" onclick="_goBook()"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>Book Again</button>';}
        else if(newStatus==='Cancelled'){arow.innerHTML='<button class="btn-action btn-action-primary" onclick="_goBook()">Book New Trip</button>';}
    }
    card.style.transition='background .35s';card.style.background='rgba(0,208,132,0.07)';setTimeout(()=>{card.style.background='';},700);
    if(newStatus==='Confirmed'&&oldStatus==='Pending')showTripsToast('Driver accepted your booking!','#1D4ED8');
    if(newStatus==='In Progress'&&oldStatus!=='In Progress')showTripsToast('Your trip has started!','#065F46');
    if(newStatus==='Completed'&&oldStatus!=='Completed')showTripsToast('Trip completed!','#00A86B');
}
const TripsPoller=(()=>{
    let _timer=null,_interval=5000,_stopped=false;
    const MIN=4000,MAX=15000,STEP=2000;
    document.addEventListener('visibilitychange',()=>{if(document.hidden)clearTimeout(_timer);else if(!_stopped)_sched(800);});
    function _sched(ms){clearTimeout(_timer);_timer=setTimeout(_tick,ms!=null?ms:_interval);}
    async function _tick(){
        if(_stopped||document.hidden)return;
        const active=document.querySelectorAll('[data-booking-id][data-status="Pending"],[data-booking-id][data-status="Confirmed"],[data-booking-id][data-status="In Progress"]');
        if(!active.length){_interval=Math.min(_interval+STEP,MAX);_sched();return;}
        try{
            const res=await fetch('passenger_trips.php?ajax_action=trips_poll',{cache:'no-store'});
            if(!res.ok)throw new Error('HTTP '+res.status);
            const json=await res.json();
            let changed=false;
            (json.bookings||[]).forEach(b=>{
                const card=document.querySelector('[data-booking-id="'+b.booking_id+'"]');
                if(!card)return;
                if(card.dataset.status!==b.booking_status||b.driver_name){applyStatusUpdate(b.booking_id,b.booking_status,b.driver_name,b.driver_contact);changed=true;}
            });
            _interval=changed?MIN:Math.min(_interval+STEP,MAX);
        }catch(e){console.warn('[TripsPoller]',e);_interval=Math.min(_interval+STEP,MAX);}
        if(!_stopped)_sched(_interval);
    }
    function start(){_stopped=false;_sched(2500);}
    function stop(){_stopped=true;clearTimeout(_timer);}
    return{start,stop};
})();
document.addEventListener('DOMContentLoaded',()=>{
    if(document.querySelector('[data-status="Pending"],[data-status="Confirmed"],[data-status="In Progress"]'))TripsPoller.start();
});
</script>
<script>
const CUSTOMER_ID = <?= (int)$customerId ?>;

const SB_URL = 'https://kyhndwabhbkduoaxeunq.supabase.co';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
let _notifOpen = false, _notifData = [], _notifTimer = null;
let _seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');

const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};

function toggleNotifPanel(e) {
    e.stopPropagation();
    _notifOpen = !_notifOpen;
    document.getElementById('notif-panel').classList.toggle('open', _notifOpen);
    if (_notifOpen) { fetchNotifs(); _notifTimer = setInterval(fetchNotifs, 8000); }
    else clearInterval(_notifTimer);
}

async function fetchNotifs() {
    try {
        const r = await fetch(SB_URL + '/rest/v1/core2_bookings?customer_id=eq.' + CUSTOMER_ID +
            '&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=15',
            {headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        _notifData = await r.json();
        renderNotifs();
        updateBadge();
    } catch(e) {}
}

function renderNotifs() {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!_notifData.length) { list.innerHTML = '<div class="notif-empty">No notifications yet.</div>'; return; }
    list.innerHTML = _notifData.map(b => {
        const cfg = STATUS_CFG[b.booking_status] || {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key = b.booking_id + '_' + b.booking_status;
        const unread = !_seen.includes(key);
        const amt = '\u20B1' + parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t = timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
}

function updateBadge() {
    const cnt = _notifData.filter(b => !_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    const el = document.getElementById('notif-count-badge');
    if (!el) return;
    if (cnt > 0) { el.textContent = cnt > 9 ? '9+' : cnt; el.style.display = 'flex'; }
    else el.style.display = 'none';
}

function goNotif(page, bid, key) {
    if (!_seen.includes(key)) { _seen.push(key); localStorage.setItem(SEEN_KEY, JSON.stringify(_seen)); }
    window.location.href = page + '?booking_id=' + bid;
}

function markAllRead() {
    _seen = _notifData.map(b => b.booking_id+'_'+b.booking_status);
    localStorage.setItem(SEEN_KEY, JSON.stringify(_seen));
    renderNotifs(); updateBadge();
}

function timeAgo(iso) {
    if (!iso) return '';
    const s = Math.floor((Date.now() - new Date(iso))/1000);
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s/60)+'m ago';
    if (s < 86400) return Math.floor(s/3600)+'h ago';
    return Math.floor(s/86400)+'d ago';
}

function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function openLogout() { document.getElementById('logout-overlay').classList.add('open'); }

document.addEventListener('click', function(e) {
    const panel = document.getElementById('notif-panel');
    const btn   = document.getElementById('notif-bell-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        _notifOpen = false; panel.classList.remove('open'); clearInterval(_notifTimer);
    }
});

document.addEventListener('DOMContentLoaded', () => { if (CUSTOMER_ID) fetchNotifs(); });
</script>

<div class="logout-overlay" id="logout-overlay" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="logout-modal">
        <div class="logout-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </div>
        <div class="logout-modal-title">Log out?</div>
        <div class="logout-modal-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-modal-btns">
            <button class="logout-cancel-btn" onclick="document.getElementById('logout-overlay').classList.remove('open')">Cancel</button>
            <button class="logout-confirm-btn" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{ once:true });
      a.addEventListener('touchstart',function(){ prerender(href); },{ once:true, passive:true });
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{ once:true });
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
<?php include 'passenger_chat_widget.php'; ?>
</body>
</html>