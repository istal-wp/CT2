<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$host = 'localhost';
$dbname = 'coretransaction2';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));

    $response = [
        'success' => true,
        'timestamp' => date('Y-m-d H:i:s'),
        'data' => []
    ];

    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM core_bookings 
        WHERE DATE(booking_date) = :today
    ");
    $stmt->execute(['today' => $today]);
    $todayBookings = $stmt->fetch()['count'];

    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM core_bookings 
        WHERE DATE(booking_date) = :yesterday
    ");
    $stmt->execute(['yesterday' => $yesterday]);
    $yesterdayBookings = $stmt->fetch()['count'];

    $bookingChange = $yesterdayBookings > 0 
        ? round((($todayBookings - $yesterdayBookings) / $yesterdayBookings) * 100, 1)
        : 0;

    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(total_amount), 0) as revenue 
        FROM core_bookings 
        WHERE DATE(booking_date) = :today 
        AND payment_status = 'Paid'
    ");
    $stmt->execute(['today' => $today]);
    $totalRevenue = $stmt->fetch()['revenue'];

    $stmt = $pdo->query("
        SELECT COUNT(*) as count 
        FROM core_trips 
        WHERE trip_status IN ('Scheduled', 'In Progress')
    ");
    $activeTrips = $stmt->fetch()['count'];

    $stmt = $pdo->query("
        SELECT COALESCE(AVG(rating_value), 0) as avg_rating 
        FROM core_ratings 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $avgRating = round($stmt->fetch()['avg_rating'], 1);

    $response['data']['quickStats'] = [
        'todayBookings' => (int)$todayBookings,
        'bookingChange' => $bookingChange,
        'totalRevenue' => number_format($totalRevenue, 2, '.', ''),
        'activeTrips' => (int)$activeTrips,
        'avgRating' => $avgRating
    ];

    $stmt = $pdo->query("
        SELECT 
            SUM(CASE WHEN booking_status = 'Pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN booking_status = 'Confirmed' THEN 1 ELSE 0 END) as confirmed,
            SUM(CASE WHEN booking_status = 'Completed' THEN 1 ELSE 0 END) as completed
        FROM core_bookings
        WHERE DATE(booking_date) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    ");
    $bookingStats = $stmt->fetch();

    $response['data']['bookingModule'] = [
        'pending' => (int)$bookingStats['pending'],
        'confirmed' => (int)$bookingStats['confirmed'],
        'completed' => (int)$bookingStats['completed']
    ];

    $stmt = $pdo->query("
        SELECT 
            COALESCE(SUM(amount), 0) as total_payments,
            SUM(CASE WHEN payment_status = 'Captured' THEN 1 ELSE 0 END) as paid_count,
            SUM(CASE WHEN payment_status = 'Pending' THEN 1 ELSE 0 END) as pending_count
        FROM core_payment_authorization
        WHERE DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    ");
    $paymentStats = $stmt->fetch();

    $response['data']['paymentModule'] = [
        'totalPayments' => number_format($paymentStats['total_payments'] / 1000, 1, '.', '') . 'K',
        'paidCount' => (int)$paymentStats['paid_count'],
        'pendingPayments' => (int)$paymentStats['pending_count']
    ];

    $stmt = $pdo->query("
        SELECT 
            (SELECT COUNT(*) FROM core_customers WHERE status = 'Active') as total_customers,
            (SELECT COUNT(*) FROM core_ratings) as total_ratings,
            (SELECT COUNT(*) FROM core_reports WHERE status = 'Open') as open_reports
    ");
    $crmStats = $stmt->fetch();

    $response['data']['crmModule'] = [
        'totalCustomers' => (int)$crmStats['total_customers'],
        'totalRatings' => (int)$crmStats['total_ratings'],
        'openReports' => (int)$crmStats['open_reports']
    ];

    $stmt = $pdo->query("
        SELECT 
            (SELECT COUNT(DISTINCT vehicle_id) FROM core_trips WHERE trip_status = 'In Progress') as active_vehicles,
            (SELECT COALESCE(SUM(distance), 0) FROM core_trips WHERE DATE(start_time) = CURDATE()) as total_distance,
            (SELECT COUNT(*) FROM core_gps_points WHERE DATE(timestamp) = CURDATE()) as gps_points
    ");
    $gpsStats = $stmt->fetch();

    $response['data']['gpsModule'] = [
        'activeVehicles' => (int)$gpsStats['active_vehicles'],
        'totalDistance' => number_format($gpsStats['total_distance'], 0),
        'gpsPoints' => number_format($gpsStats['gps_points'] / 1000, 1, '.', '') . 'K'
    ];

    $stmt = $pdo->query("
        SELECT 
            COALESCE(AVG(CASE WHEN total_trips > 0 THEN (total_trips / (total_trips + 1)) * 100 END), 0) as vehicle_performance,
            (SELECT COALESCE(AVG(on_time_percentage), 0) FROM core_driver_performance WHERE metric_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)) as on_time_percent
        FROM core_vehicle_performance
        WHERE metric_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    ");
    $analyticsStats = $stmt->fetch();

    $response['data']['analyticsModule'] = [
        'vehiclePerformance' => round($analyticsStats['vehicle_performance'], 0),
        'driverPerformance' => 88, 
        'onTimePercent' => round($analyticsStats['on_time_percent'], 0)
    ];

    $stmt = $pdo->query("
        SELECT 
            (SELECT COUNT(*) FROM core_sop_documents WHERE status = 'Active') as sop_documents,
            (SELECT COALESCE(AVG(compliance_score), 0) FROM core_sop_compliance_checks WHERE check_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)) as compliance_rate,
            (SELECT COUNT(*) FROM core_compliance_issues WHERE status = 'Open') as open_issues
    ");
    $complianceStats = $stmt->fetch();

    $response['data']['complianceModule'] = [
        'sopDocuments' => (int)$complianceStats['sop_documents'],
        'complianceRate' => round($complianceStats['compliance_rate'], 0),
        'openIssues' => (int)$complianceStats['open_issues']
    ];

    $stmt = $pdo->prepare("
        SELECT 
            b.booking_reference,
            b.booking_status,
            b.total_amount,
            c.name as customer_name,
            b.booking_date,
            b.booking_time
        FROM core_bookings b
        LEFT JOIN core_customers c ON b.customer_id = c.customer_id
        WHERE DATE(b.booking_date) = :today
        ORDER BY b.created_at DESC
        LIMIT 10
    ");
    $stmt->execute(['today' => $today]);
    $recentBookings = $stmt->fetchAll();

    $response['data']['recentActivities'] = [
        'bookings' => $recentBookings
    ];

    echo json_encode($response, JSON_PRETTY_PRINT);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database connection failed',
        'message' => $e->getMessage()
    ], JSON_PRETTY_PRINT);
}
?>