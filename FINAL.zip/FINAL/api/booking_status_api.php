<?php

session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

require_once __DIR__ . '/../config/database.php'; 

$booking_id  = (int)($_GET['booking_id'] ?? 0);
$customer_id = (int)$_SESSION['customer_id'];

if (!$booking_id) {
    echo json_encode(['error' => 'Invalid booking_id']);
    exit;
}

try {
    $pdo = getDatabaseConnection();

    $stmt = $pdo->prepare("
        SELECT
            b.booking_id,
            b.booking_status,
            b.booking_reference,
            b.total_amount,
            r.driver_id,
            r.vehicle_id,
            r.ride_status,
            d.full_name   AS driver_name,
            d.contact_number AS driver_contact,
            v.make_model  AS vehicle_model,
            v.plate_number,
            v.vehicle_type,
            dl.latitude   AS driver_lat,
            dl.longitude  AS driver_lng,
            dl.updated_at AS location_updated
        FROM core_bookings b
        LEFT JOIN core_rides r        ON r.booking_id  = b.booking_id
        LEFT JOIN core_drivers d      ON d.driver_id   = r.driver_id AND r.driver_id > 0
        LEFT JOIN core_vehicles v     ON v.vehicle_id  = r.vehicle_id
        LEFT JOIN core_driver_locations dl ON dl.driver_id = r.driver_id
        WHERE b.booking_id  = :bid
          AND b.customer_id = :cid
        LIMIT 1
    ");
    $stmt->execute([':bid' => $booking_id, ':cid' => $customer_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode(['error' => 'Booking not found']);
        exit;
    }

    $vehicle = trim(($row['vehicle_model'] ?? '') . ' ' . ($row['plate_number'] ?? ''));

    echo json_encode([
        'status'           => $row['booking_status'],
        'ride_status'      => $row['ride_status'],
        'driver_name'      => $row['driver_name'] ?? null,
        'driver_contact'   => $row['driver_contact'] ?? null,
        'vehicle'          => $vehicle ?: null,
        'vehicle_type'     => $row['vehicle_type'] ?? null,
        'driver_lat'       => $row['driver_lat'] ?? null,
        'driver_lng'       => $row['driver_lng'] ?? null,
        'location_updated' => $row['location_updated'] ?? null,
    ]);

} catch (Exception $e) {
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}