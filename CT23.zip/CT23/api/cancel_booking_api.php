<?php
/**
 * cancel_booking_api.php
 * Passenger cancels their own Pending booking.
 * Place in: C:\xampp\htdocs\CORETRANSACTION2\passenger\
 */
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once __DIR__ . '/../config/database.php'; // api/ → ../config/

$booking_id  = (int)($_POST['booking_id'] ?? 0);
$customer_id = (int)$_SESSION['customer_id'];

if (!$booking_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid booking']);
    exit;
}

try {
    $pdo = getDatabaseConnection();

    // Only allow cancel if Pending
    $check = $pdo->prepare("SELECT booking_status FROM core_bookings WHERE booking_id=? AND customer_id=?");
    $check->execute([$booking_id, $customer_id]);
    $row = $check->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode(['success' => false, 'message' => 'Booking not found']);
        exit;
    }
    if ($row['booking_status'] !== 'Pending') {
        echo json_encode(['success' => false, 'message' => 'Only pending bookings can be cancelled by passenger']);
        exit;
    }

    $pdo->beginTransaction();

    $pdo->prepare("
        UPDATE core_bookings
        SET booking_status='Cancelled', cancelled_by=?, cancelled_at=NOW(), cancellation_reason='Cancelled by passenger', updated_at=NOW()
        WHERE booking_id=?
    ")->execute([$customer_id, $booking_id]);

    $pdo->prepare("
        UPDATE core_rides SET ride_status='Cancelled' WHERE booking_id=?
    ")->execute([$booking_id]);

    $pdo->prepare("
        INSERT INTO core_booking_history (booking_id, change_type, field_changed, old_value, new_value, changed_by, notes)
        VALUES (?, 'Status Change', 'booking_status', 'Pending', 'Cancelled', ?, 'Cancelled by passenger')
    ")->execute([$booking_id, $customer_id]);

    $pdo->commit();

    echo json_encode(['success' => true]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}