<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit;
}

define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json']]);
    $resp = curl_exec($ch); curl_close($ch);
    $data = json_decode($resp, true);
    return is_array($data) ? $data : [];
}
function sb_post(string $table, array $body): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($body),CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json','Prefer: return=representation']]);
    $resp = curl_exec($ch); curl_close($ch);
    $data = json_decode($resp, true);
    return is_array($data) ? $data : [];
}
function sb_patch(string $table, array $filters, array $body): bool {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'PATCH',CURLOPT_POSTFIELDS=>json_encode($body),CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json','Prefer: return=minimal']]);
    $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return $code >= 200 && $code < 300;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    try {
        switch ($_POST['action']) {

            case 'get_all_bookings':
                $status = $_POST['status'] ?? 'all';
                $params = ['select'=>'booking_id,booking_reference,booking_status,booking_date,booking_time,total_amount,payment_status,special_requirements,created_at,customer_id,service_id','order'=>'created_at.desc','limit'=>'200'];
                if ($status !== 'all') {
                    $statuses = explode(',', $status);
                    $params['booking_status'] = 'in.('.implode(',', $statuses).')';
                }
                $bookings = sb_get('core2_bookings', $params);
                foreach ($bookings as &$b) {
                    $cust = sb_get('core2_customers', ['customer_id'=>'eq.'.$b['customer_id'],'select'=>'name,phone,email']);
                    $b['customer_name']  = $cust[0]['name']  ?? 'Guest';
                    $b['customer_phone'] = $cust[0]['phone'] ?? '';
                    $b['customer_email'] = $cust[0]['email'] ?? '';
                    $svc = sb_get('core2_services', ['service_id'=>'eq.'.$b['service_id'],'select'=>'service_name,unit_price']);
                    $b['service_name'] = $svc[0]['service_name'] ?? 'N/A';
                    $b['unit_price']   = $svc[0]['unit_price']   ?? 0;
                    $ride = sb_get('core2_rides', ['booking_id'=>'eq.'.$b['booking_id'],'select'=>'ride_id,start_location,end_location,ride_status,start_time,end_time']);
                    $b['pickup_location']  = $ride[0]['start_location'] ?? '';
                    $b['dropoff_location'] = $ride[0]['end_location']   ?? '';
                    $b['ride_status']      = $ride[0]['ride_status']    ?? '';
                    $b['start_time']       = $ride[0]['start_time']     ?? '';
                    $b['end_time']         = $ride[0]['end_time']       ?? '';
                    $b['driver_name']      = null;
                    $b['driver_id']        = null;
                }
                echo json_encode(['success'=>true,'bookings'=>$bookings]);
                break;

            case 'update_booking_status':
                $bid    = $_POST['booking_id'];
                $status = $_POST['status'];
                $now    = date('c');
                $body   = ['booking_status'=>$status];
                if ($status==='Confirmed') $body['confirmed_at'] = $now;
                $ok = sb_patch('core2_bookings', ['booking_id'=>'eq.'.$bid], $body);
                if ($ok && $status==='In Progress') {
                    $ride = sb_get('core2_rides', ['booking_id'=>'eq.'.$bid,'select'=>'ride_id']);
                    if (!empty($ride)) {
                        sb_patch('core2_rides', ['booking_id'=>'eq.'.$bid], ['ride_status'=>'In Progress','start_time'=>$now]);
                    } else {
                        $bk = sb_get('core2_bookings', ['booking_id'=>'eq.'.$bid,'select'=>'customer_id']);
                        sb_post('core2_rides', ['booking_id'=>(int)$bid,'customer_id'=>$bk[0]['customer_id']??null,'start_time'=>$now,'start_location'=>'GPS: Auto-tracking','ride_status'=>'In Progress']);
                    }
                }
                if ($ok && $status==='Completed')
                    sb_patch('core2_rides', ['booking_id'=>'eq.'.$bid], ['ride_status'=>'Completed','end_time'=>$now,'end_location'=>'GPS: Final location']);
                sb_post('core2_booking_history', ['booking_id'=>(int)$bid,'change_type'=>'Status Change','changed_by'=>$_SESSION['user_id']??null,'notes'=>'Admin updated status to: '.$status,'changed_at'=>$now]);
                $labels = ['In Progress'=>'Trip started','Completed'=>'Trip completed','Confirmed'=>'Booking confirmed'];
                echo json_encode(['success'=>$ok,'message'=>$labels[$status]??'Status updated']);
                break;

            case 'cancel_booking':
                $bid    = $_POST['booking_id'];
                $reason = $_POST['reason'] ?? '';
                $now    = date('c');
                $ok = sb_patch('core2_bookings', ['booking_id'=>'eq.'.$bid], ['booking_status'=>'Cancelled','cancellation_reason'=>$reason,'cancelled_at'=>$now]);
                sb_patch('core2_rides', ['booking_id'=>'eq.'.$bid], ['ride_status'=>'Cancelled']);
                sb_post('core2_booking_history', ['booking_id'=>(int)$bid,'change_type'=>'Cancelled','changed_by'=>$_SESSION['user_id']??null,'notes'=>'Admin cancelled. Reason: '.$reason,'changed_at'=>$now]);
                echo json_encode(['success'=>$ok,'message'=>'Booking cancelled']);
                break;

            case 'edit_booking':
                $bid  = $_POST['booking_id'];
                $body = [];
                $now  = date('c');
                if (!empty($_POST['booking_date']))          $body['booking_date']          = $_POST['booking_date'];
                if (!empty($_POST['booking_time']))          $body['booking_time']          = $_POST['booking_time'];
                if (!empty($_POST['special_requirements']))  $body['special_requirements']  = $_POST['special_requirements'];
                if (!empty($_POST['payment_status']))        $body['payment_status']        = $_POST['payment_status'];
                if (!empty($_POST['service_id'])) {
                    $body['service_id'] = (int)$_POST['service_id'];
                    $svc = sb_get('core2_services', ['service_id'=>'eq.'.$_POST['service_id'],'select'=>'unit_price']);
                    if (!empty($svc)) $body['total_amount'] = $svc[0]['unit_price'];
                }
                $ok = !empty($body) ? sb_patch('core2_bookings', ['booking_id'=>'eq.'.$bid], $body) : true;
                if (!empty($_POST['pickup_location']) || !empty($_POST['dropoff_location'])) {
                    $rb = [];
                    if (!empty($_POST['pickup_location']))  $rb['start_location'] = $_POST['pickup_location'];
                    if (!empty($_POST['dropoff_location'])) $rb['end_location']   = $_POST['dropoff_location'];
                    sb_patch('core2_rides', ['booking_id'=>'eq.'.$bid], $rb);
                }
                sb_post('core2_booking_history', ['booking_id'=>(int)$bid,'change_type'=>'Modified','changed_by'=>$_SESSION['user_id']??null,'notes'=>'Admin updated booking details','changed_at'=>$now]);
                echo json_encode(['success'=>true,'message'=>'Booking updated successfully']);
                break;

            case 'get_booking_details':
                $bid = $_POST['booking_id'];
                $bk  = sb_get('core2_bookings', ['booking_id'=>'eq.'.$bid,'select'=>'*']);
                if (empty($bk)) { echo json_encode(['success'=>false,'message'=>'Booking not found']); break; }
                $b = $bk[0];
                $cust = sb_get('core2_customers', ['customer_id'=>'eq.'.$b['customer_id'],'select'=>'name,phone,email']);
                $b['customer_name']  = $cust[0]['name']  ?? 'Guest';
                $b['customer_phone'] = $cust[0]['phone'] ?? '';
                $b['customer_email'] = $cust[0]['email'] ?? '';
                $svc = sb_get('core2_services', ['service_id'=>'eq.'.$b['service_id'],'select'=>'service_name,unit_price']);
                $b['service_name'] = $svc[0]['service_name'] ?? 'N/A';
                $ride = sb_get('core2_rides', ['booking_id'=>'eq.'.$bid,'select'=>'start_location,end_location,ride_status,start_time,end_time']);
                $b['pickup_location']  = $ride[0]['start_location'] ?? '';
                $b['dropoff_location'] = $ride[0]['end_location']   ?? '';
                $b['ride_status']      = $ride[0]['ride_status']    ?? '';
                $b['start_time']       = $ride[0]['start_time']     ?? '';
                $b['end_time']         = $ride[0]['end_time']       ?? '';
                $b['driver_name']      = null;
                $history = sb_get('core2_booking_history', ['booking_id'=>'eq.'.$bid,'order'=>'changed_at.desc','select'=>'change_type,notes,changed_at,changed_by','limit'=>'20']);
                echo json_encode(['success'=>true,'booking'=>$b,'history'=>$history]);
                break;

            default:
                echo json_encode(['success'=>false,'message'=>'Invalid action']);
        }
    } catch (Exception $e) {
        echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
    }
    exit;
}

$services_raw = sb_get('core2_services', ['status'=>'eq.Active','select'=>'service_id,service_name,unit_price','order'=>'service_name.asc']);
$bookings_raw = sb_get('core2_bookings', ['select'=>'booking_id,booking_reference,booking_status,booking_date,booking_time,total_amount,payment_status,special_requirements,created_at,customer_id,service_id','order'=>'created_at.desc','limit'=>'200']);

$allBookings = [];
foreach ($bookings_raw as $b) {
    $cust = sb_get('core2_customers', ['customer_id'=>'eq.'.$b['customer_id'],'select'=>'name,phone,email']);
    $b['customer_name']  = $cust[0]['name']  ?? 'Guest';
    $b['customer_phone'] = $cust[0]['phone'] ?? '';
    $b['customer_email'] = $cust[0]['email'] ?? '';
    $svc = sb_get('core2_services', ['service_id'=>'eq.'.$b['service_id'],'select'=>'service_name,unit_price']);
    $b['service_name'] = $svc[0]['service_name'] ?? 'N/A';
    $b['unit_price']   = $svc[0]['unit_price']   ?? 0;
    $ride = sb_get('core2_rides', ['booking_id'=>'eq.'.$b['booking_id'],'select'=>'start_location,end_location,ride_status,start_time,end_time']);
    $b['pickup_location']  = $ride[0]['start_location'] ?? '';
    $b['dropoff_location'] = $ride[0]['end_location']   ?? '';
    $b['ride_status']      = $ride[0]['ride_status']    ?? '';
    $b['start_time']       = $ride[0]['start_time']     ?? '';
    $b['end_time']         = $ride[0]['end_time']       ?? '';
    $b['driver_name']      = null;
    $b['driver_id']        = null;
    $allBookings[] = $b;
}

$cnt_pending   = count(array_filter($allBookings, fn($b)=>$b['booking_status']==='Pending'));
$cnt_confirmed = count(array_filter($allBookings, fn($b)=>$b['booking_status']==='Confirmed'));
$cnt_active    = count(array_filter($allBookings, fn($b)=>$b['booking_status']==='In Progress'));
$cnt_completed = count(array_filter($allBookings, fn($b)=>$b['booking_status']==='Completed'));
$cnt_cancelled = count(array_filter($allBookings, fn($b)=>$b['booking_status']==='Cancelled'));
$total_rev     = array_sum(array_map(fn($b)=>$b['booking_status']==='Completed'?(float)($b['total_amount']??0):0, $allBookings));

$userName    = htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin');
$userInitial = strtoupper(substr($userName, 0, 1));

function ico($path,$stroke='#4A5568',$size=18){return "<svg width='$size' height='$size' viewBox='0 0 24 24' fill='none' stroke='$stroke' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>$path</svg>";}
$iBook  ="<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>";
$iPay   ="<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iCrm   ="<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iGps   ="<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/>";
$iBar   ="<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>";
$iDoc   ="<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/><line x1='16' y1='13' x2='8' y2='13'/><line x1='16' y1='17' x2='8' y2='17'/>";
$iHome  ="<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>";
$iOut   ="<path d='M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'/><polyline points='16 17 21 12 16 7'/><line x1='21' y1='12' x2='9' y2='12'/>";
$iCheck ="<polyline points='20 6 9 17 4 12'/>";
$iX     ="<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>";
$iInfo  ="<circle cx='12' cy='12' r='10'/><line x1='12' y1='8' x2='12' y2='12'/><line x1='12' y1='16' x2='12.01' y2='16'/>";
$iEdit  ="<path d='M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7'/><path d='M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z'/>";
$iRefresh="<path d='M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2'/>";
$iTruck ="<rect x='1' y='3' width='15' height='13'/><polygon points='16 8 20 8 23 11 23 16 16 16 16 8'/><circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/>";
$iUser  ="<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>";
$iBack  ="<path d='M19 12H5M12 19l-7-7 7-7'/>";
$iClock ="<circle cx='12' cy='12' r='10'/><polyline points='12 6 12 12 16 14'/>";
$iSearch="<circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/>";
$iDownload="<path d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'/><polyline points='7 10 12 15 17 10'/><line x1='12' y1='15' x2='12' y2='3'/>";
$iFilter="<polygon points='22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3'/>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%}
:root{
  --g:#00D084;--gd:#00A86B;--gx:#005A38;--gg:rgba(0,208,132,.1);
  --bg:#F0F4F2;--surf:#fff;--surf2:#F7FAF8;--surf3:#EEF5F1;
  --bdr:#DDE8E2;--bdr2:#C8DDD5;
  --txt:#0D1F18;--txt2:#3A5248;--txt3:#7A9A8E;--txt4:#B0C8BC;
  --blue:#3B8EF0;--purple:#8B6FE8;--orange:#F07830;--red:#E84040;--yellow:#E8A020;
  --sb-bg:#991B1B;--sb-txt:#FECACA;--sb-txt2:#FCA5A5;
  --sb-bdr:rgba(255,255,255,.1);--sb-hover:rgba(255,255,255,.09);
  --sb-active:rgba(255,255,255,.16);--sb-active-bdr:rgba(255,255,255,.28);
  --sw:248px;--th:58px;--r:16px;--rs:10px;
  --shadow:0 1px 3px rgba(0,0,0,.04),0 4px 16px rgba(0,0,0,.06);
  --shadow-md:0 2px 8px rgba(0,0,0,.05),0 8px 28px rgba(0,0,0,.09);
}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--txt);-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit}
.trunc{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mono{font-family:'DM Mono',monospace}
.badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:3px 8px;border-radius:5px;text-transform:uppercase;letter-spacing:.4px}
.badge::before{content:'';width:5px;height:5px;border-radius:50%;flex-shrink:0}
.badge-green{background:rgba(0,208,132,.12);color:#008A58}.badge-green::before{background:#00A86B}
.badge-blue{background:rgba(59,142,240,.1);color:#1966C2}.badge-blue::before{background:#3B8EF0}
.badge-yellow{background:rgba(232,160,32,.12);color:#9A6A00}.badge-yellow::before{background:#E8A020}
.badge-red{background:rgba(232,64,64,.1);color:#C22020}.badge-red::before{background:#E84040}
.badge-purple{background:rgba(139,111,232,.1);color:#5A3FBB}.badge-purple::before{background:#8B6FE8}

@media(min-width:900px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}
  .sidebar{width:var(--sw);flex-shrink:0;height:100vh;display:flex;flex-direction:column;background:var(--sb-bg);overflow:hidden;box-shadow:3px 0 18px rgba(153,27,27,.22)}
  .sb-logo{height:var(--th);display:flex;align-items:center;gap:10px;padding:0 18px;border-bottom:1px solid var(--sb-bdr);flex-shrink:0}
  .sb-logo img{height:26px;filter:brightness(0) invert(1)}
  .sb-brand{font-size:16px;font-weight:800;letter-spacing:-.3px;color:#fff}.sb-brand span{color:#FCA5A5}
  .sb-nav{flex:1;overflow-y:auto;padding:12px 10px;display:flex;flex-direction:column;gap:1px}
  .sb-label{font-size:9.5px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:var(--sb-txt2);padding:14px 10px 5px}
  .sb-item{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:9px;cursor:pointer;color:rgba(255,255,255,.75);font-size:13px;font-weight:500;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover);color:#fff}
  .sb-item.active{background:var(--sb-active);color:#fff;border-color:var(--sb-active-bdr);font-weight:600}
  .sb-ico{width:30px;height:30px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item:hover .sb-ico,.sb-item.active .sb-ico{background:rgba(255,255,255,.16)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-foot{padding:12px 10px;border-top:1px solid var(--sb-bdr);flex-shrink:0;display:flex;gap:8px;align-items:center}
  .sb-av{width:34px;height:34px;border-radius:9px;flex-shrink:0;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;border:1px solid rgba(255,255,255,.28)}
  .sb-uname{font-size:12.5px;font-weight:600;color:#fff}
  .sb-urole{font-size:11px;color:var(--sb-txt2)}
  .sb-out{margin-left:auto;width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s}
  .sb-out:hover{background:rgba(239,68,68,.3)}
  .sb-out svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:var(--th);flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 24px;gap:12px}
  .tb-title{flex:1;font-size:16px;font-weight:800;letter-spacing:-.2px}
  .tb-date{font-size:12px;color:var(--txt3);font-weight:500}
  .tb-sep{width:1px;height:18px;background:var(--bdr)}
  .tb-btn{height:34px;padding:0 14px;border-radius:8px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12.5px;font-weight:600;color:var(--txt2);transition:all .15s}
  .tb-btn:hover{background:var(--bg)}
  .tb-btn svg{stroke:var(--txt3)!important}
  .scroll{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:16px}
  .scroll::-webkit-scrollbar{width:0px;background:transparent}
  .scroll{scrollbar-width:none;-ms-overflow-style:none}

  .kpi-row{display:grid;grid-template-columns:repeat(6,1fr);gap:11px}
  .kpi{background:var(--surf);border-radius:14px;padding:14px 16px;border:1px solid var(--bdr);transition:all .2s;animation:fadeUp .3s ease both}
  .kpi:hover{box-shadow:var(--shadow);transform:translateY(-1px)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
  .kpi-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-num{font-size:10px;font-weight:700;padding:2px 7px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:26px;font-weight:800;line-height:1;margin-bottom:3px;letter-spacing:-.5px}
  .kpi-val .sign{font-size:14px;font-weight:600;vertical-align:top;margin-top:4px;display:inline-block}
  .kpi-lbl{font-size:11px;color:var(--txt3);font-weight:500}

  .tool-bar{display:flex;align-items:center;gap:10px;background:var(--surf);border-radius:14px;padding:12px 16px;border:1px solid var(--bdr)}
  .search-wrap{position:relative;flex:1;max-width:320px}
  .search-ico{position:absolute;left:10px;top:50%;transform:translateY(-50%);pointer-events:none}
  .search-box{width:100%;height:34px;padding:0 12px 0 34px;border-radius:8px;border:1px solid var(--bdr);background:var(--surf2);font-size:12.5px;font-family:'DM Sans',sans-serif;color:var(--txt);transition:all .2s}
  .search-box:focus{outline:none;border-color:var(--g);background:var(--surf)}
  .tabs-bar{display:flex;gap:2px;background:var(--surf2);border-radius:9px;padding:3px;border:1px solid var(--bdr)}
  .tab-btn{padding:6px 14px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s;white-space:nowrap;display:flex;align-items:center;gap:5px}
  .tab-btn.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .tab-badge{font-size:10px;background:rgba(0,0,0,.08);color:var(--txt3);padding:1px 6px;border-radius:10px;font-weight:700}
  .tab-btn.active .tab-badge{background:rgba(0,208,132,.15);color:var(--gd)}
  .filter-sep{width:1px;height:20px;background:var(--bdr)}
  .view-btn{height:34px;padding:0 12px;border-radius:8px;border:1px solid var(--bdr);background:none;cursor:pointer;display:flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:var(--txt3);transition:all .15s}
  .view-btn.active{background:var(--surf3);color:var(--txt);border-color:var(--bdr2)}
  .view-btn svg{stroke:var(--txt3)!important}

  .panel{background:var(--surf);border-radius:var(--r);border:1px solid var(--bdr);overflow:hidden;animation:fadeUp .35s ease}
  .tbl-wrap{overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 280px)}
  table{width:100%;border-collapse:collapse;font-size:12.5px}
  thead tr{background:var(--surf2);position:sticky;top:0;z-index:2}
  thead th{padding:9px 14px;text-align:left;font-size:10.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  tbody tr{border-bottom:1px solid var(--bdr);transition:background .12s;cursor:pointer}
  tbody tr:last-child{border-bottom:none}
  tbody tr:hover{background:var(--surf2)}
  tbody td{padding:10px 14px;vertical-align:middle}
  .td-amt{font-weight:700;font-size:13px;color:var(--gd)}
  .td-muted{color:var(--txt3);font-size:11.5px}
  .td-ref{font-weight:700;font-size:13px;color:var(--txt)}
  .td-customer{font-weight:600;font-size:12.5px}
  .td-sub{font-size:11px;color:var(--txt3);margin-top:1px}
  .empty-row td{text-align:center;padding:48px;color:var(--txt3)}

  .card-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:12px;padding:16px}
  .bk-card{background:var(--surf);border-radius:14px;border:1px solid var(--bdr);overflow:hidden;transition:all .2s;cursor:pointer}
  .bk-card:hover{box-shadow:var(--shadow);border-color:var(--bdr2);transform:translateY(-1px)}
  .bc-head{padding:12px 14px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .bc-ref{font-size:13px;font-weight:800}
  .bc-body{padding:12px 14px}
  .bc-row{display:flex;gap:8px;align-items:flex-start;margin-bottom:7px;font-size:12.5px}
  .bc-row:last-child{margin:0}
  .bc-lbl{width:62px;font-size:11px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .bc-val{color:var(--txt2);font-weight:500;flex:1}
  .bc-foot{padding:10px 14px;border-top:1px solid var(--bdr);display:flex;gap:6px;flex-wrap:wrap}

  .btn{padding:7px 13px;border-radius:8px;font-size:11.5px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
  .btn:active{transform:scale(.97)}
  .btn-sm{padding:6px 11px;font-size:11px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-success:hover{box-shadow:0 4px 12px rgba(0,208,132,.3)}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-info:hover{box-shadow:0 4px 12px rgba(96,165,250,.25)}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-danger:hover{box-shadow:0 4px 12px rgba(232,64,64,.3)}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-ghost:hover{background:var(--bg)}
  .btn svg{pointer-events:none}

  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(4px);z-index:1000;align-items:center;justify-content:center;padding:20px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:20px;max-width:580px;width:100%;max-height:86vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:var(--shadow-md)}
  .modal-wide{max-width:720px}
  .modal-hdr{padding:18px 22px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s}
  .modal-close:hover{background:var(--bg)}
  .modal-body{padding:20px 22px;overflow-y:auto;flex:1}
  .modal-foot{padding:14px 22px;border-top:1px solid var(--bdr);display:flex;gap:8px;flex-shrink:0}
  .form-group{margin-bottom:14px}
  .form-label{display:block;font-size:11.5px;font-weight:600;color:var(--txt2);margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:10px 13px;font-size:13px;border:1.5px solid var(--bdr);border-radius:9px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif;transition:all .2s}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:var(--g);background:var(--surf);box-shadow:0 0 0 3px rgba(0,208,132,.08)}
  .form-textarea{resize:vertical;min-height:80px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .section-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:10px}
  .d-row{display:flex;align-items:flex-start;padding:8px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:130px;font-size:11.5px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .d-val{font-size:13px;color:var(--txt);font-weight:500;flex:1}

  .toast{position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:#0D5F3A;color:#fff;padding:11px 16px;border-radius:10px;font-size:13px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:9px;animation:toastIn .3s ease;max-width:320px}
  .toast-item.error{background:#5F1313;border-left:3px solid var(--red)}
  .toast-item.success{border-left:3px solid var(--g)}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  @keyframes toastOut{from{opacity:1}to{opacity:0;transform:translateX(20px)}}

  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:16px;padding:26px 34px;text-align:center;box-shadow:var(--shadow-md)}
  .spinner{width:42px;height:42px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
  .kpi:nth-child(1){animation-delay:.03s}
  .kpi:nth-child(2){animation-delay:.06s}
  .kpi:nth-child(3){animation-delay:.09s}
  .kpi:nth-child(4){animation-delay:.12s}
  .kpi:nth-child(5){animation-delay:.15s}
  .kpi:nth-child(6){animation-delay:.18s}
}

@media(min-width:768px) and (max-width:899px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}
  .sidebar{width:58px;height:100vh;background:var(--sb-bg);display:flex;flex-direction:column;align-items:center;padding:10px 0;gap:3px;flex-shrink:0}
  .sb-logo{width:100%;height:52px;display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--sb-bdr);margin-bottom:6px}
  .sb-logo img{height:24px;filter:brightness(0) invert(1)}
  .sb-brand,.sb-label{display:none}
  .sb-nav{flex:1;width:100%;padding:4px 6px;display:flex;flex-direction:column;align-items:center;gap:2px}
  .sb-item{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover)}
  .sb-item.active{background:var(--sb-active);border-color:var(--sb-active-bdr)}
  .sb-ico{width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-item.active .sb-ico{background:rgba(255,255,255,.18)}
  .sb-foot{padding:8px 6px;border-top:1px solid var(--sb-bdr);width:100%;display:flex;flex-direction:column;align-items:center;gap:5px}
  .sb-av{width:32px;height:32px;border-radius:8px;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:#fff}
  .sb-uname,.sb-urole{display:none}
  .sb-out{width:28px;height:28px;border-radius:7px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .sb-out svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:52px;flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 16px;gap:10px}
  .tb-title{flex:1;font-size:15px;font-weight:800}
  .tb-date{font-size:11px;color:var(--txt3)}
  .tb-sep{width:1px;height:16px;background:var(--bdr)}
  .tb-btn{height:30px;padding:0 11px;border-radius:7px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:5px;cursor:pointer;font-size:11.5px;font-weight:600;color:var(--txt2)}
  .scroll{flex:1;overflow-y:auto;padding:12px 14px;display:flex;flex-direction:column;gap:12px}
  .kpi-row{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .kpi{background:var(--surf);border-radius:12px;padding:13px 15px;border:1px solid var(--bdr)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:9px}
  .kpi-ico{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-num{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:22px;font-weight:800;line-height:1;margin-bottom:3px;letter-spacing:-.4px}
  .kpi-val .sign{font-size:13px;font-weight:600;vertical-align:top;margin-top:3px;display:inline-block}
  .kpi-lbl{font-size:10.5px;color:var(--txt3)}
  .tool-bar{display:flex;align-items:center;gap:8px;background:var(--surf);border-radius:12px;padding:10px 13px;border:1px solid var(--bdr);flex-wrap:wrap}
  .search-wrap{position:relative;flex:1}
  .search-ico{position:absolute;left:9px;top:50%;transform:translateY(-50%);pointer-events:none}
  .search-box{width:100%;height:32px;padding:0 10px 0 30px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);font-size:12px;font-family:'DM Sans',sans-serif;color:var(--txt)}
  .search-box:focus{outline:none;border-color:var(--g)}
  .tabs-bar{display:flex;gap:2px;background:var(--surf2);border-radius:8px;padding:2px;border:1px solid var(--bdr)}
  .tab-btn{padding:5px 11px;border-radius:6px;font-size:11.5px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s;display:flex;align-items:center;gap:4px}
  .tab-btn.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.07)}
  .tab-badge{font-size:9.5px;background:rgba(0,0,0,.07);color:var(--txt3);padding:1px 5px;border-radius:10px;font-weight:700}
  .tab-btn.active .tab-badge{background:rgba(0,208,132,.12);color:var(--gd)}
  .filter-sep{width:1px;height:18px;background:var(--bdr)}
  .panel{background:var(--surf);border-radius:13px;border:1px solid var(--bdr);overflow:hidden}
  .tbl-wrap{overflow-x:auto}
  table{width:100%;border-collapse:collapse;font-size:12px}
  thead tr{background:var(--surf2)}
  thead th{padding:8px 12px;text-align:left;font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  tbody tr{border-bottom:1px solid var(--bdr);transition:background .12s;cursor:pointer}
  tbody tr:last-child{border-bottom:none}
  tbody tr:hover{background:var(--surf2)}
  tbody td{padding:9px 12px;vertical-align:middle}
  .td-amt{font-weight:700;font-size:12.5px;color:var(--gd)}
  .td-muted{color:var(--txt3);font-size:11px}
  .td-ref{font-weight:700;font-size:12.5px}
  .td-customer{font-weight:600;font-size:12px}
  .td-sub{font-size:10.5px;color:var(--txt3);margin-top:1px}
  .empty-row td{text-align:center;padding:36px;color:var(--txt3)}
  .card-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:12px}
  .bk-card{background:var(--surf);border-radius:12px;border:1px solid var(--bdr);overflow:hidden;transition:all .2s;cursor:pointer}
  .bk-card:hover{box-shadow:var(--shadow)}
  .bc-head{padding:10px 12px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .bc-ref{font-size:12.5px;font-weight:800}
  .bc-body{padding:10px 12px}
  .bc-row{display:flex;gap:6px;align-items:flex-start;margin-bottom:6px;font-size:12px}
  .bc-row:last-child{margin:0}
  .bc-lbl{width:55px;font-size:10.5px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .bc-val{color:var(--txt2);font-weight:500;flex:1;font-size:11.5px}
  .bc-foot{padding:8px 12px;border-top:1px solid var(--bdr);display:flex;gap:5px;flex-wrap:wrap}
  .btn{padding:6px 11px;border-radius:7px;font-size:11px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:4px}
  .btn-sm{padding:5px 9px;font-size:10.5px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);z-index:1000;align-items:center;justify-content:center;padding:16px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:17px;max-width:540px;width:100%;max-height:86vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide{max-width:680px}
  .modal-hdr{padding:16px 20px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:14px;font-weight:800}
  .modal-close{width:27px;height:27px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:18px 20px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 20px;border-top:1px solid var(--bdr);display:flex;gap:7px}
  .form-group{margin-bottom:12px}
  .form-label{display:block;font-size:11px;font-weight:600;color:var(--txt2);margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:9px 12px;font-size:12.5px;border:1.5px solid var(--bdr);border-radius:8px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif;transition:all .2s}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:var(--g)}
  .form-textarea{resize:vertical;min-height:75px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .section-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:8px}
  .d-row{display:flex;align-items:flex-start;padding:7px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:120px;font-size:11px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .d-val{font-size:12.5px;color:var(--txt);font-weight:500;flex:1}
  .toast{position:fixed;bottom:18px;right:18px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:#0D5F3A;color:#fff;padding:10px 14px;border-radius:9px;font-size:12.5px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:8px;animation:toastIn .3s ease;max-width:280px}
  .toast-item.error{background:#5F1313}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:13px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  .view-btn,.filter-sep{display:none}
}

@media(max-width:767px){
  .sidebar,.desk-wrap{display:none!important}
  body{background:#EFF5F2;padding-bottom:80px}
  .mob-header{position:sticky;top:0;z-index:100;background:rgba(255,255,255,.9);backdrop-filter:blur(16px);border-bottom:1px solid rgba(0,0,0,.06);padding:12px 16px;display:flex;align-items:center;gap:10px}
  .mh-back{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mh-title{flex:1;font-size:16px;font-weight:800;text-align:center}
  .mh-btn{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mob-body{padding:14px 14px 18px;display:flex;flex-direction:column;gap:12px}
  .m-kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
  .mkpi{background:#fff;border-radius:13px;padding:12px 10px;border:1px solid #DDE8E2;text-align:center}
  .mkpi-v{font-size:22px;font-weight:800;line-height:1;color:#0D1F18}
  .mkpi-v.sign{font-size:14px;font-weight:600}
  .mkpi-l{font-size:10.5px;color:#7A9A8E;margin-top:3px}
  .m-filters{display:flex;gap:6px;overflow-x:auto;padding-bottom:4px}
  .m-filter-btn{padding:7px 14px;border-radius:20px;font-size:12px;font-weight:600;border:1.5px solid #DDE8E2;background:#fff;white-space:nowrap;cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:5px}
  .m-filter-btn.active{background:rgba(0,208,132,.1);border-color:rgba(0,208,132,.3);color:#008A58}
  .m-search{position:relative}
  .m-search input{width:100%;height:38px;padding:0 14px 0 36px;border-radius:12px;border:1.5px solid #DDE8E2;background:#fff;font-size:13px;font-family:'DM Sans',sans-serif;color:#0D1F18}
  .m-search input:focus{outline:none;border-color:#00D084}
  .m-search svg{position:absolute;left:10px;top:50%;transform:translateY(-50%);pointer-events:none}
  .m-bookings{display:flex;flex-direction:column;gap:10px}
  .m-bk{background:#fff;border-radius:16px;border:1.5px solid #DDE8E2;overflow:hidden}
  .mb-head{padding:11px 14px;border-bottom:1px solid #EEF5F1;display:flex;align-items:center;justify-content:space-between}
  .mb-ref{font-size:13.5px;font-weight:800;color:#0D1F18}
  .mb-body{padding:11px 14px;display:flex;flex-direction:column;gap:5px}
  .mb-row{display:flex;gap:6px;font-size:12.5px}
  .mb-lbl{font-size:11px;font-weight:600;color:#7A9A8E;width:55px;flex-shrink:0;padding-top:1px}
  .mb-val{color:#3A5248;font-weight:500;flex:1}
  .mb-foot{padding:9px 14px;border-top:1px solid #EEF5F1;display:flex;gap:6px;flex-wrap:wrap}
  .btn{padding:8px 13px;border-radius:9px;font-size:12px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:5px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:rgba(0,0,0,.04);color:#3A5248}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1000;align-items:flex-end;justify-content:center}
  .modal.open{display:flex}
  .modal-box{background:#fff;border-radius:22px 22px 0 0;width:100%;max-height:85vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide{max-height:92vh}
  .modal-hdr{padding:16px 18px;border-bottom:1px solid #DDE8E2;display:flex;align-items:center;justify-content:space-between}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid #DDE8E2;background:#F7FAF8;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:16px 18px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 18px;border-top:1px solid #DDE8E2;display:flex;gap:8px}
  .form-group{margin-bottom:13px}
  .form-label{display:block;font-size:11.5px;font-weight:600;color:#3A5248;margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:11px 13px;font-size:14px;border:1.5px solid #DDE8E2;border-radius:11px;background:#F7FAF8;color:#0D1F18;font-family:'DM Sans',sans-serif}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:#00D084}
  .form-textarea{resize:vertical;min-height:80px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .d-row{display:flex;padding:7px 0;border-bottom:1px solid #DDE8E2}
  .d-row:last-child{border:none}
  .d-label{width:110px;font-size:11.5px;font-weight:600;color:#7A9A8E;flex-shrink:0}
  .d-val{font-size:13px;color:#0D1F18;font-weight:500;flex:1}
  .section-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#7A9A8E;margin-bottom:8px}
  .mob-nav{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.96);backdrop-filter:blur(20px);border-top:1px solid rgba(0,0,0,.06);padding:8px 0 16px;display:grid;grid-template-columns:repeat(4,1fr);z-index:99}
  .mn{display:flex;flex-direction:column;align-items:center;gap:2px;padding:5px;cursor:pointer;border:none;background:none}
  .mn-ico{width:40px;height:26px;display:flex;align-items:center;justify-content:center}
  .mn-ico svg{stroke:#718096;opacity:.5}
  .mn.active .mn-ico svg{stroke:#00D084;opacity:1}
  .mn-lbl{font-size:10px;font-weight:600;color:#718096;opacity:.7}
  .mn.active .mn-lbl{color:#00D084;opacity:1}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:#fff;border-radius:16px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid #DDE8E2;border-top-color:#00D084;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  .mob-toast{position:fixed;bottom:88px;left:14px;right:14px;z-index:9999;display:flex;flex-direction:column;gap:8px}
  .mob-toast-item{background:#0D5F3A;color:#fff;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px;animation:toastIn .3s ease}
  .mob-toast-item.error{background:#5F1313}
  @keyframes toastIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  .m-empty{text-align:center;padding:44px 20px;background:#fff;border-radius:16px;border:1px solid #DDE8E2}
  .m-empty svg{margin:0 auto 12px;opacity:.2}
  .m-empty p{font-size:13px;color:#7A9A8E}
}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <img src="../images/envirocab_logo.png" alt="EC" onerror="this.style.display='none'">
  </div>
  <nav class="sb-nav">
    <div class="sb-label">Core 2</div>
    <a href="dashboard.php" class="sb-item"><div class="sb-ico"><?=ico($iHome,'#4A5568')?></div><span>Dashboard</span></a>
    <a href="booking_system.php" class="sb-item active"><div class="sb-ico"><?=ico($iBook,'#4A5568')?></div><span>Booking System</span></a>
    <a href="payment_fares.php" class="sb-item"><div class="sb-ico"><?=ico($iPay,'#4A5568')?></div><span>Payment &amp; Fares</span></a>
    <a href="crm_system.php" class="sb-item"><div class="sb-ico"><?=ico($iCrm,'#4A5568')?></div><span>CRM</span></a>
    <a href="gps_tracking.php" class="sb-item"><div class="sb-ico"><?=ico($iGps,'#4A5568')?></div><span>GPS Tracking</span></a>
    <div class="sb-label">Analytics</div>
    <a href="transport_analytics.php" class="sb-item"><div class="sb-ico"><?=ico($iBar,'#4A5568')?></div><span>Analytics &amp; KPIs</span></a>
    <a href="sop_compliance.php" class="sb-item"><div class="sb-ico"><?=ico($iDoc,'#4A5568')?></div><span>SOP Compliance</span></a>
  </nav>
  <div class="sb-foot">
    <div class="sb-av"><?=$userInitial?></div>
    <div style="flex:1;min-width:0">
      <div class="sb-uname trunc"><?=$userName?></div>
      <div class="sb-urole">Administrator</div>
    </div>
    <button class="sb-out" onclick="if(confirm('Logout?'))location.href='../auth/logout.php'" title="Logout"><?=ico($iOut,'#EF4444',14)?></button>
  </div>
</aside>

<div class="desk-wrap">
  <header class="topbar">
    <div class="tb-title">Booking Management</div>
    <div class="tb-date"><?=date('D, M j, Y')?></div>
    <div class="tb-sep"></div>
    <button class="tb-btn" onclick="exportBookings()"><?=ico($iDownload,'#4A5568',13)?> Export</button>
    <button class="tb-btn" onclick="reloadBookings()"><?=ico($iRefresh,'#4A5568',13)?> Refresh</button>
  </header>

  <div class="scroll">

    <div class="kpi-row">
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(232,160,32,.1)"><?=ico($iClock,'#E8A020',17)?></div>
          <div class="kpi-num">pending</div>
        </div>
        <div class="kpi-val"><?=$cnt_pending?></div>
        <div class="kpi-lbl">Awaiting Confirmation</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(59,142,240,.1)"><?=ico($iCheck,'#3B8EF0',17)?></div>
          <div class="kpi-num">confirmed</div>
        </div>
        <div class="kpi-val"><?=$cnt_confirmed?></div>
        <div class="kpi-lbl">Confirmed Bookings</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(139,111,232,.1)"><?=ico($iTruck,'#8B6FE8',17)?></div>
          <div class="kpi-num">on trip</div>
        </div>
        <div class="kpi-val"><?=$cnt_active?></div>
        <div class="kpi-lbl">In Progress</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iCheck,'#00A86B',17)?></div>
          <div class="kpi-num">done</div>
        </div>
        <div class="kpi-val"><?=$cnt_completed?></div>
        <div class="kpi-lbl">Completed</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(232,64,64,.08)"><?=ico($iX,'#E84040',17)?></div>
          <div class="kpi-num">cancelled</div>
        </div>
        <div class="kpi-val"><?=$cnt_cancelled?></div>
        <div class="kpi-lbl">Cancelled</div>
      </div>
      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iPay,'#00A86B',17)?></div>
          <div class="kpi-num">revenue</div>
        </div>
        <div class="kpi-val"><span class="sign">₱</span><?=number_format($total_rev/1000,1)?>K</div>
        <div class="kpi-lbl">Total Revenue</div>
      </div>
    </div>

    <div class="tool-bar">
      <div class="search-wrap">
        <div class="search-ico"><?=ico($iSearch,'#7A9A8E',13)?></div>
        <input type="text" class="search-box" id="bookSearch" placeholder="Search reference, customer, location…" oninput="searchBookings(this.value)">
      </div>
      <div class="filter-sep"></div>
      <div class="tabs-bar" id="filterTabs">
        <button class="tab-btn active" onclick="setFilter('all',this)">All <span class="tab-badge" id="badge-all"><?=count($allBookings)?></span></button>
        <button class="tab-btn" onclick="setFilter('Pending',this)">Pending <span class="tab-badge" id="badge-Pending"><?=$cnt_pending?></span></button>
        <button class="tab-btn" onclick="setFilter('Confirmed',this)">Confirmed <span class="tab-badge" id="badge-Confirmed"><?=$cnt_confirmed?></span></button>
        <button class="tab-btn" onclick="setFilter('In Progress',this)">Active <span class="tab-badge" id="badge-InProgress"><?=$cnt_active?></span></button>
        <button class="tab-btn" onclick="setFilter('Completed',this)">Completed <span class="tab-badge" id="badge-Completed"><?=$cnt_completed?></span></button>
        <button class="tab-btn" onclick="setFilter('Cancelled',this)">Cancelled <span class="tab-badge" id="badge-Cancelled"><?=$cnt_cancelled?></span></button>
      </div>
      <div class="filter-sep"></div>
      <button class="view-btn active" id="tblViewBtn" onclick="setView('table')"><?=ico("<line x1='8' y1='6' x2='21' y2='6'/><line x1='8' y1='12' x2='21' y2='12'/><line x1='8' y1='18' x2='21' y2='18'/><line x1='3' y1='6' x2='3.01' y2='6'/><line x1='3' y1='12' x2='3.01' y2='12'/><line x1='3' y1='18' x2='3.01' y2='18'/>", '#4A5568', 14)?> Table</button>
      <button class="view-btn" id="cardViewBtn" onclick="setView('card')"><?=ico("<rect x='3' y='3' width='7' height='7'/><rect x='14' y='3' width='7' height='7'/><rect x='14' y='14' width='7' height='7'/><rect x='3' y='14' width='7' height='7'/>", '#4A5568', 14)?> Cards</button>
    </div>

    <div class="panel" id="tableView">
      <div class="tbl-wrap">
        <table>
          <thead>
            <tr>
              <th>Reference</th>
              <th>Customer</th>
              <th>Service</th>
              <th>Date / Time</th>
              <th>Route</th>
              <th>Fare</th>
              <th>Status</th>
              <th>Payment</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="bookTbody">
            <tr class="empty-row"><td colspan="9">Loading bookings…</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card-grid" id="cardView" style="display:none"></div>

  </div>
</div>

<header class="mob-header">
  <button class="mh-back" onclick="location.href='dashboard.php'"><?=ico($iBack,'currentColor',16)?></button>
  <div class="mh-title">Bookings</div>
  <button class="mh-btn" onclick="reloadBookings()"><?=ico($iRefresh,'currentColor',16)?></button>
</header>

<div class="mob-body">
  <div class="m-kpis">
    <div class="mkpi">
      <div class="mkpi-v" style="color:#E8A020"><?=$cnt_pending?></div>
      <div class="mkpi-l">Pending</div>
    </div>
    <div class="mkpi">
      <div class="mkpi-v" style="color:#8B6FE8"><?=$cnt_active?></div>
      <div class="mkpi-l">On Trip</div>
    </div>
    <div class="mkpi">
      <div class="mkpi-v" style="color:#00A86B"><?=$cnt_completed?></div>
      <div class="mkpi-l">Done</div>
    </div>
  </div>

  <div class="m-search">
    <?=ico($iSearch,'#7A9A8E',16)?>
    <input type="text" id="mSearchBox" placeholder="Search bookings…" oninput="searchBookings(this.value)">
  </div>

  <div class="m-filters" id="mFilters">
    <button class="m-filter-btn active" onclick="setFilter('all',this,true)">All <span id="mbadge-all"><?=count($allBookings)?></span></button>
    <button class="m-filter-btn" onclick="setFilter('Pending',this,true)"><?=ico($iClock,'currentColor',11)?> Pending</button>
    <button class="m-filter-btn" onclick="setFilter('Confirmed',this,true)"><?=ico($iCheck,'currentColor',11)?> Confirmed</button>
    <button class="m-filter-btn" onclick="setFilter('In Progress',this,true)"><?=ico($iTruck,'currentColor',11)?> Active</button>
    <button class="m-filter-btn" onclick="setFilter('Completed',this,true)">Done</button>
    <button class="m-filter-btn" onclick="setFilter('Cancelled',this,true)">Cancelled</button>
  </div>

  <div class="m-bookings" id="mBookingList"></div>
</div>

<nav class="mob-nav">
  <button class="mn" onclick="location.href='dashboard.php'"><div class="mn-ico"><?=ico($iHome,'currentColor',22)?></div><span class="mn-lbl">Home</span></button>
  <button class="mn active"><div class="mn-ico"><?=ico($iTruck,'currentColor',22)?></div><span class="mn-lbl">Bookings</span></button>
  <button class="mn" onclick="location.href='payment_fares.php'"><div class="mn-ico"><?=ico($iPay,'currentColor',22)?></div><span class="mn-lbl">Payments</span></button>
  <button class="mn" onclick="location.href='gps_tracking.php'"><div class="mn-ico"><?=ico($iGps,'currentColor',22)?></div><span class="mn-lbl">GPS</span></button>
</nav>

<div id="editModal" class="modal">
  <div class="modal-box modal-wide">
    <div class="modal-hdr">
      <div class="modal-title">Edit Booking</div>
      <button class="modal-close" onclick="closeModal('editModal')"><?=ico($iX,'#4A5568',14)?></button>
    </div>
    <div class="modal-body">
      <form id="editForm">
        <input type="hidden" name="booking_id" id="edit_booking_id">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Pickup Date</label>
            <input type="date" class="form-input" name="booking_date" id="edit_booking_date">
          </div>
          <div class="form-group">
            <label class="form-label">Pickup Time</label>
            <input type="time" class="form-input" name="booking_time" id="edit_booking_time">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Service Type</label>
          <select class="form-select" name="service_id" id="edit_service_id">
            <option value="">— Select Service —</option>
            <?php foreach($services_raw as $svc): ?>
            <option value="<?=htmlspecialchars($svc['service_id'])?>"><?=htmlspecialchars($svc['service_name'])?> — ₱<?=number_format($svc['unit_price'],2)?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Pickup Location</label>
            <input type="text" class="form-input" name="pickup_location" id="edit_pickup">
          </div>
          <div class="form-group">
            <label class="form-label">Drop-off Location</label>
            <input type="text" class="form-input" name="dropoff_location" id="edit_dropoff">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Payment Status</label>
            <select class="form-select" name="payment_status" id="edit_payment_status">
              <option value="">— No Change —</option>
              <option value="Pending">Pending</option>
              <option value="Paid">Paid</option>
              <option value="Refunded">Refunded</option>
              <option value="Waived">Waived</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Special Requirements</label>
            <input type="text" class="form-input" name="special_requirements" id="edit_special">
          </div>
        </div>
      </form>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('editModal')">Cancel</button>
      <button class="btn btn-success" onclick="submitEdit()"><?=ico($iCheck,'#fff',14)?> Save Changes</button>
    </div>
  </div>
</div>

<div id="cancelModal" class="modal">
  <div class="modal-box">
    <div class="modal-hdr">
      <div class="modal-title">Cancel Booking</div>
      <button class="modal-close" onclick="closeModal('cancelModal')"><?=ico($iX,'#4A5568',14)?></button>
    </div>
    <div class="modal-body">
      <p style="font-size:13px;color:var(--txt3);margin-bottom:14px">Please provide a reason for cancelling this booking.</p>
      <div class="form-group">
        <label class="form-label">Cancellation Reason</label>
        <textarea id="cancel_reason" class="form-textarea" placeholder="e.g. Customer requested cancellation, Vehicle unavailable…"></textarea>
      </div>
      <div style="background:rgba(232,64,64,.06);border:1px solid rgba(232,64,64,.15);border-radius:10px;padding:10px 13px;font-size:12.5px;color:var(--red)">
        <?=ico($iInfo,'#E84040',13)?> This action cannot be undone. The booking and related ride will be cancelled.
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('cancelModal')">Go Back</button>
      <button class="btn btn-danger" id="confirmCancelBtn"><?=ico($iX,'#fff',14)?> Confirm Cancel</button>
    </div>
  </div>
</div>

<div id="detailsModal" class="modal">
  <div class="modal-box modal-wide">
    <div class="modal-hdr">
      <div class="modal-title">Booking Details</div>
      <button class="modal-close" onclick="closeModal('detailsModal')"><?=ico($iX,'#4A5568',14)?></button>
    </div>
    <div class="modal-body" id="detailsContent"></div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('detailsModal')">Close</button>
      <div id="detailsActions" style="display:flex;gap:8px"></div>
    </div>
  </div>
</div>

<div id="loading" class="loading">
  <div class="spin-box">
    <div class="spinner"></div>
    <p style="font-size:13px;font-weight:600">Processing…</p>
  </div>
</div>
<div class="toast" id="toastCont"></div>
<div class="mob-toast" id="mobToastCont"></div>

<script>
let allBookingsData = <?=json_encode(array_values($allBookings))?>;
let currentFilter = 'all';
let currentSearch = '';
let currentViewMode = 'table';
let cancelBookingId = null;

const setLoading = v => document.getElementById('loading').classList.toggle('show',v);
function openModal(id){ document.getElementById(id).classList.add('open'); }
function closeModal(id){ document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal').forEach(m => m.addEventListener('click',e=>{ if(e.target===m) m.classList.remove('open'); }));

function toast(msg, type='success'){
    ['toastCont','mobToastCont'].forEach(id=>{
        const c=document.getElementById(id); if(!c)return;
        const el=document.createElement('div');
        el.className=`toast-item ${type}`;
        const ico=type==='success'?'<polyline points="20 6 9 17 4 12"/>':'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>';
        el.innerHTML=`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${ico}</svg>${msg}`;
        c.appendChild(el);
        setTimeout(()=>{el.style.animation='toastOut .3s ease forwards';setTimeout(()=>el.remove(),300);},3500);
    });
}

async function api(data){
    const fd=new FormData();
    Object.entries(data).forEach(([k,v])=>fd.append(k,v));
    const r=await fetch('booking_system.php',{method:'POST',body:fd});
    return r.json();
}

function statusBadge(s){
    const m={Pending:'badge-yellow','In Progress':'badge-purple',Confirmed:'badge-blue',Completed:'badge-green',Cancelled:'badge-red'};
    return `<span class="badge ${m[s]||'badge-yellow'}">${s||'—'}</span>`;
}
function payBadge(s){
    const m={Paid:'badge-green',Pending:'badge-yellow',Refunded:'badge-purple',Waived:'badge-blue',Unpaid:'badge-red'};
    return `<span class="badge ${m[s]||'badge-yellow'}">${s||'—'}</span>`;
}

function setFilter(f, el, isMobile=false){
    currentFilter=f;
    const sel=isMobile?'#mFilters .m-filter-btn':'#filterTabs .tab-btn';
    document.querySelectorAll(sel).forEach(b=>b.classList.remove('active'));
    el.classList.add('active');
    renderAll();
}
function searchBookings(q){
    currentSearch=q.toLowerCase();
    renderAll();
}
function getFiltered(){
    return allBookingsData.filter(b=>{
        const fm=currentFilter==='all'||b.booking_status===currentFilter;
        const sm=!currentSearch||(b.booking_reference||'').toLowerCase().includes(currentSearch)||(b.customer_name||'').toLowerCase().includes(currentSearch)||(b.pickup_location||'').toLowerCase().includes(currentSearch)||(b.dropoff_location||'').toLowerCase().includes(currentSearch);
        return fm&&sm;
    });
}

function renderTable(bookings){
    const tb=document.getElementById('bookTbody'); if(!tb)return;
    if(!bookings.length){
        tb.innerHTML=`<tr class="empty-row"><td colspan="9" style="text-align:center;padding:48px;color:var(--txt3)">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 12px;display:block;opacity:.25"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="9" x2="15" y2="15"/><line x1="15" y1="9" x2="9" y2="15"/></svg>
          <p>No bookings found</p></td></tr>`;
        return;
    }
    tb.innerHTML = bookings.map(b=>{
        const actions = buildActions(b, 'tbl');
        const fare = parseFloat(b.total_amount||0).toFixed(2);
        const dt   = [b.booking_date||'',b.booking_time||''].filter(Boolean).join(' ');
        const route= [b.pickup_location?'<span style="font-size:10.5px;color:var(--txt3)">▲ </span>'+b.pickup_location:'', b.dropoff_location?'<span style="font-size:10.5px;color:var(--txt3)">▼ </span>'+b.dropoff_location:''].filter(Boolean).join('<br>');
        return `<tr onclick="showDetails(${b.booking_id})" data-id="${b.booking_id}">
          <td><div class="td-ref">${b.booking_reference||'—'}</div><div class="td-sub">#${b.booking_id}</div></td>
          <td><div class="td-customer">${b.customer_name||'Guest'}</div><div class="td-sub">${b.customer_phone||''}</div></td>
          <td class="td-muted">${b.service_name||'—'}</td>
          <td class="td-muted">${dt||'—'}</td>
          <td style="font-size:11.5px;max-width:180px;line-height:1.6">${route||'<span class="td-muted">—</span>'}</td>
          <td class="td-amt">₱${fare}</td>
          <td>${statusBadge(b.booking_status)}</td>
          <td>${payBadge(b.payment_status)}</td>
          <td onclick="event.stopPropagation()"><div style="display:flex;gap:5px;flex-wrap:nowrap">${actions}</div></td>
        </tr>`;
    }).join('');
}

function renderCards(bookings){
    const cv=document.getElementById('cardView'); if(!cv)return;
    if(!bookings.length){
        cv.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:48px;background:var(--surf);border-radius:var(--r);border:1px solid var(--bdr);color:var(--txt3)">No bookings found</div>`;
        return;
    }
    cv.innerHTML=bookings.map(b=>{
        const fare=parseFloat(b.total_amount||0).toFixed(2);
        const actions=buildActions(b,'card');
        return `<div class="bk-card">
          <div class="bc-head" onclick="showDetails(${b.booking_id})" style="cursor:pointer">
            <div class="bc-ref">${b.booking_reference||'—'}</div>
            ${statusBadge(b.booking_status)}
          </div>
          <div class="bc-body" onclick="showDetails(${b.booking_id})" style="cursor:pointer">
            <div class="bc-row"><div class="bc-lbl">Customer</div><div class="bc-val">${b.customer_name||'Guest'}${b.customer_phone?' · '+b.customer_phone:''}</div></div>
            <div class="bc-row"><div class="bc-lbl">Service</div><div class="bc-val">${b.service_name||'—'}</div></div>
            ${b.booking_date?`<div class="bc-row"><div class="bc-lbl">Date</div><div class="bc-val">${b.booking_date} ${b.booking_time||''}</div></div>`:''}
            ${b.pickup_location?`<div class="bc-row"><div class="bc-lbl">From</div><div class="bc-val">${b.pickup_location}</div></div>`:''}
            ${b.dropoff_location?`<div class="bc-row"><div class="bc-lbl">To</div><div class="bc-val">${b.dropoff_location}</div></div>`:''}
            <div class="bc-row"><div class="bc-lbl">Fare</div><div class="bc-val" style="font-weight:700;color:var(--gd)">₱${fare}</div></div>
          </div>
          <div class="bc-foot">${actions}</div>
        </div>`;
    }).join('');
}

function renderMobile(bookings){
    const ml=document.getElementById('mBookingList'); if(!ml)return;
    if(!bookings.length){
        ml.innerHTML=`<div class="m-empty"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="9" x2="15" y2="15"/><line x1="15" y1="9" x2="9" y2="15"/></svg><p>No bookings found</p></div>`;
        return;
    }
    ml.innerHTML=bookings.map(b=>{
        const fare=parseFloat(b.total_amount||0).toFixed(2);
        const mactions=buildActions(b,'mobile');
        return `<div class="m-bk">
          <div class="mb-head">
            <div class="mb-ref">${b.booking_reference||'—'}</div>
            ${statusBadge(b.booking_status)}
          </div>
          <div class="mb-body">
            <div class="mb-row"><div class="mb-lbl">Customer</div><div class="mb-val">${b.customer_name||'Guest'}</div></div>
            <div class="mb-row"><div class="mb-lbl">Service</div><div class="mb-val">${b.service_name||'—'}</div></div>
            ${b.booking_date?`<div class="mb-row"><div class="mb-lbl">Date</div><div class="mb-val">${b.booking_date}</div></div>`:''}
            <div class="mb-row"><div class="mb-lbl">Fare</div><div class="mb-val" style="font-weight:700;color:#00A86B">₱${fare}</div></div>
          </div>
          <div class="mb-foot">${mactions}</div>
        </div>`;
    }).join('');
}

function buildActions(b, ctx){
    const s=b.booking_status;
    const id=b.booking_id;
    const sm=ctx==='mobile'?'':' btn-sm';
    let html='';
    if(s==='Pending'){
        html+=`<button class="btn btn-success${sm}" onclick="updateStatus(${id},'Confirmed')">${svgCheck}Confirm</button>`;
        html+=`<button class="btn btn-info${sm}" onclick="editBooking(${id})">${svgEdit}Edit</button>`;
        html+=`<button class="btn btn-danger${sm}" onclick="showCancelModal(${id})">${svgX}Cancel</button>`;
    } else if(s==='Confirmed'){
        html+=`<button class="btn btn-success${sm}" onclick="updateStatus(${id},'In Progress')">${svgTruck}Start Trip</button>`;
        html+=`<button class="btn btn-info${sm}" onclick="editBooking(${id})">${svgEdit}Edit</button>`;
        html+=`<button class="btn btn-danger${sm}" onclick="showCancelModal(${id})">${svgX}</button>`;
    } else if(s==='In Progress'){
        html+=`<button class="btn btn-success${sm}" onclick="updateStatus(${id},'Completed')">${svgCheck}Complete</button>`;
        html+=`<button class="btn btn-orange${sm}" onclick="showDetails(${id})">${svgInfo}Details</button>`;
    } else if(s==='Completed'||s==='Cancelled'){
        html+=`<button class="btn btn-ghost${sm}" onclick="showDetails(${id})">${svgInfo}View</button>`;
    }
    return html;
}

const svgCheck=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
const svgX=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
const svgEdit=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;
const svgInfo=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
const svgTruck=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`;

function renderAll(){
    const filtered=getFiltered();
    renderTable(filtered);
    renderCards(filtered);
    renderMobile(filtered);
}

function setView(mode){
    currentViewMode=mode;
    const tv=document.getElementById('tableView');
    const cv=document.getElementById('cardView');
    if(mode==='table'){
        tv.classList.remove('hidden'); tv.classList.add('show');
        cv.classList.remove('show'); cv.classList.add('hidden');
        document.getElementById('tblViewBtn')?.classList.add('active');
        document.getElementById('cardViewBtn')?.classList.remove('active');
    } else {
        cv.classList.remove('hidden'); cv.classList.add('show');
        tv.classList.remove('show'); tv.classList.add('hidden');
        document.getElementById('cardViewBtn')?.classList.add('active');
        document.getElementById('tblViewBtn')?.classList.remove('active');
    }
    renderAll();
}

async function updateStatus(id,status){
    if(!confirm(`Update booking status to "${status}"?`))return;
    setLoading(true);
    try{
        const res=await api({action:'update_booking_status',booking_id:id,status});
        toast(res.message,res.success?'success':'error');
        if(res.success) await reloadBookings();
    }catch(e){toast('Error: '+e.message,'error');}
    setLoading(false);
}

async function editBooking(id){
    setLoading(true);
    try{
        const res=await api({action:'get_booking_details',booking_id:id});
        if(res.success){
            const b=res.booking;
            document.getElementById('edit_booking_id').value=b.booking_id;
            document.getElementById('edit_booking_date').value=b.booking_date||'';
            document.getElementById('edit_booking_time').value=b.booking_time||'';
            document.getElementById('edit_service_id').value=b.service_id||'';
            document.getElementById('edit_pickup').value=b.pickup_location||'';
            document.getElementById('edit_dropoff').value=b.dropoff_location||'';
            document.getElementById('edit_special').value=b.special_requirements||'';
            document.getElementById('edit_payment_status').value=b.payment_status||'';
            openModal('editModal');
        } else toast(res.message,'error');
    }catch(e){toast('Error: '+e.message,'error');}
    setLoading(false);
}
async function submitEdit(){
    const fd=new FormData(document.getElementById('editForm'));
    fd.append('action','edit_booking');
    closeModal('editModal');
    setLoading(true);
    try{
        const res=await api(Object.fromEntries(fd));
        toast(res.message,res.success?'success':'error');
        if(res.success) await reloadBookings();
    }catch(e){toast('Error: '+e.message,'error');}
    setLoading(false);
}

function showCancelModal(id){
    cancelBookingId=id;
    document.getElementById('cancel_reason').value='';
    openModal('cancelModal');
}
document.getElementById('confirmCancelBtn').onclick=async()=>{
    const reason=document.getElementById('cancel_reason').value.trim();
    if(!reason){toast('Please enter a reason','error');return;}
    closeModal('cancelModal');
    setLoading(true);
    try{
        const res=await api({action:'cancel_booking',booking_id:cancelBookingId,reason});
        toast(res.message,res.success?'success':'error');
        if(res.success) await reloadBookings();
    }catch(e){toast('Error: '+e.message,'error');}
    setLoading(false);
    cancelBookingId=null;
};

async function showDetails(id){
    setLoading(true);
    try{
        const res=await api({action:'get_booking_details',booking_id:id});
        if(res.success){
            const b=res.booking,h=res.history||[];
            document.getElementById('detailsContent').innerHTML=`
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px">
                <div>
                  <div class="section-label">Booking Info</div>
                  <div class="d-row"><div class="d-label">Reference</div><div class="d-val" style="font-weight:800">${b.booking_reference||'—'}</div></div>
                  <div class="d-row"><div class="d-label">Status</div><div class="d-val">${statusBadge(b.booking_status)}</div></div>
                  <div class="d-row"><div class="d-label">Payment</div><div class="d-val">${payBadge(b.payment_status)}</div></div>
                  <div class="d-row"><div class="d-label">Service</div><div class="d-val">${b.service_name||'—'}</div></div>
                  <div class="d-row"><div class="d-label">Date</div><div class="d-val">${b.booking_date||'—'} ${b.booking_time||''}</div></div>
                  <div class="d-row"><div class="d-label">Fare</div><div class="d-val" style="font-weight:800;font-size:16px;color:var(--gd)">₱${parseFloat(b.total_amount||0).toFixed(2)}</div></div>
                  ${b.special_requirements?`<div class="d-row"><div class="d-label">Notes</div><div class="d-val">${b.special_requirements}</div></div>`:''}
                </div>
                <div>
                  <div class="section-label">Customer</div>
                  <div class="d-row"><div class="d-label">Name</div><div class="d-val" style="font-weight:600">${b.customer_name||'Guest'}</div></div>
                  <div class="d-row"><div class="d-label">Phone</div><div class="d-val">${b.customer_phone||'—'}</div></div>
                  ${b.customer_email?`<div class="d-row"><div class="d-label">Email</div><div class="d-val">${b.customer_email}</div></div>`:''}
                  <div class="section-label" style="margin-top:14px">Route</div>
                  ${b.pickup_location?`<div class="d-row"><div class="d-label">Pickup</div><div class="d-val">${b.pickup_location}</div></div>`:''}
                  ${b.dropoff_location?`<div class="d-row"><div class="d-label">Drop-off</div><div class="d-val">${b.dropoff_location}</div></div>`:''}
                  ${b.ride_status?`<div class="d-row"><div class="d-label">Ride Status</div><div class="d-val">${statusBadge(b.ride_status)}</div></div>`:''}
                  ${b.start_time?`<div class="d-row"><div class="d-label">Start</div><div class="d-val">${new Date(b.start_time).toLocaleString()}</div></div>`:''}
                  ${b.end_time?`<div class="d-row"><div class="d-label">End</div><div class="d-val">${new Date(b.end_time).toLocaleString()}</div></div>`:''}
                </div>
              </div>
              ${h.length?`<div class="section-label">Change History (${h.length})</div>
              <div style="display:flex;flex-direction:column;gap:6px">
              ${h.map(e=>`
                <div style="display:flex;align-items:flex-start;gap:10px;background:var(--surf2);border-radius:9px;padding:10px 12px;border:1px solid var(--bdr)">
                  <div style="flex:1">
                    <div style="font-size:12px;font-weight:700;color:var(--txt)">${e.change_type}</div>
                    <div style="font-size:11.5px;color:var(--txt2);margin-top:2px">${e.notes}</div>
                  </div>
                  <div style="font-size:11px;color:var(--txt3);white-space:nowrap">${new Date(e.changed_at).toLocaleString()}</div>
                </div>`).join('')}
              </div>`:''}`;
            const da=document.getElementById('detailsActions');
            da.innerHTML='';
            if(b.booking_status==='Pending'){ da.innerHTML+=`<button class="btn btn-success" onclick="closeModal('detailsModal');updateStatus(${b.booking_id},'Confirmed')">${svgCheck}Confirm</button>`; }
            if(b.booking_status==='Confirmed'){ da.innerHTML+=`<button class="btn btn-success" onclick="closeModal('detailsModal');updateStatus(${b.booking_id},'In Progress')">${svgTruck}Start Trip</button>`; }
            if(b.booking_status==='In Progress'){ da.innerHTML+=`<button class="btn btn-success" onclick="closeModal('detailsModal');updateStatus(${b.booking_id},'Completed')">${svgCheck}Complete</button>`; }
            if(b.booking_status!=='Cancelled'&&b.booking_status!=='Completed'){ da.innerHTML+=`<button class="btn btn-ghost" onclick="closeModal('detailsModal');editBooking(${b.booking_id})">${svgEdit}Edit</button><button class="btn btn-danger" onclick="closeModal('detailsModal');showCancelModal(${b.booking_id})">${svgX}Cancel</button>`; }
            openModal('detailsModal');
        } else toast(res.message,'error');
    }catch(e){toast('Error: '+e.message,'error');}
    setLoading(false);
}

async function reloadBookings(){
    setLoading(true);
    try{
        const res=await api({action:'get_all_bookings',status:'all'});
        if(res.success){
            allBookingsData=res.bookings;
            renderAll();
        }
    }catch(e){console.error(e);}
    setLoading(false);
}

function exportBookings(){
    const rows=[['Booking ID','Reference','Customer','Phone','Service','Date','Time','Pickup','Dropoff','Fare','Status','Payment']];
    getFiltered().forEach(b=>rows.push([b.booking_id,b.booking_reference,b.customer_name,b.customer_phone,b.service_name,b.booking_date,b.booking_time,b.pickup_location,b.dropoff_location,b.total_amount,b.booking_status,b.payment_status]));
    const csv=rows.map(r=>r.map(c=>`"${(c||'').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
    const a=document.createElement('a');
    a.href='data:text/csv;charset=utf-8,'+encodeURIComponent(csv);
    a.download='bookings_'+new Date().toISOString().slice(0,10)+'.csv';
    a.click();
}

window.addEventListener('load',()=>{
    document.getElementById('tableView').classList.add('show');
    renderAll();
});
</script>
<?php include __DIR__ . '/chat_widget.php'; ?>
</body>
</html>