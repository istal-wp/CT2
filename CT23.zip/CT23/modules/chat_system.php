<?php
/**
 * EnviroCab Admin Chat System — FIXED VERSION
 * Fixes:
 *  1. Session key fallback chain (admin_uuid / admin_id / user_id / id)
 *  2. sb_get — commas and dots NOT encoded (Supabase needs literal commas in select=)
 *  3. sb_request uses Prefer:return=minimal — no SELECT RLS dependency
 *  4. start_conversation — PHP UUID generation, intersection duplicate check
 *  5. send_message — PHP UUID, returns data immediately without re-fetching
 */

session_start();
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

$currentAdminId = $_SESSION['admin_uuid']
               ?? $_SESSION['admin_id']
               ?? $_SESSION['user_id']
               ?? $_SESSION['id']
               ?? null;

$currentAdminName = $_SESSION['full_name']
                 ?? $_SESSION['display_name']
                 ?? $_SESSION['name']
                 ?? 'Admin';

function gen_uuid(): string {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff),
        mt_rand(0,0x0fff)|0x4000, mt_rand(0,0x3fff)|0x8000,
        mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff));
}

function sb_request(string $method, string $endpoint, array $body = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . ltrim($endpoint, '/');
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => strtoupper($method),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=minimal',
        ],
        CURLOPT_POSTFIELDS => json_encode($body),
    ]);
    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode >= 400) return ['error' => $resp, 'http' => $httpCode];
    return ['ok' => true, 'http' => $httpCode];
}

function sb_get(string $table, array $params = []): array {
    $parts = [];
    foreach ($params as $k => $v) {
        $encoded = str_replace(
            ['%2C','%2c','%2E','%2e','%3A','%3a'],
            [',',  ',',  '.',  '.',  ':',  ':'],
            rawurlencode($v)
        );
        $parts[] = rawurlencode($k) . '=' . $encoded;
    }
    $qs  = $parts ? '?' . implode('&', $parts) : '';
    $url = SUPABASE_URL . '/rest/v1/' . $table . $qs;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Accept: application/json',
        ],
    ]);
    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode >= 400) { error_log("sb_get [$table] HTTP $httpCode: $resp"); return []; }
    $data = json_decode($resp, true);
    return is_array($data) ? array_values(array_filter($data, 'is_array')) : [];
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if (!$currentAdminId) {
    echo json_encode(['success' => false, 'message' => 'Session admin ID not found.']);
    exit;
}

switch ($action) {

    case 'get_conversations':
        $memberships = sb_get('admin_conversation_members', [
            'admin_id' => 'eq.' . $currentAdminId,
            'select'   => 'conversation_id',
        ]);
        $convIds = array_column($memberships, 'conversation_id');
        if (empty($convIds)) { echo json_encode(['success' => true, 'data' => []]); exit; }

        $convs = [];
        foreach ($convIds as $cid) {
            $conv = sb_get('admin_conversations', ['id' => 'eq.' . $cid, 'select' => 'id,created_at']);
            if (empty($conv[0])) continue;

            $members    = sb_get('admin_conversation_members', ['conversation_id' => 'eq.' . $cid, 'select' => 'admin_id']);
            $otherNames = [];
            foreach (array_column($members, 'admin_id') as $mid) {
                if ($mid === $currentAdminId) continue;
                $acc = sb_get('admin_accounts', ['id' => 'eq.' . $mid, 'select' => 'display_name,email']);
                $otherNames[] = $acc[0]['display_name'] ?? explode('@', $acc[0]['email'] ?? 'Unknown')[0];
            }

            $lastMsg = sb_get('admin_messages', [
                'conversation_id' => 'eq.' . $cid,
                'order'           => 'created_at.desc',
                'limit'           => '1',
                'select'          => 'content,created_at,sender_name',
            ]);

            $since  = gmdate('Y-m-d\TH:i:s\Z', strtotime('-24 hours'));
            $unread = sb_get('admin_messages', [
                'conversation_id' => 'eq.' . $cid,
                'sender_id'       => 'neq.' . $currentAdminId,
                'created_at'      => 'gte.' . $since,
                'select'          => 'id',
            ]);

            $convs[] = [
                'id'           => $cid,
                'created_at'   => $conv[0]['created_at'],
                'members'      => $otherNames,
                'last_message' => $lastMsg[0]['content']     ?? '',
                'last_time'    => $lastMsg[0]['created_at']  ?? $conv[0]['created_at'],
                'last_sender'  => $lastMsg[0]['sender_name'] ?? '',
                'unread'       => count($unread),
            ];
        }
        usort($convs, fn($a, $b) => strcmp($b['last_time'], $a['last_time']));
        echo json_encode(['success' => true, 'data' => $convs]);
        break;

    case 'get_messages':
        $convId = $_POST['conversation_id'] ?? $_GET['conversation_id'] ?? '';
        $since  = $_POST['since'] ?? $_GET['since'] ?? null;
        if (!$convId) { echo json_encode(['success' => false, 'message' => 'Missing conversation_id']); exit; }
        $params = [
            'conversation_id' => 'eq.' . $convId,
            'order'           => 'created_at.asc',
            'limit'           => '200',
            'select'          => 'id,sender_id,sender_name,content,created_at',
        ];
        if ($since) $params['created_at'] = 'gt.' . $since;
        $messages = sb_get('admin_messages', $params);
        $tagged   = array_map(function ($m) use ($currentAdminId) {
            $m['is_mine'] = !empty($m['sender_id']) && $m['sender_id'] === $currentAdminId;
            return $m;
        }, $messages);
        echo json_encode(['success' => true, 'data' => $tagged]);
        break;

    case 'send_message':
        $convId  = $_POST['conversation_id'] ?? '';
        $content = trim($_POST['content'] ?? '');
        if (!$convId || !$content) { echo json_encode(['success' => false, 'message' => 'Missing fields']); exit; }
        $msgId  = gen_uuid();
        $now    = gmdate('Y-m-d\TH:i:s\Z');
        $result = sb_request('POST', 'admin_messages', [
            'id'              => $msgId,
            'conversation_id' => $convId,
            'sender_id'       => $currentAdminId,
            'sender_name'     => $currentAdminName,
            'content'         => $content,
        ]);
        if (!empty($result['error'])) {
            echo json_encode(['success' => false, 'message' => 'Failed to send', 'debug' => $result]);
            exit;
        }
        echo json_encode(['success' => true, 'data' => [
            'id'              => $msgId,
            'conversation_id' => $convId,
            'sender_id'       => $currentAdminId,
            'sender_name'     => $currentAdminName,
            'content'         => $content,
            'created_at'      => $now,
            'is_mine'         => true,
        ]]);
        break;

    case 'start_conversation':
        $targetId = $_POST['target_admin_id'] ?? '';
        if (!$targetId) { echo json_encode(['success' => false, 'message' => 'Missing target']); exit; }

        $myIds    = array_column(sb_get('admin_conversation_members', ['admin_id' => 'eq.' . $currentAdminId, 'select' => 'conversation_id']), 'conversation_id');
        $theirIds = array_column(sb_get('admin_conversation_members', ['admin_id' => 'eq.' . $targetId,       'select' => 'conversation_id']), 'conversation_id');
        $shared   = array_values(array_intersect($myIds, $theirIds));

        if (!empty($shared)) {
            echo json_encode(['success' => true, 'conversation_id' => $shared[0], 'existing' => true]);
            exit;
        }

        $newCid  = gen_uuid();
        $convRes = sb_request('POST', 'admin_conversations', ['id' => $newCid, 'created_by' => $currentAdminId]);
        if (!empty($convRes['error'])) {
            echo json_encode(['success' => false, 'message' => 'Could not create conversation', 'debug' => $convRes]);
            exit;
        }
        $m1 = sb_request('POST', 'admin_conversation_members', ['conversation_id' => $newCid, 'admin_id' => $currentAdminId]);
        $m2 = sb_request('POST', 'admin_conversation_members', ['conversation_id' => $newCid, 'admin_id' => $targetId]);
        if (!empty($m1['error']) || !empty($m2['error'])) {
            echo json_encode(['success' => false, 'message' => 'Members failed', 'debug' => ['m1' => $m1, 'm2' => $m2]]);
            exit;
        }
        echo json_encode(['success' => true, 'conversation_id' => $newCid, 'existing' => false]);
        break;

    case 'get_admins':
        $admins  = sb_get('admin_accounts', ['id' => 'neq.' . $currentAdminId, 'select' => 'id,display_name,email,role']);
        $cleaned = array_map(function ($a) {
            $a['display_name'] = $a['display_name'] ?: explode('@', $a['email'])[0];
            return $a;
        }, $admins);
        echo json_encode(['success' => true, 'data' => $cleaned]);
        break;

    case 'get_unread_count':
        $memberships = sb_get('admin_conversation_members', ['admin_id' => 'eq.' . $currentAdminId, 'select' => 'conversation_id']);
        $total = 0;
        $since = gmdate('Y-m-d\TH:i:s\Z', strtotime('-24 hours'));
        foreach (array_column($memberships, 'conversation_id') as $cid) {
            $unread = sb_get('admin_messages', [
                'conversation_id' => 'eq.' . $cid,
                'sender_id'       => 'neq.' . $currentAdminId,
                'created_at'      => 'gte.' . $since,
                'select'          => 'id',
            ]);
            $total += count($unread);
        }
        echo json_encode(['success' => true, 'count' => $total]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Unknown action: ' . $action]);
}
?>