<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';
try { $pdo = getDatabaseConnection(); } catch (PDOException $e) { die("DB error: ".$e->getMessage()); }

$userId = $_SESSION['user_id'];
$userData = [];
$userStats = ['total_bookings'=>0,'total_spent'=>0,'total_trips'=>0,'completed_trips'=>0,'member_since'=>date('Y-m-d'),'avg_rating'=>0];
$recentBookings = [];

try {
    $stmt = $pdo->prepare("SELECT * FROM core_users WHERE user_id = :user_id");
    $stmt->execute(['user_id'=>$userId]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($userData) $userStats['member_since'] = date('M Y', strtotime($userData['created_at']));

    foreach([
        ['total_bookings','SELECT COUNT(*) as count FROM core_bookings WHERE customer_id = :uid'],
        ['total_trips',   'SELECT COUNT(*) as count FROM core_rides WHERE customer_id = :uid'],
        ['completed_trips','SELECT COUNT(*) as count FROM core_rides WHERE customer_id = :uid AND ride_status = \'Completed\''],
    ] as [$key,$sql]){
        $stmt=$pdo->prepare($sql); $stmt->execute(['uid'=>$userId]); $userStats[$key]=$stmt->fetch()['count']??0;
    }
    $stmt=$pdo->prepare("SELECT COALESCE(SUM(total_amount),0) as total FROM core_bookings WHERE customer_id=:uid AND payment_status='Paid'");
    $stmt->execute(['uid'=>$userId]); $userStats['total_spent']=$stmt->fetch()['total']??0;
    $stmt=$pdo->prepare("SELECT COALESCE(AVG(rating_value),0) as rating FROM core_ratings WHERE customer_id=:uid");
    $stmt->execute(['uid'=>$userId]); $userStats['avg_rating']=$stmt->fetch()['rating']??0;
    $stmt=$pdo->prepare("SELECT b.booking_reference,b.booking_status,b.total_amount,b.booking_date,s.service_name FROM core_bookings b LEFT JOIN core_services s ON b.service_id=s.service_id WHERE b.customer_id=:uid ORDER BY b.created_at DESC LIMIT 5");
    $stmt->execute(['uid'=>$userId]); $recentBookings=$stmt->fetchAll();
} catch(PDOException $e){ error_log("Profile error: ".$e->getMessage()); }

$userName    = htmlspecialchars($userData['full_name'] ?? $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin');
$userEmail   = htmlspecialchars($userData['email'] ?? '');
$userRole    = htmlspecialchars($userData['role'] ?? 'Administrator');
$userPhone   = htmlspecialchars($userData['phone'] ?? '');
$userStatus  = htmlspecialchars($userData['status'] ?? 'Active');
$userInitial = strtoupper(substr($userName, 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile – EnviroCab</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <style>
        * { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }

        :root {
          --g:#00D084; --gd:#00A86B; --gx:#006B45;
          --gg:rgba(0,208,132,.13);
          --bg:#EDF7F2; --surf:#fff; --surf2:#F6FBF8;
          --bdr:#E0EDE8; --txt:#0E1E17; --txt2:#3A5248; --txt3:#7A9A8E;
          --blue:#4A9EFF; --purple:#9B7FFF; --orange:#FF8A4A; --red:#FF5055;
          --yellow:#FFCA4A;
          --sw:256px; --th:62px; --r:18px; --rs:12px;
          --shadow:0 2px 12px rgba(0,0,0,.06);
          --sb-bg:#B91C1C; --sb-bg2:#991B1B; --sb-accent:#EF4444;
          --sb-txt:#FECACA; --sb-txt2:#FCA5A5; --sb-bdr:rgba(255,255,255,.12);
          --sb-item-hover:rgba(255,255,255,.1); --sb-active:rgba(255,255,255,.18);
          --sb-active-bdr:rgba(255,255,255,.3);
        }

        html, body { height:100%; }
        body {
          font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;
          background:var(--bg); color:var(--txt);
          -webkit-font-smoothing:antialiased;
        }

        /* ── SIDEBAR ── */
        .sidebar { display:none; }
        .desk-wrap { display:none; }

        /* ── MOBILE (< 768px) ── */
        .mob-shell {
          display:flex; flex-direction:column; min-height:100vh;
          padding-bottom:80px;
        }
        .mob-header {
          background:rgba(255,255,255,.95); backdrop-filter:blur(20px);
          padding:16px 20px; position:sticky; top:0; z-index:100;
          border-bottom:1px solid var(--bdr);
          display:flex; align-items:center; justify-content:space-between;
        }
        .mob-title { font-size:18px; font-weight:800; color:var(--txt); }
        .mob-body { padding:20px; flex:1; display:flex; flex-direction:column; gap:16px; }
        .mob-nav {
          position:fixed; bottom:0; left:0; right:0;
          background:rgba(255,255,255,.95); backdrop-filter:blur(20px);
          border-top:1px solid var(--bdr);
          padding:10px 0 18px;
          display:grid; grid-template-columns:repeat(4,1fr);
          z-index:99;
        }
        .mn { display:flex; flex-direction:column; align-items:center; gap:4px; padding:6px; cursor:pointer; border:none; background:none; }
        .mn svg { stroke:var(--txt3); opacity:.55; transition:all .2s; }
        .mn.active svg { stroke:var(--g); opacity:1; }
        .mn-lbl { font-size:10px; font-weight:600; color:var(--txt3); opacity:.7; }
        .mn.active .mn-lbl { color:var(--g); opacity:1; }

        /* ── DESKTOP (≥ 900px) ── */
        @media(min-width:900px) {
          .mob-shell { display:none !important; }
          body { display:flex; overflow:hidden; }

          .sidebar {
            display:flex; width:var(--sw); flex-shrink:0; height:100vh;
            flex-direction:column; background:var(--sb-bg);
            overflow:hidden; box-shadow:4px 0 20px rgba(185,28,28,.25);
          }
          .sb-logo { height:var(--th); display:flex; align-items:center; gap:10px; padding:0 20px; border-bottom:1px solid var(--sb-bdr); flex-shrink:0; }
          .sb-logo img { height:28px; width:auto; filter:brightness(0) invert(1); }
          .sb-logo-text { font-size:17px; font-weight:800; letter-spacing:-.3px; color:#fff; }
          .sb-logo-text span { color:#FCA5A5; }
          .sb-nav { flex:1; overflow-y:auto; padding:14px 12px; display:flex; flex-direction:column; gap:2px; }
          .sb-label { font-size:10px; font-weight:700; letter-spacing:1.1px; text-transform:uppercase; color:var(--sb-txt2); padding:14px 8px 6px; }
          .sb-item { display:flex; align-items:center; gap:10px; padding:9px 12px; border-radius:var(--rs); cursor:pointer; color:var(--sb-txt); font-size:13.5px; font-weight:500; border:1.5px solid transparent; transition:all .15s; text-decoration:none; }
          .sb-item:hover { background:var(--sb-item-hover); color:#fff; }
          .sb-item.active { background:var(--sb-active); color:#fff; border-color:var(--sb-active-bdr); font-weight:600; }
          .sb-icon { width:32px; height:32px; border-radius:9px; flex-shrink:0; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,.1); transition:background .15s; }
          .sb-item:hover .sb-icon, .sb-item.active .sb-icon { background:rgba(255,255,255,.22); }
          .sb-item svg { stroke:var(--sb-txt) !important; }
          .sb-item:hover svg, .sb-item.active svg { stroke:#fff !important; }
          .sb-badge { margin-left:auto; font-size:10.5px; font-weight:700; background:rgba(255,255,255,.2); color:#fff; padding:1px 7px; border-radius:20px; }
          .sb-foot { padding:14px 12px; border-top:1px solid var(--sb-bdr); flex-shrink:0; display:flex; gap:8px; align-items:center; }
          .sb-avatar { width:36px; height:36px; border-radius:10px; flex-shrink:0; background:rgba(255,255,255,.22); display:flex; align-items:center; justify-content:center; font-size:14px; font-weight:800; color:#fff; border:1.5px solid rgba(255,255,255,.3); }
          .sb-uname { font-size:13px; font-weight:600; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
          .sb-urole { font-size:11px; color:var(--sb-txt2); margin-top:1px; }
          .sb-logout { margin-left:auto; width:32px; height:32px; border-radius:9px; background:rgba(255,255,255,.12); border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:background .15s; flex-shrink:0; }
          .sb-logout:hover { background:rgba(255,255,255,.22); }

          .desk-wrap { display:flex; flex:1; flex-direction:column; height:100vh; overflow:hidden; min-width:0; }
          .topbar { height:var(--th); flex-shrink:0; background:var(--surf); border-bottom:1px solid var(--bdr); display:flex; align-items:center; padding:0 28px; gap:14px; }
          .tb-title { flex:1; font-size:18px; font-weight:800; color:var(--txt); letter-spacing:-.2px; }
          .tb-date { font-size:13px; color:var(--txt3); font-weight:500; white-space:nowrap; }
          .tb-sep { width:1px; height:20px; background:var(--bdr); }
          .tb-bell { width:36px; height:36px; border-radius:10px; background:var(--surf2); border:1px solid var(--bdr); display:flex; align-items:center; justify-content:center; cursor:pointer; transition:background .15s; }
          .tb-bell:hover { background:var(--bg); }
          .desk-scroll { flex:1; overflow-y:auto; padding:24px; display:flex; flex-direction:column; gap:20px; }
          .desk-scroll::-webkit-scrollbar { width:5px; }
          .desk-scroll::-webkit-scrollbar-thumb { background:var(--bdr); border-radius:10px; }
        }

        /* ── TABLET (768–899px) ── */
        @media(min-width:768px) and (max-width:899px) {
          .mob-shell { display:none !important; }
          body { display:flex; overflow:hidden; }

          .sidebar { display:flex; width:64px; height:100vh; background:var(--sb-bg); flex-direction:column; align-items:center; padding:12px 0; gap:4px; flex-shrink:0; box-shadow:4px 0 16px rgba(185,28,28,.2); }
          .sb-logo { width:100%; height:54px; display:flex; align-items:center; justify-content:center; border-bottom:1px solid var(--sb-bdr); margin-bottom:8px; }
          .sb-logo img { height:26px; filter:brightness(0) invert(1); }
          .sb-logo-text, .sb-label, .sb-badge, .sb-uname, .sb-urole { display:none; }
          .sb-nav { flex:1; width:100%; padding:4px 8px; display:flex; flex-direction:column; align-items:center; gap:3px; }
          .sb-item { width:46px; height:46px; border-radius:12px; display:flex; align-items:center; justify-content:center; cursor:pointer; border:1.5px solid transparent; transition:all .15s; text-decoration:none; }
          .sb-item:hover { background:var(--sb-item-hover); }
          .sb-item.active { background:var(--sb-active); border-color:var(--sb-active-bdr); }
          .sb-icon { width:32px; height:32px; border-radius:9px; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,.1); }
          .sb-item svg { stroke:var(--sb-txt) !important; }
          .sb-item:hover svg, .sb-item.active svg { stroke:#fff !important; }
          .sb-item.active .sb-icon { background:rgba(255,255,255,.22); }
          .sb-foot { padding:8px; border-top:1px solid var(--sb-bdr); width:100%; display:flex; flex-direction:column; align-items:center; gap:6px; }
          .sb-avatar { width:34px; height:34px; border-radius:9px; background:rgba(255,255,255,.2); display:flex; align-items:center; justify-content:center; font-size:13px; font-weight:800; color:#fff; border:1.5px solid rgba(255,255,255,.3); }
          .sb-logout { width:30px; height:30px; border-radius:8px; background:rgba(255,255,255,.12); border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; }
          .sb-logout svg { stroke:#fff !important; }

          .desk-wrap { display:flex; flex:1; flex-direction:column; height:100vh; overflow:hidden; min-width:0; }
          .topbar { height:54px; flex-shrink:0; background:var(--surf); border-bottom:1px solid var(--bdr); display:flex; align-items:center; padding:0 18px; gap:10px; }
          .tb-title { flex:1; font-size:16px; font-weight:800; color:var(--txt); letter-spacing:-.2px; }
          .tb-date { font-size:12px; color:var(--txt3); }
          .tb-sep { width:1px; height:18px; background:var(--bdr); }
          .tb-bell { width:34px; height:34px; border-radius:9px; background:var(--surf2); border:1px solid var(--bdr); display:flex; align-items:center; justify-content:center; cursor:pointer; }
          .desk-scroll { flex:1; overflow-y:auto; padding:16px; display:flex; flex-direction:column; gap:14px; }
        }

        /* ── SHARED CONTENT COMPONENTS ── */
        .panel { background:var(--surf); border-radius:var(--r); padding:20px; border:1px solid var(--bdr); }
        .panel-h { font-size:15px; font-weight:800; margin-bottom:16px; display:flex; align-items:center; justify-content:space-between; color:var(--txt); }
        .panel-h a { font-size:12px; font-weight:600; color:var(--gd); text-decoration:none; }
        .g2 { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
        .g3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:14px; }
        .g4 { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; }
        .kpi { background:var(--surf); border-radius:var(--r); padding:20px; border:1px solid var(--bdr); display:flex; flex-direction:column; gap:10px; }
        .kpi-top { display:flex; align-items:center; justify-content:space-between; }
        .kpi-ico { width:40px; height:40px; border-radius:11px; display:flex; align-items:center; justify-content:center; }
        .kpi-trend { font-size:10.5px; font-weight:700; padding:3px 8px; border-radius:7px; }
        .tu { background:rgba(0,208,132,.12); color:var(--gd); }
        .td { background:rgba(255,80,85,.12); color:var(--red); }
        .tn { background:rgba(0,0,0,.05); color:var(--txt3); }
        .kpi-val { font-size:32px; font-weight:800; line-height:1; color:var(--txt); }
        .kpi-lbl { font-size:12.5px; color:var(--txt3); font-weight:500; }
        .hero-banner { background:linear-gradient(135deg,var(--g) 0%,var(--gx) 100%); border-radius:var(--r); padding:26px 24px; color:#fff; position:relative; overflow:hidden; box-shadow:0 8px 32px rgba(0,208,132,.22); }
        .hero-banner::before { content:''; position:absolute; top:-60px; right:-40px; width:200px; height:200px; background:rgba(255,255,255,.07); border-radius:50%; pointer-events:none; }
        .hb-stats { display:flex; gap:10px; margin-top:20px; }
        .hbs { flex:1; background:rgba(255,255,255,.15); border-radius:11px; padding:11px; text-align:center; backdrop-filter:blur(6px); }
        .hbs-v { font-size:20px; font-weight:800; }
        .hbs-l { font-size:10.5px; opacity:.82; margin-top:2px; }
        .badge { display:inline-block; padding:4px 10px; border-radius:7px; font-size:11px; font-weight:700; }
        .badge-critical { background:rgba(255,80,85,.12); color:var(--red); }
        .badge-high { background:rgba(255,138,74,.14); color:var(--orange); }
        .badge-medium { background:rgba(255,202,74,.2); color:#9A6A00; }
        .badge-low { background:rgba(0,208,132,.12); color:var(--gd); }
        .badge-open { background:rgba(255,80,85,.12); color:var(--red); }
        .badge-underreview { background:rgba(74,158,255,.14); color:var(--blue); }
        .badge-resolved { background:rgba(0,208,132,.12); color:var(--gd); }
        .badge-closed { background:rgba(0,0,0,.05); color:var(--txt3); }
        .data-table { width:100%; border-collapse:collapse; }
        .data-table th { background:var(--surf2); padding:12px 14px; text-align:left; font-size:11.5px; font-weight:700; color:var(--txt3); border-bottom:1px solid var(--bdr); text-transform:uppercase; letter-spacing:.5px; }
        .data-table td { padding:13px 14px; font-size:13.5px; color:var(--txt); border-bottom:1px solid var(--bdr); }
        .data-table tr:last-child td { border-bottom:none; }
        .data-table tbody tr:hover { background:var(--surf2); }
        .tabs { display:flex; gap:8px; flex-wrap:wrap; }
        .tab { padding:9px 18px; border-radius:var(--rs); background:var(--surf2); border:1.5px solid var(--bdr); font-size:13px; font-weight:600; color:var(--txt2); cursor:pointer; transition:all .15s; }
        .tab.active { background:var(--gg); border-color:rgba(0,208,132,.3); color:var(--gd); }
        .tab:hover:not(.active) { border-color:var(--g); color:var(--gd); }
        .tab-content { display:none; }
        .tab-content.active { display:block; }
        .empty-state { text-align:center; padding:48px 24px; }
        .empty-ico { width:72px; height:72px; margin:0 auto 16px; background:var(--surf2); border-radius:50%; display:flex; align-items:center; justify-content:center; }
        .empty-title { font-size:15px; font-weight:700; color:var(--txt2); margin-bottom:6px; }
        .empty-text { font-size:13px; color:var(--txt3); }
        .chart-box { position:relative; height:260px; }
        .chart-box-sm { position:relative; height:210px; }
        @keyframes fadeUp { from { opacity:0; transform:translateY(14px); } to { opacity:1; transform:translateY(0); } }

        /* ── PROFILE-SPECIFIC ── */
        .profile-banner {
          background:linear-gradient(135deg,var(--g) 0%,var(--gx) 100%);
          border-radius:var(--r); padding:28px 24px; color:#fff;
          position:relative; overflow:hidden; box-shadow:0 8px 32px rgba(0,208,132,.22);
          display:flex; align-items:center; gap:20px;
        }
        .profile-banner::before { content:''; position:absolute; top:-60px; right:-40px; width:200px; height:200px; background:rgba(255,255,255,.07); border-radius:50%; pointer-events:none; }
        .profile-avatar-big {
          width:72px; height:72px; border-radius:20px; flex-shrink:0;
          background:rgba(255,255,255,.22); border:2px solid rgba(255,255,255,.35);
          display:flex; align-items:center; justify-content:center;
          font-size:28px; font-weight:900; color:#fff; position:relative;
        }
        .pb-info { position:relative; flex:1; min-width:0; }
        .pb-name { font-size:22px; font-weight:800; line-height:1.2; }
        .pb-email { font-size:13px; opacity:.9; margin-top:3px; }
        .pb-role { display:inline-block; margin-top:8px; padding:4px 12px; background:rgba(255,255,255,.2); border-radius:20px; font-size:11px; font-weight:700; }
        .pb-stats { display:flex; gap:10px; margin-top:16px; position:relative; }
        .pbs { flex:1; background:rgba(255,255,255,.15); border-radius:10px; padding:10px; text-align:center; backdrop-filter:blur(6px); }
        .pbs-v { font-size:18px; font-weight:800; }
        .pbs-l { font-size:10px; opacity:.85; margin-top:1px; }
        .section-title { font-size:15px; font-weight:800; color:var(--txt); margin-bottom:14px; display:flex; align-items:center; gap:10px; }
        .section-ico { width:32px; height:32px; border-radius:9px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .menu-item {
          display:flex; align-items:center; gap:14px; padding:13px 12px;
          border-radius:var(--rs); cursor:pointer; transition:all .15s;
          background:transparent; border:none; width:100%; text-align:left;
        }
        .menu-item:hover { background:var(--surf2); }
        .menu-ico { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .menu-txt { flex:1; }
        .menu-title { font-size:13.5px; font-weight:600; color:var(--txt); }
        .menu-sub { font-size:11.5px; color:var(--txt3); margin-top:2px; }
        .menu-arr { font-size:18px; color:var(--txt3); }
        .menu-badge { padding:3px 9px; border-radius:7px; font-size:11px; font-weight:700; background:rgba(0,208,132,.12); color:var(--gd); }
        .divider { height:1px; background:var(--bdr); margin:4px 0; }
        .activity-row { display:flex; align-items:center; gap:12px; padding:11px 0; border-bottom:1px solid var(--bdr); }
        .activity-row:last-child { border-bottom:none; }
        .activity-ico { width:38px; height:38px; border-radius:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .activity-info { flex:1; min-width:0; }
        .activity-title { font-size:13px; font-weight:600; color:var(--txt); }
        .activity-sub { font-size:11px; color:var(--txt3); margin-top:2px; }
        .activity-amt { font-size:13px; font-weight:700; color:var(--txt); }
        /* Modal */
        .modal { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); backdrop-filter:blur(4px); z-index:1000; align-items:center; justify-content:center; padding:24px; }
        .modal.active { display:flex; }
        .modal-box { background:var(--surf); border-radius:var(--r); padding:28px 24px; width:100%; max-width:440px; box-shadow:0 20px 60px rgba(0,0,0,.2); }
        .modal-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
        .modal-title { font-size:18px; font-weight:800; color:var(--txt); }
        .modal-close { width:30px; height:30px; border-radius:9px; background:var(--surf2); border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; }
        .form-group { margin-bottom:14px; }
        .form-label { display:block; font-size:12.5px; font-weight:600; color:var(--txt2); margin-bottom:6px; }
        .form-input { width:100%; padding:11px 14px; border:1.5px solid var(--bdr); border-radius:var(--rs); font-size:13.5px; font-family:'Inter',sans-serif; transition:border-color .15s; }
        .form-input:focus { outline:none; border-color:var(--g); box-shadow:0 0 0 3px rgba(0,208,132,.1); }
        .btn-primary { width:100%; padding:13px; background:linear-gradient(135deg,var(--g),var(--gd)); color:#fff; border:none; border-radius:var(--rs); font-size:14px; font-weight:700; cursor:pointer; margin-top:6px; transition:opacity .15s; }
        .btn-primary:hover { opacity:.9; }
        .btn-danger-full { width:100%; padding:13px; background:rgba(255,80,85,.1); color:var(--red); border:1.5px solid rgba(255,80,85,.2); border-radius:var(--rs); font-size:14px; font-weight:700; cursor:pointer; margin-top:8px; }
  </style>
</head>
<body>

<?php
function ico($p,$s='#4A5568',$z=18){return "<svg width='$z' height='$z' viewBox='0 0 24 24' fill='none' stroke='$s' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>$p</svg>";}
$iHome ="<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>";
$iBook ="<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>";
$iPay  ="<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iCrm  ="<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iGps  ="<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/>";
$iBar  ="<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>";
$iDoc  ="<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/><line x1='16' y1='13' x2='8' y2='13'/><line x1='16' y1='17' x2='8' y2='17'/>";
$iBell ="<path d='M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9'/><path d='M13.73 21a2 2 0 0 1-3.46 0'/>";
$iOut  ="<path d='M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'/><polyline points='16 17 21 12 16 7'/><line x1='21' y1='12' x2='9' y2='12'/>";
$iUser ="<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>";
$iEdit ="<path d='M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7'/><path d='M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z'/>";
$iLock ="<rect x='3' y='11' width='18' height='11' rx='2' ry='2'/><path d='M7 11V7a5 5 0 0 1 10 0v4'/>";
$iShield="<path d='M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z'/>";
$iBell2="<path d='M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9'/><path d='M13.73 21a2 2 0 0 1-3.46 0'/>";
$iPhone="<path d='M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.13 12 19.79 19.79 0 0 1 1.07 3.38 2 2 0 0 1 3.05 1.2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L7.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 21.22 16z'/>";
$iStar ="<path d='M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2'/>";
$iPay2 ="<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iTrash="<polyline points='3 6 5 6 21 6'/><path d='M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2'/>";
$iHelp ="<circle cx='12' cy='12' r='10'/><path d='M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3'/><line x1='12' y1='17' x2='12.01' y2='17'/>";
$iGlobe="<circle cx='12' cy='12' r='10'/><line x1='2' y1='12' x2='22' y2='12'/><path d='M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z'/>";
?>

<!-- ══ SIDEBAR ══════════════════════════════════════════════════════ -->
<aside class="sidebar">
  <div class="sb-logo">
    <img src="../images/envirocab_logo.png" alt="EnviroCab" onerror="this.style.display='none'">
  </div>
  <nav class="sb-nav">
    <div class="sb-label">Main</div>
    <a href="dashboard.php" class="sb-item"><div class="sb-icon"><?=ico($iHome)?></div><span>Dashboard</span></a>
    <a href="booking_system.php" class="sb-item"><div class="sb-icon"><?=ico($iBook)?></div><span>Booking System</span></a>
    <a href="payment_fares.php" class="sb-item"><div class="sb-icon"><?=ico($iPay)?></div><span>Payment &amp; Fares</span></a>
    <a href="crm_system.php" class="sb-item"><div class="sb-icon"><?=ico($iCrm)?></div><span>CRM</span></a>
    <a href="gps_tracking.php" class="sb-item"><div class="sb-icon"><?=ico($iGps)?></div><span>GPS Tracking</span></a>
    <div class="sb-label">Analytics</div>
    <a href="transport_analytics.php" class="sb-item"><div class="sb-icon"><?=ico($iBar)?></div><span>Analytics &amp; KPIs</span></a>
    <a href="sop_compliance.php" class="sb-item"><div class="sb-icon"><?=ico($iDoc)?></div><span>SOP Compliance</span></a>
    <div class="sb-label">Account</div>
    <a href="profile.php" class="sb-item active"><div class="sb-icon"><?=ico($iUser)?></div><span>Profile</span></a>
  </nav>
  <div class="sb-foot">
    <div class="sb-avatar"><?=$userInitial?></div>
    <div style="flex:1;min-width:0">
      <div class="sb-uname"><?=$userName?></div>
      <div class="sb-urole"><?=$userRole?></div>
    </div>
    <button class="sb-logout" onclick="if(confirm('Logout?'))window.location.href='../auth/logout.php'" title="Logout"><?=ico($iOut,'#EF4444',15)?></button>
  </div>
</aside>

<!-- ══ DESKTOP MAIN ════════════════════════════════════════════════ -->
<div class="desk-wrap">
  <header class="topbar">
    <div class="tb-title">Profile</div>
    <div class="tb-date"><?=date('l, F j, Y')?></div>
    <div class="tb-sep"></div>
    <div class="tb-bell" onclick="openEditModal()"><?=ico($iEdit,'#4A5568')?></div>
  </header>
  <div class="desk-scroll">

    <!-- Profile Banner -->
    <div class="profile-banner">
      <div class="profile-avatar-big"><?=$userInitial?></div>
      <div class="pb-info">
        <div class="pb-name"><?=$userName?></div>
        <div class="pb-email"><?=$userEmail?></div>
        <div class="pb-role"><?=$userRole?></div>
      </div>
      <div style="position:relative">
        <div class="pb-stats">
          <div class="pbs"><div class="pbs-v"><?=$userStats['total_bookings']?></div><div class="pbs-l">Bookings</div></div>
          <div class="pbs"><div class="pbs-v">₱<?=number_format($userStats['total_spent']/1000,1)?>K</div><div class="pbs-l">Spent</div></div>
          <div class="pbs"><div class="pbs-v"><?=$userStats['completed_trips']?></div><div class="pbs-l">Trips</div></div>
          <div class="pbs"><div class="pbs-v"><?=number_format($userStats['avg_rating'],1)?> ★</div><div class="pbs-l">Rating</div></div>
        </div>
        <div style="font-size:12px;opacity:.8;margin-top:8px;text-align:right">Member since <?=$userStats['member_since']?></div>
      </div>
    </div>

    <!-- Two column layout -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

      <!-- Left: Account Info + Settings -->
      <div style="display:flex;flex-direction:column;gap:16px">
        <div class="panel">
          <div class="section-title">
            <div class="section-ico" style="background:rgba(0,208,132,.12)"><?=ico($iUser,'#00D084')?></div>
            Account Information
          </div>
          <button class="menu-item" onclick="openEditModal()">
            <div class="menu-ico" style="background:rgba(74,158,255,.12)"><?=ico($iUser,'#4A9EFF')?></div>
            <div class="menu-txt"><div class="menu-title">Personal Information</div><div class="menu-sub"><?=$userName?></div></div>
            <span class="menu-arr">›</span>
          </button>
          <button class="menu-item" onclick="alert('Phone: <?=htmlspecialchars($userPhone ?: "Not set")?>')"
            <div class="menu-ico" style="background:rgba(155,127,255,.12)"><?=ico($iPhone,'#9B7FFF')?></div>
            <div class="menu-txt"><div class="menu-title">Contact Details</div><div class="menu-sub"><?=$userPhone?:'Add phone number'?></div></div>
            <span class="menu-arr">›</span>
          </button>
          <button class="menu-item">
            <div class="menu-ico" style="background:rgba(0,208,132,.12)"><?=ico("<path d='M22 11.08V12a10 10 0 1 1-5.93-9.14'/><polyline points='22 4 12 14.01 9 11.01'/>", '#00D084')?></div>
            <div class="menu-txt"><div class="menu-title">Account Status</div><div class="menu-sub">Member since <?=$userStats['member_since']?></div></div>
            <span class="menu-badge"><?=$userStatus?></span>
          </button>
        </div>

        <div class="panel">
          <div class="section-title">
            <div class="section-ico" style="background:rgba(74,158,255,.12)"><?=ico($iEdit,'#4A9EFF')?></div>
            Settings
          </div>
          <button class="menu-item" onclick="openPasswordModal()">
            <div class="menu-ico" style="background:rgba(255,138,74,.12)"><?=ico($iLock,'#FF8A4A')?></div>
            <div class="menu-txt"><div class="menu-title">Change Password</div><div class="menu-sub">Update your password</div></div>
            <span class="menu-arr">›</span>
          </button>
          <button class="menu-item" onclick="alert('Notifications – Coming Soon!')">
            <div class="menu-ico" style="background:rgba(155,127,255,.12)"><?=ico($iBell2,'#9B7FFF')?></div>
            <div class="menu-txt"><div class="menu-title">Notifications</div><div class="menu-sub">Manage alerts</div></div>
            <span class="menu-arr">›</span>
          </button>
          <button class="menu-item" onclick="alert('Privacy – Coming Soon!')">
            <div class="menu-ico" style="background:rgba(74,158,255,.12)"><?=ico($iShield,'#4A9EFF')?></div>
            <div class="menu-txt"><div class="menu-title">Privacy &amp; Security</div><div class="menu-sub">Control your privacy</div></div>
            <span class="menu-arr">›</span>
          </button>
          <button class="menu-item" onclick="alert('Language: English')">
            <div class="menu-ico" style="background:rgba(255,202,74,.15)"><?=ico($iGlobe,'#FFCA4A')?></div>
            <div class="menu-txt"><div class="menu-title">Language</div><div class="menu-sub">English</div></div>
            <span class="menu-arr">›</span>
          </button>
        </div>
      </div>

      <!-- Right: Recent Activity + Payment + Support -->
      <div style="display:flex;flex-direction:column;gap:16px">
        <div class="panel">
          <div class="section-title">
            <div class="section-ico" style="background:rgba(155,127,255,.12)"><?=ico("<polyline points='22 12 18 12 15 21 9 3 6 12 2 12'/>", '#9B7FFF')?></div>
            Recent Activity
          </div>
          <?php if(!empty($recentBookings)):
            $cols=[['rgba(0,208,132,.12)','#00D084'],['rgba(74,158,255,.12)','#4A9EFF'],['rgba(255,138,74,.12)','#FF8A4A'],['rgba(155,127,255,.12)','#9B7FFF'],['rgba(255,202,74,.15)','#FFCA4A']];
            foreach($recentBookings as $i=>$b): [$bg,$cl]=$cols[$i%5]; ?>
          <div class="activity-row">
            <div class="activity-ico" style="background:<?=$bg?>"><?=ico($iBook,$cl)?></div>
            <div class="activity-info">
              <div class="activity-title"><?=htmlspecialchars($b['service_name']??'Service')?></div>
              <div class="activity-sub"><?=$b['booking_reference']?> · <?=date('M d',strtotime($b['booking_date']))?></div>
            </div>
            <div class="activity-amt">₱<?=number_format($b['total_amount'],0)?></div>
          </div>
          <?php endforeach; else: ?>
          <div class="empty-state"><div class="empty-ico"><?=ico("<circle cx='12' cy='12' r='10'/><line x1='12' y1='8' x2='12' y2='12'/><line x1='12' y1='16' x2='12.01' y2='16'/>", '#7A9A8E', 28)?></div><div class="empty-title">No recent activity</div></div>
          <?php endif;?>
        </div>

        <div class="panel">
          <div class="section-title">
            <div class="section-ico" style="background:rgba(74,158,255,.12)"><?=ico($iPay2,'#4A9EFF')?></div>
            Payment &amp; Billing
          </div>
          <button class="menu-item" onclick="alert('Payment Methods – Coming Soon!')">
            <div class="menu-ico" style="background:rgba(74,158,255,.12)"><?=ico($iPay2,'#4A9EFF')?></div>
            <div class="menu-txt"><div class="menu-title">Payment Methods</div><div class="menu-sub">Manage cards &amp; payments</div></div>
            <span class="menu-arr">›</span>
          </button>
          <button class="menu-item" onclick="alert('Transaction History – Coming Soon!')">
            <div class="menu-ico" style="background:rgba(0,208,132,.12)"><?=ico("<line x1='12' y1='1' x2='12' y2='23'/><path d='M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6'/>", '#00D084')?></div>
            <div class="menu-txt"><div class="menu-title">Transaction History</div><div class="menu-sub">View all transactions</div></div>
            <span class="menu-arr">›</span>
          </button>
        </div>

        <div class="panel">
          <div class="section-title">
            <div class="section-ico" style="background:rgba(255,138,74,.12)"><?=ico($iHelp,'#FF8A4A')?></div>
            Support &amp; Help
          </div>
          <button class="menu-item" onclick="alert('Help Center – Coming Soon!')">
            <div class="menu-ico" style="background:rgba(255,138,74,.12)"><?=ico($iDoc,'#FF8A4A')?></div>
            <div class="menu-txt"><div class="menu-title">Help Center</div><div class="menu-sub">FAQs &amp; guides</div></div>
            <span class="menu-arr">›</span>
          </button>
          <button class="menu-item" onclick="alert('Support: support@envirocab.com')">
            <div class="menu-ico" style="background:rgba(74,158,255,.12)"><?=ico("<path d='M21 11.5a8.38 8.38 0 0 1-.9 3.8A8.5 8.5 0 0 1 12 19.3a8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7A8.38 8.38 0 0 1 4 11.5 8.5 8.5 0 0 1 12 3h.5A8.48 8.48 0 0 1 21 11v.5z'/>", '#4A9EFF')?></div>
            <div class="menu-txt"><div class="menu-title">Contact Support</div><div class="menu-sub">Get help from our team</div></div>
            <span class="menu-arr">›</span>
          </button>
          <div class="divider"></div>
          <button class="menu-item" onclick="if(confirm('Logout?'))window.location.href='../auth/logout.php'">
            <div class="menu-ico" style="background:rgba(255,138,74,.12)"><?=ico($iOut,'#FF8A4A')?></div>
            <div class="menu-txt"><div class="menu-title">Logout</div><div class="menu-sub">Sign out of your account</div></div>
            <span class="menu-arr">›</span>
          </button>
        </div>
      </div>
    </div>

  </div><!-- desk-scroll -->
</div><!-- desk-wrap -->

<!-- ══ MOBILE SHELL ════════════════════════════════════════════════ -->
<div class="mob-shell">
  <div class="mob-header">
    <button onclick="window.location.href='dashboard.php'" style="background:none;border:none;cursor:pointer;display:flex;align-items:center"><?=ico("<path d='M19 12H5'/><path d='M12 19l-7-7 7-7'/>", '#0E1E17')?></button>
    <div class="mob-title">Profile</div>
    <button onclick="openEditModal()" style="background:none;border:none;cursor:pointer;display:flex;align-items:center"><?=ico($iEdit,'#0E1E17')?></button>
  </div>
  <div class="mob-body">
    <div style="background:linear-gradient(135deg,var(--g),var(--gx));border-radius:var(--r);padding:24px;color:#fff;text-align:center">
      <div style="width:72px;height:72px;border-radius:20px;background:rgba(255,255,255,.22);border:2px solid rgba(255,255,255,.35);display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:900;margin:0 auto 12px"><?=$userInitial?></div>
      <div style="font-size:20px;font-weight:800"><?=$userName?></div>
      <div style="font-size:13px;opacity:.9;margin-top:3px"><?=$userEmail?></div>
      <div style="display:inline-block;margin-top:8px;padding:4px 12px;background:rgba(255,255,255,.2);border-radius:20px;font-size:11px;font-weight:700"><?=$userRole?></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:16px">
        <div style="background:rgba(255,255,255,.15);border-radius:10px;padding:10px"><div style="font-size:18px;font-weight:800"><?=$userStats['total_bookings']?></div><div style="font-size:10px;opacity:.85">Bookings</div></div>
        <div style="background:rgba(255,255,255,.15);border-radius:10px;padding:10px"><div style="font-size:18px;font-weight:800">₱<?=number_format($userStats['total_spent']/1000,1)?>K</div><div style="font-size:10px;opacity:.85">Spent</div></div>
      </div>
    </div>
    <?php
    $sections=[
      ['Account',[$iUser,'#00D084','Personal Info','Update your details','openEditModal()'],[$iPhone,'#9B7FFF','Contact Details',$userPhone?:'Not set','alert(\'Contact\')'],[$iLock,'#FF8A4A','Change Password','Update password','openPasswordModal()']],
    ];
    ?>
    <div style="background:var(--surf);border-radius:var(--rs);padding:4px;border:1px solid var(--bdr)">
      <button class="menu-item" onclick="openEditModal()">
        <div class="menu-ico" style="background:rgba(74,158,255,.12)"><?=ico($iUser,'#4A9EFF')?></div>
        <div class="menu-txt"><div class="menu-title">Personal Information</div><div class="menu-sub"><?=$userName?></div></div>
        <span class="menu-arr">›</span>
      </button>
      <button class="menu-item" onclick="openPasswordModal()">
        <div class="menu-ico" style="background:rgba(255,138,74,.12)"><?=ico($iLock,'#FF8A4A')?></div>
        <div class="menu-txt"><div class="menu-title">Change Password</div><div class="menu-sub">Update your password</div></div>
        <span class="menu-arr">›</span>
      </button>
      <button class="menu-item" onclick="if(confirm('Logout?'))window.location.href='../auth/logout.php'">
        <div class="menu-ico" style="background:rgba(255,138,74,.12)"><?=ico($iOut,'#FF8A4A')?></div>
        <div class="menu-txt"><div class="menu-title">Logout</div><div class="menu-sub">Sign out</div></div>
        <span class="menu-arr">›</span>
      </button>
    </div>
  </div>
  <nav class="mob-nav">
    <button class="mn" onclick="window.location.href='dashboard.php'"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg><span class="mn-lbl">Home</span></button>
    <button class="mn" onclick="window.location.href='booking_system.php'"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/></svg><span class="mn-lbl">Book</span></button>
    <button class="mn" onclick="window.location.href='gps_tracking.php'"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg><span class="mn-lbl">Track</span></button>
    <button class="mn active"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span class="mn-lbl">Profile</span></button>
  </nav>
</div>

<!-- Modals -->
<div id="editModal" class="modal">
  <div class="modal-box">
    <div class="modal-head">
      <div class="modal-title">Edit Profile</div>
      <button class="modal-close" onclick="closeModal('editModal')"><?=ico("<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>", '#4A5568')?></button>
    </div>
    <div class="form-group"><label class="form-label">Full Name</label><input type="text" class="form-input" id="editFullName" value="<?=htmlspecialchars($userData['full_name']??'')?>" required></div>
    <div class="form-group"><label class="form-label">Email Address</label><input type="email" class="form-input" id="editEmail" value="<?=$userEmail?>"></div>
    <div class="form-group"><label class="form-label">Phone Number</label><input type="tel" class="form-input" id="editPhone" value="<?=$userPhone?>"></div>
    <button class="btn-primary" onclick="updateProfile()">Save Changes</button>
  </div>
</div>

<div id="pwModal" class="modal">
  <div class="modal-box">
    <div class="modal-head">
      <div class="modal-title">Change Password</div>
      <button class="modal-close" onclick="closeModal('pwModal')"><?=ico("<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>", '#4A5568')?></button>
    </div>
    <div class="form-group"><label class="form-label">Current Password</label><input type="password" class="form-input" id="curPw" required></div>
    <div class="form-group"><label class="form-label">New Password</label><input type="password" class="form-input" id="newPw" required minlength="6"></div>
    <div class="form-group"><label class="form-label">Confirm New Password</label><input type="password" class="form-input" id="conPw" required minlength="6"></div>
    <button class="btn-primary" onclick="changePassword()">Update Password</button>
  </div>
</div>

<script>
function openEditModal()  { document.getElementById('editModal').classList.add('active'); }
function openPasswordModal(){ document.getElementById('pwModal').classList.add('active'); }
function closeModal(id)   { document.getElementById(id).classList.remove('active'); }
window.onclick = e => { if(e.target.classList.contains('modal')) e.target.classList.remove('active'); };

function updateProfile() {
  const fd = new FormData();
  fd.append('full_name', document.getElementById('editFullName').value);
  fd.append('email', document.getElementById('editEmail').value);
  fd.append('phone', document.getElementById('editPhone').value);
  fetch('update_profile.php', {method:'POST',body:fd})
    .then(r=>r.json()).then(d=>{ if(d.success){alert(d.message);closeModal('editModal');location.reload();}else alert('Error: '+d.message); })
    .catch(()=>alert('Error updating profile'));
}

function changePassword() {
  const np = document.getElementById('newPw').value;
  const cp = document.getElementById('conPw').value;
  if(np!==cp){alert('Passwords do not match!');return;}
  const fd = new FormData();
  fd.append('current_password', document.getElementById('curPw').value);
  fd.append('new_password', np);
  fd.append('confirm_password', cp);
  fetch('change_password.php', {method:'POST',body:fd})
    .then(r=>r.json()).then(d=>{ if(d.success){alert(d.message);closeModal('pwModal');}else alert('Error: '+d.message); })
    .catch(()=>alert('Error changing password'));
}
</script>
<?php include __DIR__ . '/chat_widget.php'; ?>
</body>
</html>