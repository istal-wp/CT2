<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../auth/login.php'); exit;
}

define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) { $qs = http_build_query($params); $qs = str_replace(['%5B','%5D'],['[',']'],$qs); $url .= '?' . $qs; }
    $ch = curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json','Accept: application/json']]);
    $resp = curl_exec($ch); curl_close($ch);
    $d = json_decode($resp, true);
    return is_array($d) ? $d : [];
}

// ── Date helpers ────────────────────────────────────────────────────────────────
$today          = date('Y-m-d');
$last7          = date('Y-m-d', strtotime('-6 days'));
$last30         = date('Y-m-d', strtotime('-29 days'));
$thisMonthStart = date('Y-m-01');
$lastMonthStart = date('Y-m-01', strtotime('-1 month'));
$lastMonthEnd   = date('Y-m-t',  strtotime('-1 month'));
$thisYearStart  = date('Y-01-01');

// ── AJAX handler ────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    try {
        switch ($action) {

            case 'get_date_range_analytics': {
                $from = $_POST['from'] ?? date('Y-m-d', strtotime('-29 days'));
                $to   = $_POST['to']   ?? date('Y-m-d');
                $bks  = sb('core2_bookings',['select'=>'booking_id,booking_reference,booking_date,booking_status,payment_status,total_amount,service_id,customer_id','booking_date'=>'gte.'.$from.',lte.'.$to,'order'=>'booking_date.asc']);
                $rev = $comp = $canc = $inprog = $pending = 0;
                $byDate = []; $bkIds = [];
                foreach ($bks as $b) {
                    $st = $b['booking_status'] ?? '';
                    $amt = (float)($b['total_amount'] ?? 0);
                    if ($st==='Completed') { $rev += $amt; $comp++; }
                    if ($st==='Cancelled') $canc++;
                    if ($st==='In Progress') $inprog++;
                    if ($st==='Pending') $pending++;
                    $d = substr($b['booking_date']??'',0,10);
                    if ($d) { if(!isset($byDate[$d])) $byDate[$d]=0; if($st==='Completed') $byDate[$d]+=$amt; }
                    if (!empty($b['booking_id'])) $bkIds[] = (int)$b['booking_id'];
                }
                ksort($byDate);
                $daily = []; foreach ($byDate as $d=>$r) $daily[]=compact('d','r');
                $total = count($bks);
                echo json_encode(['success'=>true,'revenue'=>$rev,'bookings'=>$total,'completed'=>$comp,'cancelled'=>$canc,'in_progress'=>$inprog,'pending'=>$pending,'completion_rate'=>$total>0?round($comp/$total*100,1):0,'cancellation_rate'=>$total>0?round($canc/$total*100,1):0,'daily'=>$daily]);
                break;
            }

            case 'get_driver_leaderboard': {
                $from = $_POST['from'] ?? date('Y-m-d', strtotime('-29 days'));
                $to   = $_POST['to']   ?? date('Y-m-d');
                $rides = sb('core2_rides',['select'=>'ride_id,driver_id,booking_id,ride_status','created_at'=>'gte.'.$from.'T00:00:00,lte.'.$to.'T23:59:59']);
                $bids = array_unique(array_filter(array_column($rides,'booking_id')));
                $earnMap = [];
                if (!empty($bids)) {
                    $cb = sb('core2_bookings',['select'=>'booking_id,total_amount','booking_status'=>'eq.Completed','booking_id'=>'in.('.implode(',',$bids).')']);
                    foreach ($cb as $b) $earnMap[(int)$b['booking_id']] = (float)($b['total_amount']??0);
                }
                $dids = array_unique(array_filter(array_column($rides,'driver_id')));
                $dmap = [];
                if (!empty($dids)) {
                    $dr = sb('core1_drivers',['select'=>'id,driver_name,status,core2_driver_id,wallet_balance','core2_driver_id'=>'in.('.implode(',',$dids).')']);
                    foreach ($dr as $d) $dmap[(int)($d['core2_driver_id']??0)] = $d;
                    // Fallback: match by core1_drivers.id directly
                    if (empty($dmap)) {
                        $dr2 = sb('core1_drivers',['select'=>'id,driver_name,status,core2_driver_id,wallet_balance','id'=>'in.('.implode(',',$dids).')']);
                        foreach ($dr2 as $d) $dmap[(int)$d['id']] = $d;
                    }
                }
                // Ratings
                $ratMap = [];
                if (!empty($dids)) {
                    $rtd = sb('core2_ratings',['select'=>'driver_id,rating_value','driver_id'=>'in.('.implode(',',$dids).')']);
                    foreach ($rtd as $r) { $did=(int)$r['driver_id']; if(!isset($ratMap[$did])) $ratMap[$did]=['s'=>0,'c'=>0]; $ratMap[$did]['s']+=(float)$r['rating_value']; $ratMap[$did]['c']++; }
                }
                $ds = [];
                foreach ($rides as $rd) {
                    $did = (int)($rd['driver_id']??0); if(!$did) continue;
                    if (!isset($ds[$did])) $ds[$did]=['trips'=>0,'completed'=>0,'cancelled'=>0,'revenue'=>0];
                    $ds[$did]['trips']++;
                    $st = $rd['ride_status']??'';
                    if ($st==='Completed') { $ds[$did]['completed']++; $ds[$did]['revenue'] += $earnMap[(int)($rd['booking_id']??0)] ?? 0; }
                    if ($st==='Cancelled') $ds[$did]['cancelled']++;
                }
                uasort($ds, fn($a,$b)=>$b['revenue']<=>$a['revenue']);
                $list = []; $rank=1;
                foreach ($ds as $did=>$st) {
                    if ($rank>15) break;
                    $info = $dmap[$did] ?? [];
                    $rat  = isset($ratMap[$did]) && $ratMap[$did]['c']>0 ? round($ratMap[$did]['s']/$ratMap[$did]['c'],1) : 0;
                    $compRate = $st['trips']>0 ? round($st['completed']/$st['trips']*100) : 0;
                    $list[] = ['rank'=>$rank++,'name'=>$info['driver_name']??('Driver #'.$did),'status'=>$info['status']??'Unknown','trips'=>$st['trips'],'completed'=>$st['completed'],'cancelled'=>$st['cancelled'],'revenue'=>$st['revenue'],'rating'=>$rat,'wallet'=>$info['wallet_balance']??0,'comp_rate'=>$compRate];
                }
                echo json_encode(['success'=>true,'drivers'=>$list]);
                break;
            }

            case 'get_revenue_breakdown': {
                $from = $_POST['from'] ?? date('Y-m-d', strtotime('-29 days'));
                $to   = $_POST['to']   ?? date('Y-m-d');
                $bks  = sb('core2_bookings',['select'=>'service_id,total_amount,booking_status','booking_date'=>'gte.'.$from.',lte.'.$to,'booking_status'=>'eq.Completed']);
                $svcIds = array_unique(array_filter(array_column($bks,'service_id')));
                $svcMap = [];
                if (!empty($svcIds)) {
                    $svcs = sb('core2_services',['select'=>'service_id,service_name,service_category','service_id'=>'in.('.implode(',',$svcIds).')']);
                    foreach ($svcs as $s) $svcMap[(int)$s['service_id']] = $s;
                }
                $byService = []; $total = 0;
                foreach ($bks as $b) {
                    $sid = (int)($b['service_id']??0);
                    $sn  = $svcMap[$sid]['service_name'] ?? 'Service #'.$sid;
                    $amt = (float)($b['total_amount']??0);
                    if (!isset($byService[$sn])) $byService[$sn]=0;
                    $byService[$sn]+=$amt; $total+=$amt;
                }
                arsort($byService);
                $breakdown = [];
                foreach ($byService as $name=>$amt) $breakdown[]=compact('name','amt');
                echo json_encode(['success'=>true,'breakdown'=>$breakdown,'total'=>$total]);
                break;
            }

            case 'get_customer_stats': {
                $from = $_POST['from'] ?? date('Y-m-d', strtotime('-29 days'));
                $to   = $_POST['to']   ?? date('Y-m-d');
                $bks  = sb('core2_bookings',['select'=>'customer_id,total_amount,booking_status','booking_date'=>'gte.'.$from.',lte.'.$to]);
                $custIds = array_unique(array_filter(array_column($bks,'customer_id')));
                $custMap = [];
                if (!empty($custIds)) {
                    $custs = sb('core2_customers',['select'=>'customer_id,name,customer_type,status','customer_id'=>'in.('.implode(',',$custIds).')']);
                    foreach ($custs as $c) $custMap[(int)$c['customer_id']] = $c;
                }
                $byType = []; $topCustomers = [];
                foreach ($bks as $b) {
                    $cid = (int)($b['customer_id']??0);
                    $ct  = $custMap[$cid]['customer_type'] ?? 'Unknown';
                    $amt = (float)($b['total_amount']??0);
                    if (!isset($byType[$ct])) $byType[$ct]=0; $byType[$ct]++;
                    if (!isset($topCustomers[$cid])) $topCustomers[$cid]=['name'=>$custMap[$cid]['name']??'Guest','type'=>$ct,'bookings'=>0,'revenue'=>0];
                    $topCustomers[$cid]['bookings']++;
                    if ($b['booking_status']==='Completed') $topCustomers[$cid]['revenue']+=$amt;
                }
                uasort($topCustomers, fn($a,$b)=>$b['revenue']<=>$a['revenue']);
                $topList = array_slice(array_values($topCustomers),0,10);
                $typeData = []; foreach ($byType as $t=>$c) $typeData[]=compact('t','c');
                echo json_encode(['success'=>true,'by_type'=>$typeData,'top_customers'=>$topList]);
                break;
            }

            case 'get_operational_metrics': {
                // Cancellation reasons from reports
                $reports = sb('core2_reports',['select'=>'report_type,severity,status,reported_at','order'=>'reported_at.desc','limit'=>'100']);
                $byType = []; $bySeverity = [];
                foreach ($reports as $r) {
                    $t = $r['report_type']??'Other'; if(!isset($byType[$t])) $byType[$t]=0; $byType[$t]++;
                    $s = $r['severity']??'Medium'; if(!isset($bySeverity[$s])) $bySeverity[$s]=0; $bySeverity[$s]++;
                }
                // Maintenance issues
                $maint = sb('core1_maintenance_requests',['select'=>'issue_type,status','order'=>'reported_at.desc','limit'=>'50']);
                $maintByType = []; $maintByStatus = [];
                foreach ($maint as $m) {
                    $t=$m['issue_type']??'Other'; if(!isset($maintByType[$t])) $maintByType[$t]=0; $maintByType[$t]++;
                    $s=$m['status']??'Pending'; if(!isset($maintByStatus[$s])) $maintByStatus[$s]=0; $maintByStatus[$s]++;
                }
                $reportsList = []; foreach($byType as $t=>$c) $reportsList[]=compact('t','c');
                $maintList = []; foreach($maintByType as $t=>$c) $maintList[]=compact('t','c');
                echo json_encode(['success'=>true,'report_types'=>$reportsList,'report_severity'=>array_values(array_map(fn($s,$c)=>['s'=>$s,'c'=>$c],array_keys($bySeverity),$bySeverity)),'maint_types'=>$maintList,'maint_status'=>array_values(array_map(fn($s,$c)=>['s'=>$s,'c'=>$c],array_keys($maintByStatus),$maintByStatus)),'total_reports'=>count($reports),'total_maint'=>count($maint)]);
                break;
            }

            case 'export_csv': {
                $from = $_POST['from'] ?? date('Y-m-d', strtotime('-29 days'));
                $to   = $_POST['to']   ?? date('Y-m-d');
                $type = $_POST['type'] ?? 'bookings';
                if ($type==='bookings') {
                    $rows = sb('core2_bookings',['select'=>'booking_reference,booking_date,booking_status,payment_status,total_amount,service_id','booking_date'=>'gte.'.$from.',lte.'.$to,'order'=>'booking_date.desc']);
                    $csv = "Reference,Date,Status,Payment Status,Amount\n";
                    foreach ($rows as $r) $csv .= '"'.($r['booking_reference']??'').'","'.($r['booking_date']??'').'","'.($r['booking_status']??'').'","'.($r['payment_status']??'').'","'.($r['total_amount']??'')."\"\n";
                } else {
                    $rides = sb('core2_rides',['select'=>'ride_id,driver_id,ride_status,start_time,end_time,start_location,end_location','created_at'=>'gte.'.$from.'T00:00:00,lte.'.$to.'T23:59:59','order'=>'start_time.desc']);
                    $csv = "Ride ID,Driver ID,Status,Start Time,End Time,Start Location,End Location\n";
                    foreach ($rides as $r) $csv .= '"'.($r['ride_id']??'').'","'.($r['driver_id']??'').'","'.($r['ride_status']??'').'","'.($r['start_time']??'').'","'.($r['end_time']??'').'","'.str_replace('"','""',$r['start_location']??'').'","'.str_replace('"','""',$r['end_location']??'')."\"\n";
                }
                echo json_encode(['success'=>true,'csv'=>$csv,'filename'=>"analytics_{$type}_{$from}_to_{$to}.csv"]);
                break;
            }

            case 'export_pdf': {
                $from = $_POST['from'] ?? date('Y-m-d', strtotime('-29 days'));
                $to   = $_POST['to']   ?? date('Y-m-d');
                // For now send as JSON to be rendered client-side
                echo json_encode(['success'=>true,'message'=>'PDF export triggered','from'=>$from,'to'=>$to]);
                break;
            }

            default:
                echo json_encode(['success'=>false,'message'=>'Unknown action']);
        }
    } catch (Exception $e) {
        echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
    }
    exit;
}

// ── Page data load ───────────────────────────────────────────────────────────────
$totalRevenue=$totalTrips=$totalBookings=$avgFare=$activeDrivers=$activeVehicles=$customerCount=0;
$completionRate=$cancellationRate=$paymentSuccessRate=$avgRating=$revenueGrowth=$tripGrowth=0;
$ratingCount=0;
$dailyRevData=$dailyTripData=$statusData=$payMethodData=$topDriversData=$peakHourData=$serviceData=[];
$cancReasonData=[];

try {
    // Revenue 30d
    $paidBks = sb('core2_bookings',['select'=>'total_amount,booking_date','booking_status'=>'eq.Completed','booking_date'=>'gte.'.$last30]);
    $totalRevenue = array_sum(array_column($paidBks,'total_amount'));

    // Trips & bookings
    $rides = sb('core2_rides',['select'=>'ride_id,driver_id,booking_id,created_at,start_time,end_time,ride_status','created_at'=>'gte.'.$last30.'T00:00:00']);
    $totalTrips = count($rides);

    $allBks = sb('core2_bookings',['select'=>'booking_id,booking_status,payment_status,total_amount,service_id,booking_date,customer_id','booking_date'=>'gte.'.$last30,'order'=>'booking_date.asc']);
    $totalBookings = count($allBks);
    $avgFare = $totalTrips>0 ? $totalRevenue/$totalTrips : 0;

    // Rates
    if ($totalBookings>0) {
        $comp=0; $canc=0; $paid=0;
        foreach ($allBks as $b) {
            $s = $b['booking_status']??'';
            if ($s==='Completed') { $comp++; $paid++; }
            if ($s==='Cancelled') $canc++;
            if ($s==='Confirmed') $paid++;
        }
        $completionRate   = round($comp/$totalBookings*100,1);
        $cancellationRate = round($canc/$totalBookings*100,1);
        $paymentSuccessRate = round($paid/$totalBookings*100,1);
    }

    // Ratings
    $ratRows = sb('core2_ratings',['select'=>'rating_value','created_at'=>'gte.'.$last30.'T00:00:00']);
    $ratingCount = count($ratRows);
    $avgRating = $ratingCount>0 ? round(array_sum(array_column($ratRows,'rating_value'))/$ratingCount,1) : 0;

    // Fleet
    $activeDrivers  = count(sb('core1_drivers',  ['select'=>'id','status'=>'neq.Offline']));
    $activeVehicles = count(sb('core1_vehicles',  ['select'=>'id']));
    $customerCount  = count(sb('core2_customers', ['select'=>'customer_id']));

    // Monthly growth
    $curMonBks = sb('core2_bookings',['select'=>'total_amount','booking_status'=>'eq.Completed','booking_date'=>'gte.'.$thisMonthStart]);
    $curMonRev  = array_sum(array_column($curMonBks,'total_amount'));
    $lastMonBks = sb('core2_bookings',['select'=>'total_amount','booking_status'=>'eq.Completed','booking_date'=>'gte.'.$lastMonthStart.',lte.'.$lastMonthEnd]);
    $lastMonRev = array_sum(array_column($lastMonBks,'total_amount'));
    $revenueGrowth = $lastMonRev>0 ? round(($curMonRev-$lastMonRev)/$lastMonRev*100,1) : 0;

    $curMonTrips  = count(sb('core2_rides',['select'=>'ride_id','created_at'=>'gte.'.$thisMonthStart.'T00:00:00']));
    $lastMonTrips = count(sb('core2_rides',['select'=>'ride_id','created_at'=>'gte.'.$lastMonthStart.'T00:00:00,lte.'.$lastMonthEnd.'T23:59:59']));
    $tripGrowth = $lastMonTrips>0 ? round(($curMonTrips-$lastMonTrips)/$lastMonTrips*100,1) : 0;

    // Daily Revenue (7d)
    $revByDate = [];
    foreach ($paidBks as $b) { $d=substr($b['booking_date'],0,10); if(!isset($revByDate[$d])) $revByDate[$d]=0; $revByDate[$d]+=(float)($b['total_amount']??0); }
    $dailyRevData = [];
    for ($i=6;$i>=0;$i--) { $d=date('Y-m-d',strtotime("-$i days")); $dailyRevData[]=['date'=>$d,'rev'=>$revByDate[$d]??0]; }

    // Daily Trips (7d)
    $tripByDate = [];
    foreach ($rides as $rd) { $d=substr($rd['created_at']??'',0,10); if($d){if(!isset($tripByDate[$d])) $tripByDate[$d]=0; $tripByDate[$d]++;} }
    $dailyTripData = [];
    for ($i=6;$i>=0;$i--) { $d=date('Y-m-d',strtotime("-$i days")); $dailyTripData[]=['date'=>$d,'count'=>$tripByDate[$d]??0]; }

    // Status breakdown
    $sc = [];
    foreach ($allBks as $b) { $s=$b['booking_status']??'Unknown'; if(!isset($sc[$s])) $sc[$s]=0; $sc[$s]++; }
    foreach ($sc as $s=>$c) $statusData[]=['status'=>$s,'count'=>$c];

    // Payment methods
    $pm = [];
    foreach ($allBks as $b) { $m=$b['payment_status']??'Unknown'; if(!isset($pm[$m])) $pm[$m]=0; $pm[$m]++; }
    foreach ($pm as $m=>$c) $payMethodData[]=['method'=>$m,'count'=>$c];
    usort($payMethodData,fn($a,$b)=>$b['count']<=>$a['count']);

    // Peak hours
    $hc = array_fill(0,24,0);
    foreach ($rides as $rd) { $ts = $rd['start_time']??($rd['created_at']??null); if($ts){ $h=(int)date('G',strtotime($ts)); if($h>=0&&$h<24) $hc[$h]++; } }
    for ($h=0;$h<24;$h++) $peakHourData[]=['hour'=>$h,'count'=>$hc[$h]];

    // Service breakdown
    $svcs = sb('core2_services',['select'=>'service_id,service_name']);
    $svcMap = [];
    foreach ($svcs as $s) $svcMap[(int)$s['service_id']] = $s['service_name']??'Unknown';
    $svcCnt = [];
    foreach ($allBks as $b) { $sid=(int)($b['service_id']??0); $sn=$svcMap[$sid]??('Service #'.$sid); if(!isset($svcCnt[$sn])) $svcCnt[$sn]=0; $svcCnt[$sn]++; }
    arsort($svcCnt);
    foreach ($svcCnt as $n=>$c) $serviceData[]=['name'=>$n,'count'=>$c];

    // Top drivers
    $ridesD = sb('core2_rides',['select'=>'driver_id,booking_id,ride_status','created_at'=>'gte.'.$last30.'T00:00:00']);
    if (!empty($ridesD)) {
        $bids = array_unique(array_filter(array_column($ridesD,'booking_id')));
        $eMap = [];
        if (!empty($bids)) {
            $eb = sb('core2_bookings',['select'=>'booking_id,total_amount','booking_status'=>'eq.Completed','booking_id'=>'in.('.implode(',',$bids).')']);
            foreach ($eb as $b) $eMap[(int)$b['booking_id']] = (float)($b['total_amount']??0);
        }
        $dids = array_unique(array_filter(array_column($ridesD,'driver_id')));
        $dmap = [];
        if (!empty($dids)) {
            // Try matching via core2_driver_id first
            $dr = sb('core1_drivers',['select'=>'id,driver_name,status,core2_driver_id,wallet_balance','core2_driver_id'=>'in.('.implode(',',$dids).')']);
            foreach ($dr as $d) $dmap[(int)($d['core2_driver_id']??0)] = $d;
            // If no matches, try matching directly via core1_drivers.id (in case rides store core1 id)
            if (empty($dmap)) {
                $dr2 = sb('core1_drivers',['select'=>'id,driver_name,status,core2_driver_id,wallet_balance','id'=>'in.('.implode(',',$dids).')']);
                foreach ($dr2 as $d) $dmap[(int)$d['id']] = $d;
            }
        }
        $ratMap = [];
        if (!empty($dids)) {
            $rtd = sb('core2_ratings',['select'=>'driver_id,rating_value','driver_id'=>'in.('.implode(',',$dids).')']);
            foreach ($rtd as $r) { $did=(int)$r['driver_id']; if(!isset($ratMap[$did])) $ratMap[$did]=['s'=>0,'c'=>0]; $ratMap[$did]['s']+=(float)$r['rating_value']; $ratMap[$did]['c']++; }
        }
        $ds = [];
        foreach ($ridesD as $rd) {
            $did=(int)($rd['driver_id']??0); if(!$did) continue;
            if(!isset($ds[$did])) $ds[$did]=['trips'=>0,'completed'=>0,'cancelled'=>0,'revenue'=>0];
            $ds[$did]['trips']++;
            $st=$rd['ride_status']??'';
            if($st==='Completed'){$ds[$did]['completed']++; $ds[$did]['revenue']+=$eMap[(int)($rd['booking_id']??0)]??0;}
            if($st==='Cancelled') $ds[$did]['cancelled']++;
        }
        uasort($ds,fn($a,$b)=>$b['revenue']<=>$a['revenue']);
        $rank=1;
        foreach ($ds as $did=>$st) {
            if($rank>10) break;
            $info=$dmap[$did]??[];
            $rat=isset($ratMap[$did])&&$ratMap[$did]['c']>0?round($ratMap[$did]['s']/$ratMap[$did]['c'],1):0;
            $topDriversData[]=['rank'=>$rank++,'name'=>$info['driver_name']??'Driver #'.$did,'status'=>$info['status']??'Unknown','trips'=>$st['trips'],'completed'=>$st['completed'],'cancelled'=>$st['cancelled'],'revenue'=>$st['revenue'],'rating'=>$rat,'wallet'=>(float)($info['wallet_balance']??0)];
        }
    }

    // Cancellation reasons
    $cancBks = sb('core2_bookings',['select'=>'cancellation_reason','booking_status'=>'eq.Cancelled','booking_date'=>'gte.'.$last30,'cancellation_reason'=>'not.is.null']);
    $crMap=[];
    foreach ($cancBks as $b) { $r = trim($b['cancellation_reason']??'Other'); if(!$r) $r='Other'; $r=substr($r,0,40); if(!isset($crMap[$r])) $crMap[$r]=0; $crMap[$r]++; }
    arsort($crMap);
    foreach (array_slice($crMap,0,6,true) as $r=>$c) $cancReasonData[]=['reason'=>$r,'count'=>$c];

} catch (Exception $e) {
    error_log('Analytics: '.$e->getMessage());
}

// Peak hour insights
$topHour = 0; $topCount = 0;
foreach ($peakHourData as $p) { if($p['count']>$topCount){$topCount=$p['count'];$topHour=$p['hour'];} }
$amPeak = array_sum(array_map(fn($p)=>$p['hour']>=6&&$p['hour']<12?$p['count']:0,$peakHourData));
$pmPeak = array_sum(array_map(fn($p)=>$p['hour']>=16&&$p['hour']<21?$p['count']:0,$peakHourData));

$userName    = htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin');
$userInitial = strtoupper(substr($userName,0,1));

// Year-to-date revenue
$ytdBks = sb('core2_bookings',['select'=>'total_amount','booking_status'=>'eq.Completed','booking_date'=>'gte.'.$thisYearStart]);
$ytdRevenue = array_sum(array_column($ytdBks,'total_amount'));

function ico($p,$s='#4A5568',$sz=16){return "<svg width='$sz' height='$sz' viewBox='0 0 24 24' fill='none' stroke='$s' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>$p</svg>";}
$iHome="<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>";
$iBook="<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>";
$iPay="<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iCrm="<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iGps="<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/>";
$iBar="<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>";
$iDoc="<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/>";
$iOut="<path d='M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'/><polyline points='16 17 21 12 16 7'/><line x1='21' y1='12' x2='9' y2='12'/>";
$iTruck="<rect x='1' y='3' width='15' height='13'/><polygon points='16 8 20 8 23 11 23 16 16 16 16 8'/><circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/>";
$iUser="<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>";
$iDl="<path d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'/><polyline points='7 10 12 15 17 10'/><line x1='12' y1='15' x2='12' y2='3'/>";
$iRef="<polyline points='23 4 23 10 17 10'/><polyline points='1 20 1 14 7 14'/><path d='M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15'/>";
$iStar="<polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/>";
$iAlert="<path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'/><line x1='12' y1='9' x2='12' y2='13'/><line x1='12' y1='17' x2='12.01' y2='17'/>";
$iTarget="<circle cx='12' cy='12' r='10'/><circle cx='12' cy='12' r='6'/><circle cx='12' cy='12' r='2'/>";
$iTrend="<polyline points='23 6 13.5 15.5 8.5 10.5 1 18'/><polyline points='17 6 23 6 23 12'/>";
$iClock="<circle cx='12' cy='12' r='10'/><polyline points='12 6 12 12 16 14'/>";
$iPeople="<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iCheck="<path d='M22 11.08V12a10 10 0 1 1-5.93-9.14'/><polyline points='22 4 12 14.01 9 11.01'/>";
$iX="<line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/>";
$iSearch="<circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/>";
$iRevenue="<line x1='12' y1='1' x2='12' y2='23'/><path d='M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6'/>";
$iHealth="<path d='M22 12h-4l-3 9L9 3l-3 9H2'/>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Analytics &amp; KPIs — EnviroCab</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800;900&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%}
:root{
  --g:#00D084;--gd:#00A86B;--gx:#005A38;--gg:rgba(0,208,132,.1);
  --bg:#F0F4F2;--surf:#fff;--surf2:#F7FAF8;--surf3:#EEF5F1;
  --bdr:#DDE8E2;--bdr2:#C8DDD5;
  --txt:#0D1F18;--txt2:#3A5248;--txt3:#7A9A8E;--txt4:#B0C8BC;
  --blue:#3B8EF0;--purple:#8B6FE8;--orange:#F07830;--red:#E84040;--yellow:#E8A020;
  --sb-bg:#991B1B;--sb-txt:#FECACA;--sb-txt2:#FCA5A5;
  --sb-bdr:rgba(255,255,255,.1);--sb-hover:rgba(255,255,255,.09);
  --sb-active:rgba(255,255,255,.16);--sb-active-bdr:rgba(255,255,255,.28);
  --sw:248px;--th:58px;--r:16px;--rs:10px;
  --shadow:0 1px 3px rgba(0,0,0,.04),0 4px 16px rgba(0,0,0,.06);
  --shadow-md:0 2px 8px rgba(0,0,0,.05),0 8px 28px rgba(0,0,0,.09);
}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--txt);-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit}
.mono{font-family:'DM Mono',monospace}
.trunc{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:3px 8px;border-radius:5px;text-transform:uppercase;letter-spacing:.4px}
.badge::before{content:'';width:5px;height:5px;border-radius:50%;flex-shrink:0}
.badge-green{background:rgba(0,208,132,.12);color:#008A58}.badge-green::before{background:#00A86B}
.badge-blue{background:rgba(59,142,240,.1);color:#1966C2}.badge-blue::before{background:#3B8EF0}
.badge-yellow{background:rgba(232,160,32,.12);color:#9A6A00}.badge-yellow::before{background:#E8A020}
.badge-red{background:rgba(232,64,64,.1);color:#C22020}.badge-red::before{background:#E84040}
.badge-purple{background:rgba(139,111,232,.1);color:#5A3FBB}.badge-purple::before{background:#8B6FE8}
.badge-grey{background:rgba(0,0,0,.06);color:#5A6B64}.badge-grey::before{background:#7A9A8E}

/* ══════════ DESKTOP ≥900px ═════════════════════════════════════════════════ */
@media(min-width:900px){
  .mob-shell{display:none!important}
  body{display:flex;overflow:hidden}
  .sidebar{width:var(--sw);flex-shrink:0;height:100vh;display:flex;flex-direction:column;background:var(--sb-bg);overflow:hidden;box-shadow:3px 0 18px rgba(153,27,27,.22)}
  .sb-logo{height:var(--th);display:flex;align-items:center;gap:10px;padding:0 18px;border-bottom:1px solid var(--sb-bdr);flex-shrink:0}
  .sb-logo img{height:26px;filter:brightness(0) invert(1)}
  .sb-brand{font-size:16px;font-weight:800;letter-spacing:-.3px;color:#fff}.sb-brand span{color:#FCA5A5}
  .sb-nav{flex:1;overflow-y:auto;padding:12px 10px;display:flex;flex-direction:column;gap:1px}
  .sb-nav::-webkit-scrollbar{width:0}
  .sb-label{font-size:9.5px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:var(--sb-txt2);padding:14px 10px 5px}
  .sb-item{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:9px;cursor:pointer;color:rgba(255,255,255,.75);font-size:13px;font-weight:500;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover);color:#fff}
  .sb-item.active{background:var(--sb-active);color:#fff;border-color:var(--sb-active-bdr);font-weight:600}
  .sb-ico{width:30px;height:30px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item:hover .sb-ico,.sb-item.active .sb-ico{background:rgba(255,255,255,.16)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-foot{padding:12px 10px;border-top:1px solid var(--sb-bdr);flex-shrink:0;display:flex;gap:8px;align-items:center}
  .sb-av{width:34px;height:34px;border-radius:9px;flex-shrink:0;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;border:1px solid rgba(255,255,255,.28)}
  .sb-uname{font-size:12.5px;font-weight:600;color:#fff}
  .sb-urole{font-size:11px;color:var(--sb-txt2)}
  .sb-out{margin-left:auto;width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s}
  .sb-out:hover{background:rgba(239,68,68,.3)}
  .sb-out svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:var(--th);flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 24px;gap:10px}
  .tb-title{flex:1;font-size:16px;font-weight:800;letter-spacing:-.2px}
  .tb-date{font-size:12px;color:var(--txt3);font-weight:500}
  .tb-sep{width:1px;height:18px;background:var(--bdr)}
  .tb-btn{height:34px;padding:0 14px;border-radius:8px;background:var(--surf2);border:1px solid var(--bdr);display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:12.5px;font-weight:600;color:var(--txt2);transition:all .15s;font-family:'DM Sans',sans-serif;white-space:nowrap}
  .tb-btn:hover{background:var(--surf3);border-color:var(--bdr2)}
  .tb-btn.primary{background:var(--g);border-color:var(--gd);color:#fff}
  .tb-btn.primary:hover{background:var(--gd)}
  .date-in{height:32px;padding:0 10px;border:1px solid var(--bdr);border-radius:7px;font-size:12px;font-family:'DM Sans',sans-serif;background:var(--surf2);color:var(--txt)}
  .date-in:focus{outline:none;border-color:var(--g)}
  .filter-bar{display:flex;align-items:center;gap:8px}
  .filter-bar label{font-size:12px;color:var(--txt3);font-weight:600}
  .filter-btn{height:32px;padding:0 12px;background:var(--g);color:#fff;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:5px;font-family:'DM Sans',sans-serif;transition:background .15s}
  .filter-btn:hover{background:var(--gd)}
  .scroll{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:16px}
  .scroll::-webkit-scrollbar{width:5px}
  .scroll::-webkit-scrollbar-thumb{background:var(--bdr);border-radius:10px}

  /* Hero */
  .hero{background:linear-gradient(135deg,#0D5F3A 0%,#1A8A56 50%,#065435 100%);border-radius:var(--r);padding:24px 28px}
  .hero,.hero *{color:#fff !important}
  .hero-inner{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:center}
  .hero-rev{font-size:48px;font-weight:900;letter-spacing:-2px;line-height:1;margin-bottom:4px}
  .hero-sub{font-size:12px;opacity:.8;text-transform:uppercase;letter-spacing:.7px;font-weight:600;margin-bottom:14px}
  .hero-growth{font-size:13px;font-weight:600;opacity:.9}
  .hero-stats{display:flex;gap:24px;margin-top:16px}
  .hst{display:flex;flex-direction:column;gap:2px}
  .hst-v{font-size:22px;font-weight:800;line-height:1}
  .hst-l{font-size:10.5px;opacity:.7;text-transform:uppercase;letter-spacing:.4px;font-weight:600;margin-top:2px}
  .hero-right{display:flex;flex-direction:column;gap:10px;text-align:right}
  .hero-kpi-mini{background:rgba(255,255,255,.12);border-radius:11px;padding:12px 16px;border:1px solid rgba(255,255,255,.2)}
  .hero-kpi-mini .v{font-size:22px;font-weight:800}
  .hero-kpi-mini .l{font-size:10.5px;opacity:.75;font-weight:600;letter-spacing:.3px}

  /* KPI grid */
  .kpi-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:11px}
  .kpi{background:var(--surf);border-radius:14px;padding:14px 16px;border:1px solid var(--bdr);transition:all .2s;animation:fadeUp .3s ease both}
  .kpi:hover{box-shadow:var(--shadow);transform:translateY(-1px)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
  .kpi-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-badge{font-size:10px;font-weight:700;padding:2px 7px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .badge-up{background:rgba(0,208,132,.12);color:#008A58}
  .badge-dn{background:rgba(232,64,64,.1);color:#C22020}
  .kpi-val{font-size:26px;font-weight:800;line-height:1;margin-bottom:3px;letter-spacing:-.5px}
  .kpi-val .sign{font-size:14px;font-weight:600;vertical-align:top;margin-top:4px;display:inline-block}
  .kpi-lbl{font-size:11px;color:var(--txt3);font-weight:500}

  /* Panels */
  .panel{background:var(--surf);border-radius:var(--r);border:1px solid var(--bdr);overflow:hidden;animation:fadeUp .35s ease}
  .panel-hdr{padding:14px 18px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;gap:10px;flex-shrink:0}
  .panel-title{font-size:13px;font-weight:700;color:var(--txt);display:flex;align-items:center;gap:7px}
  .panel-body{padding:18px}

  /* Tabs */
  .sec-tabs{display:flex;gap:2px;background:var(--surf2);border-radius:9px;padding:3px;border:1px solid var(--bdr);overflow-x:auto}
  .sec-tab{padding:7px 14px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s;white-space:nowrap;font-family:'DM Sans',sans-serif}
  .sec-tab.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .sec-panel{display:none}
  .sec-panel.active{display:block}

  /* Charts */
  .chart-wrap{height:200px;position:relative}
  .chart-wrap-sm{height:160px;position:relative}
  .chart-wrap-lg{height:220px;position:relative}
  .chart-xl{height:260px;position:relative}

  /* Grid helpers */
  .g2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  .g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px}
  .g4{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:11px}

  /* Progress bars */
  .prog-row{display:flex;align-items:center;gap:10px;margin-bottom:8px}
  .prog-row:last-child{margin:0}
  .prog-lbl{width:130px;font-size:11.5px;font-weight:600;color:var(--txt2);flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .prog-bar{flex:1;height:7px;background:var(--surf3);border-radius:4px;overflow:hidden}
  .prog-fill{height:100%;border-radius:4px;transition:width .6s ease}
  .prog-val{width:36px;text-align:right;font-size:11.5px;font-weight:700;color:var(--txt3);flex-shrink:0}

  /* Driver table */
  .dtable{width:100%;border-collapse:collapse;font-size:12.5px}
  .dtable thead tr{background:var(--surf2)}
  .dtable thead th{padding:10px 14px;text-align:left;font-size:10.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);white-space:nowrap}
  .dtable tbody tr{border-bottom:1px solid var(--bdr);transition:background .12s;cursor:default}
  .dtable tbody tr:last-child{border:0}
  .dtable tbody tr:hover{background:var(--surf2)}
  .dtable td{padding:10px 14px;vertical-align:middle}
  .rank-medal{width:26px;height:26px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;flex-shrink:0}

  /* Insight cards */
  .insight-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .insight-card{background:var(--surf2);border-radius:11px;padding:13px 14px;border:1px solid var(--bdr);display:flex;gap:10px;align-items:flex-start}
  .insight-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .insight-title{font-size:11.5px;font-weight:700;color:var(--txt);margin-bottom:3px}
  .insight-body{font-size:11.5px;color:var(--txt3)}

  /* Buttons */
  .btn{padding:7px 12px;border-radius:8px;font-size:12px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:5px;transition:all .15s;font-family:'DM Sans',sans-serif}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-primary{background:var(--g);color:#fff}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-orange{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-ghost:hover{background:var(--surf3)}
  .btn-sm{padding:5px 10px;font-size:11px}

  /* Modals */
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);z-index:1000;align-items:center;justify-content:center;padding:16px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:17px;max-width:560px;width:100%;max-height:88vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide{max-width:760px}
  .modal-xl{max-width:900px}
  .modal-hdr{padding:16px 20px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:14px;font-weight:800}
  .modal-close{width:27px;height:27px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:18px 20px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 20px;border-top:1px solid var(--bdr);display:flex;gap:7px}

  /* Form */
  .form-group{margin-bottom:12px}
  .form-label{display:block;font-size:11px;font-weight:600;color:var(--txt2);margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select{width:100%;padding:9px 12px;font-size:12.5px;border:1.5px solid var(--bdr);border-radius:8px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif;transition:all .2s}
  .form-input:focus,.form-select:focus{outline:none;border-color:var(--g)}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}

  /* Detail rows */
  .d-row{display:flex;align-items:flex-start;padding:7px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:0}
  .d-label{width:130px;font-size:11px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .d-val{font-size:12.5px;color:var(--txt);font-weight:500;flex:1}
  .section-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:8px}

  /* Fleet boxes */
  .fleet-box{background:var(--surf2);border:1px solid var(--bdr);border-radius:12px;padding:14px 16px;display:flex;flex-direction:column;align-items:center;gap:7px}
  .fleet-ico{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center}
  .fleet-v{font-size:28px;font-weight:900;letter-spacing:-.5px;line-height:1}
  .fleet-l{font-size:11px;color:var(--txt3);font-weight:500}

  /* Satisfaction meter */
  .sat-ring{width:80px;height:80px;position:relative}
  .sat-val{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800}
  .sat-lbl{font-size:11px;color:var(--txt3);font-weight:500;margin-top:5px;text-align:center}

  /* Toast */
  .toast{position:fixed;bottom:18px;right:18px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:#0D5F3A;color:#fff;padding:10px 14px;border-radius:9px;font-size:12.5px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:8px;animation:toastIn .3s ease;max-width:300px}
  .toast-item.error{background:#5F1313}
  .toast-item.warn{background:#7A5000}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}

  /* Loading */
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:13px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  .spin-lbl{font-size:12.5px;color:var(--txt3);font-weight:500}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}

  /* Heatmap */
  .heatmap-grid{display:grid;grid-template-columns:repeat(12,1fr);gap:4px}
  .hm-cell{height:28px;border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:rgba(255,255,255,.9);cursor:default;transition:transform .15s}
  .hm-cell:hover{transform:scale(1.08)}

  /* Leaderboard specific */
  .ldr-bar{display:flex;align-items:center;gap:10px;margin-bottom:10px}
  .ldr-bar label{font-size:12px;color:var(--txt3);font-weight:600}

  /* Breakdown table */
  .bk-table{width:100%;border-collapse:collapse;font-size:12.5px}
  .bk-table th{padding:9px 12px;text-align:left;font-size:10.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);background:var(--surf2)}
  .bk-table td{padding:9px 12px;border-bottom:1px solid var(--bdr);vertical-align:middle}
  .bk-table tbody tr:last-child td{border:0}
  .bk-table tbody tr:hover td{background:var(--surf2)}

  /* Mini bar for in-table usage */
  .mini-bar-wrap{display:flex;align-items:center;gap:6px;min-width:80px}
  .mini-bar{flex:1;height:5px;background:var(--surf3);border-radius:3px;overflow:hidden}
  .mini-bar-fill{height:100%;border-radius:3px}
  .mini-bar-val{font-size:11px;font-weight:700;color:var(--txt3);width:32px;text-align:right;flex-shrink:0}
}

/* ══════════ TABLET 768-899 ═════════════════════════════════════════════════ */
@media(min-width:768px) and (max-width:899px){
  .mob-shell{display:none!important}
  body{display:flex;overflow:hidden}
  .sidebar{width:60px;flex-shrink:0;height:100vh;display:flex;flex-direction:column;align-items:center;background:var(--sb-bg);padding:10px 0;gap:3px;box-shadow:3px 0 14px rgba(153,27,27,.2)}
  .sb-logo{width:100%;height:52px;display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--sb-bdr);margin-bottom:6px}
  .sb-logo img{height:22px;filter:brightness(0) invert(1)}
  .sb-brand,.sb-label{display:none}
  .sb-nav{flex:1;width:100%;padding:4px 7px;display:flex;flex-direction:column;align-items:center;gap:3px}
  .sb-item{width:44px;height:44px;border-radius:11px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:1.5px solid transparent;transition:all .15s}
  .sb-item span{display:none}
  .sb-item:hover{background:var(--sb-hover)}
  .sb-item.active{background:var(--sb-active);border-color:var(--sb-active-bdr)}
  .sb-ico{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.09)}
  .sb-item svg{stroke:rgba(255,255,255,.55)!important}
  .sb-item.active svg,.sb-item:hover svg{stroke:#fff!important}
  .sb-foot{padding:8px 7px;border-top:1px solid var(--sb-bdr);display:flex;justify-content:center}
  .sb-av{width:34px;height:34px;border-radius:9px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff}
  .sb-uname,.sb-urole,.sb-out{display:none}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:52px;flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 16px;gap:8px}
  .tb-title{flex:1;font-size:15px;font-weight:800}
  .tb-date{font-size:11px;color:var(--txt3)}
  .tb-sep{width:1px;height:16px;background:var(--bdr)}
  .date-in{height:30px;padding:0 8px;border:1px solid var(--bdr);border-radius:6px;font-size:11.5px;font-family:'DM Sans',sans-serif;background:var(--surf2);color:var(--txt)}
  .filter-bar{display:flex;align-items:center;gap:6px}
  .filter-bar label{font-size:11px;color:var(--txt3);font-weight:600}
  .filter-btn{height:30px;padding:0 10px;background:var(--g);color:#fff;border:none;border-radius:6px;font-size:11.5px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:4px;font-family:'DM Sans',sans-serif}
  .tb-btn{height:30px;padding:0 11px;border-radius:7px;background:var(--surf2);border:1px solid var(--bdr);display:inline-flex;align-items:center;gap:5px;cursor:pointer;font-size:11.5px;font-weight:600;color:var(--txt2);font-family:'DM Sans',sans-serif}
  .tb-btn.primary{background:var(--g);color:#fff;border-color:var(--gd)}
  .scroll{flex:1;overflow-y:auto;padding:14px 16px;display:flex;flex-direction:column;gap:14px}
  .scroll::-webkit-scrollbar{width:4px}
  .scroll::-webkit-scrollbar-thumb{background:var(--bdr);border-radius:10px}
  .hero{background:linear-gradient(135deg,#0D5F3A,#1A8A56 50%,#065435);border-radius:13px;padding:18px 20px}
  .hero,.hero *{color:#fff !important}
  .hero-inner{display:grid;grid-template-columns:1fr auto;gap:16px}
  .hero-rev{font-size:36px;font-weight:900;letter-spacing:-1.5px;line-height:1;margin-bottom:3px}
  .hero-sub{font-size:11px;opacity:.8;text-transform:uppercase;letter-spacing:.5px;font-weight:600;margin-bottom:10px}
  .hero-growth{font-size:12px;font-weight:600;opacity:.9}
  .hero-stats{display:flex;gap:18px;margin-top:12px}
  .hst{display:flex;flex-direction:column;gap:2px}
  .hst-v{font-size:18px;font-weight:800;line-height:1}
  .hst-l{font-size:10px;opacity:.7;text-transform:uppercase;letter-spacing:.3px;font-weight:600;margin-top:2px}
  .hero-right{display:none}
  .kpi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .kpi{background:var(--surf);border-radius:12px;padding:13px 14px;border:1px solid var(--bdr)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:9px}
  .kpi-ico{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-badge{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:4px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .badge-up{background:rgba(0,208,132,.12);color:#008A58}
  .badge-dn{background:rgba(232,64,64,.1);color:#C22020}
  .kpi-val{font-size:22px;font-weight:800;line-height:1;margin-bottom:2px;letter-spacing:-.4px}
  .kpi-val .sign{font-size:12px;font-weight:600;vertical-align:top;margin-top:3px;display:inline-block}
  .kpi-lbl{font-size:10.5px;color:var(--txt3)}
  .panel{background:var(--surf);border-radius:13px;border:1px solid var(--bdr);overflow:hidden}
  .panel-hdr{padding:12px 16px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;gap:8px}
  .panel-title{font-size:12.5px;font-weight:700;display:flex;align-items:center;gap:7px}
  .panel-body{padding:14px 16px}
  .sec-tabs{display:flex;gap:2px;background:var(--surf2);border-radius:8px;padding:2px;border:1px solid var(--bdr);overflow-x:auto}
  .sec-tab{padding:6px 11px;border-radius:6px;font-size:11.5px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;white-space:nowrap;font-family:'DM Sans',sans-serif}
  .sec-tab.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 3px rgba(0,0,0,.07)}
  .sec-panel{display:none}.sec-panel.active{display:block}
  .chart-wrap{height:170px;position:relative}
  .chart-wrap-sm{height:140px;position:relative}
  .chart-wrap-lg{height:185px;position:relative}
  .chart-xl{height:220px;position:relative}
  .g2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .g3{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .g4{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .prog-row{display:flex;align-items:center;gap:8px;margin-bottom:7px}
  .prog-row:last-child{margin:0}
  .prog-lbl{width:100px;font-size:11px;font-weight:600;color:var(--txt2);flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .prog-bar{flex:1;height:6px;background:var(--surf3);border-radius:3px;overflow:hidden}
  .prog-fill{height:100%;border-radius:3px}
  .prog-val{width:32px;text-align:right;font-size:11px;font-weight:700;color:var(--txt3);flex-shrink:0}
  .dtable{width:100%;border-collapse:collapse;font-size:11.5px}
  .dtable thead th{padding:8px 12px;text-align:left;font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);background:var(--surf2)}
  .dtable tbody tr{border-bottom:1px solid var(--bdr)}
  .dtable td{padding:8px 12px;vertical-align:middle}
  .rank-medal{width:24px;height:24px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800}
  .insight-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .insight-card{background:var(--surf2);border-radius:10px;padding:12px;border:1px solid var(--bdr);display:flex;gap:9px;align-items:flex-start}
  .insight-ico{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .insight-title{font-size:11px;font-weight:700;margin-bottom:2px}
  .insight-body{font-size:11px;color:var(--txt3)}
  .btn{padding:6px 11px;border-radius:7px;font-size:11.5px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:4px;font-family:'DM Sans',sans-serif}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-sm{padding:4px 9px;font-size:11px}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);z-index:1000;align-items:center;justify-content:center;padding:12px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:15px;max-width:540px;width:100%;max-height:88vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide{max-width:700px}
  .modal-xl{max-width:820px}
  .modal-hdr{padding:14px 18px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:13.5px;font-weight:800}
  .modal-close{width:26px;height:26px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:16px 18px;overflow-y:auto;flex:1}
  .modal-foot{padding:11px 18px;border-top:1px solid var(--bdr);display:flex;gap:7px}
  .form-group{margin-bottom:11px}
  .form-label{display:block;font-size:10.5px;font-weight:600;color:var(--txt2);margin-bottom:4px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select{width:100%;padding:8px 11px;font-size:12px;border:1.5px solid var(--bdr);border-radius:8px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif}
  .form-input:focus,.form-select:focus{outline:none;border-color:var(--g)}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .d-row{display:flex;align-items:flex-start;padding:6px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:0}
  .d-label{width:115px;font-size:10.5px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .d-val{font-size:12px;color:var(--txt);font-weight:500;flex:1}
  .section-label{font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:7px}
  .fleet-box{background:var(--surf2);border:1px solid var(--bdr);border-radius:11px;padding:12px;display:flex;flex-direction:column;align-items:center;gap:6px}
  .fleet-ico{width:34px;height:34px;border-radius:9px;display:flex;align-items:center;justify-content:center}
  .fleet-v{font-size:24px;font-weight:900;letter-spacing:-.4px;line-height:1}
  .fleet-l{font-size:10.5px;color:var(--txt3)}
  .heatmap-grid{display:grid;grid-template-columns:repeat(12,1fr);gap:3px}
  .hm-cell{height:24px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:rgba(255,255,255,.9)}
  .toast{position:fixed;bottom:14px;right:14px;z-index:9999;display:flex;flex-direction:column;gap:6px}
  .toast-item{background:#0D5F3A;color:#fff;padding:9px 13px;border-radius:8px;font-size:12px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:7px;animation:toastIn .3s ease;max-width:260px}
  .toast-item.error{background:#5F1313}
  .toast-item.warn{background:#7A5000}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:var(--surf);border-radius:12px;padding:20px 26px;text-align:center}
  .spinner{width:36px;height:36px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 9px}
  .spin-lbl{font-size:12px;color:var(--txt3)}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
  .bk-table{width:100%;border-collapse:collapse;font-size:11.5px}
  .bk-table th{padding:8px 12px;text-align:left;font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--bdr);background:var(--surf2)}
  .bk-table td{padding:8px 12px;border-bottom:1px solid var(--bdr);vertical-align:middle}
  .bk-table tbody tr:last-child td{border:0}
  .mini-bar-wrap{display:flex;align-items:center;gap:5px;min-width:60px}
  .mini-bar{flex:1;height:5px;background:var(--surf3);border-radius:3px;overflow:hidden}
  .mini-bar-fill{height:100%;border-radius:3px}
  .mini-bar-val{font-size:10.5px;font-weight:700;color:var(--txt3);width:28px;text-align:right;flex-shrink:0}
  .ldr-bar{display:flex;align-items:center;gap:8px;margin-bottom:9px}
  .ldr-bar label{font-size:11.5px;color:var(--txt3);font-weight:600}
}

/* ══════════ MOBILE <768px ══════════════════════════════════════════════════ */
@media(max-width:767px){
  .sidebar,.desk-wrap{display:none!important}
  body{background:var(--bg);padding-bottom:74px}
  .mob-hdr{position:sticky;top:0;z-index:100;background:rgba(255,255,255,.92);backdrop-filter:blur(16px);border-bottom:1px solid rgba(0,0,0,.06);padding:12px 16px;display:flex;align-items:center;gap:8px}
  .mob-title{flex:1;font-size:16px;font-weight:800}
  .mob-actions{display:flex;gap:6px}
  .mob-btn{height:32px;padding:0 11px;border-radius:9px;background:rgba(0,0,0,.05);border:none;font-size:12px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:4px;font-family:'DM Sans',sans-serif;color:var(--txt2)}
  .mob-btn.primary{background:var(--g);color:#fff}
  .mob-body{padding:14px 14px 20px;display:flex;flex-direction:column;gap:12px}
  .hero{background:linear-gradient(135deg,#0D5F3A,#1A8A56 60%,#065435);border-radius:16px;padding:18px 18px 16px}
  .hero,.hero *{color:#fff !important}
  .hero-rev{font-size:38px;font-weight:900;letter-spacing:-1.5px;line-height:1;margin-bottom:3px}
  .hero-sub{font-size:10.5px;opacity:.8;text-transform:uppercase;letter-spacing:.5px;font-weight:600;margin-bottom:10px}
  .hero-growth{font-size:12px;font-weight:600;opacity:.9}
  .hero-stats{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:6px;margin-top:12px}
  .hst{display:flex;flex-direction:column;gap:2px}
  .hst-v{font-size:17px;font-weight:800;line-height:1}
  .hst-l{font-size:9.5px;opacity:.7;text-transform:uppercase;letter-spacing:.3px;font-weight:600;margin-top:1px}
  .hero-right,.hero-inner{display:block}
  .kpi-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
  .kpi{background:#fff;border-radius:13px;padding:12px 14px;border:1.5px solid var(--bdr)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
  .kpi-ico{width:28px;height:28px;border-radius:7px;display:flex;align-items:center;justify-content:center}
  .kpi-badge{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:4px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .badge-up{background:rgba(0,208,132,.12);color:#008A58}
  .badge-dn{background:rgba(232,64,64,.1);color:#C22020}
  .kpi-val{font-size:22px;font-weight:800;line-height:1;margin-bottom:2px;letter-spacing:-.4px}
  .kpi-val .sign{font-size:12px;font-weight:600;vertical-align:top;margin-top:3px;display:inline-block}
  .kpi-lbl{font-size:10px;color:var(--txt3)}
  .panel{background:#fff;border-radius:15px;border:1.5px solid var(--bdr);overflow:hidden}
  .panel-hdr{padding:12px 14px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;gap:8px}
  .panel-title{font-size:12.5px;font-weight:700;display:flex;align-items:center;gap:6px}
  .panel-body{padding:14px}
  .sec-tabs{display:flex;gap:2px;background:var(--surf2);border-radius:8px;padding:2px;border:1px solid var(--bdr);overflow-x:auto}
  .sec-tab{padding:6px 12px;border-radius:6px;font-size:11.5px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;white-space:nowrap;font-family:'DM Sans',sans-serif}
  .sec-tab.active{background:#fff;color:var(--txt);box-shadow:0 1px 3px rgba(0,0,0,.08)}
  .sec-panel{display:none}.sec-panel.active{display:block}
  .chart-wrap{height:160px;position:relative}
  .chart-wrap-sm{height:130px;position:relative}
  .chart-wrap-lg{height:175px;position:relative}
  .chart-xl{height:200px;position:relative}
  .g2{display:flex;flex-direction:column;gap:14px}
  .g3{display:flex;flex-direction:column;gap:12px}
  .g4{display:grid;grid-template-columns:1fr 1fr;gap:9px}
  .prog-row{display:flex;align-items:center;gap:8px;margin-bottom:7px}
  .prog-row:last-child{margin:0}
  .prog-lbl{width:90px;font-size:11px;font-weight:600;color:var(--txt2);flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .prog-bar{flex:1;height:6px;background:var(--surf3);border-radius:3px;overflow:hidden}
  .prog-fill{height:100%;border-radius:3px}
  .prog-val{width:30px;text-align:right;font-size:11px;font-weight:700;color:var(--txt3);flex-shrink:0}
  .dtable{width:100%;border-collapse:collapse;font-size:12px}
  .dtable thead th{padding:9px 12px;font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.4px;border-bottom:1px solid var(--bdr);background:var(--surf2)}
  .dtable tbody tr{border-bottom:1px solid var(--bdr)}
  .dtable td{padding:9px 12px;vertical-align:middle}
  .rank-medal{width:24px;height:24px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800}
  .insight-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .insight-card{background:var(--surf2);border-radius:11px;padding:11px;border:1px solid var(--bdr);display:flex;gap:8px}
  .insight-ico{width:28px;height:28px;border-radius:7px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .insight-title{font-size:11px;font-weight:700;margin-bottom:2px}
  .insight-body{font-size:10.5px;color:var(--txt3)}
  .btn{padding:8px 13px;border-radius:9px;font-size:12px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:5px;font-family:'DM Sans',sans-serif}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-ghost{background:rgba(0,0,0,.04);color:var(--txt2)}
  .btn-sm{padding:6px 10px;font-size:11.5px}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1000;align-items:flex-end;justify-content:center}
  .modal.open{display:flex}
  .modal-box{background:#fff;border-radius:22px 22px 0 0;width:100%;max-height:88vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-wide,.modal-xl{max-height:92vh}
  .modal-hdr{padding:16px 18px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:16px 18px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 18px;border-top:1px solid var(--bdr);display:flex;gap:8px}
  .form-group{margin-bottom:13px}
  .form-label{display:block;font-size:11.5px;font-weight:600;color:var(--txt2);margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select{width:100%;padding:11px 13px;font-size:14px;border:1.5px solid var(--bdr);border-radius:11px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif}
  .form-input:focus,.form-select:focus{outline:none;border-color:var(--g)}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .d-row{display:flex;padding:7px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:0}
  .d-label{width:115px;font-size:11.5px;font-weight:600;color:var(--txt3);flex-shrink:0}
  .d-val{font-size:13px;color:var(--txt);font-weight:500;flex:1}
  .section-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--txt3);margin-bottom:8px}
  .fleet-box{background:var(--surf2);border:1px solid var(--bdr);border-radius:12px;padding:13px;display:flex;flex-direction:column;align-items:center;gap:6px}
  .fleet-ico{width:34px;height:34px;border-radius:9px;display:flex;align-items:center;justify-content:center}
  .fleet-v{font-size:26px;font-weight:900;letter-spacing:-.4px;line-height:1}
  .fleet-l{font-size:11px;color:var(--txt3)}
  .heatmap-grid{display:grid;grid-template-columns:repeat(8,1fr);gap:3px}
  .hm-cell{height:26px;border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:8.5px;font-weight:700;color:rgba(255,255,255,.9)}
  .mob-nav{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.96);backdrop-filter:blur(20px);border-top:1px solid rgba(0,0,0,.07);padding:8px 0 14px;display:grid;grid-template-columns:repeat(4,1fr);z-index:99}
  .mn{display:flex;flex-direction:column;align-items:center;gap:2px;padding:5px;cursor:pointer;border:none;background:none}
  .mn-ico{width:40px;height:26px;display:flex;align-items:center;justify-content:center}
  .mn-ico svg{stroke:#718096;opacity:.5}
  .mn.active .mn-ico svg{stroke:#00D084;opacity:1}
  .mn-lbl{font-size:10px;font-weight:600;color:#718096;opacity:.7}
  .mn.active .mn-lbl{color:#00D084;opacity:1}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.show{display:flex}
  .spin-box{background:#fff;border-radius:16px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  .spin-lbl{font-size:12.5px;color:var(--txt3)}
  @keyframes spin{to{transform:rotate(360deg)}}
  .mob-toast{position:fixed;bottom:84px;left:14px;right:14px;z-index:9999;display:flex;flex-direction:column;gap:8px}
  .mob-toast-item{background:#0D5F3A;color:#fff;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px;animation:toastIn .3s ease}
  .mob-toast-item.error{background:#5F1313}
  .mob-toast-item.warn{background:#7A5000}
  @keyframes toastIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  .bk-table{width:100%;border-collapse:collapse;font-size:12px}
  .bk-table th{padding:9px 12px;text-align:left;font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.4px;border-bottom:1px solid var(--bdr);background:var(--surf2)}
  .bk-table td{padding:9px 12px;border-bottom:1px solid var(--bdr);vertical-align:middle}
  .bk-table tbody tr:last-child td{border:0}
  .mini-bar-wrap{display:flex;align-items:center;gap:5px}
  .mini-bar{flex:1;height:5px;background:var(--surf3);border-radius:3px;overflow:hidden}
  .mini-bar-fill{height:100%;border-radius:3px}
  .mini-bar-val{font-size:11px;font-weight:700;color:var(--txt3);width:28px;text-align:right;flex-shrink:0}
  .ldr-bar{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}
  .ldr-bar label{font-size:12px;color:var(--txt3);font-weight:600}
  .ldr-bar .form-input{width:120px;height:34px}
}
</style>
</head>
<body>

<!-- ════════════════════════════════════════ SIDEBAR ═════════════════════════ -->
<aside class="sidebar">
  <div class="sb-logo">
    <img src="../images/envirocab_logo.png" alt="EC" onerror="this.style.display='none'">
    <div class="sb-brand">Enviro<span>Cab</span></div>
  </div>
  <nav class="sb-nav">
    <div class="sb-label">Core 2</div>
    <a href="dashboard.php"          class="sb-item"><div class="sb-ico"><?=ico($iHome,'#fff')?></div><span>Dashboard</span></a>
    <a href="booking_system.php"     class="sb-item"><div class="sb-ico"><?=ico($iBook,'#fff')?></div><span>Booking System</span></a>
    <a href="payment_fares.php"      class="sb-item"><div class="sb-ico"><?=ico($iPay,'#fff')?></div><span>Payment &amp; Fares</span></a>
    <a href="crm_system.php"         class="sb-item"><div class="sb-ico"><?=ico($iCrm,'#fff')?></div><span>CRM</span></a>
    <a href="gps_tracking.php"       class="sb-item"><div class="sb-ico"><?=ico($iGps,'#fff')?></div><span>GPS Tracking</span></a>
    <div class="sb-label">Analytics</div>
    <a href="transport_analytics.php" class="sb-item active"><div class="sb-ico"><?=ico($iBar,'#fff')?></div><span>Analytics &amp; KPIs</span></a>
    <a href="sop_compliance.php"     class="sb-item"><div class="sb-ico"><?=ico($iDoc,'#fff')?></div><span>SOP Compliance</span></a>
  </nav>
  <div class="sb-foot">
    <div class="sb-av"><?=$userInitial?></div>
    <div style="flex:1;min-width:0"><div class="sb-uname"><?=$userName?></div><div class="sb-urole">Administrator</div></div>
    <button class="sb-out" onclick="if(confirm('Logout?'))window.location.href='../auth/logout.php'" title="Logout"><?=ico($iOut,'#fff',14)?></button>
  </div>
</aside>

<!-- ════════════════════════════════════════ DESKTOP WRAP ════════════════════ -->
<div class="desk-wrap">
  <header class="topbar">
    <div class="tb-title"><?=ico($iBar,'var(--g)',16)?>&nbsp;Analytics &amp; KPIs</div>
    <div class="tb-date"><?=date('D, M j, Y')?></div>
    <div class="tb-sep"></div>
    <div class="filter-bar">
      <label>From</label>
      <input type="date" class="date-in" id="df-from" value="<?=$last30?>">
      <label>To</label>
      <input type="date" class="date-in" id="df-to" value="<?=$today?>">
      <button class="filter-btn" onclick="applyDateFilter()"><?=ico($iRef,'#fff',12)?> Apply</button>
    </div>
    <div class="tb-sep"></div>
    <button class="tb-btn" onclick="showExportModal()"><?=ico($iDl,'#3A5248',13)?> Export</button>
    <button class="tb-btn" onclick="openDriverModal()"><?=ico($iStar,'#3A5248',13)?> Leaderboard</button>
    <button class="tb-btn primary" onclick="refreshAll()"><?=ico($iRef,'#fff',13)?> Refresh</button>
  </header>

  <div class="scroll">

    <!-- Hero -->
    <div class="hero">
      <div class="hero-inner">
        <div>
          <div class="hero-sub">Total Revenue &middot; Last 30 Days</div>
          <div class="hero-rev">₱<?=number_format($totalRevenue/1000,1)?>K</div>
          <div class="hero-growth"><?=($revenueGrowth>=0?'↑':'↓').' '.abs($revenueGrowth).'% vs last month'?> &nbsp;·&nbsp; YTD: ₱<?=number_format($ytdRevenue/1000,1)?>K</div>
          <div class="hero-stats">
            <div class="hst"><div class="hst-v"><?=number_format($totalTrips)?></div><div class="hst-l">Trips</div></div>
            <div class="hst"><div class="hst-v"><?=number_format($totalBookings)?></div><div class="hst-l">Bookings</div></div>
            <div class="hst"><div class="hst-v"><?=$completionRate?>%</div><div class="hst-l">Completion</div></div>
            <div class="hst"><div class="hst-v"><?=$avgRating?> ★</div><div class="hst-l">Avg Rating</div></div>
            <div class="hst"><div class="hst-v"><?=$paymentSuccessRate?>%</div><div class="hst-l">Pay Success</div></div>
          </div>
        </div>
        <div class="hero-right">
          <div class="hero-kpi-mini">
            <div class="v">₱<?=number_format($avgFare,0)?></div>
            <div class="l">Avg Fare / Trip</div>
          </div>
          <div class="hero-kpi-mini">
            <div class="v"><?=$ratingCount?></div>
            <div class="l">Reviews This Month</div>
          </div>
          <div class="hero-kpi-mini">
            <div class="v"><?=$cancellationRate?>%</div>
            <div class="l">Cancellation Rate</div>
          </div>
        </div>
      </div>
    </div>

    <!-- KPI Grid -->
    <?php $revBadge=$revenueGrowth>=0?'badge-up':'badge-dn'; $revArrow=$revenueGrowth>=0?'↑':'↓'; $tripBadge=$tripGrowth>=0?'badge-up':'badge-dn'; $tripArrow=$tripGrowth>=0?'↑':'↓'; ?>
    <div class="kpi-grid">
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iRevenue,'#00D084')?></div><span class="kpi-badge <?=$revBadge?>"><?=$revArrow?> <?=abs($revenueGrowth)?>%</span></div>
        <div class="kpi-val"><span class="sign">₱</span><?=number_format($totalRevenue/1000,1)?>K</div>
        <div class="kpi-lbl">Revenue (30d)</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(59,142,240,.1)"><?=ico($iTruck,'#3B8EF0')?></div><span class="kpi-badge <?=$tripBadge?>"><?=$tripArrow?> <?=abs($tripGrowth)?>%</span></div>
        <div class="kpi-val"><?=number_format($totalTrips)?></div>
        <div class="kpi-lbl">Total Trips (30d)</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(139,111,232,.1)"><?=ico($iBook,'#8B6FE8')?></div></div>
        <div class="kpi-val"><?=number_format($totalBookings)?></div>
        <div class="kpi-lbl">Bookings (30d)</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(232,160,32,.12)"><?=ico($iRevenue,'#E8A020')?></div></div>
        <div class="kpi-val"><span class="sign">₱</span><?=number_format($avgFare,0)?></div>
        <div class="kpi-lbl">Average Fare</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iCheck,'#00D084')?></div><span class="kpi-badge badge-up"><?=$completionRate?>%</span></div>
        <div class="kpi-val"><?=$completionRate?>%</div>
        <div class="kpi-lbl">Completion Rate</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(232,64,64,.1)"><?=ico($iX,'#E84040')?></div><span class="kpi-badge badge-dn"><?=$cancellationRate?>%</span></div>
        <div class="kpi-val"><?=$cancellationRate?>%</div>
        <div class="kpi-lbl">Cancellation Rate</div>
      </div>
    </div>

    <!-- Section Tabs Panel -->
    <div class="panel">
      <div class="panel-hdr">
        <div class="sec-tabs" id="mainTabs">
          <button class="sec-tab active" onclick="switchTab('revenue')">Revenue Trends</button>
          <button class="sec-tab" onclick="switchTab('trips')">Trip Analytics</button>
          <button class="sec-tab" onclick="switchTab('drivers')">Driver Performance</button>
          <button class="sec-tab" onclick="switchTab('demand')">Peak Demand</button>
          <button class="sec-tab" onclick="switchTab('operations')">Operations</button>
          <button class="sec-tab" onclick="switchTab('satisfaction')">Satisfaction</button>
        </div>
      </div>
      <div class="panel-body">

        <!-- Revenue Trends -->
        <div id="tab-revenue" class="sec-panel active">
          <div class="g2" style="gap:20px">
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Daily Revenue (Last 7 Days)</div>
              <div class="chart-wrap-lg"><canvas id="chartRevenue"></canvas></div>
            </div>
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Booking Status Distribution</div>
              <div class="chart-wrap-lg"><canvas id="chartStatus"></canvas></div>
            </div>
          </div>
          <div style="margin-top:20px">
            <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Payment Status Breakdown</div>
            <div class="g2" style="gap:16px">
              <div class="chart-wrap-sm"><canvas id="chartPayment"></canvas></div>
              <div>
                <?php
                $colors=['#00D084','#3B8EF0','#8B6FE8','#E8A020','#E84040'];
                foreach (array_slice($payMethodData,0,5) as $i=>$pm):
                  $pct = $totalBookings>0 ? round($pm['count']/$totalBookings*100) : 0;
                ?>
                <div class="prog-row">
                  <div class="prog-lbl"><?=htmlspecialchars($pm['method'])?></div>
                  <div class="prog-bar"><div class="prog-fill" style="width:<?=$pct?>%;background:<?=$colors[$i%5]?>"></div></div>
                  <div class="prog-val"><?=$pct?>%</div>
                </div>
                <?php endforeach; if(empty($payMethodData)): ?><div style="font-size:12px;color:var(--txt3)">No data</div><?php endif; ?>
              </div>
            </div>
          </div>
        </div>

        <!-- Trip Analytics -->
        <div id="tab-trips" class="sec-panel">
          <div class="g2" style="gap:20px">
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Daily Trips (Last 7 Days)</div>
              <div class="chart-wrap-lg"><canvas id="chartTrips"></canvas></div>
            </div>
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Service Type Distribution</div>
              <div class="chart-wrap-lg"><canvas id="chartService"></canvas></div>
            </div>
          </div>
          <div style="margin-top:18px">
            <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Service Booking Share</div>
            <?php foreach (array_slice($serviceData,0,6) as $i=>$sv):
              $pct = $totalBookings>0 ? round($sv['count']/$totalBookings*100) : 0;
            ?>
            <div class="prog-row">
              <div class="prog-lbl"><?=htmlspecialchars($sv['name'])?></div>
              <div class="prog-bar"><div class="prog-fill" style="width:<?=$pct?>%;background:<?=$colors[$i%5]?>"></div></div>
              <div class="prog-val"><?=$sv['count']?></div>
            </div>
            <?php endforeach; if(empty($serviceData)): ?><div style="font-size:12px;color:var(--txt3)">No data</div><?php endif; ?>
          </div>
        </div>

        <!-- Driver Performance -->
        <div id="tab-drivers" class="sec-panel">
          <div style="overflow-x:auto">
            <table class="dtable">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Driver</th>
                  <th>Status</th>
                  <th style="text-align:center">Trips</th>
                  <th style="text-align:center">Completed</th>
                  <th style="text-align:center">Cancelled</th>
                  <th style="text-align:center">Rating</th>
                  <th style="text-align:right">Revenue (30d)</th>
                  <th style="text-align:right">Wallet Bal.</th>
                </tr>
              </thead>
              <tbody>
                <?php if (!empty($topDriversData)): foreach ($topDriversData as $d):
                  $rColors=['#E8A020','#9CA3AF','#CD7F32'];
                  $rBg=['rgba(232,160,32,.12)','rgba(156,163,175,.1)','rgba(205,127,50,.09)'];
                  $rIdx=min($d['rank']-1,2);
                  $compRate=$d['trips']>0?round($d['completed']/$d['trips']*100):0;
                  $statusClass=['Active'=>'badge-green','Offline'=>'badge-grey','In Progress'=>'badge-blue','Suspended'=>'badge-red','Pending'=>'badge-yellow'][$d['status']] ?? 'badge-grey';
                ?>
                <tr>
                  <td><div class="rank-medal" style="background:<?=$d['rank']<=3?$rBg[$rIdx]:'rgba(0,0,0,.04)'?>;color:<?=$d['rank']<=3?$rColors[$rIdx]:'var(--txt3)'?>"><?=$d['rank']?></div></td>
                  <td>
                    <div style="font-weight:700;font-size:13px"><?=htmlspecialchars($d['name'])?></div>
                    <div style="font-size:10.5px;color:var(--txt3);margin-top:1px">Comp. rate: <?=$compRate?>%</div>
                  </td>
                  <td><span class="badge <?=$statusClass?>"><?=$d['status']?></span></td>
                  <td style="text-align:center;font-weight:700"><?=$d['trips']?></td>
                  <td style="text-align:center"><span class="badge badge-green"><?=$d['completed']?></span></td>
                  <td style="text-align:center"><span class="badge badge-red"><?=$d['cancelled']?></span></td>
                  <td style="text-align:center"><span class="badge badge-yellow"><?=$d['rating']?> ★</span></td>
                  <td style="text-align:right;font-weight:800;color:var(--gd)">₱<?=number_format($d['revenue'],0)?></td>
                  <td style="text-align:right;font-weight:600;color:var(--txt2)">₱<?=number_format($d['wallet'],2)?></td>
                </tr>
                <?php endforeach; else: ?>
                <tr><td colspan="9" style="text-align:center;padding:32px;color:var(--txt3)">No driver data for this period</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <div style="margin-top:14px;display:flex;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="openDriverModal()"><?=ico($iStar,'#3A5248',12)?> Full Leaderboard</button>
          </div>
        </div>

        <!-- Peak Demand -->
        <div id="tab-demand" class="sec-panel">
          <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Hourly Demand Heatmap (Last 30 Days)</div>
          <div class="chart-xl" style="margin-bottom:18px"><canvas id="chartPeak"></canvas></div>
          <div class="insight-grid">
            <div class="insight-card">
              <div class="insight-ico" style="background:rgba(0,208,132,.1)"><?=ico($iTarget,'#00D084')?></div>
              <div><div class="insight-title">Peak Hour</div><div class="insight-body"><?=date('g:00 A',$topHour*3600)?> &mdash; <?=$topCount?> trips recorded</div></div>
            </div>
            <div class="insight-card">
              <div class="insight-ico" style="background:rgba(59,142,240,.1)"><?=ico($iClock,'#3B8EF0')?></div>
              <div><div class="insight-title">Morning Rush (6–11am)</div><div class="insight-body"><?=number_format($amPeak)?> trips &mdash; <?=$totalTrips>0?round($amPeak/$totalTrips*100).'% of total':'–'?></div></div>
            </div>
            <div class="insight-card">
              <div class="insight-ico" style="background:rgba(139,111,232,.1)"><?=ico($iTrend,'#8B6FE8')?></div>
              <div><div class="insight-title">Evening Rush (4–9pm)</div><div class="insight-body"><?=number_format($pmPeak)?> trips &mdash; <?=$totalTrips>0?round($pmPeak/$totalTrips*100).'% of total':'–'?></div></div>
            </div>
            <div class="insight-card">
              <div class="insight-ico" style="background:rgba(232,160,32,.12)"><?=ico($iAlert,'#E8A020')?></div>
              <div><div class="insight-title">Off-Peak Demand</div><div class="insight-body"><?=$totalTrips-$amPeak-$pmPeak?> trips outside rush hours</div></div>
            </div>
          </div>
        </div>

        <!-- Operations -->
        <div id="tab-operations" class="sec-panel">
          <div class="g2" style="gap:20px">
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Cancellation Reasons (Last 30d)</div>
              <?php if(!empty($cancReasonData)):
                $maxCanc = max(array_column($cancReasonData,'count'),0) ?: 1;
                foreach ($cancReasonData as $i=>$cr):
                  $pct = round($cr['count']/$maxCanc*100);
              ?>
              <div class="prog-row">
                <div class="prog-lbl"><?=htmlspecialchars($cr['reason'])?></div>
                <div class="prog-bar"><div class="prog-fill" style="width:<?=$pct?>%;background:<?=$colors[$i%5]?>"></div></div>
                <div class="prog-val"><?=$cr['count']?></div>
              </div>
              <?php endforeach; else: ?><div style="font-size:12px;color:var(--txt3)">No cancellation data</div><?php endif; ?>
            </div>
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Booking Funnel</div>
              <?php
              $statuses=['Pending','Confirmed','In Progress','Completed','Cancelled','No Show'];
              $statCnts=[];
              foreach($allBks as $b){$s=$b['booking_status']??'Unknown';if(!isset($statCnts[$s]))$statCnts[$s]=0;$statCnts[$s]++;}
              $fColors=['#E8A020','#3B8EF0','#8B6FE8','#00D084','#E84040','#9CA3AF'];
              foreach ($statuses as $si=>$stat):
                $cnt = $statCnts[$stat] ?? 0;
                $pct = $totalBookings>0 ? round($cnt/$totalBookings*100) : 0;
              ?>
              <div class="prog-row">
                <div class="prog-lbl"><?=$stat?></div>
                <div class="prog-bar"><div class="prog-fill" style="width:<?=$pct?>%;background:<?=$fColors[$si%6]?>"></div></div>
                <div class="prog-val"><?=$cnt?></div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <div style="margin-top:18px">
            <button class="btn btn-ghost btn-sm" onclick="loadOperationalMetrics()"><?=ico($iRef,'#3A5248',12)?> Load Full Operational Report</button>
          </div>
          <div id="ops-extra" style="display:none;margin-top:16px"></div>
        </div>

        <!-- Satisfaction -->
        <div id="tab-satisfaction" class="sec-panel">
          <div class="g2" style="gap:20px">
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:14px">Customer Satisfaction Overview</div>
              <div style="display:flex;flex-direction:column;gap:12px">
                <div style="display:flex;align-items:center;gap:16px;background:var(--surf2);border-radius:12px;padding:14px;border:1px solid var(--bdr)">
                  <div style="text-align:center">
                    <div style="font-size:44px;font-weight:900;color:var(--yellow);line-height:1"><?=$avgRating?></div>
                    <div style="font-size:20px;color:var(--yellow);margin-top:2px"><?=str_repeat('★',floor($avgRating)).($avgRating-floor($avgRating)>=0.5?'☆':'')?></div>
                    <div style="font-size:11px;color:var(--txt3);margin-top:5px"><?=$ratingCount?> reviews</div>
                  </div>
                  <div style="flex:1">
                    <?php for($star=5;$star>=1;$star--): $sCount=0; foreach($ratRows as $r) if((int)round($r['rating_value'])===$star) $sCount++; $pct=$ratingCount>0?round($sCount/$ratingCount*100):0; ?>
                    <div class="prog-row" style="margin-bottom:5px">
                      <div class="prog-lbl" style="width:50px"><?=$star?> ★</div>
                      <div class="prog-bar"><div class="prog-fill" style="width:<?=$pct?>%;background:var(--yellow)"></div></div>
                      <div class="prog-val"><?=$sCount?></div>
                    </div>
                    <?php endfor; ?>
                  </div>
                </div>
                <div class="g2" style="gap:10px">
                  <div style="background:var(--surf2);border:1px solid var(--bdr);border-radius:11px;padding:12px;text-align:center">
                    <div style="font-size:24px;font-weight:800;color:var(--gd)"><?=$paymentSuccessRate?>%</div>
                    <div style="font-size:11px;color:var(--txt3);margin-top:3px">Payment Success</div>
                  </div>
                  <div style="background:var(--surf2);border:1px solid var(--bdr);border-radius:11px;padding:12px;text-align:center">
                    <div style="font-size:24px;font-weight:800;color:var(--blue)"><?=$completionRate?>%</div>
                    <div style="font-size:11px;color:var(--txt3);margin-top:3px">Trip Completion</div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:14px">Issue & Report Overview</div>
              <div style="display:flex;flex-direction:column;gap:8px">
                <div style="background:rgba(232,64,64,.06);border:1px solid rgba(232,64,64,.15);border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:10px">
                  <?=ico($iAlert,'#E84040',16)?>
                  <div>
                    <div style="font-size:12.5px;font-weight:700">Open Reports</div>
                    <div style="font-size:11.5px;color:var(--txt3)">Complaints requiring attention</div>
                  </div>
                  <div style="margin-left:auto;font-size:20px;font-weight:800;color:#E84040" id="openReportCount">—</div>
                </div>
                <div style="background:rgba(59,142,240,.06);border:1px solid rgba(59,142,240,.12);border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:10px">
                  <?=ico($iHealth,'#3B8EF0',16)?>
                  <div>
                    <div style="font-size:12.5px;font-weight:700">Maintenance Requests</div>
                    <div style="font-size:11.5px;color:var(--txt3)">Vehicle/fleet issues</div>
                  </div>
                  <div style="margin-left:auto;font-size:20px;font-weight:800;color:#3B8EF0" id="maintRequestCount">—</div>
                </div>
                <div style="margin-top:4px">
                  <button class="btn btn-ghost btn-sm" onclick="loadSatisfactionDetails()"><?=ico($iRef,'#3A5248',12)?> Load Detailed Report</button>
                </div>
                <div id="sat-details" style="display:none;margin-top:10px"></div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /panel-body -->
    </div><!-- /main panel -->

    <!-- Fleet + Top Drivers -->
    <div class="g3" style="gap:14px">
      <div class="panel">
        <div class="panel-hdr"><div class="panel-title"><?=ico($iTruck,'#4A5568',14)?> Fleet Overview</div></div>
        <div class="panel-body">
          <div class="g3" style="gap:10px">
            <div class="fleet-box">
              <div class="fleet-ico" style="background:linear-gradient(135deg,var(--g),var(--gd))"><?=ico($iTruck,'#fff',18)?></div>
              <div class="fleet-v"><?=$activeVehicles?></div>
              <div class="fleet-l">Vehicles</div>
            </div>
            <div class="fleet-box">
              <div class="fleet-ico" style="background:linear-gradient(135deg,#3B8EF0,#2563EB)"><?=ico($iUser,'#fff',18)?></div>
              <div class="fleet-v"><?=$activeDrivers?></div>
              <div class="fleet-l">Online Drivers</div>
            </div>
            <div class="fleet-box">
              <div class="fleet-ico" style="background:linear-gradient(135deg,#8B6FE8,#7C3AED)"><?=ico($iCrm,'#fff',18)?></div>
              <div class="fleet-v"><?=$customerCount?></div>
              <div class="fleet-l">Customers</div>
            </div>
          </div>
          <div style="margin-top:14px">
            <div class="d-row"><div class="d-label">Avg Fare / Trip</div><div class="d-val" style="font-weight:700;color:var(--gd)">₱<?=number_format($avgFare,2)?></div></div>
            <div class="d-row"><div class="d-label">Avg Rating</div><div class="d-val" style="font-weight:700;color:var(--yellow)"><?=$avgRating?> ★ <span style="font-size:11px;color:var(--txt3)">(<?=$ratingCount?> reviews)</span></div></div>
            <div class="d-row"><div class="d-label">Pay Success Rate</div><div class="d-val" style="font-weight:700;color:var(--gd)"><?=$paymentSuccessRate?>%</div></div>
            <div class="d-row"><div class="d-label">Completion Rate</div><div class="d-val" style="font-weight:700;color:var(--blue)"><?=$completionRate?>%</div></div>
            <div class="d-row"><div class="d-label">YTD Revenue</div><div class="d-val" style="font-weight:800;color:var(--gd)">₱<?=number_format($ytdRevenue,0)?></div></div>
          </div>
        </div>
      </div>
      <div class="panel" style="grid-column:span 2">
        <div class="panel-hdr">
          <div class="panel-title"><?=ico($iStar,'#4A5568',14)?> Top 5 Drivers by Revenue (30d)</div>
          <button class="btn btn-ghost btn-sm" onclick="openDriverModal()"><?=ico($iBar,'#3A5248',12)?> Full Leaderboard</button>
        </div>
        <div class="panel-body" style="padding:0">
          <?php if(!empty($topDriversData)):
            foreach(array_slice($topDriversData,0,5) as $d):
              $rColors=['#E8A020','#9CA3AF','#CD7F32'];
              $rBg=['rgba(232,160,32,.12)','rgba(156,163,175,.1)','rgba(205,127,50,.09)'];
              $rIdx=min($d['rank']-1,2);
              $compRate=$d['trips']>0?round($d['completed']/$d['trips']*100):0;
          ?>
          <div style="display:flex;align-items:center;gap:12px;padding:12px 18px;border-bottom:1px solid var(--surf3)">
            <div class="rank-medal" style="background:<?=$d['rank']<=3?$rBg[$rIdx]:'rgba(0,0,0,.04)'?>;color:<?=$d['rank']<=3?$rColors[$rIdx]:'var(--txt3)'?>"><?=$d['rank']?></div>
            <div style="flex:1;min-width:0">
              <div style="font-size:13px;font-weight:700"><?=htmlspecialchars($d['name'])?></div>
              <div style="font-size:11px;color:var(--txt3);margin-top:1px"><?=$d['trips']?> trips &bull; <?=$d['completed']?> completed &bull; <?=$compRate?>% rate</div>
            </div>
            <?php if($d['rating']>0):?><span class="badge badge-yellow"><?=$d['rating']?> ★</span><?php endif;?>
            <div style="font-weight:800;color:var(--gd);font-size:14px">₱<?=number_format($d['revenue'],0)?></div>
          </div>
          <?php endforeach; else: ?>
          <div style="text-align:center;padding:32px;color:var(--txt3);font-size:13px">No driver data available</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Custom Date Range Analysis -->
    <div class="panel">
      <div class="panel-hdr">
        <div class="panel-title"><?=ico($iTarget,'#4A5568',14)?> Custom Date Range Analysis</div>
        <div style="display:flex;gap:7px;align-items:center">
          <div class="filter-bar" style="gap:7px">
            <label>From</label>
            <input type="date" class="date-in" id="range-from" value="<?=$last30?>">
            <label>To</label>
            <input type="date" class="date-in" id="range-to" value="<?=$today?>">
            <button class="filter-btn" onclick="applyRangeFilter()"><?=ico($iRef,'#fff',12)?> Analyze</button>
          </div>
          <button class="btn btn-ghost btn-sm" id="range-export-btn" onclick="exportRange()" style="display:none"><?=ico($iDl,'#3A5248',12)?> Export</button>
        </div>
      </div>
      <div class="panel-body">
        <div id="range-loading" style="display:none;text-align:center;padding:40px;color:var(--txt3)"><div class="spinner" style="margin:0 auto 10px;width:28px;height:28px;border-width:2px"></div>Analyzing…</div>
        <div id="range-results" style="display:none">
          <div class="kpi-grid" style="margin-bottom:16px" id="range-kpis"></div>
          <div class="chart-wrap"><canvas id="chartRange"></canvas></div>
        </div>
        <div id="range-placeholder" style="text-align:center;padding:36px;color:var(--txt3)">
          <?=ico($iTarget,'var(--txt4)',32)?>
          <div style="font-size:13px;font-weight:600;color:var(--txt3);margin-top:10px">Select a date range and click Analyze to view detailed metrics</div>
        </div>
      </div>
    </div>

    <!-- Revenue Breakdown by Service -->
    <div class="panel">
      <div class="panel-hdr">
        <div class="panel-title"><?=ico($iRevenue,'#4A5568',14)?> Revenue Breakdown by Service</div>
        <button class="btn btn-ghost btn-sm" onclick="loadRevenueBreakdown()"><?=ico($iRef,'#3A5248',12)?> Load Breakdown</button>
      </div>
      <div class="panel-body">
        <div id="rev-breakdown-loading" style="display:none;text-align:center;padding:28px;color:var(--txt3)"><div class="spinner" style="margin:0 auto 8px;width:24px;height:24px;border-width:2px"></div>Loading…</div>
        <div id="rev-breakdown" style="display:none">
          <div class="g2" style="gap:18px">
            <div class="chart-wrap-lg"><canvas id="chartRevBreakdown"></canvas></div>
            <div id="rev-breakdown-table"></div>
          </div>
        </div>
        <div id="rev-breakdown-placeholder" style="text-align:center;padding:28px;color:var(--txt3);font-size:12.5px">Click "Load Breakdown" to view revenue by service type (using date filter range)</div>
      </div>
    </div>

    <!-- Customer Analytics -->
    <div class="panel">
      <div class="panel-hdr">
        <div class="panel-title"><?=ico($iPeople,'#4A5568',14)?> Customer Analytics</div>
        <button class="btn btn-ghost btn-sm" onclick="loadCustomerStats()"><?=ico($iRef,'#3A5248',12)?> Load Stats</button>
      </div>
      <div class="panel-body">
        <div id="cust-loading" style="display:none;text-align:center;padding:28px;color:var(--txt3)"><div class="spinner" style="margin:0 auto 8px;width:24px;height:24px;border-width:2px"></div>Loading…</div>
        <div id="cust-results" style="display:none">
          <div class="g2" style="gap:18px">
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px">Customer Type Distribution</div>
              <div class="chart-wrap-sm"><canvas id="chartCustType"></canvas></div>
            </div>
            <div>
              <div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Top 10 Customers by Revenue</div>
              <div id="top-customers-table"></div>
            </div>
          </div>
        </div>
        <div id="cust-placeholder" style="text-align:center;padding:28px;color:var(--txt3);font-size:12.5px">Click "Load Stats" to analyze customer behavior and top spenders</div>
      </div>
    </div>

  </div><!-- /scroll -->
</div><!-- /desk-wrap -->

<!-- ════════════════════════════════════════ MOBILE SHELL ════════════════════ -->
<div class="mob-shell">
  <div class="mob-hdr">
    <div class="mob-title">Analytics &amp; KPIs</div>
    <div class="mob-actions">
      <button class="mob-btn" onclick="showExportModal()"><?=ico($iDl,'#3A5248',13)?></button>
      <button class="mob-btn primary" onclick="refreshAll()"><?=ico($iRef,'#fff',13)?></button>
    </div>
  </div>
  <div class="mob-body">
    <!-- Hero -->
    <div class="hero">
      <div class="hero-sub">Revenue · Last 30 Days</div>
      <div class="hero-rev">₱<?=number_format($totalRevenue/1000,1)?>K</div>
      <div class="hero-growth"><?=($revenueGrowth>=0?'↑':'↓').' '.abs($revenueGrowth).'% vs last month'?></div>
      <div class="hero-stats">
        <div class="hst"><div class="hst-v"><?=number_format($totalTrips)?></div><div class="hst-l">Trips</div></div>
        <div class="hst"><div class="hst-v"><?=$completionRate?>%</div><div class="hst-l">Done</div></div>
        <div class="hst"><div class="hst-v"><?=$avgRating?> ★</div><div class="hst-l">Rating</div></div>
        <div class="hst"><div class="hst-v"><?=$cancellationRate?>%</div><div class="hst-l">Canc.</div></div>
      </div>
    </div>
    <!-- KPIs -->
    <div class="kpi-grid">
      <div class="kpi"><div class="kpi-top"><div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iRevenue,'#00D084',14)?></div><span class="kpi-badge <?=$revBadge?>"><?=$revArrow?> <?=abs($revenueGrowth)?>%</span></div><div class="kpi-val" style="font-size:20px"><span class="sign" style="font-size:11px">₱</span><?=number_format($totalRevenue/1000,1)?>K</div><div class="kpi-lbl">Revenue</div></div>
      <div class="kpi"><div class="kpi-top"><div class="kpi-ico" style="background:rgba(59,142,240,.1)"><?=ico($iTruck,'#3B8EF0',14)?></div><span class="kpi-badge <?=$tripBadge?>"><?=$tripArrow?> <?=abs($tripGrowth)?>%</span></div><div class="kpi-val" style="font-size:20px"><?=number_format($totalTrips)?></div><div class="kpi-lbl">Trips</div></div>
      <div class="kpi"><div class="kpi-top"><div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iCheck,'#00D084',14)?></div></div><div class="kpi-val" style="font-size:20px"><?=$completionRate?>%</div><div class="kpi-lbl">Completion</div></div>
      <div class="kpi"><div class="kpi-top"><div class="kpi-ico" style="background:rgba(232,160,32,.12)"><?=ico($iStar,'#E8A020',14)?></div></div><div class="kpi-val" style="font-size:20px"><?=$avgRating?>★</div><div class="kpi-lbl">Avg Rating</div></div>
    </div>
    <!-- Revenue Chart -->
    <div class="panel">
      <div class="panel-hdr"><div class="panel-title"><?=ico($iBar,'#4A5568',13)?> Revenue (Last 7 Days)</div></div>
      <div class="panel-body"><div class="chart-wrap"><canvas id="mChartRevenue"></canvas></div></div>
    </div>
    <!-- Main tabs (mobile) -->
    <div class="panel">
      <div class="panel-hdr" style="padding:10px 14px">
        <div class="sec-tabs">
          <button class="sec-tab active" onclick="switchTab('mob-trips')">Trips</button>
          <button class="sec-tab" onclick="switchTab('mob-drivers')">Drivers</button>
          <button class="sec-tab" onclick="switchTab('mob-demand')">Peak</button>
        </div>
      </div>
      <div class="panel-body">
        <div id="tab-mob-trips" class="sec-panel active">
          <div class="chart-wrap"><canvas id="mChartTrips"></canvas></div>
          <div style="margin-top:12px">
            <?php foreach (array_slice($serviceData,0,5) as $i=>$sv):
              $pct = $totalBookings>0 ? round($sv['count']/$totalBookings*100) : 0;
            ?>
            <div class="prog-row">
              <div class="prog-lbl"><?=htmlspecialchars($sv['name'])?></div>
              <div class="prog-bar"><div class="prog-fill" style="width:<?=$pct?>%;background:<?=$colors[$i%5]?>"></div></div>
              <div class="prog-val"><?=$sv['count']?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <div id="tab-mob-drivers" class="sec-panel">
          <?php foreach (array_slice($topDriversData,0,5) as $d):
            $compRate=$d['trips']>0?round($d['completed']/$d['trips']*100):0;
          ?>
          <div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--bdr)">
            <div style="width:24px;height:24px;border-radius:6px;background:rgba(0,0,0,.06);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:var(--txt3)"><?=$d['rank']?></div>
            <div style="flex:1;min-width:0">
              <div style="font-size:12.5px;font-weight:700" class="trunc"><?=htmlspecialchars($d['name'])?></div>
              <div style="font-size:10.5px;color:var(--txt3)"><?=$d['trips']?> trips · <?=$compRate?>%</div>
            </div>
            <div style="font-weight:800;color:var(--gd);font-size:13px">₱<?=number_format($d['revenue'],0)?></div>
          </div>
          <?php endforeach; if(empty($topDriversData)): ?><div style="padding:20px;text-align:center;color:var(--txt3);font-size:12.5px">No data</div><?php endif; ?>
        </div>
        <div id="tab-mob-demand" class="sec-panel">
          <div class="chart-wrap"><canvas id="mChartPeak"></canvas></div>
          <div class="insight-grid" style="margin-top:12px">
            <div class="insight-card"><div class="insight-ico" style="background:rgba(0,208,132,.1)"><?=ico($iTarget,'#00D084',14)?></div><div><div class="insight-title">Peak Hour</div><div class="insight-body"><?=date('g A',$topHour*3600)?></div></div></div>
            <div class="insight-card"><div class="insight-ico" style="background:rgba(59,142,240,.1)"><?=ico($iClock,'#3B8EF0',14)?></div><div><div class="insight-title">Morning Rush</div><div class="insight-body"><?=number_format($amPeak)?> trips</div></div></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Date filter (mobile) -->
    <div class="panel">
      <div class="panel-hdr"><div class="panel-title"><?=ico($iTarget,'#4A5568',13)?> Custom Range</div></div>
      <div class="panel-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
          <div><div style="font-size:10.5px;font-weight:600;color:var(--txt3);text-transform:uppercase;margin-bottom:5px">From</div><input type="date" class="form-input" id="m-range-from" value="<?=$last30?>" style="height:36px;font-size:12.5px;padding:0 10px"></div>
          <div><div style="font-size:10.5px;font-weight:600;color:var(--txt3);text-transform:uppercase;margin-bottom:5px">To</div><input type="date" class="form-input" id="m-range-to" value="<?=$today?>" style="height:36px;font-size:12.5px;padding:0 10px"></div>
        </div>
        <button class="btn btn-success" style="width:100%" onclick="applyMobRangeFilter()"><?=ico($iRef,'#fff',13)?> Analyze Period</button>
        <div id="mob-range-results" style="display:none;margin-top:12px">
          <div id="mob-range-kpis" class="kpi-grid" style="grid-template-columns:1fr 1fr;gap:8px"></div>
        </div>
      </div>
    </div>
    <!-- Fleet overview -->
    <div class="panel">
      <div class="panel-hdr"><div class="panel-title"><?=ico($iTruck,'#4A5568',13)?> Fleet Overview</div></div>
      <div class="panel-body">
        <div class="g3"><div class="fleet-box"><div class="fleet-ico" style="background:linear-gradient(135deg,var(--g),var(--gd))"><?=ico($iTruck,'#fff',16)?></div><div class="fleet-v"><?=$activeVehicles?></div><div class="fleet-l">Vehicles</div></div><div class="fleet-box"><div class="fleet-ico" style="background:linear-gradient(135deg,#3B8EF0,#2563EB)"><?=ico($iUser,'#fff',16)?></div><div class="fleet-v"><?=$activeDrivers?></div><div class="fleet-l">Drivers</div></div><div class="fleet-box"><div class="fleet-ico" style="background:linear-gradient(135deg,#8B6FE8,#7C3AED)"><?=ico($iCrm,'#fff',16)?></div><div class="fleet-v"><?=$customerCount?></div><div class="fleet-l">Customers</div></div></div>
      </div>
    </div>
  </div><!-- /mob-body -->
  <!-- Mobile Nav -->
  <nav class="mob-nav">
    <button class="mn" onclick="window.location.href='booking_system.php'"><div class="mn-ico"><?=ico($iBook,'currentColor',20)?></div><div class="mn-lbl">Bookings</div></button>
    <button class="mn" onclick="window.location.href='payment_fares.php'"><div class="mn-ico"><?=ico($iPay,'currentColor',20)?></div><div class="mn-lbl">Payments</div></button>
    <button class="mn" onclick="window.location.href='gps_tracking.php'"><div class="mn-ico"><?=ico($iGps,'currentColor',20)?></div><div class="mn-lbl">GPS</div></button>
    <button class="mn active"><div class="mn-ico"><?=ico($iBar,'currentColor',20)?></div><div class="mn-lbl">Analytics</div></button>
  </nav>
  <div class="mob-toast" id="mobToast"></div>
</div><!-- /mob-shell -->

<!-- ══ Loading overlay ══════════════════════════════════════════════════════ -->
<div class="loading" id="loadingOverlay">
  <div class="spin-box">
    <div class="spinner"></div>
    <div class="spin-lbl" id="loadingLabel">Loading…</div>
  </div>
</div>

<!-- ══ Toast ════════════════════════════════════════════════════════════════ -->
<div class="toast" id="toastContainer"></div>

<!-- ══ DRIVER LEADERBOARD MODAL ═════════════════════════════════════════════ -->
<div class="modal" id="driverModal">
  <div class="modal-box modal-wide">
    <div class="modal-hdr">
      <div class="modal-title"><?=ico($iStar,'#E8A020',14)?>&nbsp; Driver Leaderboard</div>
      <button class="modal-close" onclick="closeModal('driverModal')"><?=ico($iX,'#4A5568',12)?></button>
    </div>
    <div class="modal-body">
      <div class="ldr-bar">
        <label>From</label>
        <input type="date" class="form-input" id="ldr-from" value="<?=$last30?>" style="width:140px;height:32px">
        <label>To</label>
        <input type="date" class="form-input" id="ldr-to" value="<?=$today?>" style="width:140px;height:32px">
        <button class="btn btn-success btn-sm" onclick="loadLeaderboard()"><?=ico($iRef,'#fff',12)?> Load</button>
      </div>
      <div id="ldr-loading" style="display:none;text-align:center;padding:24px;color:var(--txt3)"><div class="spinner" style="margin:0 auto 8px;width:26px;height:26px;border-width:2px"></div>Loading leaderboard…</div>
      <div id="ldr-table" style="overflow-x:auto">
        <table class="dtable">
          <thead>
            <tr>
              <th>#</th>
              <th>Driver</th>
              <th>Status</th>
              <th style="text-align:center">Trips</th>
              <th style="text-align:center">Completed</th>
              <th style="text-align:center">Cancelled</th>
              <th style="text-align:center">Comp. Rate</th>
              <th style="text-align:center">Rating</th>
              <th style="text-align:right">Revenue</th>
              <th style="text-align:right">Wallet</th>
            </tr>
          </thead>
          <tbody id="ldr-tbody">
            <tr><td colspan="10" style="text-align:center;padding:28px;color:var(--txt3)">Set a date range and click Load</td></tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost btn-sm" onclick="exportLeaderboard()"><?=ico($iDl,'#3A5248',12)?> Export CSV</button>
      <button class="btn btn-ghost btn-sm" onclick="closeModal('driverModal')" style="margin-left:auto"><?=ico($iX,'#3A5248',12)?> Close</button>
    </div>
  </div>
</div>

<!-- ══ EXPORT MODAL ══════════════════════════════════════════════════════════ -->
<div class="modal" id="exportModal">
  <div class="modal-box">
    <div class="modal-hdr">
      <div class="modal-title"><?=ico($iDl,'#3A5248',14)?>&nbsp; Export Data</div>
      <button class="modal-close" onclick="closeModal('exportModal')"><?=ico($iX,'#4A5568',12)?></button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <div class="form-label">Date Range</div>
        <div class="form-row">
          <input type="date" class="form-input" id="exp-from" value="<?=$last30?>">
          <input type="date" class="form-input" id="exp-to" value="<?=$today?>">
        </div>
      </div>
      <div class="form-group">
        <div class="form-label">Export Type</div>
        <select class="form-select" id="exp-type">
          <option value="bookings">Bookings Report (CSV)</option>
          <option value="trips">Trips Report (CSV)</option>
        </select>
      </div>
      <div style="background:var(--surf2);border-radius:10px;padding:12px;border:1px solid var(--bdr);font-size:12px;color:var(--txt3)">
        <?=ico($iAlert,'var(--txt4)',13)?> CSV export includes all records within the date range
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-success" onclick="doExport()"><?=ico($iDl,'#fff',13)?> Download CSV</button>
      <button class="btn btn-ghost" onclick="closeModal('exportModal')"><?=ico($iX,'#3A5248',12)?> Cancel</button>
    </div>
  </div>
</div>

<!-- ══ PHP Data ══════════════════════════════════════════════════════════════ -->
<script>
var PHP = {
  dailyRev:  <?=json_encode($dailyRevData)?>,
  dailyTrip: <?=json_encode($dailyTripData)?>,
  status:    <?=json_encode($statusData)?>,
  payment:   <?=json_encode($payMethodData)?>,
  peak:      <?=json_encode($peakHourData)?>,
  services:  <?=json_encode($serviceData)?>,
  totalBookings: <?=$totalBookings?>,
  totalRevenue: <?=$totalRevenue?>
};
</script>

<script>
// ── Utilities ──────────────────────────────────────────────────────────────────
function showLoading(show, lbl) {
  var el = document.getElementById('loadingOverlay');
  if (el) { el.className = 'loading' + (show?' show':''); }
  if (lbl && document.getElementById('loadingLabel')) document.getElementById('loadingLabel').textContent = lbl;
}

function toast(msg, type) {
  type = type || 'success';
  var isMob = window.innerWidth < 768;
  if (isMob) {
    var c = document.getElementById('mobToast');
    if (!c) return;
    var d = document.createElement('div');
    d.className = 'mob-toast-item' + (type==='error'?' error':type==='warn'?' warn':'');
    d.textContent = msg;
    c.appendChild(d);
    setTimeout(function(){if(d.parentNode)d.parentNode.removeChild(d);}, 3000);
  } else {
    var c = document.getElementById('toastContainer');
    if (!c) return;
    var d = document.createElement('div');
    d.className = 'toast-item' + (type==='error'?' error':type==='warn'?' warn':'');
    d.textContent = msg;
    c.appendChild(d);
    setTimeout(function(){if(d.parentNode)d.parentNode.removeChild(d);}, 3000);
  }
}

async function post(action, extra) {
  var fd = new FormData();
  fd.append('action', action);
  if (extra) Object.keys(extra).forEach(function(k){ fd.append(k, extra[k]); });
  var r = await fetch(window.location.href, { method:'POST', body:fd });
  return r.json();
}

function openModal(id) { var m=document.getElementById(id); if(m) m.classList.add('open'); }
function closeModal(id) { var m=document.getElementById(id); if(m) m.classList.remove('open'); }
function refreshAll() { showLoading(true,'Refreshing…'); setTimeout(function(){window.location.reload();},300); }
function fmtDate(d) { var dt=new Date(d+'T00:00:00'); return (dt.getMonth()+1)+'/'+(dt.getDate()); }
function fmtMoney(v) { return '₱'+Number(v).toLocaleString('en-PH',{maximumFractionDigits:0}); }

// ── Tab switching ──────────────────────────────────────────────────────────────
function switchTab(tabId) {
  // find the tab container
  var btn = event ? event.target : null;
  var tabsBar = btn ? btn.closest('.sec-tabs') : null;
  if (tabsBar) {
    tabsBar.querySelectorAll('.sec-tab').forEach(function(t){t.classList.remove('active');});
    if (btn) btn.classList.add('active');
  }
  // find sibling sec-panels
  var panelBody = tabsBar ? tabsBar.closest('.panel-hdr').nextElementSibling : null;
  if (panelBody) {
    panelBody.querySelectorAll('.sec-panel').forEach(function(p){p.classList.remove('active');});
    var tp = document.getElementById('tab-'+tabId);
    if (tp) tp.classList.add('active');
  }
}

// ── Charts ─────────────────────────────────────────────────────────────────────
var COLORS = ['#00D084','#3B8EF0','#8B6FE8','#E8A020','#E84040','#F07830','#4A9EFF','#9CA3AF'];

function buildRevChart(id, data) {
  var el = document.getElementById(id); if(!el) return;
  new Chart(el, {
    type:'line',
    data:{
      labels: data.map(function(d){return fmtDate(d.date);}),
      datasets:[{
        label:'Revenue',
        data: data.map(function(d){return d.rev;}),
        borderColor:'#00D084',backgroundColor:'rgba(0,208,132,.08)',
        tension:0.4,fill:true,pointRadius:4,pointBackgroundColor:'#00D084',pointBorderColor:'#fff',pointBorderWidth:2
      }]
    },
    options:{
      responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return fmtMoney(c.parsed.y);}}}},
      scales:{y:{beginAtZero:true,ticks:{callback:function(v){return '₱'+v.toLocaleString();}},grid:{color:'rgba(0,0,0,.04)'}},x:{grid:{display:false},ticks:{font:{size:10}}}}
    }
  });
}

function buildStatusChart() {
  var el = document.getElementById('chartStatus'); if(!el) return;
  var statColors = {'Completed':'#00D084','Confirmed':'#3B8EF0','In Progress':'#8B6FE8','Pending':'#E8A020','Cancelled':'#E84040','No Show':'#9CA3AF'};
  new Chart(el, {
    type:'doughnut',
    data:{
      labels: PHP.status.map(function(s){return s.status;}),
      datasets:[{data:PHP.status.map(function(s){return s.count;}),backgroundColor:PHP.status.map(function(s){return statColors[s.status]||'#9CA3AF';}),borderWidth:2,borderColor:'#fff'}]
    },
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{font:{size:11},padding:10,boxWidth:12}}}}
  });
}

function buildPaymentChart() {
  var el = document.getElementById('chartPayment'); if(!el) return;
  new Chart(el, {
    type:'bar',
    data:{
      labels: PHP.payment.map(function(p){return p.method;}),
      datasets:[{data:PHP.payment.map(function(p){return p.count;}),backgroundColor:COLORS,borderRadius:6,borderSkipped:false}]
    },
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1},grid:{color:'rgba(0,0,0,.04)'}},x:{grid:{display:false},ticks:{font:{size:10}}}}}
  });
}

function buildTripsChart(id) {
  id = id || 'chartTrips';
  var el = document.getElementById(id); if(!el) return;
  new Chart(el, {
    type:'bar',
    data:{
      labels: PHP.dailyTrip.map(function(d){return fmtDate(d.date);}),
      datasets:[{label:'Trips',data:PHP.dailyTrip.map(function(d){return d.count;}),backgroundColor:'rgba(59,142,240,.8)',borderRadius:5,borderSkipped:false}]
    },
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1},grid:{color:'rgba(0,0,0,.04)'}},x:{grid:{display:false},ticks:{font:{size:10}}}}}
  });
}

function buildServiceChart() {
  var el = document.getElementById('chartService'); if(!el) return;
  new Chart(el, {
    type:'doughnut',
    data:{
      labels: PHP.services.slice(0,6).map(function(s){return s.name;}),
      datasets:[{data:PHP.services.slice(0,6).map(function(s){return s.count;}),backgroundColor:COLORS,borderWidth:2,borderColor:'#fff'}]
    },
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{font:{size:10},padding:8,boxWidth:10}}}}
  });
}

function buildPeakChart(id) {
  id = id || 'chartPeak';
  var el = document.getElementById(id); if(!el) return;
  var max = Math.max.apply(null, PHP.peak.map(function(h){return h.count;})) || 1;
  new Chart(el, {
    type:'bar',
    data:{
      labels: PHP.peak.map(function(h){
        var ampm=h.hour<12?'am':'pm';
        var hr=h.hour===0?12:(h.hour>12?h.hour-12:h.hour);
        return hr+ampm;
      }),
      datasets:[{
        label:'Trips',
        data: PHP.peak.map(function(h){return h.count;}),
        backgroundColor: PHP.peak.map(function(h){
          var i=h.count/max;
          return 'rgba(0,'+ Math.round(208*i+60*(1-i)) +','+ Math.round(132*i+40*(1-i)) +','+(0.2+0.8*i)+')';
        }),
        borderRadius:4,borderSkipped:false
      }]
    },
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1},grid:{color:'rgba(0,0,0,.04)'}},x:{grid:{display:false},ticks:{font:{size:9}}}}}
  });
}

// Range chart ref
var rangeChart = null;
var revBreakdownChart = null;
var custTypeChart = null;

// ── Date range analysis ────────────────────────────────────────────────────────
async function applyDateFilter() {
  var from = document.getElementById('df-from').value;
  var to   = document.getElementById('df-to').value;
  if (!from||!to||from>to){ toast('Invalid date range','warn'); return; }
  // Sync range inputs
  ['range-from','range-to','exp-from','exp-to','ldr-from','ldr-to'].forEach(function(id){
    var el=document.getElementById(id);
    if(el){ if(id.includes('from')||id.includes('ldr-from')) el.value=from; else el.value=to; }
  });
  await applyRangeFilter();
}

async function applyRangeFilter() {
  var from = document.getElementById('range-from') ? document.getElementById('range-from').value : document.getElementById('df-from').value;
  var to   = document.getElementById('range-to') ? document.getElementById('range-to').value : document.getElementById('df-to').value;
  if (!from||!to||from>to){ toast('Invalid date range','warn'); return; }

  document.getElementById('range-placeholder') && (document.getElementById('range-placeholder').style.display='none');
  document.getElementById('range-loading') && (document.getElementById('range-loading').style.display='block');
  document.getElementById('range-results') && (document.getElementById('range-results').style.display='none');
  document.getElementById('range-export-btn') && (document.getElementById('range-export-btn').style.display='none');

  try {
    var res = await post('get_date_range_analytics',{from:from,to:to});
    document.getElementById('range-loading').style.display='none';
    if(!res.success){ toast('Failed to load analysis','error'); document.getElementById('range-placeholder').style.display=''; return; }

    document.getElementById('range-kpis').innerHTML = [
      {ico:'<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',col:'rgba(0,208,132,.1)',stroke:'#00D084',val:fmtMoney(res.revenue),lbl:'Revenue'},
      {ico:'<rect x="3" y="4" width="18" height="18" rx="2"/>',col:'rgba(59,142,240,.1)',stroke:'#3B8EF0',val:res.bookings,lbl:'Bookings'},
      {ico:'<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',col:'rgba(0,208,132,.1)',stroke:'#00D084',val:res.completion_rate+'%',lbl:'Completion'},
      {ico:'<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>',col:'rgba(232,64,64,.1)',stroke:'#E84040',val:res.cancellation_rate+'%',lbl:'Cancellation'},
      {ico:'<line x1="12" y1="1" x2="12" y2="23"/>',col:'rgba(232,160,32,.12)',stroke:'#E8A020',val:res.completed,lbl:'Completed'},
      {ico:'<circle cx="12" cy="12" r="10"/>',col:'rgba(139,111,232,.1)',stroke:'#8B6FE8',val:res.cancelled,lbl:'Cancelled'}
    ].map(function(k){
      return '<div class="kpi"><div class="kpi-top"><div class="kpi-ico" style="background:'+k.col+'"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="'+k.stroke+'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+k.ico+'</svg></div></div><div class="kpi-val" style="font-size:20px">'+k.val+'</div><div class="kpi-lbl">'+k.lbl+'</div></div>';
    }).join('');

    document.getElementById('range-results').style.display='block';
    document.getElementById('range-export-btn').style.display='';

    if (rangeChart) rangeChart.destroy();
    var rCtx = document.getElementById('chartRange');
    if (rCtx && res.daily && res.daily.length) {
      rangeChart = new Chart(rCtx, {
        type:'line',
        data:{
          labels:res.daily.map(function(d){return fmtDate(d.d);}),
          datasets:[{label:'Revenue',data:res.daily.map(function(d){return d.r;}),borderColor:'#00D084',backgroundColor:'rgba(0,208,132,.07)',tension:0.4,fill:true,pointRadius:3,pointBackgroundColor:'#00D084',pointBorderColor:'#fff',pointBorderWidth:2}]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return fmtMoney(c.parsed.y);}}}},scales:{y:{beginAtZero:true,ticks:{callback:function(v){return '₱'+v.toLocaleString();}},grid:{color:'rgba(0,0,0,.04)'}},x:{grid:{display:false}}}}
      });
    }
    toast('Analysis loaded: ' + from + ' → ' + to, 'success');
  } catch(e) {
    document.getElementById('range-loading').style.display='none';
    document.getElementById('range-placeholder').style.display='';
    toast('Error loading data','error');
  }
}

async function applyMobRangeFilter() {
  var from = document.getElementById('m-range-from').value;
  var to   = document.getElementById('m-range-to').value;
  if (!from||!to||from>to){ toast('Invalid date range','warn'); return; }
  showLoading(true,'Analyzing…');
  try {
    var res = await post('get_date_range_analytics',{from:from,to:to});
    showLoading(false);
    if(!res.success){ toast('Failed','error'); return; }
    document.getElementById('mob-range-kpis').innerHTML = [
      {val:fmtMoney(res.revenue),lbl:'Revenue',col:'rgba(0,208,132,.1)'},
      {val:res.bookings,lbl:'Bookings',col:'rgba(59,142,240,.1)'},
      {val:res.completion_rate+'%',lbl:'Completion',col:'rgba(0,208,132,.1)'},
      {val:res.cancellation_rate+'%',lbl:'Cancellation',col:'rgba(232,64,64,.1)'}
    ].map(function(k){return '<div class="kpi"><div class="kpi-top"><div class="kpi-ico" style="background:'+k.col+'"></div></div><div class="kpi-val" style="font-size:18px">'+k.val+'</div><div class="kpi-lbl">'+k.lbl+'</div></div>';}).join('');
    document.getElementById('mob-range-results').style.display='block';
    toast('Loaded: '+from+' → '+to);
  } catch(e){ showLoading(false); toast('Error','error'); }
}

// ── Driver leaderboard ─────────────────────────────────────────────────────────
function openDriverModal() { openModal('driverModal'); }

async function loadLeaderboard() {
  var from = document.getElementById('ldr-from').value;
  var to   = document.getElementById('ldr-to').value;
  if (!from||!to||from>to){ toast('Invalid date range','warn'); return; }
  document.getElementById('ldr-loading').style.display='block';
  document.getElementById('ldr-table').style.opacity='.4';
  try {
    var res = await post('get_driver_leaderboard',{from:from,to:to});
    document.getElementById('ldr-loading').style.display='none';
    document.getElementById('ldr-table').style.opacity='1';
    if(!res.success){ toast('Failed','error'); return; }
    var rBg=['rgba(232,160,32,.14)','rgba(156,163,175,.1)','rgba(205,127,50,.1)'];
    var rCol=['#E8A020','#9CA3AF','#CD7F32'];
    var statBadge={'Active':'badge-green','Offline':'badge-grey','In Progress':'badge-blue','Suspended':'badge-red','Pending':'badge-yellow'};
    document.getElementById('ldr-tbody').innerHTML = res.drivers.length
      ? res.drivers.map(function(d){
          var bg = rBg[Math.min(d.rank-1,2)] || 'rgba(0,0,0,.05)';
          var col = rCol[Math.min(d.rank-1,2)] || 'var(--txt3)';
          var sc = statBadge[d.status] || 'badge-grey';
          return '<tr>'+
            '<td><div class="rank-medal" style="background:'+bg+';color:'+col+'">'+d.rank+'</div></td>'+
            '<td><div style="font-weight:700">'+d.name+'</div><div style="font-size:10.5px;color:var(--txt3)">Comp. rate: '+d.comp_rate+'%</div></td>'+
            '<td><span class="badge '+sc+'">'+d.status+'</span></td>'+
            '<td style="text-align:center;font-weight:700">'+d.trips+'</td>'+
            '<td style="text-align:center"><span class="badge badge-green">'+d.completed+'</span></td>'+
            '<td style="text-align:center"><span class="badge badge-red">'+d.cancelled+'</span></td>'+
            '<td style="text-align:center"><span class="badge badge-yellow">'+d.comp_rate+'%</span></td>'+
            '<td style="text-align:center"><span class="badge badge-yellow">'+(d.rating||'—')+' ★</span></td>'+
            '<td style="text-align:right;font-weight:800;color:var(--gd)">₱'+Number(d.revenue).toLocaleString('en-PH',{maximumFractionDigits:0})+'</td>'+
            '<td style="text-align:right;color:var(--txt2)">₱'+Number(d.wallet).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2})+'</td>'+
            '</tr>';
        }).join('')
      : '<tr><td colspan="10" style="text-align:center;padding:28px;color:var(--txt3)">No driver data for this period</td></tr>';
    toast('Leaderboard updated','success');
  } catch(e){ document.getElementById('ldr-loading').style.display='none'; document.getElementById('ldr-table').style.opacity='1'; toast('Error','error'); }
}

function exportLeaderboard() {
  var tbody = document.getElementById('ldr-tbody');
  if (!tbody) return;
  var rows = [['Rank','Driver','Status','Trips','Completed','Cancelled','Comp. Rate','Rating','Revenue','Wallet']];
  tbody.querySelectorAll('tr').forEach(function(tr){
    var cells = tr.querySelectorAll('td');
    if (cells.length<5) return;
    rows.push([cells[0].textContent.trim(),cells[1].textContent.trim().replace(/\n/g,' '),cells[2].textContent.trim(),cells[3].textContent.trim(),cells[4].textContent.trim(),cells[5].textContent.trim(),cells[6].textContent.trim(),cells[7].textContent.trim(),cells[8].textContent.trim(),cells[9].textContent.trim()]);
  });
  var csv = rows.map(function(r){return r.map(function(c){return '"'+String(c).replace(/"/g,'""')+'"';}).join(',');}).join('\n');
  var a = document.createElement('a');
  a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
  a.download = 'leaderboard_'+document.getElementById('ldr-from').value+'_to_'+document.getElementById('ldr-to').value+'.csv';
  a.click();
}

// ── Revenue breakdown by service ───────────────────────────────────────────────
async function loadRevenueBreakdown() {
  var from = document.getElementById('df-from') ? document.getElementById('df-from').value : document.getElementById('range-from').value;
  var to   = document.getElementById('df-to') ? document.getElementById('df-to').value : document.getElementById('range-to').value;
  document.getElementById('rev-breakdown-placeholder').style.display='none';
  document.getElementById('rev-breakdown-loading').style.display='block';
  try {
    var res = await post('get_revenue_breakdown',{from:from,to:to});
    document.getElementById('rev-breakdown-loading').style.display='none';
    if(!res.success){ toast('Failed','error'); document.getElementById('rev-breakdown-placeholder').style.display=''; return; }
    // Chart
    if(revBreakdownChart) revBreakdownChart.destroy();
    var rCtx = document.getElementById('chartRevBreakdown');
    if(rCtx && res.breakdown.length) {
      revBreakdownChart = new Chart(rCtx, {
        type:'doughnut',
        data:{labels:res.breakdown.map(function(b){return b.name;}),datasets:[{data:res.breakdown.map(function(b){return b.amt;}),backgroundColor:COLORS,borderWidth:2,borderColor:'#fff'}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{font:{size:10},padding:8,boxWidth:10}},tooltip:{callbacks:{label:function(c){return fmtMoney(c.parsed);}}}}}
      });
    }
    // Table
    var maxAmt = res.breakdown.length ? res.breakdown[0].amt : 1;
    document.getElementById('rev-breakdown-table').innerHTML = '<table class="bk-table"><thead><tr><th>Service</th><th>Revenue</th><th style="min-width:100px">Share</th></tr></thead><tbody>' +
      res.breakdown.map(function(b,i){
        var pct = res.total>0 ? (b.amt/res.total*100).toFixed(1) : 0;
        var barPct = maxAmt>0 ? Math.round(b.amt/maxAmt*100) : 0;
        return '<tr><td style="font-weight:600">'+b.name+'</td><td style="font-weight:700;color:var(--gd)">'+fmtMoney(b.amt)+'</td><td><div class="mini-bar-wrap"><div class="mini-bar"><div class="mini-bar-fill" style="width:'+barPct+'%;background:'+COLORS[i%COLORS.length]+'"></div></div><div class="mini-bar-val">'+pct+'%</div></div></td></tr>';
      }).join('') + '</tbody></table>';
    document.getElementById('rev-breakdown').style.display='block';
    toast('Revenue breakdown loaded','success');
  } catch(e){ document.getElementById('rev-breakdown-loading').style.display='none'; document.getElementById('rev-breakdown-placeholder').style.display=''; toast('Error','error'); }
}

// ── Customer stats ─────────────────────────────────────────────────────────────
async function loadCustomerStats() {
  var from = document.getElementById('df-from') ? document.getElementById('df-from').value : '';
  var to   = document.getElementById('df-to') ? document.getElementById('df-to').value : '';
  document.getElementById('cust-placeholder').style.display='none';
  document.getElementById('cust-loading').style.display='block';
  try {
    var res = await post('get_customer_stats',{from:from,to:to});
    document.getElementById('cust-loading').style.display='none';
    if(!res.success){ toast('Failed','error'); document.getElementById('cust-placeholder').style.display=''; return; }
    if(custTypeChart) custTypeChart.destroy();
    var cCtx = document.getElementById('chartCustType');
    if(cCtx && res.by_type.length){
      custTypeChart = new Chart(cCtx, {
        type:'doughnut',
        data:{labels:res.by_type.map(function(t){return t.t;}),datasets:[{data:res.by_type.map(function(t){return t.c;}),backgroundColor:COLORS,borderWidth:2,borderColor:'#fff'}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{font:{size:10},padding:8,boxWidth:10}}}}
      });
    }
    document.getElementById('top-customers-table').innerHTML = res.top_customers.length
      ? '<table class="bk-table"><thead><tr><th>#</th><th>Customer</th><th>Type</th><th>Bookings</th><th>Revenue</th></tr></thead><tbody>'+
        res.top_customers.map(function(c,i){
          return '<tr><td style="font-weight:700;color:var(--txt3)">'+(i+1)+'</td><td style="font-weight:600">'+c.name+'</td><td><span class="badge badge-blue">'+c.type+'</span></td><td style="text-align:center">'+c.bookings+'</td><td style="font-weight:800;color:var(--gd)">'+fmtMoney(c.revenue)+'</td></tr>';
        }).join('') + '</tbody></table>'
      : '<div style="font-size:12px;color:var(--txt3);padding:16px 0">No customer data</div>';
    document.getElementById('cust-results').style.display='block';
    toast('Customer stats loaded','success');
  } catch(e){ document.getElementById('cust-loading').style.display='none'; document.getElementById('cust-placeholder').style.display=''; toast('Error','error'); }
}

// ── Operational metrics ────────────────────────────────────────────────────────
async function loadOperationalMetrics() {
  var extra = document.getElementById('ops-extra');
  if(!extra) return;
  extra.innerHTML = '<div style="text-align:center;padding:20px;color:var(--txt3)"><div class="spinner" style="margin:0 auto 8px;width:22px;height:22px;border-width:2px"></div>Loading…</div>';
  extra.style.display='block';
  try {
    var res = await post('get_operational_metrics',{});
    if(!res.success){ extra.innerHTML='<div style="color:var(--txt3);font-size:12px">Failed to load</div>'; return; }
    // update counters on satisfaction tab
    var orc = document.getElementById('openReportCount');
    var mrc = document.getElementById('maintRequestCount');
    if(orc) orc.textContent = res.total_reports;
    if(mrc) mrc.textContent = res.total_maint;
    extra.innerHTML = '<div class="g2" style="gap:14px;margin-top:2px">'+
      '<div><div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Report Types</div>'+
      (res.report_types.length ? res.report_types.map(function(r){
        return '<div class="prog-row"><div class="prog-lbl">'+r.t+'</div><div class="prog-bar"><div class="prog-fill" style="width:'+Math.min(100,Math.round(r.c/res.total_reports*100))+'%;background:var(--red)"></div></div><div class="prog-val">'+r.c+'</div></div>';
      }).join('') : '<div style="font-size:12px;color:var(--txt3)">No reports</div>') +
      '</div><div><div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Maintenance Issues</div>'+
      (res.maint_types.length ? res.maint_types.map(function(m){
        return '<div class="prog-row"><div class="prog-lbl">'+m.t+'</div><div class="prog-bar"><div class="prog-fill" style="width:'+Math.min(100,res.total_maint>0?Math.round(m.c/res.total_maint*100):0)+'%;background:var(--orange)"></div></div><div class="prog-val">'+m.c+'</div></div>';
      }).join('') : '<div style="font-size:12px;color:var(--txt3)">No maintenance requests</div>') +
      '</div></div>';
    toast('Operational report loaded','success');
  } catch(e){ extra.innerHTML='<div style="color:var(--txt3);font-size:12px">Error loading report</div>'; }
}

// ── Satisfaction details ───────────────────────────────────────────────────────
async function loadSatisfactionDetails() {
  var btn = event.target;
  btn.disabled = true;
  try {
    var res = await post('get_operational_metrics',{});
    if(!res.success){ toast('Failed','error'); btn.disabled=false; return; }
    var orc = document.getElementById('openReportCount');
    var mrc = document.getElementById('maintRequestCount');
    if(orc) orc.textContent = res.total_reports;
    if(mrc) mrc.textContent = res.total_maint;
    var det = document.getElementById('sat-details');
    det.innerHTML = '<div style="font-size:11.5px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Report Severity Breakdown</div>'+
      (res.report_severity.length ? res.report_severity.map(function(r){
        var sevCol={'Critical':'#E84040','High':'#F07830','Medium':'#E8A020','Low':'#00D084'}[r.s]||'#9CA3AF';
        return '<div class="prog-row"><div class="prog-lbl">'+r.s+'</div><div class="prog-bar"><div class="prog-fill" style="width:'+Math.min(100,res.total_reports>0?Math.round(r.c/res.total_reports*100):0)+'%;background:'+sevCol+'"></div></div><div class="prog-val">'+r.c+'</div></div>';
      }).join('') : '<div style="font-size:12px;color:var(--txt3)">No data</div>');
    det.style.display='block';
    toast('Details loaded','success');
  } catch(e){ toast('Error','error'); }
  btn.disabled = false;
}

// ── Export ─────────────────────────────────────────────────────────────────────
function showExportModal() { openModal('exportModal'); }
function exportRange() {
  document.getElementById('exp-from').value = document.getElementById('range-from').value;
  document.getElementById('exp-to').value   = document.getElementById('range-to').value;
  showExportModal();
}

async function doExport() {
  var from = document.getElementById('exp-from').value;
  var to   = document.getElementById('exp-to').value;
  var type = document.getElementById('exp-type').value;
  if(!from||!to){ toast('Select date range','warn'); return; }
  closeModal('exportModal');
  showLoading(true,'Exporting…');
  try {
    var res = await post('export_csv',{from:from,to:to,type:type});
    showLoading(false);
    if(!res.success){ toast('Export failed','error'); return; }
    var blob = new Blob([res.csv],{type:'text/csv'});
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = res.filename;
    a.click();
    toast('Exported: '+res.filename,'success');
  } catch(e){ showLoading(false); toast('Export error','error'); }
}

// ── Init ───────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  buildRevChart('chartRevenue', PHP.dailyRev);
  buildRevChart('mChartRevenue', PHP.dailyRev);
  buildStatusChart();
  buildPaymentChart();
  buildTripsChart('chartTrips');
  buildTripsChart('mChartTrips');
  buildServiceChart();
  buildPeakChart('chartPeak');
  buildPeakChart('mChartPeak');
});
</script>

<?php if (file_exists(__DIR__ . '/chat_widget.php')): ?>
<?php include __DIR__ . '/chat_widget.php'; ?>
<?php endif; ?>

</body>
</html>