<?php
session_start();
header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDatabaseConnection();
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

$fullName = $_POST['full_name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$userId = $_SESSION['user_id'];

if (empty($fullName)) {
    echo json_encode(['success' => false, 'message' => 'Full name is required']);
    exit;
}

if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        UPDATE core_users 
        SET full_name = :full_name, 
            email = :email, 
            phone = :phone,
            updated_at = CURRENT_TIMESTAMP
        WHERE user_id = :user_id
    ");
    
    $stmt->execute([
        'full_name' => $fullName,
        'email' => $email,
        'phone' => $phone,
        'user_id' => $userId
    ]);
    
    $_SESSION['full_name'] = $fullName;
    
    echo json_encode([
        'success' => true, 
        'message' => 'Profile updated successfully',
        'data' => [
            'full_name' => $fullName,
            'email' => $email,
            'phone' => $phone
        ]
    ]);
    
} catch (PDOException $e) {
    error_log("Profile update error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to update profile']);
}
?>