<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

define('SUPABASE_URL',     'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function supabase(string $table, string $method = 'GET', array $params = [], array $body = [], array $extraHeaders = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) {
        $url .= '?' . http_build_query($params);
    }

    $headers = [
        'apikey: '        . SUPABASE_ANON_KEY,
        'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        'Content-Type: application/json',
        'Accept: application/json',
    ];
    foreach ($extraHeaders as $h) {
        $headers[] = $h;
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($body && in_array($method, ['POST','PATCH'])) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }

    $response   = curl_exec($ch);
    $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $decoded = json_decode($response, true);
    return ['data' => $decoded, 'status' => $httpStatus, 'error' => ($httpStatus >= 400 ? $decoded : null)];
}

function getCore1DriverMap(array $core2DriverIds): array {
    if (empty($core2DriverIds)) return [];

    $inList = implode(',', array_map('intval', array_unique($core2DriverIds)));
    $res = supabase('core1_drivers', 'GET', [
        'select'          => 'id,driver_name,license_number,phone,email,status,wallet_balance,boundary_amount,assigned_vehicle_id,core2_driver_id',
        'core2_driver_id' => 'in.(' . $inList . ')',
    ]);

    if ($res['status'] >= 400 || empty($res['data'])) return [];

    $map = [];
    foreach ($res['data'] as $d) {
        if (!empty($d['core2_driver_id'])) {
            $map[(int)$d['core2_driver_id']] = $d;
        }
    }
    return $map;
}

function mergeDriverData(array $record, array $core1Map): array {
    $driverId = (int)($record['driver_id'] ?? 0);
    if ($driverId && isset($core1Map[$driverId])) {
        $c1 = $core1Map[$driverId];
        $record['driver_name']           = $c1['driver_name']           ?? $record['driver_name']    ?? null;
        $record['driver_phone']          = $c1['phone']                 ?? $record['driver_phone']   ?? null;
        $record['driver_email']          = $c1['email']                 ?? null;
        $record['driver_license']        = $c1['license_number']        ?? null;
        $record['driver_status']         = $c1['status']                ?? null;
        $record['driver_wallet_balance'] = $c1['wallet_balance']        ?? null;
        $record['driver_boundary']       = $c1['boundary_amount']       ?? null;
        $record['core1_driver_id']       = $c1['id']                    ?? null;
    }
    return $record;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    try {
        switch ($_POST['action']) {
            case 'get_all_complaints':
                $result = getAllComplaints($_POST['status'] ?? 'all');
                echo json_encode($result);
                break;

            case 'update_complaint_status':
                $result = updateComplaintStatus($_POST['report_id'], $_POST['status'], $_POST['notes'] ?? '');
                echo json_encode($result);
                break;

            case 'get_all_users':
                $result = getAllUsers($_POST['filter'] ?? 'all');
                echo json_encode($result);
                break;

            case 'update_user_status':
                $result = updateUserStatus($_POST['user_id'], $_POST['status']);
                echo json_encode($result);
                break;

            case 'create_announcement':
                $result = createAnnouncement($_POST);
                echo json_encode($result);
                break;

            case 'get_announcements':
                $result = getAnnouncements();
                echo json_encode($result);
                break;

            case 'get_customer_details':
                $result = getCustomerDetails($_POST['customer_id']);
                echo json_encode($result);
                break;

            case 'get_reviews':
                $result = getReviews($_POST['filter'] ?? 'all');
                echo json_encode($result);
                break;

            case 'search_customers':
                $result = searchCustomers($_POST['query']);
                echo json_encode($result);
                break;

            default:
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

function getAllComplaints(string $status = 'all'): array {
    $select = implode(',', [
        'report_id',
        'report_type',
        'severity',
        'description',
        'status',
        'reported_at',
        'resolved_at',
        'booking_id',
        'driver_id',
        'core2_customers(customer_id,name,phone,email)',
        'core2_bookings(booking_id,booking_reference,booking_date)',
    ]);

    $params = ['select' => $select, 'order' => 'reported_at.desc', 'limit' => '100'];
    if ($status !== 'all') {
        $params['status'] = 'eq.' . $status;
    }

    $res = supabase('core2_reports', 'GET', $params);

    if ($res['status'] >= 400) {
        return ['success' => false, 'message' => $res['error']['message'] ?? 'Failed to fetch complaints'];
    }

    $rows = $res['data'] ?? [];

    $driverIds = array_filter(array_unique(array_column($rows, 'driver_id')));
    $core1Map  = getCore1DriverMap($driverIds);

    $complaints = array_map(function ($r) use ($core1Map) {
        $r['customer_name']     = $r['core2_customers']['name']               ?? null;
        $r['customer_phone']    = $r['core2_customers']['phone']              ?? null;
        $r['customer_email']    = $r['core2_customers']['email']              ?? null;
        $r['booking_reference'] = $r['core2_bookings']['booking_reference']   ?? null;
        $r['booking_date']      = $r['core2_bookings']['booking_date']        ?? null;

        $r = mergeDriverData($r, $core1Map);

        unset($r['core2_customers'], $r['core2_bookings']);
        return $r;
    }, $rows);

    return ['success' => true, 'complaints' => $complaints];
}

function updateComplaintStatus(string $report_id, string $status, string $notes = ''): array {
    $patchBody = ['status' => $status];
    if (in_array($status, ['Resolved', 'Closed'])) {
        $patchBody['resolved_at'] = date('c'); // ISO 8601
    } else {
        $patchBody['resolved_at'] = null;
    }

    $res = supabase('core2_reports', 'PATCH',
        ['report_id' => 'eq.' . $report_id],
        $patchBody,
        ['Prefer: return=representation']
    );

    if ($res['status'] >= 400) {
        return ['success' => false, 'message' => $res['error']['message'] ?? 'Failed to update complaint'];
    }

    if (empty($res['data'])) {
        return ['success' => false, 'message' => 'Report not found'];
    }

    $report = $res['data'][0];

    if (!empty($report['booking_id'])) {
        $logNote = "Admin updated complaint #$report_id to $status" . ($notes ? ": $notes" : '');
        supabase('core2_booking_history', 'POST', [], [
            'booking_id'   => (int)$report['booking_id'],
            'change_type'  => 'Status Change',
            'changed_by'   => $_SESSION['user_id'] ?? null,
            'notes'        => $logNote,
            'changed_at'   => date('c'),
        ], ['Prefer: return=minimal']);
    }

    return ['success' => true, 'message' => 'Complaint status updated successfully'];
}

function getAllUsers(string $filter = 'all'): array {
    $params = [
        'select' => 'customer_id,customer_code,name,email,phone,customer_type,status,created_at,auth_user_id,core2_bookings(booking_id,total_amount)',
        'order'  => 'created_at.desc',
        'limit'  => '100',
    ];

    if ($filter === 'active') {
        $params['status'] = 'eq.Active';
    } elseif ($filter === 'inactive') {
        $params['status'] = 'eq.Inactive';
    }

    $res = supabase('core2_customers', 'GET', $params);

    if ($res['status'] >= 400) {
        return ['success' => false, 'message' => $res['error']['message'] ?? 'Failed to fetch users'];
    }

    $users = array_map(function ($c) {
        $bookings           = $c['core2_bookings'] ?? [];
        $c['user_id']       = $c['customer_id'];   // alias for JS compatibility
        $c['username']      = $c['name'];
        $c['full_name']     = $c['name'];
        $c['role']          = $c['customer_type'];
        $c['total_bookings']= count($bookings);
        $c['total_spent']   = array_sum(array_column($bookings, 'total_amount'));
        unset($c['core2_bookings']);
        return $c;
    }, $res['data'] ?? []);

    return ['success' => true, 'users' => $users];
}

function updateUserStatus(string $user_id, string $status): array {
    $res = supabase('core2_customers', 'PATCH',
        ['customer_id' => 'eq.' . $user_id],
        ['status' => $status],
        ['Prefer: return=representation']
    );

    if ($res['status'] >= 400) {
        return ['success' => false, 'message' => $res['error']['message'] ?? 'Failed to update user'];
    }

    if (empty($res['data'])) {
        return ['success' => false, 'message' => 'User not found'];
    }

    return ['success' => true, 'message' => 'User status updated successfully'];
}

function createAnnouncement(array $data): array {
    $title    = $data['title']    ?? '';
    $message  = $data['message']  ?? '';
    $target   = $data['target']   ?? 'all';
    $priority = $data['priority'] ?? 'normal';

    $userCount = 0;

    if ($target === 'driver') {
        $drvRes = supabase('core1_drivers', 'GET', [
            'select' => 'id,driver_name,core2_driver_id',
            'status' => 'eq.Active',
        ]);
        if ($drvRes['status'] >= 400) {
            return ['success' => false, 'message' => $drvRes['error']['message'] ?? 'Failed to fetch drivers'];
        }
        $userCount = count($drvRes['data'] ?? []);
        if ($userCount === 0) {
            return ['success' => false, 'message' => 'No active drivers found'];
        }
    } else {
        $params = ['select' => 'customer_id', 'status' => 'eq.Active'];
        if ($target !== 'all') {
            $typeMap = ['admin' => 'Corporate', 'staff' => 'Individual'];
            if (isset($typeMap[$target])) {
                $params['customer_type'] = 'eq.' . $typeMap[$target];
            }
        }
        $usersRes = supabase('core2_customers', 'GET', $params);
        if ($usersRes['status'] >= 400) {
            return ['success' => false, 'message' => $usersRes['error']['message'] ?? 'Failed to fetch users'];
        }
        $userCount = count($usersRes['data'] ?? []);
        if ($userCount === 0) {
            return ['success' => false, 'message' => 'No active users found for the selected target'];
        }
    }

    $announcementText = "ANNOUNCEMENT [$priority]: $title - $message";
    $insertRow = [
        'booking_id'  => 1,
        'change_type' => 'Created',
        'changed_by'  => isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null,
        'notes'       => $announcementText,
        'changed_at'  => date('c'),
    ];

    $insertRes = supabase('core2_booking_history', 'POST', [], $insertRow, ['Prefer: return=minimal']);

    if ($insertRes['status'] >= 400) {
        return ['success' => false, 'message' => $insertRes['error']['message'] ?? 'Failed to create announcement'];
    }

    return [
        'success'    => true,
        'message'    => 'Announcement sent to ' . $userCount . ' ' . ($target === 'driver' ? 'drivers' : 'users'),
        'user_count' => $userCount,
    ];
}

function getAnnouncements(): array {
    $params = [
        'select'      => 'history_id,booking_id,change_type,changed_by,notes,changed_at',
        'change_type' => 'eq.Created',
        'notes'       => 'like.ANNOUNCEMENT%',
        'order'       => 'changed_at.desc',
        'limit'       => '50',
    ];

    $res = supabase('core2_booking_history', 'GET', $params);

    if ($res['status'] >= 400) {
        return ['success' => false, 'message' => $res['error']['message'] ?? 'Failed to fetch announcements'];
    }

    $announcements = array_map(function ($a) {
        $a['created_by_name'] = 'Admin #' . ($a['changed_by'] ?? '?');
        return $a;
    }, $res['data'] ?? []);

    return ['success' => true, 'announcements' => $announcements];
}

function getCustomerDetails(string $customer_id): array {
    $custRes = supabase('core2_customers', 'GET', [
        'select'      => '*',
        'customer_id' => 'eq.' . $customer_id,
        'limit'       => '1',
    ]);

    if ($custRes['status'] >= 400 || empty($custRes['data'])) {
        return ['success' => false, 'message' => 'Customer not found'];
    }

    $customer = $custRes['data'][0];

    $bookRes = supabase('core2_bookings', 'GET', [
        'select'      => '*,core2_services(service_name)',
        'customer_id' => 'eq.' . $customer_id,
        'order'       => 'created_at.desc',
        'limit'       => '10',
    ]);

    $bookings = [];
    if ($bookRes['status'] < 400) {
        $bookings = array_map(function ($b) {
            $b['service_name'] = $b['core2_services']['service_name'] ?? null;
            unset($b['core2_services']);
            return $b;
        }, $bookRes['data'] ?? []);
    }

    $allBookRes = supabase('core2_bookings', 'GET', [
        'select'      => 'booking_id,total_amount,booking_status',
        'customer_id' => 'eq.' . $customer_id,
    ]);

    $allBookings = $allBookRes['data'] ?? [];
    $customer['total_bookings']  = count($allBookings);
    $customer['total_spent']     = array_sum(array_column($allBookings, 'total_amount'));
    $customer['completed_trips'] = count(array_filter($allBookings, fn($b) => $b['booking_status'] === 'Completed'));

    return ['success' => true, 'customer' => $customer, 'bookings' => $bookings];
}

function getReviews(string $filter = 'all'): array {
    $params = [
        'select' => implode(',', [
            'rating_id',
            'rating_value',
            'comment',
            'rating_type',
            'created_at',
            'driver_id',
            'core2_rides(ride_id,booking_id)',
            'core2_customers(name)',
        ]),
        'order' => 'created_at.desc',
        'limit' => '50',
    ];

    if ($filter === 'recent') {
        $params['created_at'] = 'gte.' . date('c', strtotime('-7 days'));
    } elseif ($filter === 'high') {
        $params['rating_value'] = 'gte.4';
    } elseif ($filter === 'low') {
        $params['rating_value'] = 'lte.2';
    }

    $res = supabase('core2_ratings', 'GET', $params);

    if ($res['status'] >= 400) {
        return ['success' => false, 'message' => $res['error']['message'] ?? 'Failed to fetch reviews'];
    }

    $rows = $res['data'] ?? [];

    $driverIds = array_filter(array_unique(array_column($rows, 'driver_id')));
    $core1Map  = getCore1DriverMap($driverIds);

    $reviews = array_map(function ($r) use ($core1Map) {
        $r['booking_id']    = $r['core2_rides']['booking_id']           ?? null;
        $r['customer_name'] = $r['core2_customers']['name']             ?? null;

        $r = mergeDriverData($r, $core1Map);

        unset($r['core2_rides'], $r['core2_customers']);
        return $r;
    }, $rows);

    return ['success' => true, 'reviews' => $reviews];
}

function searchCustomers(string $query): array {
    if (empty(trim($query))) {
        return ['success' => false, 'message' => 'Empty query'];
    }

    $params = [
        'select' => 'customer_id,name,email,phone,customer_type,status,created_at,core2_bookings(booking_id,total_amount)',
        'or'     => "(name.ilike.*{$query}*,phone.ilike.*{$query}*,email.ilike.*{$query}*)",
        'order'  => 'created_at.desc',
        'limit'  => '20',
    ];

    $res = supabase('core2_customers', 'GET', $params);

    if ($res['status'] >= 400) {
        return ['success' => false, 'message' => $res['error']['message'] ?? 'Search failed'];
    }

    $customers = array_map(function ($c) {
        $bookings           = $c['core2_bookings'] ?? [];
        $c['user_id']       = $c['customer_id'];
        $c['username']      = $c['name'];
        $c['full_name']     = $c['name'];
        $c['role']          = $c['customer_type'];
        $c['total_bookings']= count($bookings);
        $c['total_spent']   = array_sum(array_column($bookings, 'total_amount'));
        unset($c['core2_bookings']);
        return $c;
    }, $res['data'] ?? []);

    return ['success' => true, 'customers' => $customers];
}

$totalCustomers = 0;
$activeUsers    = 0;
$totalReviews   = 0;
$avgRating      = 0;
$openComplaints = 0;

try {
    $r = supabase('core2_customers', 'GET', ['select' => 'customer_id']);
    $totalCustomers = count($r['data'] ?? []);

    $r = supabase('core2_customers', 'GET', ['select' => 'customer_id', 'status' => 'eq.Active']);
    $activeUsers = count($r['data'] ?? []);

    $r = supabase('core2_ratings', 'GET', ['select' => 'rating_id,rating_value']);
    $ratings = $r['data'] ?? [];
    $totalReviews = count($ratings);
    $avgRating    = $totalReviews > 0
        ? array_sum(array_column($ratings, 'rating_value')) / $totalReviews
        : 0;

    $r = supabase('core2_reports', 'GET', ['select' => 'report_id', 'status' => 'eq.Open']);
    $openComplaints = count($r['data'] ?? []);

} catch (Exception $e) {
    error_log("CRM stats error: " . $e->getMessage());
}

$userName    = htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin');
$userInitial = strtoupper(substr($userName, 0, 1));

function ico($path, $stroke = '#4A5568', $size = 18) {
    return "<svg width='$size' height='$size' viewBox='0 0 24 24' fill='none' stroke='$stroke' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>$path</svg>";
}
$iBook    = "<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>";
$iPay     = "<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iCrm     = "<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iGps     = "<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/>";
$iBar     = "<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>";
$iDoc     = "<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/><line x1='16' y1='13' x2='8' y2='13'/><line x1='16' y1='17' x2='8' y2='17'/>";
$iHome    = "<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>";
$iTruck   = "<rect x='1' y='3' width='15' height='13'/><polygon points='16 8 20 8 23 11 23 16 16 16 16 8'/><circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/>";
$iUser    = "<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>";
$iOut     = "<path d='M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'/><polyline points='16 17 21 12 16 7'/><line x1='21' y1='12' x2='9' y2='12'/>";
$iRefresh = "<path d='M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2'/>";
$iBack    = "<path d='M19 12H5M12 19l-7-7 7-7'/>";
$iAlert   = "<circle cx='12' cy='12' r='10'></circle><line x1='12' y1='8' x2='12' y2='12'></line><line x1='12' y1='16' x2='12.01' y2='16'></line>";
$iMsg     = "<path d='M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z'></path>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CRM Management</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>

*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%}
.peso{font-family:'DM Sans',sans-serif;font-weight:700}

:root{
  --sb-bg:#991B1B; --sb-bg2:#7F1D1D; --sb-accent:#EF4444;
  --sb-txt:#FECACA; --sb-txt2:#FCA5A5; --sb-bdr:rgba(255,255,255,.1);
  --sb-hover:rgba(255,255,255,.09); --sb-active:rgba(255,255,255,.16);
  --sb-active-bdr:rgba(255,255,255,.28);
  --g:#00D084; --gd:#00A86B; --gx:#005A38;
  --gg:rgba(0,208,132,.1);
  --bg:#F0F4F2; --surf:#fff; --surf2:#F7FAF8; --surf3:#EEF5F1;
  --bdr:#DDE8E2; --bdr2:#C8DDD5;
  --txt:#0D1F18; --txt2:#3A5248; --txt3:#7A9A8E; --txt4:#B0C8BC;
  --blue:#3B8EF0; --purple:#8B6FE8; --orange:#F07830; --red:#E84040; --yellow:#E8A020;
  --sw:248px; --th:58px; --r:16px; --rs:10px;
  --shadow:0 1px 3px rgba(0,0,0,.04),0 4px 16px rgba(0,0,0,.06);
  --shadow-md:0 2px 8px rgba(0,0,0,.05),0 8px 28px rgba(0,0,0,.09);
}

body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--txt);-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit}
.trunc{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mono{font-family:'DM Mono',monospace}
.badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:3px 8px;border-radius:5px;text-transform:uppercase;letter-spacing:.4px}
.badge::before{content:'';width:5px;height:5px;border-radius:50%;flex-shrink:0}
.badge-green{background:rgba(0,208,132,.12);color:#008A58}.badge-green::before{background:#00A86B}
.badge-blue{background:rgba(59,142,240,.1);color:#1966C2}.badge-blue::before{background:#3B8EF0}
.badge-yellow{background:rgba(232,160,32,.12);color:#9A6A00}.badge-yellow::before{background:#E8A020}
.badge-red{background:rgba(232,64,64,.1);color:#C22020}.badge-red::before{background:#E84040}
.badge-purple{background:rgba(139,111,232,.1);color:#5A3FBB}.badge-purple::before{background:#8B6FE8}
.badge-gray{background:rgba(100,116,139,.1);color:#4B5563}.badge-gray::before{background:#6B7280}

@media(min-width:900px){

  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}

  .sidebar{width:var(--sw);flex-shrink:0;height:100vh;display:flex;flex-direction:column;background:var(--sb-bg);overflow:hidden;box-shadow:3px 0 18px rgba(153,27,27,.22)}
  .sb-logo{height:var(--th);display:flex;align-items:center;gap:10px;padding:0 18px;border-bottom:1px solid var(--sb-bdr);flex-shrink:0}
  .sb-logo img{height:26px;filter:brightness(0) invert(1)}
  .sb-brand{font-size:16px;font-weight:800;letter-spacing:-.3px;color:#fff}.sb-brand span{color:#FCA5A5}
  .sb-nav{flex:1;overflow-y:auto;padding:12px 10px;display:flex;flex-direction:column;gap:1px}
  .sb-label{font-size:9.5px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:var(--sb-txt2);padding:14px 10px 5px}
  .sb-item{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:9px;cursor:pointer;color:rgba(255,255,255,.75);font-size:13px;font-weight:500;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover);color:#fff}
  .sb-item.active{background:var(--sb-active);color:#fff;border-color:var(--sb-active-bdr);font-weight:600}
  .sb-ico{width:30px;height:30px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item:hover .sb-ico,.sb-item.active .sb-ico{background:rgba(255,255,255,.16)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-foot{padding:12px 10px;border-top:1px solid var(--sb-bdr);flex-shrink:0;display:flex;gap:8px;align-items:center}
  .sb-av{width:34px;height:34px;border-radius:9px;flex-shrink:0;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;border:1px solid rgba(255,255,255,.28)}
  .sb-uname{font-size:12.5px;font-weight:600;color:#fff}
  .sb-urole{font-size:11px;color:var(--sb-txt2)}
  .sb-out{margin-left:auto;width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s}
  .sb-out:hover{background:rgba(239,68,68,.3)}
  .sb-out svg{stroke:#fff!important}

  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}

  .topbar{height:var(--th);flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 24px;gap:12px}
  .tb-title{flex:1;font-size:16px;font-weight:800;letter-spacing:-.2px}
  .tb-date{font-size:12px;color:var(--txt3);font-weight:500}
  .tb-sep{width:1px;height:18px;background:var(--bdr)}
  .tb-btn{height:34px;padding:0 14px;border-radius:8px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12.5px;font-weight:600;color:var(--txt2);transition:all .15s}
  .tb-btn:hover{background:var(--bg)}
  .tb-btn svg{stroke:var(--txt3)!important}

  .desk-scroll{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:16px}
  .desk-scroll::-webkit-scrollbar{width:0;background:transparent}
  .desk-scroll{scrollbar-width:none}

  .kpi-row{display:grid;grid-template-columns:repeat(5,1fr);gap:11px}
  .kpi{background:var(--surf);border-radius:14px;padding:14px 16px;border:1px solid var(--bdr);transition:all .2s;animation:fadeUp .3s ease both}
  .kpi:hover{box-shadow:var(--shadow);transform:translateY(-1px)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
  .kpi-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center}
  .kpi-num{font-size:10px;font-weight:700;padding:2px 7px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:26px;font-weight:800;line-height:1;margin-bottom:3px;letter-spacing:-.5px}
  .kpi-lbl{font-size:11px;color:var(--txt3);font-weight:500}

  .crm-tabs{display:flex;gap:2px;background:var(--surf2);border-radius:12px;padding:4px;border:1px solid var(--bdr);margin-bottom:4px}
  .crm-tab{padding:7px 16px;border-radius:9px;font-size:12.5px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s;white-space:nowrap;display:flex;align-items:center;gap:6px}
  .crm-tab.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .crm-tab svg{stroke:var(--txt3)!important}
  .crm-tab.active svg{stroke:var(--gd)!important}

  .panel{background:var(--surf);border-radius:var(--r);padding:0;border:1px solid var(--bdr);overflow:hidden;animation:fadeUp .35s ease}
  .panel-h{padding:14px 18px;font-size:14px;font-weight:800;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .panel-body{padding:16px 18px}

  .list-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:12px}
  .list-item{background:var(--surf);border-radius:13px;padding:16px;border:1px solid var(--bdr);transition:all .2s}
  .list-item:hover{box-shadow:var(--shadow);border-color:var(--bdr2)}
  .list-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:11px}
  .list-title{font-size:14px;font-weight:800;color:var(--txt)}
  .list-info{font-size:12.5px;color:var(--txt2);margin-bottom:4px;display:flex;gap:6px}
  .list-info strong{font-weight:600;color:var(--txt);flex-shrink:0;min-width:90px}
  .list-actions{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:12px;padding-top:12px;border-top:1px solid var(--bdr)}

  .btn{padding:7px 13px;border-radius:8px;font-size:11.5px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
  .btn:active{transform:scale(.97)}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-success:hover{box-shadow:0 4px 12px rgba(0,208,132,.3)}
  .btn-info{background:linear-gradient(135deg,#60A5FA,#3B82F6);color:#fff}
  .btn-warning{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-danger:hover{box-shadow:0 4px 12px rgba(232,64,64,.3)}
  .btn-primary{background:linear-gradient(135deg,var(--g),var(--gd));color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-ghost:hover{background:var(--bg)}
  .btn-sm{padding:5px 10px;font-size:11px}
  .btn-full{width:100%;justify-content:center}

  .status-badge{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:3px 8px;border-radius:5px;text-transform:uppercase;letter-spacing:.4px}
  .status-open{background:rgba(232,160,32,.12);color:#9A6A00}
  .status-resolved{background:rgba(0,208,132,.12);color:#008A58}
  .status-closed{background:rgba(100,116,139,.1);color:#4B5563}
  .status-under-review,.status-under_review{background:rgba(59,142,240,.1);color:#1966C2}
  .status-active{background:rgba(0,208,132,.12);color:#008A58}
  .status-inactive{background:rgba(232,64,64,.1);color:#C22020}

  .form-group{margin-bottom:14px}
  .form-label{display:block;font-size:11.5px;font-weight:600;color:var(--txt2);margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:10px 13px;font-size:13px;border:1.5px solid var(--bdr);border-radius:9px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif;transition:all .2s}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:var(--g);background:var(--surf);box-shadow:0 0 0 3px rgba(0,208,132,.08)}
  .form-textarea{resize:vertical;min-height:80px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .search-box{position:relative;margin-bottom:14px}
  .search-input{padding-left:38px!important}
  .search-icon{position:absolute;left:12px;top:50%;transform:translateY(-50%);pointer-events:none}

  .toast{position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:#0D5F3A;color:#fff;padding:11px 16px;border-radius:10px;font-size:13px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:9px;animation:toastIn .3s ease;max-width:320px}
  .toast-item.error{background:#5F1313;border-left:3px solid var(--red)}
  .toast-item.success{border-left:3px solid var(--g)}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  @keyframes toastOut{from{opacity:1}to{opacity:0;transform:translateX(20px)}}

  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.active{display:flex}
  .spin-box{background:var(--surf);border-radius:16px;padding:26px 34px;text-align:center;box-shadow:var(--shadow-md)}
  .spinner{width:42px;height:42px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}

  .tab-content{display:none}
  .tab-content.active{display:block;animation:fadeUp .35s ease}
  @keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
  @keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
  .kpi:nth-child(1){animation-delay:.03s}.kpi:nth-child(2){animation-delay:.06s}
  .kpi:nth-child(3){animation-delay:.09s}.kpi:nth-child(4){animation-delay:.12s}
  .kpi:nth-child(5){animation-delay:.15s}

  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(4px);z-index:1000;align-items:center;justify-content:center;padding:20px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:20px;max-width:600px;width:100%;max-height:88vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:var(--shadow-md)}
  .modal-wide{max-width:720px}
  .modal-hdr{padding:18px 22px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s}
  .modal-close:hover{background:var(--bg)}
  .modal-body{padding:20px 22px;overflow-y:auto;flex:1}
  .modal-foot{padding:14px 22px;border-top:1px solid var(--bdr);display:flex;gap:8px;flex-shrink:0}

  .conv-layout{display:grid;grid-template-columns:300px 1fr;height:calc(100vh - 230px);gap:0;background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);overflow:hidden}
  .conv-list{border-right:1px solid var(--bdr);overflow-y:auto;display:flex;flex-direction:column}
  .conv-list::-webkit-scrollbar{width:0}
  .conv-search{padding:12px;border-bottom:1px solid var(--bdr);flex-shrink:0}
  .conv-item{padding:12px 14px;border-bottom:1px solid var(--bdr);cursor:pointer;transition:background .15s;display:flex;gap:10px;align-items:flex-start}
  .conv-item:hover{background:var(--surf2)}
  .conv-item.active{background:var(--gg);border-right:3px solid var(--g)}
  .conv-av{width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,var(--g),var(--gd));display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;color:#fff;flex-shrink:0}
  .conv-info{flex:1;min-width:0}
  .conv-name{font-size:13px;font-weight:700;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .conv-preview{font-size:11.5px;color:var(--txt3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}
  .conv-time{font-size:10.5px;color:var(--txt4);flex-shrink:0}
  .conv-unread{width:18px;height:18px;border-radius:50%;background:var(--g);color:#fff;font-size:9px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .conv-main{display:flex;flex-direction:column;background:var(--surf2)}
  .conv-header{padding:14px 18px;border-bottom:1px solid var(--bdr);background:var(--surf);display:flex;align-items:center;gap:12px;flex-shrink:0}
  .conv-messages{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px}
  .conv-messages::-webkit-scrollbar{width:0}
  .msg-row{display:flex;gap:8px;align-items:flex-end}
  .msg-row.admin{flex-direction:row-reverse}
  .msg-bubble{max-width:65%;padding:10px 13px;border-radius:14px;font-size:13px;line-height:1.5}
  .msg-bubble.customer{background:var(--surf);border:1px solid var(--bdr);color:var(--txt);border-radius:14px 14px 14px 4px}
  .msg-bubble.admin{background:linear-gradient(135deg,var(--g),var(--gd));color:#fff;border-radius:14px 14px 4px 14px}
  .msg-meta{font-size:10.5px;color:var(--txt3);margin-top:3px;text-align:right}
  .msg-meta.admin{text-align:left;color:rgba(255,255,255,.75)}
  .conv-input{padding:14px 18px;border-top:1px solid var(--bdr);background:var(--surf);display:flex;gap:10px;align-items:flex-end;flex-shrink:0}
  .conv-input textarea{flex:1;border:1.5px solid var(--bdr);border-radius:10px;padding:10px 13px;font-size:13px;font-family:'DM Sans',sans-serif;color:var(--txt);background:var(--surf2);resize:none;min-height:42px;max-height:120px}
  .conv-input textarea:focus{outline:none;border-color:var(--g)}
  .no-conv{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--txt3);gap:12px}

  .stars{display:flex;gap:2px}
  .star{color:#E8A020;font-size:14px}
  .star.empty{color:var(--bdr2);font-size:14px}

  .d-row{display:flex;align-items:flex-start;padding:8px 0;border-bottom:1px solid var(--bdr)}
  .d-row:last-child{border:none}
  .d-label{width:140px;font-size:11.5px;font-weight:600;color:var(--txt3);flex-shrink:0;padding-top:1px}
  .d-val{font-size:13px;color:var(--txt);font-weight:500;flex:1}
  .section-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:10px;margin-top:16px}
  .section-label:first-child{margin-top:0}
}

@media(min-width:768px) and (max-width:899px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}
  .sidebar{width:58px;height:100vh;background:var(--sb-bg);display:flex;flex-direction:column;align-items:center;padding:10px 0;gap:3px;flex-shrink:0}
  .sb-logo{width:100%;height:52px;display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--sb-bdr);margin-bottom:6px}
  .sb-logo img{height:24px;filter:brightness(0) invert(1)}
  .sb-brand,.sb-label{display:none}
  .sb-nav{flex:1;width:100%;padding:4px 6px;display:flex;flex-direction:column;align-items:center;gap:2px}
  .sb-item{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:1px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-hover)}.sb-item.active{background:var(--sb-active);border-color:var(--sb-active-bdr)}
  .sb-ico{width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.08)}
  .sb-item svg{stroke:rgba(255,255,255,.6)!important}.sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-foot{padding:8px 6px;border-top:1px solid var(--sb-bdr);width:100%;display:flex;flex-direction:column;align-items:center;gap:5px}
  .sb-av{width:32px;height:32px;border-radius:8px;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:#fff}
  .sb-uname,.sb-urole{display:none}
  .sb-out{width:28px;height:28px;border-radius:7px;background:rgba(255,255,255,.1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .sb-out svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:52px;flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 16px;gap:10px}
  .tb-title{flex:1;font-size:15px;font-weight:800}.tb-date{font-size:11px;color:var(--txt3)}.tb-sep{width:1px;height:16px;background:var(--bdr)}
  .tb-btn{height:30px;padding:0 11px;border-radius:7px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;gap:5px;cursor:pointer;font-size:11.5px;font-weight:600;color:var(--txt2)}
  .desk-scroll{flex:1;overflow-y:auto;padding:12px 14px;display:flex;flex-direction:column;gap:12px;scrollbar-width:none}
  .desk-scroll::-webkit-scrollbar{width:0}
  .kpi-row{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
  .kpi{background:var(--surf);border-radius:12px;padding:12px 14px;border:1px solid var(--bdr)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
  .kpi-ico{width:28px;height:28px;border-radius:7px;display:flex;align-items:center;justify-content:center}
  .kpi-num{font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:5px;background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-size:20px;font-weight:800;line-height:1;margin-bottom:2px}.kpi-lbl{font-size:10px;color:var(--txt3)}
  .crm-tabs{display:flex;gap:2px;background:var(--surf2);border-radius:10px;padding:3px;border:1px solid var(--bdr);flex-wrap:wrap}
  .crm-tab{padding:6px 12px;border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;color:var(--txt3);border:none;background:none;transition:all .15s;display:flex;align-items:center;gap:5px}
  .crm-tab.active{background:var(--surf);color:var(--txt);box-shadow:0 1px 4px rgba(0,0,0,.07)}
  .panel{background:var(--surf);border-radius:12px;padding:0;border:1px solid var(--bdr);overflow:hidden}
  .panel-h{padding:12px 14px;font-size:13px;font-weight:800;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between}
  .panel-body{padding:14px}
  .list-grid{display:grid;grid-template-columns:1fr;gap:10px}
  .list-item{background:var(--surf);border-radius:11px;padding:14px;border:1px solid var(--bdr)}
  .list-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:9px}
  .list-title{font-size:13px;font-weight:800}
  .list-info{font-size:12px;color:var(--txt2);margin-bottom:3px;display:flex;gap:6px}
  .list-info strong{font-weight:600;color:var(--txt);flex-shrink:0;min-width:80px}
  .list-actions{display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid var(--bdr)}
  .btn{padding:6px 11px;border-radius:7px;font-size:11px;font-weight:600;border:none;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:4px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-warning{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-primary{background:linear-gradient(135deg,var(--g),var(--gd));color:#fff}
  .btn-ghost{background:var(--surf2);border:1px solid var(--bdr);color:var(--txt2)}
  .btn-full{width:100%;justify-content:center}
  .status-badge{display:inline-flex;align-items:center;font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:5px;text-transform:uppercase;letter-spacing:.3px}
  .status-open{background:rgba(232,160,32,.12);color:#9A6A00}
  .status-resolved{background:rgba(0,208,132,.12);color:#008A58}
  .status-closed{background:rgba(100,116,139,.1);color:#4B5563}
  .status-under-review,.status-under_review{background:rgba(59,142,240,.1);color:#1966C2}
  .status-active{background:rgba(0,208,132,.12);color:#008A58}
  .status-inactive{background:rgba(232,64,64,.1);color:#C22020}
  .form-group{margin-bottom:12px}
  .form-label{display:block;font-size:11px;font-weight:600;color:var(--txt2);margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:9px 12px;font-size:12.5px;border:1.5px solid var(--bdr);border-radius:8px;background:var(--surf2);color:var(--txt);font-family:'DM Sans',sans-serif;transition:all .2s}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:var(--g)}
  .form-textarea{resize:vertical;min-height:75px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .search-box{position:relative;margin-bottom:12px}
  .search-input{padding-left:36px!important}
  .search-icon{position:absolute;left:11px;top:50%;transform:translateY(-50%);pointer-events:none}
  .toast{position:fixed;bottom:18px;right:18px;z-index:9999;display:flex;flex-direction:column;gap:7px}
  .toast-item{background:#0D5F3A;color:#fff;padding:10px 14px;border-radius:9px;font-size:12.5px;font-weight:500;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:8px;animation:toastIn .3s ease;max-width:280px}
  .toast-item.error{background:#5F1313}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.active{display:flex}
  .spin-box{background:var(--surf);border-radius:13px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid var(--bdr);border-top-color:var(--g);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  .tab-content{display:none}.tab-content.active{display:block;animation:fadeUp .3s ease}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);z-index:1000;align-items:center;justify-content:center;padding:16px}
  .modal.open{display:flex}
  .modal-box{background:var(--surf);border-radius:17px;max-width:540px;width:100%;max-height:86vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-hdr{padding:16px 20px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
  .modal-title{font-size:14px;font-weight:800}
  .modal-close{width:27px;height:27px;border-radius:7px;border:1px solid var(--bdr);background:var(--surf2);cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:18px 20px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 20px;border-top:1px solid var(--bdr);display:flex;gap:7px}
  .stars{display:flex;gap:2px}.star{color:#E8A020;font-size:13px}.star.empty{color:var(--bdr2);font-size:13px}
  .d-row{display:flex;padding:7px 0;border-bottom:1px solid var(--bdr)}.d-row:last-child{border:none}
  .d-label{width:120px;font-size:11px;font-weight:600;color:var(--txt3);flex-shrink:0}
  .d-val{font-size:12.5px;color:var(--txt);font-weight:500;flex:1}
  .section-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);margin-bottom:8px;margin-top:14px}.section-label:first-child{margin-top:0}
  .conv-layout{display:flex;flex-direction:column;height:calc(100vh - 200px);background:var(--surf);border:1px solid var(--bdr);border-radius:12px;overflow:hidden}
  .conv-list{max-height:220px;overflow-y:auto;border-bottom:1px solid var(--bdr)}
  .conv-item{padding:10px 12px;border-bottom:1px solid var(--bdr);cursor:pointer;display:flex;gap:8px;align-items:flex-start;transition:background .15s}
  .conv-item:hover{background:var(--surf2)}.conv-item.active{background:var(--gg)}
  .conv-av{width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,var(--g),var(--gd));display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;flex-shrink:0}
  .conv-info{flex:1;min-width:0}.conv-name{font-size:12.5px;font-weight:700;color:var(--txt)}.conv-preview{font-size:11px;color:var(--txt3)}
  .conv-main{display:flex;flex-direction:column;flex:1}
  .conv-header{padding:12px 14px;border-bottom:1px solid var(--bdr);background:var(--surf);display:flex;align-items:center;gap:10px;flex-shrink:0}
  .conv-messages{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px;scrollbar-width:none}
  .msg-row{display:flex;gap:7px;align-items:flex-end}.msg-row.admin{flex-direction:row-reverse}
  .msg-bubble{max-width:70%;padding:9px 12px;border-radius:12px;font-size:12.5px;line-height:1.45}
  .msg-bubble.customer{background:var(--surf);border:1px solid var(--bdr);color:var(--txt)}
  .msg-bubble.admin{background:linear-gradient(135deg,var(--g),var(--gd));color:#fff}
  .msg-meta{font-size:10px;color:var(--txt3);margin-top:2px}.msg-meta.admin{color:rgba(255,255,255,.75)}
  .conv-input{padding:12px 14px;border-top:1px solid var(--bdr);background:var(--surf);display:flex;gap:8px;flex-shrink:0}
  .conv-input textarea{flex:1;border:1.5px solid var(--bdr);border-radius:9px;padding:9px 12px;font-size:12.5px;font-family:'DM Sans',sans-serif;color:var(--txt);background:var(--surf2);resize:none;min-height:40px}
  .conv-input textarea:focus{outline:none;border-color:var(--g)}
  .no-conv{padding:32px;text-align:center;color:var(--txt3)}
}

@media(max-width:767px){
  .sidebar,.desk-wrap{display:none!important}
  body{background:#EFF5F2;padding-bottom:80px}
  .mob-header{position:sticky;top:0;z-index:100;background:rgba(255,255,255,.9);backdrop-filter:blur(16px);border-bottom:1px solid rgba(0,0,0,.06);padding:12px 16px;display:flex;align-items:center;gap:10px}
  .mh-back{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mh-title{flex:1;font-size:16px;font-weight:800;text-align:center}
  .mh-btn{width:34px;height:34px;border-radius:10px;background:rgba(0,0,0,.05);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
  .mob-body{padding:14px 14px 18px;display:flex;flex-direction:column;gap:12px}
  .m-kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
  .mkpi{background:#fff;border-radius:13px;padding:12px 10px;border:1px solid #DDE8E2;text-align:center}
  .mkpi-v{font-size:20px;font-weight:800;line-height:1;color:#0D1F18}
  .mkpi-l{font-size:10px;color:#7A9A8E;margin-top:3px}
  .m-tabs-row{display:flex;gap:6px;overflow-x:auto;padding-bottom:4px}
  .m-tab-btn{padding:7px 14px;border-radius:20px;font-size:12px;font-weight:600;border:1.5px solid #DDE8E2;background:#fff;white-space:nowrap;cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:5px}
  .m-tab-btn.active{background:rgba(0,208,132,.1);border-color:rgba(0,208,132,.3);color:#008A58}
  .m-search{position:relative}
  .m-search input{width:100%;height:38px;padding:0 14px 0 36px;border-radius:12px;border:1.5px solid #DDE8E2;background:#fff;font-size:13px;font-family:'DM Sans',sans-serif;color:#0D1F18}
  .m-search input:focus{outline:none;border-color:#00D084}
  .m-search svg{position:absolute;left:10px;top:50%;transform:translateY(-50%);pointer-events:none}
  .m-list{display:flex;flex-direction:column;gap:10px}
  .m-item{background:#fff;border-radius:16px;border:1.5px solid #DDE8E2;overflow:hidden;padding:14px}
  .mi-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}
  .mi-title{font-size:14px;font-weight:800;color:#0D1F18}
  .status-badge{display:inline-flex;align-items:center;font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:5px;text-transform:uppercase;letter-spacing:.3px}
  .status-open{background:rgba(232,160,32,.12);color:#9A6A00}
  .status-resolved{background:rgba(0,208,132,.12);color:#008A58}
  .status-closed{background:rgba(100,116,139,.1);color:#4B5563}
  .status-under-review,.status-under_review{background:rgba(59,142,240,.1);color:#1966C2}
  .status-active{background:rgba(0,208,132,.12);color:#008A58}
  .status-inactive{background:rgba(232,64,64,.1);color:#C22020}
  .mi-info{font-size:12.5px;color:#3A5248;margin-bottom:4px;display:flex;gap:6px}
  .mi-info strong{font-weight:600;color:#0D1F18;flex-shrink:0;min-width:80px}
  .mi-actions{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:12px;padding-top:12px;border-top:1px solid #DDE8E2}
  .btn{padding:9px 13px;border-radius:9px;font-size:12px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:5px}
  .btn-success{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-warning{background:linear-gradient(135deg,#FB923C,#F07830);color:#fff}
  .btn-danger{background:linear-gradient(135deg,#E84040,#C22020);color:#fff}
  .btn-primary{background:linear-gradient(135deg,#00D084,#00A86B);color:#fff}
  .btn-ghost{background:rgba(0,0,0,.04);color:#3A5248}
  .btn-full{width:100%;justify-content:center}
  .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1000;align-items:flex-end;justify-content:center}
  .modal.open{display:flex}
  .modal-box{background:#fff;border-radius:22px 22px 0 0;width:100%;max-height:88vh;overflow:hidden;display:flex;flex-direction:column}
  .modal-hdr{padding:16px 18px;border-bottom:1px solid #DDE8E2;display:flex;align-items:center;justify-content:space-between}
  .modal-title{font-size:15px;font-weight:800}
  .modal-close{width:28px;height:28px;border-radius:7px;border:1px solid #DDE8E2;background:#F7FAF8;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .modal-body{padding:16px 18px;overflow-y:auto;flex:1}
  .modal-foot{padding:12px 18px;border-top:1px solid #DDE8E2;display:flex;gap:8px}
  .form-group{margin-bottom:13px}
  .form-label{display:block;font-size:11.5px;font-weight:600;color:#3A5248;margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
  .form-input,.form-select,.form-textarea{width:100%;padding:11px 13px;font-size:14px;border:1.5px solid #DDE8E2;border-radius:11px;background:#F7FAF8;color:#0D1F18;font-family:'DM Sans',sans-serif}
  .form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:#00D084}
  .form-textarea{resize:vertical;min-height:80px}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .m-empty{text-align:center;padding:44px 20px;background:#fff;border-radius:16px;border:1px solid #DDE8E2}
  .m-empty svg{margin:0 auto 12px;opacity:.2}
  .m-empty p{font-size:13px;color:#7A9A8E}
  .mob-nav{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.96);backdrop-filter:blur(20px);border-top:1px solid rgba(0,0,0,.06);padding:8px 0 16px;display:grid;grid-template-columns:repeat(4,1fr);z-index:99}
  .mn{display:flex;flex-direction:column;align-items:center;gap:2px;padding:5px;cursor:pointer;border:none;background:none}
  .mn-ico{width:40px;height:26px;display:flex;align-items:center;justify-content:center}
  .mn-ico svg{stroke:#718096;opacity:.5}
  .mn.active .mn-ico svg{stroke:#00D084;opacity:1}
  .mn-lbl{font-size:10px;font-weight:600;color:#718096;opacity:.7}
  .mn.active .mn-lbl{color:#00D084;opacity:1}
  .loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:2000;align-items:center;justify-content:center}
  .loading.active{display:flex}
  .spin-box{background:#fff;border-radius:16px;padding:22px 28px;text-align:center}
  .spinner{width:40px;height:40px;border:3px solid #DDE8E2;border-top-color:#00D084;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  .mob-toast{position:fixed;bottom:88px;left:14px;right:14px;z-index:9999;display:flex;flex-direction:column;gap:8px}
  .mob-toast-item{background:#0D5F3A;color:#fff;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px}
  .mob-toast-item.error{background:#5F1313}
  @keyframes toastIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  .tab-content{display:none}.tab-content.active{display:block}
  .stars{display:flex;gap:2px}.star{color:#E8A020;font-size:13px}.star.empty{color:#DDE8E2}
}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <img src="../images/envirocab_logo.png" alt="EC" onerror="this.style.display='none'">
    <div class="sb-brand">Enviro<span>Cab</span></div>
  </div>
  <nav class="sb-nav">
    <div class="sb-label">Core 2</div>
    <a href="dashboard.php" class="sb-item">
      <div class="sb-ico"><?=ico($iHome,'#4A5568')?></div>
      <span>Dashboard</span>
    </a>
    <a href="booking_system.php" class="sb-item">
      <div class="sb-ico"><?=ico($iBook,'#4A5568')?></div>
      <span>Booking System</span>
    </a>
    <a href="payment_fares.php" class="sb-item">
      <div class="sb-ico"><?=ico($iPay,'#4A5568')?></div>
      <span>Payment &amp; Fares</span>
    </a>
    <a href="crm_system.php" class="sb-item active">
      <div class="sb-ico"><?=ico($iCrm,'#4A5568')?></div>
      <span>CRM</span>
    </a>
    <a href="gps_tracking.php" class="sb-item">
      <div class="sb-ico"><?=ico($iGps,'#4A5568')?></div>
      <span>GPS Tracking</span>
    </a>
    <div class="sb-label">Analytics</div>
    <a href="transport_analytics.php" class="sb-item">
      <div class="sb-ico"><?=ico($iBar,'#4A5568')?></div>
      <span>Analytics &amp; KPIs</span>
    </a>
    <a href="sop_compliance.php" class="sb-item">
      <div class="sb-ico"><?=ico($iDoc,'#4A5568')?></div>
      <span>SOP Compliance</span>
    </a>
  </nav>
  <div class="sb-foot">
    <div class="sb-av"><?=$userInitial?></div>
    <div style="flex:1;min-width:0">
      <div class="sb-uname trunc"><?=$userName?></div>
      <div class="sb-urole">Administrator</div>
    </div>
    <button class="sb-out" onclick="if(confirm('Logout?'))window.location.href='../auth/logout.php'" title="Logout">
      <?=ico($iOut,'#EF4444',14)?>
    </button>
  </div>
</aside>

<div class="desk-wrap">
  <header class="topbar">
    <div class="tb-title">CRM Management</div>
    <div class="tb-date"><?=date('D, M j, Y')?></div>
    <div class="tb-sep"></div>
    <button class="tb-btn" onclick="exportSatisfactionReport()"><?=ico("<path d='M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'/><polyline points='7 10 12 15 17 10'/><line x1='12' y1='15' x2='12' y2='3'/>", '#4A5568', 13)?> Report</button>
    <button class="tb-btn" onclick="location.reload()"><?=ico($iRefresh,'#4A5568',13)?> Refresh</button>
  </header>

  <div class="desk-scroll">

    <div class="kpi-row">
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iCrm,'#00A86B',17)?></div><div class="kpi-num">total</div></div>
        <div class="kpi-val"><?=$totalCustomers?></div>
        <div class="kpi-lbl">Total Customers</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(59,142,240,.1)"><?=ico($iUser,'#3B8EF0',17)?></div><div class="kpi-num">active</div></div>
        <div class="kpi-val"><?=$activeUsers?></div>
        <div class="kpi-lbl">Active Users</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(232,160,32,.1)"><?=ico($iAlert,'#E8A020',17)?></div><div class="kpi-num">open</div></div>
        <div class="kpi-val"><?=$openComplaints?></div>
        <div class="kpi-lbl">Open Complaints</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(139,111,232,.1)"><?=ico("<polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/>", '#8B6FE8', 17)?></div><div class="kpi-num">avg</div></div>
        <div class="kpi-val"><?=number_format($avgRating,1)?>★</div>
        <div class="kpi-lbl">Avg Rating</div>
      </div>
      <div class="kpi">
        <div class="kpi-top"><div class="kpi-ico" style="background:rgba(0,208,132,.1)"><?=ico($iMsg,'#00A86B',17)?></div><div class="kpi-num">reviews</div></div>
        <div class="kpi-val"><?=$totalReviews?></div>
        <div class="kpi-lbl">Total Reviews</div>
      </div>
    </div>

    <div id="alertContainer"></div>

    <div class="crm-tabs" id="crmTabs">
      <button class="crm-tab active" onclick="switchTab('complaints',this)"><?=ico($iAlert,'currentColor',14)?> Complaints</button>
      <button class="crm-tab" onclick="switchTab('users',this)"><?=ico($iCrm,'currentColor',14)?> Users</button>
      <button class="crm-tab" onclick="switchTab('conversations',this)"><?=ico($iMsg,'currentColor',14)?> Conversations</button>
      <button class="crm-tab" onclick="switchTab('reviews',this)"><?=ico("<polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'/>", 'currentColor', 14)?> Reviews</button>
      <button class="crm-tab" onclick="switchTab('announcements',this)"><?=ico("<path d='M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z'/>", 'currentColor', 14)?> Announcements</button>
    </div>

    <div id="tab-complaints" class="tab-content active">
      <div class="panel" style="margin-bottom:12px">
        <div class="panel-h">Manage Complaints &amp; Reports
          <select class="form-select" style="width:180px;padding:6px 10px;font-size:12px" onchange="loadComplaints(this.value)">
            <option value="all">All Complaints</option>
            <option value="Open">Open</option>
            <option value="Under Review">Under Review</option>
            <option value="Resolved">Resolved</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
      </div>
      <div id="complaintsList" class="list-grid"></div>
    </div>

    <div id="tab-users" class="tab-content">
      <div class="panel" style="margin-bottom:12px">
        <div class="panel-h">Manage Customer Accounts
          <div style="display:flex;gap:8px;align-items:center">
            <div class="search-box" style="margin:0;width:220px">
              <svg class="search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#7A9A8E" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
              <input type="text" class="form-input search-input" style="height:32px;font-size:12px;padding:0 10px 0 32px" placeholder="Search customers..." onkeyup="searchUsers(this.value)">
            </div>
            <select class="form-select" style="width:150px;padding:6px 10px;font-size:12px" onchange="loadUsers(this.value)">
              <option value="all">All Users</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>
      <div id="usersList" class="list-grid"></div>
    </div>

    <div id="tab-conversations" class="tab-content">
      <div class="conv-layout" id="convLayout">
        <div class="conv-list">
          <div class="conv-search">
            <div class="search-box" style="margin:0">
              <svg class="search-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#7A9A8E" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
              <input type="text" class="form-input search-input" style="height:32px;font-size:12px;padding:0 10px 0 30px" placeholder="Search customers..." oninput="filterConvList(this.value)">
            </div>
          </div>
          <div id="convListItems"></div>
        </div>
        <div class="conv-main">
          <div class="no-conv" id="noConvSelected">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity:.3"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <p style="font-size:13px">Select a customer to view conversation</p>
          </div>
          <div id="convActivePanel" style="display:none;flex-direction:column;height:100%">
            <div class="conv-header">
              <div class="conv-av" id="convHeaderAv">?</div>
              <div>
                <div style="font-size:14px;font-weight:700" id="convHeaderName">Customer</div>
                <div style="font-size:11.5px;color:var(--txt3)" id="convHeaderSub">Loading…</div>
              </div>
              <button class="btn btn-ghost btn-sm" style="margin-left:auto" onclick="showCustomerDetails(currentConvCustomerId)"><?=ico($iUser,'#4A5568',13)?> Profile</button>
            </div>
            <div class="conv-messages" id="convMessages"></div>
            <div class="conv-input">
              <textarea id="convMsgInput" placeholder="Type a message to send…" rows="2" onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendAdminMessage()}"></textarea>
              <button class="btn btn-primary" onclick="sendAdminMessage()" style="padding:10px 14px;height:42px;align-self:flex-end"><?=ico("<path d='M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z'/>", '#fff', 14)?></button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-reviews" class="tab-content">
      <div class="panel" style="margin-bottom:12px">
        <div class="panel-h">Customer Ratings &amp; Feedback
          <select class="form-select" style="width:160px;padding:6px 10px;font-size:12px" onchange="loadReviews(this.value)">
            <option value="all">All Reviews</option>
            <option value="recent">Recent (7 days)</option>
            <option value="high">High (4-5★)</option>
            <option value="low">Low (1-2★)</option>
          </select>
        </div>
      </div>
      <div id="reviewsList" class="list-grid"></div>
    </div>

    <div id="tab-announcements" class="tab-content">
      <div style="display:grid;grid-template-columns:400px 1fr;gap:14px">
        <div class="panel">
          <div class="panel-h">Send Announcement</div>
          <div class="panel-body">
            <form id="announcementForm">
              <div class="form-group">
                <label class="form-label">Target Audience</label>
                <select class="form-select" name="target">
                  <option value="all">All Users</option>
                  <option value="admin">Admins Only</option>
                  <option value="staff">Staff Only</option>
                  <option value="driver">Drivers Only</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Priority</label>
                <select class="form-select" name="priority">
                  <option value="normal">Normal</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Title</label>
                <input type="text" class="form-input" name="title" placeholder="Announcement title..." required>
              </div>
              <div class="form-group">
                <label class="form-label">Message</label>
                <textarea class="form-textarea" name="message" placeholder="Announcement message..." required></textarea>
              </div>
              <button type="submit" class="btn btn-primary btn-full"><?=ico("<path d='M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z'/>", '#fff', 14)?> Send Announcement</button>
            </form>
          </div>
        </div>
        <div class="panel">
          <div class="panel-h">Recent Announcements</div>
          <div class="panel-body" style="padding-top:0">
            <div id="announcementsList"></div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<header class="mob-header">
  <button class="mh-back" onclick="window.location.href='dashboard.php'"><?=ico($iBack,'currentColor')?></button>
  <div class="mh-title">CRM</div>
  <button class="mh-btn" onclick="location.reload()"><?=ico($iRefresh,'currentColor')?></button>
</header>

<div class="mob-body">
  <div class="m-kpis">
    <div class="mkpi"><div class="mkpi-v"><?=$activeUsers?></div><div class="mkpi-l">Active</div></div>
    <div class="mkpi"><div class="mkpi-v"><?=number_format($avgRating,1)?>★</div><div class="mkpi-l">Rating</div></div>
    <div class="mkpi"><div class="mkpi-v"><?=$openComplaints?></div><div class="mkpi-l">Issues</div></div>
  </div>

  <div id="alertContainerMobile"></div>

  <div class="m-tabs-row" id="mTabsRow">
    <button class="m-tab-btn active" onclick="switchTabMobile('complaints',this)">Complaints</button>
    <button class="m-tab-btn" onclick="switchTabMobile('users',this)">Users</button>
    <button class="m-tab-btn" onclick="switchTabMobile('reviews',this)">Reviews</button>
    <button class="m-tab-btn" onclick="switchTabMobile('announcements',this)">Announce</button>
  </div>

  <div id="mtab-complaints" class="tab-content active">
    <select class="form-select" style="margin-bottom:12px" onchange="loadComplaintsMobile(this.value)">
      <option value="all">All Complaints</option>
      <option value="Open">Open</option>
      <option value="Under Review">Under Review</option>
      <option value="Resolved">Resolved</option>
      <option value="Closed">Closed</option>
    </select>
    <div id="complaintsListMobile" class="m-list"></div>
  </div>

  <div id="mtab-users" class="tab-content">
    <div class="m-search" style="margin-bottom:10px">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#7A9A8E" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <input type="text" placeholder="Search customers..." onkeyup="searchUsersMobile(this.value)">
    </div>
    <select class="form-select" style="margin-bottom:12px" onchange="loadUsersMobile(this.value)">
      <option value="all">All Users</option>
      <option value="active">Active</option>
      <option value="inactive">Inactive</option>
    </select>
    <div id="usersListMobile" class="m-list"></div>
  </div>

  <div id="mtab-reviews" class="tab-content">
    <select class="form-select" style="margin-bottom:12px" onchange="loadReviewsMobile(this.value)">
      <option value="all">All Reviews</option>
      <option value="recent">Recent (7 days)</option>
      <option value="high">High (4-5★)</option>
      <option value="low">Low (1-2★)</option>
    </select>
    <div id="reviewsListMobile" class="m-list"></div>
  </div>

  <div id="mtab-announcements" class="tab-content">
    <div style="background:#fff;border-radius:16px;border:1.5px solid #DDE8E2;padding:16px;margin-bottom:12px">
      <div style="font-size:14px;font-weight:800;margin-bottom:12px">Send Announcement</div>
      <form id="announcementFormMobile">
        <div class="form-group">
          <label class="form-label">Target</label>
          <select class="form-select" name="target">
            <option value="all">All Users</option>
            <option value="admin">Admins Only</option>
            <option value="staff">Staff Only</option>
            <option value="driver">Drivers Only</option>
          </select>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Priority</label>
            <select class="form-select" name="priority">
              <option value="normal">Normal</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Title</label>
          <input type="text" class="form-input" name="title" placeholder="Title..." required>
        </div>
        <div class="form-group">
          <label class="form-label">Message</label>
          <textarea class="form-textarea" name="message" placeholder="Message..." required></textarea>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Send</button>
      </form>
    </div>
    <div id="announcementsListMobile" class="m-list"></div>
  </div>
</div>

<nav class="mob-nav">
  <button class="mn" onclick="window.location.href='dashboard.php'">
    <div class="mn-ico"><?=ico($iHome,'currentColor',22)?></div>
    <span class="mn-lbl">Home</span>
  </button>
  <button class="mn" onclick="window.location.href='booking_system.php'">
    <div class="mn-ico"><?=ico($iTruck,'currentColor',22)?></div>
    <span class="mn-lbl">Bookings</span>
  </button>
  <button class="mn active">
    <div class="mn-ico"><?=ico($iCrm,'currentColor',22)?></div>
    <span class="mn-lbl">CRM</span>
  </button>
  <button class="mn" onclick="window.location.href='profile.php'">
    <div class="mn-ico"><?=ico($iUser,'currentColor',22)?></div>
    <span class="mn-lbl">Profile</span>
  </button>
</nav>

<div id="customerModal" class="modal">
  <div class="modal-box modal-wide">
    <div class="modal-hdr">
      <div class="modal-title">Customer Profile</div>
      <button class="modal-close" onclick="closeModal('customerModal')">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body" id="customerModalBody">Loading...</div>
    <div class="modal-foot" id="customerModalFoot"></div>
  </div>
</div>

<div id="loading" class="loading">
  <div class="spin-box">
    <div class="spinner"></div>
    <p style="font-size:13px;font-weight:600">Processing…</p>
  </div>
</div>
<div class="toast" id="toastCont"></div>
<div class="mob-toast" id="mobToastCont"></div>

<script>
function openModal(id){ document.getElementById(id).classList.add('open'); }
function closeModal(id){ document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal').forEach(m => m.addEventListener('click', e => { if(e.target===m) m.classList.remove('open'); }));

function toast(msg, type='success'){
    ['toastCont','mobToastCont'].forEach(id => {
        const c = document.getElementById(id); if(!c) return;
        const el = document.createElement('div');
        el.className = `toast-item ${type}`;
        el.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">${type==='success'?'<polyline points="20 6 9 17 4 12"/>':'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>'}</svg>${msg}`;
        c.appendChild(el);
        setTimeout(() => { el.style.animation='toastOut .3s ease forwards'; setTimeout(()=>el.remove(),300); }, 3500);
    });
}

function showLoading(show) {
    const l = document.getElementById('loading');
    if(show) l.classList.add('active'); else l.classList.remove('active');
}

async function post(action, extra={}) {
    const fd = new FormData();
    fd.append('action', action);
    for(const [k,v] of Object.entries(extra)) fd.append(k,v);
    const r = await fetch('crm_system.php', { method:'POST', body:fd });
    return r.json();
}

function starsHtml(n) {
    const full = Math.round(n||0);
    let h = '';
    for(let i=0;i<5;i++) h += `<span class="star${i<full?'':' empty'}">★</span>`;
    return `<div class="stars">${h}</div>`;
}

function switchTab(tab, el) {
    document.querySelectorAll('.crm-tabs .crm-tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    document.querySelectorAll('.desk-scroll .tab-content').forEach(c => c.classList.remove('active'));
    document.getElementById('tab-'+tab).classList.add('active');
    if(tab==='complaints') loadComplaints('all');
    else if(tab==='users') loadUsers('all');
    else if(tab==='conversations') loadConvList();
    else if(tab==='reviews') loadReviews('all');
    else if(tab==='announcements') loadAnnouncements();
}

function switchTabMobile(tab, el) {
    document.querySelectorAll('.m-tabs-row .m-tab-btn').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    document.querySelectorAll('.mob-body .tab-content').forEach(c => c.classList.remove('active'));
    document.getElementById('mtab-'+tab).classList.add('active');
    if(tab==='complaints') loadComplaintsMobile('all');
    else if(tab==='users') loadUsersMobile('all');
    else if(tab==='reviews') loadReviewsMobile('all');
    else if(tab==='announcements') loadAnnouncementsMobile();
}

async function loadComplaints(status) {
    showLoading(true);
    const result = await post('get_all_complaints', {status});
    if(result.success) displayComplaints(result.complaints, false);
    else toast(result.message, 'error');
    showLoading(false);
}
async function loadComplaintsMobile(status) {
    showLoading(true);
    const result = await post('get_all_complaints', {status});
    if(result.success) displayComplaints(result.complaints, true);
    showLoading(false);
}

function displayComplaints(complaints, isMobile) {
    const cid = isMobile ? 'complaintsListMobile' : 'complaintsList';
    const c = document.getElementById(cid);
    const emptyIco = `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 12px;display:block;opacity:.2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
    if(!complaints||!complaints.length){
        c.innerHTML = isMobile
          ? `<div class="m-empty">${emptyIco}<p>No complaints found</p></div>`
          : `<div style="grid-column:1/-1;text-align:center;padding:44px;background:var(--surf);border-radius:var(--r);border:1px solid var(--bdr)">${emptyIco}<p style="color:var(--txt3);font-size:13px">No complaints found</p></div>`;
        return;
    }
    const [ic,hc,tc,lc,ac] = isMobile
      ? ['m-item','mi-header','mi-title','mi-info','mi-actions']
      : ['list-item','list-header','list-title','list-info','list-actions'];

    c.innerHTML = complaints.map(cp => `
        <div class="${ic}">
            <div class="${hc}">
                <div class="${tc}">Report #${cp.report_id} — ${cp.report_type||'N/A'}</div>
                <span class="status-badge status-${(cp.status||'').toLowerCase().replace(' ','-')}">${cp.status||'—'}</span>
            </div>
            <div class="${lc}"><strong>Severity</strong> ${cp.severity||'—'}</div>
            <div class="${lc}"><strong>Customer</strong> ${cp.customer_name||'N/A'}${cp.customer_phone?' ('+cp.customer_phone+')':''}</div>
            <div class="${lc}"><strong>Booking</strong> ${cp.booking_reference||'N/A'}</div>
            ${cp.driver_name?`<div class="${lc}"><strong>Driver</strong> ${cp.driver_name}</div>`:''}
            <div class="${lc}" style="font-size:11.5px">${cp.description||''}</div>
            <div class="${lc}" style="color:var(--txt3);font-size:11px">Reported: ${new Date(cp.reported_at).toLocaleDateString()}</div>
            ${cp.status==='Open'?`
            <div class="${ac}">
                <button class="btn btn-warning" onclick="updateComplaintStatus(${cp.report_id},'Under Review')">Under Review</button>
                <button class="btn btn-success" onclick="updateComplaintStatus(${cp.report_id},'Resolved')">Resolve</button>
            </div>`:cp.status==='Under Review'?`
            <div class="${ac}">
                <button class="btn btn-success" onclick="updateComplaintStatus(${cp.report_id},'Resolved')">Resolve</button>
                <button class="btn btn-ghost" onclick="updateComplaintStatus(${cp.report_id},'Closed')">Close</button>
            </div>`:''}
        </div>
    `).join('');
}

async function updateComplaintStatus(reportId, status) {
    if(!confirm('Update complaint status to '+status+'?')) return;
    showLoading(true);
    const result = await post('update_complaint_status', {report_id:reportId, status});
    toast(result.message, result.success?'success':'error');
    if(result.success){ loadComplaints('all'); loadComplaintsMobile('all'); }
    showLoading(false);
}

async function loadUsers(filter) {
    showLoading(true);
    const result = await post('get_all_users', {filter});
    if(result.success) displayUsers(result.users, false);
    showLoading(false);
}
async function loadUsersMobile(filter) {
    showLoading(true);
    const result = await post('get_all_users', {filter});
    if(result.success) displayUsers(result.users, true);
    showLoading(false);
}

function displayUsers(users, isMobile) {
    const cid = isMobile ? 'usersListMobile' : 'usersList';
    const c = document.getElementById(cid);
    if(!users||!users.length){
        c.innerHTML = `<div class="${isMobile?'m-empty':''}">No users found</div>`;
        return;
    }
    const [ic,hc,tc,lc] = isMobile
      ? ['m-item','mi-header','mi-title','mi-info']
      : ['list-item','list-header','list-title','list-info'];
    c.innerHTML = users.map(u => `
        <div class="${ic}">
            <div class="${hc}">
                <div style="display:flex;align-items:center;gap:9px">
                    <div style="width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,var(--g),var(--gd));display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#fff;flex-shrink:0">${(u.username||u.name||'?')[0].toUpperCase()}</div>
                    <div class="${tc}">${u.username||u.name||'—'}</div>
                </div>
                <span class="status-badge status-${(u.status||'').toLowerCase()}">${u.status||'—'}</span>
            </div>
            <div class="${lc}"><strong>Email</strong> ${u.email||'N/A'}</div>
            <div class="${lc}"><strong>Phone</strong> ${u.phone||'N/A'}</div>
            <div class="${lc}"><strong>Type</strong> ${u.role||u.customer_type||'Customer'}</div>
            <div class="${lc}"><strong>Bookings</strong> ${u.total_bookings||0} trips • ₱${parseFloat(u.total_spent||0).toFixed(2)} spent</div>
            <div class="${lc}" style="color:var(--txt3);font-size:11px">Joined: ${new Date(u.created_at).toLocaleDateString()}</div>
            <div style="display:flex;gap:6px;margin-top:10px">
                <button class="btn btn-ghost btn-sm" onclick="showCustomerDetails(${u.user_id||u.customer_id})">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> Profile
                </button>
                ${u.status==='Active'
                  ? `<button class="btn btn-danger btn-sm" onclick="updateUserStatus(${u.user_id||u.customer_id},'Inactive')">Suspend</button>`
                  : `<button class="btn btn-success btn-sm" onclick="updateUserStatus(${u.user_id||u.customer_id},'Active')">Activate</button>`}
            </div>
        </div>
    `).join('');
}

async function updateUserStatus(userId, status) {
    if(!confirm('Update user status to '+status+'?')) return;
    showLoading(true);
    const result = await post('update_user_status', {user_id:userId, status});
    toast(result.message, result.success?'success':'error');
    if(result.success){ loadUsers('all'); loadUsersMobile('all'); }
    showLoading(false);
}

let searchTimeout;
function searchUsers(query) {
    clearTimeout(searchTimeout);
    if(query.length<2){ loadUsers('all'); return; }
    searchTimeout = setTimeout(async()=>{
        showLoading(true);
        const r = await post('search_customers', {query});
        if(r.success) displayUsers(r.customers, false);
        showLoading(false);
    }, 400);
}
function searchUsersMobile(query) {
    clearTimeout(searchTimeout);
    if(query.length<2){ loadUsersMobile('all'); return; }
    searchTimeout = setTimeout(async()=>{
        showLoading(true);
        const r = await post('search_customers', {query});
        if(r.success) displayUsers(r.customers, true);
        showLoading(false);
    }, 400);
}

let currentConvCustomerId = null;
async function showCustomerDetails(customerId) {
    showLoading(true);
    const result = await post('get_customer_details', {customer_id:customerId});
    showLoading(false);
    if(!result.success){ toast(result.message,'error'); return; }
    const c = result.customer;
    const b = result.bookings||[];
    const statusBadge = s => {
        const map = {Active:'badge-green',Inactive:'badge-red',Pending:'badge-yellow'};
        return `<span class="badge ${map[s]||'badge-gray'}">${s||'—'}</span>`;
    };
    document.getElementById('customerModalBody').innerHTML = `
        <div style="display:flex;gap:16px;align-items:flex-start;margin-bottom:16px">
          <div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,var(--g),var(--gd));display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:800;color:#fff;flex-shrink:0">${(c.name||'?')[0].toUpperCase()}</div>
          <div style="flex:1">
            <div style="font-size:16px;font-weight:800">${c.name||'—'}</div>
            <div style="font-size:12.5px;color:var(--txt3);margin-top:2px">${c.email||''} ${c.phone?'· '+c.phone:''}</div>
            <div style="margin-top:6px;display:flex;gap:6px">${statusBadge(c.status)} <span class="badge badge-blue">${c.customer_type||'Customer'}</span></div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:16px">
          <div style="background:var(--surf2);border-radius:10px;padding:12px;text-align:center;border:1px solid var(--bdr)">
            <div style="font-size:20px;font-weight:800">${c.total_bookings||0}</div>
            <div style="font-size:11px;color:var(--txt3)">Total Bookings</div>
          </div>
          <div style="background:var(--surf2);border-radius:10px;padding:12px;text-align:center;border:1px solid var(--bdr)">
            <div style="font-size:20px;font-weight:800">${c.completed_trips||0}</div>
            <div style="font-size:11px;color:var(--txt3)">Completed</div>
          </div>
          <div style="background:var(--surf2);border-radius:10px;padding:12px;text-align:center;border:1px solid var(--bdr)">
            <div style="font-size:20px;font-weight:800;color:var(--gd)">₱${parseFloat(c.total_spent||0).toLocaleString('en-PH',{minimumFractionDigits:0,maximumFractionDigits:0})}</div>
            <div style="font-size:11px;color:var(--txt3)">Total Spent</div>
          </div>
        </div>
        <div class="section-label">Account Info</div>
        <div class="d-row"><div class="d-label">Customer Code</div><div class="d-val mono">${c.customer_code||'—'}</div></div>
        <div class="d-row"><div class="d-label">Joined</div><div class="d-val">${new Date(c.created_at).toLocaleDateString('en-PH',{year:'numeric',month:'long',day:'numeric'})}</div></div>
        ${c.address?`<div class="d-row"><div class="d-label">Address</div><div class="d-val">${c.address}</div></div>`:''}
        ${b.length?`
        <div class="section-label">Recent Bookings</div>
        <div style="display:flex;flex-direction:column;gap:7px">
          ${b.slice(0,5).map(bk=>`
            <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:var(--surf2);border-radius:9px;border:1px solid var(--bdr)">
              <div>
                <div style="font-size:12.5px;font-weight:700">${bk.booking_reference||'#'+bk.booking_id}</div>
                <div style="font-size:11px;color:var(--txt3)">${bk.service_name||''} · ${bk.booking_date||''}</div>
              </div>
              <div style="text-align:right">
                <div style="font-size:12.5px;font-weight:700;color:var(--gd)">₱${parseFloat(bk.total_amount||0).toFixed(2)}</div>
                <div style="font-size:10.5px"><span class="status-badge status-${(bk.booking_status||'').toLowerCase().replace(' ','-')}">${bk.booking_status||'—'}</span></div>
              </div>
            </div>
          `).join('')}
        </div>`:''}
        ${(c.total_bookings||0)>=5?`<div style="margin-top:10px;padding:10px;background:rgba(0,208,132,.08);border-radius:9px;border:1px solid rgba(0,208,132,.2);font-size:12.5px;color:var(--gd);font-weight:600">⭐ Frequent Customer — ${c.total_bookings} bookings</div>`:''}
    `;
    document.getElementById('customerModalFoot').innerHTML = `
        <button class="btn btn-primary" onclick="closeModal('customerModal');openConversation(${c.customer_id},'${(c.name||'').replace(/'/g,"\\'")}')">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> Message
        </button>
        ${c.status==='Active'
          ? `<button class="btn btn-danger" onclick="closeModal('customerModal');updateUserStatus(${c.customer_id},'Inactive')">Suspend</button>`
          : `<button class="btn btn-success" onclick="closeModal('customerModal');updateUserStatus(${c.customer_id},'Active')">Activate</button>`}
        <button class="btn btn-ghost" onclick="closeModal('customerModal')">Close</button>
    `;
    openModal('customerModal');
}

let allConvUsers = [];
let conversations = {}; // customerId -> [messages]

async function loadConvList() {
    showLoading(true);
    const r = await post('get_all_users', {filter:'all'});
    showLoading(false);
    if(!r.success) return;
    allConvUsers = r.users;
    renderConvList(allConvUsers);
}

function renderConvList(users) {
    const c = document.getElementById('convListItems');
    if(!users.length){ c.innerHTML = '<div style="padding:20px;text-align:center;color:var(--txt3);font-size:12.5px">No customers found</div>'; return; }
    c.innerHTML = users.map(u => `
        <div class="conv-item${currentConvCustomerId===u.customer_id?' active':''}" onclick="openConversation(${u.customer_id||u.user_id},'${(u.name||u.username||'').replace(/'/g,"\\'")}')">
            <div class="conv-av">${(u.name||u.username||'?')[0].toUpperCase()}</div>
            <div class="conv-info">
                <div class="conv-name">${u.name||u.username||'—'}</div>
                <div class="conv-preview">${u.email||u.phone||'No contact info'}</div>
            </div>
        </div>
    `).join('');
}

function filterConvList(q) {
    const filtered = allConvUsers.filter(u => {
        const s = (u.name||u.username||'').toLowerCase()+(u.email||'').toLowerCase()+(u.phone||'').toLowerCase();
        return s.includes(q.toLowerCase());
    });
    renderConvList(filtered);
}

async function openConversation(customerId, customerName) {
    currentConvCustomerId = customerId;
    const convTab = document.querySelector('[onclick*="conversations"]');
    if(convTab && !document.getElementById('tab-conversations').classList.contains('active')) {
        convTab.click();
        await new Promise(r => setTimeout(r,200));
    }
    renderConvList(allConvUsers);
    document.getElementById('noConvSelected').style.display = 'none';
    const panel = document.getElementById('convActivePanel');
    panel.style.display = 'flex';
    document.getElementById('convHeaderAv').textContent = (customerName||'?')[0].toUpperCase();
    document.getElementById('convHeaderName').textContent = customerName||'Customer';
    document.getElementById('convHeaderSub').textContent = 'Loading details…';

    const r = await post('get_customer_details', {customer_id:customerId});
    if(r.success){
        const c = r.customer;
        document.getElementById('convHeaderSub').textContent = `${c.email||''} · ${c.total_bookings||0} bookings`;
    }

    await renderConversation(customerId);
}

async function renderConversation(customerId) {
    const msgs = document.getElementById('convMessages');
    msgs.innerHTML = '<div style="text-align:center;padding:20px;color:var(--txt3);font-size:12.5px">Loading messages…</div>';
    
    try {
        const r = await post('get_customer_details', {customer_id:customerId});
        if(r.success && r.bookings && r.bookings.length > 0){
            const convData = conversations[customerId] || [];
            const historyMsgs = r.bookings.map(b => ({
                type: 'customer',
                text: `Booking ${b.booking_reference||'#'+b.booking_id}: ${b.service_name||'Service'} on ${b.booking_date||'—'} — ₱${parseFloat(b.total_amount||0).toFixed(2)} [${b.booking_status}]`,
                time: b.created_at
            }));
            const allMsgs = [...historyMsgs, ...convData];
            if(!allMsgs.length){
                msgs.innerHTML = '<div class="no-conv"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity:.25"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><p style="font-size:12.5px;margin-top:8px">No conversation history</p></div>';
                return;
            }
            msgs.innerHTML = allMsgs.map(m => `
                <div class="msg-row ${m.type==='admin'?'admin':''}">
                    <div class="msg-bubble ${m.type==='admin'?'admin':'customer'}">
                        ${m.text}
                        <div class="msg-meta ${m.type==='admin'?'admin':''}">${m.time ? new Date(m.time).toLocaleString() : ''}</div>
                    </div>
                </div>
            `).join('');
            msgs.scrollTop = msgs.scrollHeight;
        } else {
            msgs.innerHTML = '<div class="no-conv" style="text-align:center;padding:32px;color:var(--txt3)"><p style="font-size:12.5px">No booking history found</p></div>';
        }
    } catch(e) {
        msgs.innerHTML = '<div style="padding:20px;color:var(--red);font-size:12px">Error loading messages</div>';
    }
}

async function sendAdminMessage() {
    const input = document.getElementById('convMsgInput');
    const text = input.value.trim();
    if(!text||!currentConvCustomerId) return;
    
    if(!conversations[currentConvCustomerId]) conversations[currentConvCustomerId] = [];
    conversations[currentConvCustomerId].push({
        type:'admin',
        text: text,
        time: new Date().toISOString()
    });
    input.value = '';
    await renderConversation(currentConvCustomerId);
    toast('Message sent (demo — connect messaging table for persistence)', 'success');
}

async function loadReviews(filter) {
    showLoading(true);
    const r = await post('get_reviews', {filter});
    if(r.success) displayReviews(r.reviews, false);
    showLoading(false);
}
async function loadReviewsMobile(filter) {
    showLoading(true);
    const r = await post('get_reviews', {filter});
    if(r.success) displayReviews(r.reviews, true);
    showLoading(false);
}
function displayReviews(reviews, isMobile) {
    const cid = isMobile ? 'reviewsListMobile' : 'reviewsList';
    const c = document.getElementById(cid);
    if(!reviews||!reviews.length){
        c.innerHTML = `<div style="${isMobile?'':'grid-column:1/-1;'}text-align:center;padding:44px;color:var(--txt3)">No reviews found</div>`;
        return;
    }
    const [ic,hc,tc,lc] = isMobile
      ? ['m-item','mi-header','mi-title','mi-info']
      : ['list-item','list-header','list-title','list-info'];
    c.innerHTML = reviews.map(rv => `
        <div class="${ic}">
            <div class="${hc}">
                <div>
                  <div class="${tc}">Review #${rv.rating_id}</div>
                  ${starsHtml(rv.rating_value)}
                </div>
                <span class="status-badge ${rv.rating_value>=4?'status-resolved':rv.rating_value<=2?'status-open':'status-under-review'}">${rv.rating_value}★</span>
            </div>
            <div class="${lc}"><strong>Customer</strong> ${rv.customer_name||'N/A'}</div>
            ${rv.driver_name?`<div class="${lc}"><strong>Driver</strong> ${rv.driver_name}</div>`:''}
            ${rv.comment?`<div class="${lc}" style="font-style:italic">"${rv.comment}"</div>`:'<div class="${lc}"><em style="color:var(--txt3)">No comment</em></div>'}
            <div class="${lc}" style="color:var(--txt3);font-size:11px">${new Date(rv.created_at).toLocaleDateString()}</div>
        </div>
    `).join('');
}

document.getElementById('announcementForm').addEventListener('submit', async(e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target).entries());
    showLoading(true);
    const r = await post('create_announcement', data);
    toast(r.message, r.success?'success':'error');
    if(r.success){ e.target.reset(); loadAnnouncements(); }
    showLoading(false);
});

document.getElementById('announcementFormMobile').addEventListener('submit', async(e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target).entries());
    showLoading(true);
    const r = await post('create_announcement', data);
    toast(r.message, r.success?'success':'error');
    if(r.success){ e.target.reset(); loadAnnouncementsMobile(); }
    showLoading(false);
});

async function loadAnnouncements() {
    showLoading(true);
    const r = await post('get_announcements');
    if(r.success) displayAnnouncements(r.announcements, false);
    showLoading(false);
}
async function loadAnnouncementsMobile() {
    showLoading(true);
    const r = await post('get_announcements');
    if(r.success) displayAnnouncements(r.announcements, true);
    showLoading(false);
}
function displayAnnouncements(items, isMobile) {
    const cid = isMobile ? 'announcementsListMobile' : 'announcementsList';
    const c = document.getElementById(cid);
    if(!items||!items.length){ c.innerHTML = '<p style="text-align:center;padding:24px;color:var(--txt3);font-size:12.5px">No announcements yet</p>'; return; }
    c.innerHTML = items.map(a => {
        const notes = (a.notes||'').replace('ANNOUNCEMENT ','');
        const parts = notes.split(': ');
        const priority = parts[0].replace('[','').replace(']','').toLowerCase();
        const content = parts.slice(1).join(': ');
        const [title,...msgParts] = content.split(' - ');
        const message = msgParts.join(' - ');
        const cls = priority==='urgent'?'status-open':priority==='high'?'status-under-review':'status-resolved';
        return `<div style="padding:12px;border-bottom:1px solid var(--bdr);display:flex;gap:10px;align-items:flex-start">
          <span class="status-badge ${cls}" style="margin-top:2px">${priority.toUpperCase()}</span>
          <div style="flex:1">
            <div style="font-size:13px;font-weight:700">${title||'Announcement'}</div>
            <div style="font-size:12px;color:var(--txt2);margin-top:3px">${message||''}</div>
            <div style="font-size:11px;color:var(--txt3);margin-top:4px">By: ${a.created_by_name||'Admin'} · ${new Date(a.changed_at).toLocaleDateString()}</div>
          </div>
        </div>`;
    }).join('');
}

function exportSatisfactionReport() {
    const rows = [['Metric','Value']];
    rows.push(['Total Customers','<?=$totalCustomers?>']);
    rows.push(['Active Users','<?=$activeUsers?>']);
    rows.push(['Open Complaints','<?=$openComplaints?>']);
    rows.push(['Average Rating','<?=number_format($avgRating,2)?>']);
    rows.push(['Total Reviews','<?=$totalReviews?>']);
    rows.push(['Report Date', new Date().toLocaleDateString()]);
    const csv = rows.map(r=>r.map(c=>`"${c}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,'+encodeURIComponent(csv);
    a.download = 'satisfaction_report_'+new Date().toISOString().slice(0,10)+'.csv';
    a.click();
}

window.addEventListener('load', () => {
    loadComplaints('all');
    loadComplaintsMobile('all');
});
</script>
<?php include __DIR__ . '/chat_widget.php'; ?>
</body>
</html>