<?php
session_start();
header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 0);  // Never expose errors in production JSON endpoint

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDatabaseConnection();
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

$currentPassword = $_POST['current_password'] ?? '';
$newPassword     = $_POST['new_password']     ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';
$userId          = $_SESSION['user_id'];

if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

if ($newPassword !== $confirmPassword) {
    echo json_encode(['success' => false, 'message' => 'New passwords do not match']);
    exit;
}

if (strlen($newPassword) < 8) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters']);
    exit;
}

// Basic strength check
if (!preg_match('/[A-Z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
    echo json_encode(['success' => false, 'message' => 'Password must contain at least one uppercase letter and one number']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT password FROM core_users WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    // Support both hashed (bcrypt) and legacy plain passwords
    $storedPassword = $user['password'];
    $isHashed       = strlen($storedPassword) >= 60 && str_starts_with($storedPassword, '$2');

    if ($isHashed) {
        $verified = password_verify($currentPassword, $storedPassword);
    } else {
        // Legacy plain-text comparison (migrate on success)
        $verified = ($storedPassword === $currentPassword);
    }

    if (!$verified) {
        echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
        exit;
    }

    // Hash the new password
    $hashed = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);

    $stmt = $pdo->prepare("
        UPDATE core_users
        SET password   = :password,
            updated_at = CURRENT_TIMESTAMP
        WHERE user_id  = :user_id
    ");
    $stmt->execute([
        'password' => $hashed,
        'user_id'  => $userId,
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Password changed successfully',
    ]);

} catch (PDOException $e) {
    error_log("Password change error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to change password']);
}
?>