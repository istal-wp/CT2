<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get(string $table, array $params = []) {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: count=exact',
        ],
    ]);
    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode < 200 || $httpCode >= 300) {
        error_log("Supabase sb_get Error ({$table}): HTTP {$httpCode} - {$resp}");
        return [];
    }
    $data = json_decode($resp, true);
    if (!is_array($data)) return [];
    if (array_key_exists('message', $data) || array_key_exists('code', $data)) {
        error_log("Supabase sb_get Error ({$table}): " . $resp);
        return [];
    }
    return array_values(array_filter($data, fn($row) => is_array($row)));
}

function sb_count(string $table, array $params = []): int {
    $params['select'] = 'count';
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($params);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Prefer: count=exact',
        ],
        CURLOPT_HEADER         => true,
        CURLOPT_NOBODY         => true,
    ]);
    $resp    = curl_exec($ch);
    $headers = curl_getinfo($ch);
    curl_close($ch);

    if (preg_match('/content-range:\s*\d+-\d+\/(\d+)/i', $resp, $m)) {
        return (int)$m[1];
    }
    return 0;
}

date_default_timezone_set('Asia/Manila');
$today     = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));
$month_ago = date('Y-m-d', strtotime('-30 days'));
$hour      = (int)date('H');
$greeting  = $hour < 12 ? 'Good Morning' : ($hour < 18 ? 'Good Afternoon' : 'Good Evening');

// Exclude cancelled bookings from today's data
$bookings_today = sb_get('core2_bookings', [
    'booking_date' => 'eq.' . $today,
    'booking_status' => 'neq.Cancelled', // Exclude cancelled
    'select' => 'booking_id,booking_status,total_amount,payment_status,created_at'
]);

$bookings_yesterday = sb_get('core2_bookings', [
    'booking_date' => 'eq.' . $yesterday,
    'booking_status' => 'neq.Cancelled', // Exclude cancelled
    'select' => 'booking_id'
]);

$all_bookings = sb_get('core2_bookings', [
    'select' => 'booking_id,booking_status,booking_reference,total_amount,payment_status,created_at,booking_date,customer_id'
]);

$totalBookings    = count($bookings_today);
$yb               = count($bookings_yesterday);
$bookingChange    = $yb > 0 ? round((($totalBookings - $yb) / $yb) * 100) : 0;
$pendingBookings  = count(array_filter($all_bookings, fn($b) => is_array($b) && ($b['booking_status'] ?? '') === 'Pending'));
$confirmedBookings= count(array_filter($all_bookings, fn($b) => is_array($b) && ($b['booking_status'] ?? '') === 'Confirmed'));

$week_ago = date('Y-m-d', strtotime('-7 days'));
$completedBookings = count(array_filter($all_bookings, fn($b) => is_array($b) && ($b['booking_status'] ?? '') === 'Completed' && ($b['booking_date'] ?? '') >= $week_ago
));

$todayEarnings = array_sum(array_map(
    fn($b) => (is_array($b) 
        && ($b['payment_status'] ?? '') === 'Paid' 
        && ($b['booking_status'] ?? '') !== 'Cancelled')
        ? (float)($b['total_amount'] ?? 0) 
        : 0,
    $bookings_today
));

$payments_month = sb_get('core2_payment_authorization', [
    'created_at' => 'gte.' . $month_ago . 'T00:00:00',
    'payment_status' => 'in.(Captured,Paid)',  // Only include captured/paid
    'select'     => 'payment_id,amount,payment_status',
]);
$totalPayments = array_sum(array_map(fn($p) => is_array($p) ? (float)($p['amount'] ?? 0) : 0, $payments_month));

$payments_today = sb_get('core2_payment_authorization', [
    'created_at'     => 'gte.' . $today . 'T00:00:00',
    'payment_status' => 'eq.Captured',
    'select'         => 'amount',
]);
$totalRevenue = array_sum(array_map(fn($p) => is_array($p) ? (float)($p['amount'] ?? 0) : 0, $payments_today));

$customers = sb_get('core2_customers', [
    'status' => 'eq.Active',
    'select' => 'customer_id,name,customer_type',
]);
$totalCustomers = count($customers);

$rides_active = sb_get('core2_rides', [
    'ride_status' => 'in.(Accepted,In Progress)',
    'select'      => 'ride_id,ride_status,driver_id,fleet_id',
]);
$activeTrips = count($rides_active);

$rides_today = sb_get('core2_rides', [
    'start_time' => 'gte.' . $today . 'T00:00:00',
    'select'     => 'ride_id,ride_status',
]);
$todayTrips = count($rides_today);

$ratings = sb_get('core2_ratings', [
    'created_at' => 'gte.' . $month_ago . 'T00:00:00',
    'select'     => 'rating_value',
]);
$rating = count($ratings) > 0
    ? array_sum(array_map(fn($r) => is_array($r) ? (float)($r['rating_value'] ?? 0) : 0, $ratings)) / count($ratings)
    : 0;

$visitors_month = sb_get('administrative_walkin_visitors', [
    'created_at' => 'gte.' . $month_ago . 'T00:00:00',
    'select'     => 'id,status,type',
]);
$sopDocuments    = count($visitors_month);
$openIssues      = count(array_filter($visitors_month, fn($v) => is_array($v) && ($v['status'] ?? '') === 'Checked In'));
$completedVisits = count(array_filter($visitors_month, fn($v) => is_array($v) && ($v['status'] ?? '') === 'Completed'));
$complianceRate  = $sopDocuments > 0 ? round(($completedVisits / $sopDocuments) * 100) : 0;

$recent_raw = sb_get('core2_bookings', [
    'select'   => 'booking_reference,booking_status,total_amount,created_at,customer_id',
    'order'    => 'created_at.desc',
    'limit'    => '5',
]);

$recentBookings = [];
foreach ($recent_raw as $b) {
    if (!is_array($b)) continue;
    $cust = isset($b['customer_id']) ? sb_get('core2_customers', [
        'customer_id' => 'eq.' . $b['customer_id'],
        'select'      => 'name',
    ]) : [];
    $b['customer_name'] = (is_array($cust) && !empty($cust[0]['name'])) ? $cust[0]['name'] : 'Guest';
    $recentBookings[]   = $b;
}

$userName    = htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin');
$userInitial = strtoupper(substr($userName, 0, 1));

function statusClass($s) {
    return ['Pending'=>'sp','Confirmed'=>'sc','Completed'=>'sk','Cancelled'=>'sx','In Progress'=>'si'][$s] ?? 'sp';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>

*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%}
.peso{font-family:'DM Sans',sans-serif;font-weight:700}
.hc-peso{font-family:'DM Sans',sans-serif;font-weight:800;font-size:.75em;vertical-align:2px}

:root{
  --g:#00D084; --gd:#00A86B; --gx:#005A38;
  --gg:rgba(0,208,132,.1);
  --bg:#F0F4F2; --surf:#fff; --surf2:#F7FAF8; --surf3:#EEF5F1;
  --bdr:#DDE8E2; --bdr2:#C8DDD5;
  --txt:#0D1F18; --txt2:#3A5248; --txt3:#7A9A8E; --txt4:#B0C8BC;
  --blue:#3B8EF0; --purple:#8B6FE8; --orange:#F07830; --red:#E84040; --yellow:#E8A020;
  --sw:248px; --th:58px; --r:16px; --rs:10px;
  --shadow:0 1px 3px rgba(0,0,0,.04),0 4px 16px rgba(0,0,0,.06);
  --shadow-md:0 2px 8px rgba(0,0,0,.05),0 8px 28px rgba(0,0,0,.09);
  --sb-bg:#991B1B; --sb-bg2:#7F1D1D;
  --sb-txt:#FECACA; --sb-txt2:#FCA5A5; --sb-bdr:rgba(255,255,255,.1);
  --sb-item-hover:rgba(255,255,255,.09); --sb-active:rgba(255,255,255,.16);
  --sb-active-bdr:rgba(255,255,255,.28);
}

body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--txt);-webkit-font-smoothing:antialiased}

.f{font-family:'DM Sans',sans-serif;font-weight:800}
.trunc{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
a{text-decoration:none;color:inherit}

@media(min-width:900px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}

  .sidebar{width:var(--sw);flex-shrink:0;height:100vh;display:flex;flex-direction:column;background:var(--sb-bg);border-right:none;overflow:hidden;box-shadow:4px 0 20px rgba(185,28,28,.25)}
  .sb-logo{height:var(--th);display:flex;align-items:center;gap:10px;padding:0 20px;border-bottom:1px solid var(--sb-bdr);flex-shrink:0}
  .sb-logo img{height:28px;width:auto;filter:brightness(0) invert(1)}
  .sb-logo-text,.sb-brand{font-family:'DM Sans',sans-serif;font-size:16px;font-weight:800;letter-spacing:-.3px;color:#fff}
  .sb-logo-text span,.sb-brand span{color:#FCA5A5}
  .sb-nav{flex:1;overflow-y:auto;padding:14px 12px;display:flex;flex-direction:column;gap:2px}
  .sb-label{font-size:10px;font-weight:700;letter-spacing:1.1px;text-transform:uppercase;color:var(--sb-txt2);padding:14px 8px 6px}
  .sb-item{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:var(--rs);cursor:pointer;color:var(--sb-txt);font-size:13.5px;font-weight:500;border:1.5px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-item-hover);color:#fff}
  .sb-item.active{background:var(--sb-active);color:#fff;border-color:var(--sb-active-bdr);font-weight:600}
  .sb-icon{width:32px;height:32px;border-radius:9px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.1);transition:background .15s}
  .sb-item:hover .sb-icon{background:rgba(255,255,255,.15)}
  .sb-item.active .sb-icon{background:rgba(255,255,255,.22)}
  .sb-item svg{stroke:var(--sb-txt)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-badge{margin-left:auto;font-size:10.5px;font-weight:700;background:rgba(255,255,255,.2);color:#fff;padding:1px 7px;border-radius:20px}
  .sb-foot{padding:14px 12px;border-top:1px solid var(--sb-bdr);flex-shrink:0;display:flex;gap:8px;align-items:center}
  .sb-avatar{width:36px;height:36px;border-radius:10px;flex-shrink:0;background:rgba(255,255,255,.22);display:flex;align-items:center;justify-content:center;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:800;color:#fff;border:1.5px solid rgba(255,255,255,.3)}
  .sb-uname{font-size:13px;font-weight:600;color:#fff}
  .sb-urole{font-size:11px;color:var(--sb-txt2);margin-top:1px}
  .sb-logout{margin-left:auto;width:32px;height:32px;border-radius:9px;background:rgba(255,255,255,.12);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background .15s;flex-shrink:0}
  .sb-logout:hover{background:rgba(255,255,255,.22)}

  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}

  .topbar{height:var(--th);flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 28px;gap:14px}
  .tb-title{flex:1;font-family:'DM Sans',sans-serif;font-size:18px;font-weight:800;color:var(--txt);letter-spacing:-.2px}
  .tb-date{font-size:13px;color:var(--txt3);font-weight:500;white-space:nowrap}
  .tb-sep{width:1px;height:20px;background:var(--bdr)}
  .tb-bell{width:36px;height:36px;border-radius:10px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative;transition:background .15s}
  .tb-bell:hover{background:var(--bg)}
  .tb-dot{position:absolute;top:8px;right:8px;width:6px;height:6px;border-radius:50%;background:var(--red);border:2px solid var(--surf)}

  .desk-scroll{flex:1;overflow-y:auto;padding:24px;display:flex;flex-direction:column;gap:20px}
  .desk-scroll::-webkit-scrollbar{width:0;background:transparent}
  .desk-scroll{scrollbar-width:none}

  .g4{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
  .g3{display:grid;grid-template-columns:1fr 1fr 320px;gap:14px}
  .g6{display:grid;grid-template-columns:repeat(6,1fr);gap:12px}

  .hero-card{grid-column:span 2;background:linear-gradient(135deg,var(--g) 0%,var(--gx) 100%);border-radius:var(--r);padding:26px 24px;color:#fff;position:relative;overflow:hidden;box-shadow:0 8px 32px rgba(0,208,132,.22)}
  .hero-card::before{content:'';position:absolute;top:-60px;right:-40px;width:200px;height:200px;background:rgba(255,255,255,.07);border-radius:50%;pointer-events:none}
  .hero-card::after{content:'';position:absolute;bottom:-50px;right:50px;width:140px;height:140px;background:rgba(255,255,255,.04);border-radius:50%;pointer-events:none}
  .hc-greet{font-size:12.5px;opacity:.85;margin-bottom:3px;position:relative}
  .hc-name{font-family:'DM Sans',sans-serif;font-size:21px;font-weight:800;margin-bottom:18px;position:relative}
  .hc-elabel{font-size:11px;opacity:.8;position:relative;margin-bottom:3px}
  .hc-amount{font-family:'DM Sans',sans-serif;font-size:38px;font-weight:800;letter-spacing:-1px;line-height:1;position:relative}
  .hc-stats{display:flex;gap:10px;margin-top:20px;position:relative}
  .hcs{flex:1;background:rgba(255,255,255,.15);border-radius:11px;padding:11px;text-align:center;backdrop-filter:blur(6px)}
  .hcs-v{font-family:'DM Sans',sans-serif;font-size:20px;font-weight:800}
  .hcs-l{font-size:10.5px;opacity:.82;margin-top:2px}

  .kpi{background:var(--surf);border-radius:var(--r);padding:20px;border:1px solid var(--bdr);display:flex;flex-direction:column;gap:10px;transition:box-shadow .2s}
  .kpi:hover{box-shadow:var(--shadow)}
  .kpi-top{display:flex;align-items:center;justify-content:space-between}
  .kpi-ico{width:40px;height:40px;border-radius:11px;display:flex;align-items:center;justify-content:center}
  .kpi-trend{font-size:10.5px;font-weight:700;padding:3px 8px;border-radius:7px}
  .tu{background:rgba(0,208,132,.12);color:var(--gd)}
  .td{background:rgba(255,80,85,.12);color:var(--red)}
  .tn{background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-family:'DM Sans',sans-serif;font-size:34px;font-weight:800;line-height:1}
  .kpi-val .peso{font-family:'DM Sans',sans-serif;font-size:28px;font-weight:700}
  .kpi-lbl{font-size:12.5px;color:var(--txt3);font-weight:500}

  .panel{background:var(--surf);border-radius:var(--r);padding:20px;border:1px solid var(--bdr)}
  .panel-h{font-family:'DM Sans',sans-serif;font-size:15px;font-weight:800;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between}
  .panel-h a{font-family:'DM Sans',sans-serif;font-size:12px;font-weight:600;color:var(--gd)}

  .qa-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
  .qa{background:var(--surf2);border:1.5px solid var(--bdr);border-radius:13px;padding:13px 12px;display:flex;align-items:center;gap:11px;cursor:pointer;transition:all .18s}
  .qa:hover{border-color:var(--g);background:var(--gg);transform:translateY(-2px);box-shadow:0 4px 14px rgba(0,208,132,.1)}
  .qa-ico{width:38px;height:38px;border-radius:11px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .qa-t{font-size:13px;font-weight:600}
  .qa-s{font-size:11px;color:var(--txt3);margin-top:1px}

  .bstat-row{display:flex;gap:8px;margin-top:14px;padding-top:14px;border-top:1px solid var(--bdr)}
  .bstat{flex:1;border-radius:11px;padding:11px;text-align:center}
  .bstat-v{font-family:'DM Sans',sans-serif;font-size:20px;font-weight:800}
  .bstat-l{font-size:10.5px;font-weight:600;margin-top:2px}

  .act-list{display:flex;flex-direction:column;gap:7px}
  .act{display:flex;align-items:center;gap:11px;padding:11px;background:var(--surf2);border-radius:12px;transition:background .15s}
  .act:hover{background:var(--bg)}
  .act-ico{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .act-info{flex:1;min-width:0}
  .act-name{font-size:13px;font-weight:600}
  .act-meta{font-size:11px;color:var(--txt3);margin-top:2px;display:flex;align-items:center;gap:5px}
  .act-amt{font-size:13.5px;font-weight:700}
  .pill{display:inline-block;font-size:9.5px;font-weight:700;padding:2px 6px;border-radius:5px;text-transform:uppercase;letter-spacing:.3px}
  .sp{background:rgba(255,202,74,.2);color:#9A6A00}
  .sc{background:rgba(74,158,255,.14);color:#1460AA}
  .sk{background:rgba(0,208,132,.14);color:var(--gd)}
  .sx{background:rgba(255,80,85,.12);color:var(--red)}
  .si{background:rgba(155,127,255,.14);color:#5B3FBB}

  .ring-wrap{text-align:center;padding:8px 0 14px}
  .ring-label{font-size:13px;font-weight:600;color:var(--txt2);margin-top:4px}
  .ring-sub{font-size:11px;color:var(--txt3);margin-top:2px}
  .c-rows{display:flex;flex-direction:column;gap:7px}
  .c-row{display:flex;align-items:center;justify-content:space-between;padding:9px 11px;background:var(--surf2);border-radius:10px}
  .c-row-l{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--txt2);font-weight:500}
  .c-dot{width:7px;height:7px;border-radius:50%}
  .c-row-v{font-size:13px;font-weight:700}

  .mods-title{font-family:'DM Sans',sans-serif;font-size:15px;font-weight:800;margin-bottom:13px}
  .mod{background:var(--surf);border:1.5px solid var(--bdr);border-radius:var(--r);padding:18px 12px;text-align:center;cursor:pointer;transition:all .2s;display:flex;flex-direction:column;align-items:center;gap:9px}
  .mod:hover{border-color:var(--g);transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,208,132,.12)}
  .mod-ico{width:46px;height:46px;border-radius:13px;display:flex;align-items:center;justify-content:center}
  .mod-t{font-size:12px;font-weight:700;line-height:1.3}
  .mod-s{font-size:10.5px;color:var(--txt3)}

  .desk-scroll::-webkit-scrollbar{width:5px}
  .desk-scroll::-webkit-scrollbar-track{background:transparent}
  .desk-scroll::-webkit-scrollbar-thumb{background:var(--bdr);border-radius:10px}
}

@media(min-width:768px) and (max-width:899px){
  body{display:flex;overflow:hidden}
  .mob-header,.mob-body,.mob-nav{display:none!important}
  .sidebar{width:64px;height:100vh;background:var(--sb-bg);border-right:none;display:flex;flex-direction:column;align-items:center;padding:12px 0;gap:4px;flex-shrink:0;box-shadow:4px 0 16px rgba(185,28,28,.2)}
  .sb-logo{width:100%;height:54px;display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--sb-bdr);margin-bottom:8px}
  .sb-logo img{height:26px;filter:brightness(0) invert(1)}
  .sb-logo-text,.sb-label,.sb-badge,.sb-uname,.sb-urole{display:none}
  .sb-nav{flex:1;width:100%;padding:4px 8px;display:flex;flex-direction:column;align-items:center;gap:3px}
  .sb-item{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:1.5px solid transparent;transition:all .15s}
  .sb-item:hover{background:var(--sb-item-hover)}
  .sb-item.active{background:var(--sb-active);border-color:var(--sb-active-bdr)}
  .sb-icon{width:32px;height:32px;border-radius:9px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.1)}
  .sb-item svg{stroke:var(--sb-txt)!important}
  .sb-item:hover svg,.sb-item.active svg{stroke:#fff!important}
  .sb-item.active .sb-icon{background:rgba(255,255,255,.22)}
  .sb-foot{padding:8px;border-top:1px solid var(--sb-bdr);width:100%;display:flex;flex-direction:column;align-items:center;gap:6px}
  .sb-avatar{width:34px;height:34px;border-radius:9px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:800;color:#fff;border:1.5px solid rgba(255,255,255,.3)}
  .sb-logout{width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.12);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .sb-logout svg{stroke:#fff!important}
  .desk-wrap{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;min-width:0}
  .topbar{height:54px;flex-shrink:0;background:var(--surf);border-bottom:1px solid var(--bdr);display:flex;align-items:center;padding:0 18px;gap:10px}
  .tb-title{flex:1;font-family:'DM Sans',sans-serif;font-size:16px;font-weight:800;letter-spacing:-.2px}
  .tb-date{font-size:12px;color:var(--txt3)}
  .tb-sep{width:1px;height:18px;background:var(--bdr)}
  .tb-bell{width:34px;height:34px;border-radius:9px;background:var(--surf2);border:1px solid var(--bdr);display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative}
  .tb-dot{position:absolute;top:7px;right:7px;width:6px;height:6px;border-radius:50%;background:var(--red);border:2px solid var(--surf)}
  .desk-scroll{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:14px}
  .g4{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .hero-card{grid-column:span 2;background:linear-gradient(135deg,var(--g),var(--gx));border-radius:16px;padding:20px;color:#fff;position:relative;overflow:hidden;box-shadow:0 6px 24px rgba(0,208,132,.2)}
  .hero-card::before{content:'';position:absolute;top:-50px;right:-30px;width:170px;height:170px;background:rgba(255,255,255,.07);border-radius:50%;pointer-events:none}
  .hc-greet{font-size:12px;opacity:.85;margin-bottom:2px;position:relative}
  .hc-name{font-family:'DM Sans',sans-serif;font-size:18px;font-weight:800;margin-bottom:14px;position:relative}
  .hc-elabel{font-size:11px;opacity:.8;position:relative;margin-bottom:2px}
  .hc-amount{font-family:'DM Sans',sans-serif;font-size:32px;font-weight:800;letter-spacing:-1px;line-height:1;position:relative}
  .hc-stats{display:flex;gap:8px;margin-top:16px;position:relative}
  .hcs{flex:1;background:rgba(255,255,255,.15);border-radius:10px;padding:9px;text-align:center}
  .hcs-v{font-family:'DM Sans',sans-serif;font-size:18px;font-weight:800}
  .hcs-l{font-size:10px;opacity:.82;margin-top:2px}
  .kpi{background:var(--surf);border-radius:14px;padding:16px;border:1px solid var(--bdr);display:flex;flex-direction:column;gap:8px}
  .kpi-top{display:flex;align-items:center;justify-content:space-between}
  .kpi-ico{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center}
  .kpi-trend{font-size:10px;font-weight:700;padding:2px 7px;border-radius:6px}
  .tu{background:rgba(0,208,132,.12);color:var(--gd)}
  .td{background:rgba(255,80,85,.12);color:var(--red)}
  .tn{background:rgba(0,0,0,.05);color:var(--txt3)}
  .kpi-val{font-family:'DM Sans',sans-serif;font-size:30px;font-weight:800;line-height:1}
  .kpi-val .peso{font-family:'DM Sans',sans-serif;font-size:24px;font-weight:700}
  .kpi-lbl{font-size:12px;color:var(--txt3)}
  .g3{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .panel{background:var(--surf);border-radius:14px;padding:16px;border:1px solid var(--bdr)}
  .panel-h{font-family:'DM Sans',sans-serif;font-size:14px;font-weight:800;margin-bottom:13px;display:flex;align-items:center;justify-content:space-between}
  .panel-h a{font-family:'DM Sans',sans-serif;font-size:11px;font-weight:600;color:var(--gd)}
  .qa-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .qa{background:var(--surf2);border:1.5px solid var(--bdr);border-radius:12px;padding:11px;display:flex;align-items:center;gap:9px;cursor:pointer;transition:all .15s}
  .qa:hover{border-color:var(--g);background:var(--gg)}
  .qa-ico{width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .qa-t{font-size:12px;font-weight:600}
  .qa-s{font-size:10px;color:var(--txt3);margin-top:1px}
  .bstat-row{display:flex;gap:7px;margin-top:12px;padding-top:12px;border-top:1px solid var(--bdr)}
  .bstat{flex:1;border-radius:10px;padding:10px;text-align:center}
  .bstat-v{font-family:'DM Sans',sans-serif;font-size:18px;font-weight:800}
  .bstat-l{font-size:10px;font-weight:600;margin-top:2px}
  .act-list{display:flex;flex-direction:column;gap:6px}
  .act{display:flex;align-items:center;gap:9px;padding:9px;background:var(--surf2);border-radius:11px}
  .act-ico{width:32px;height:32px;border-radius:9px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .act-info{flex:1;min-width:0}
  .act-name{font-size:12px;font-weight:600}
  .act-meta{font-size:10px;color:var(--txt3);margin-top:2px}
  .act-amt{font-size:12.5px;font-weight:700}
  .pill{display:inline-block;font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;text-transform:uppercase;letter-spacing:.3px}
  .sp{background:rgba(255,202,74,.2);color:#9A6A00}
  .sc{background:rgba(74,158,255,.14);color:#1460AA}
  .sk{background:rgba(0,208,132,.14);color:var(--gd)}
  .sx{background:rgba(255,80,85,.12);color:var(--red)}
  .si{background:rgba(155,127,255,.14);color:#5B3FBB}
  .ring-wrap{text-align:center;padding:6px 0 12px}
  .ring-label{font-size:12px;font-weight:600;color:var(--txt2);margin-top:4px}
  .ring-sub{font-size:10px;color:var(--txt3);margin-top:2px}
  .c-rows{display:flex;flex-direction:column;gap:6px}
  .c-row{display:flex;align-items:center;justify-content:space-between;padding:8px 10px;background:var(--surf2);border-radius:9px}
  .c-row-l{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--txt2);font-weight:500}
  .c-dot{width:6px;height:6px;border-radius:50%}
  .c-row-v{font-size:12px;font-weight:700}
  .g6{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .mods-title{font-family:'DM Sans',sans-serif;font-size:14px;font-weight:800;margin-bottom:11px}
  .mod{background:var(--surf);border:1.5px solid var(--bdr);border-radius:14px;padding:14px 10px;text-align:center;cursor:pointer;transition:all .2s;display:flex;flex-direction:column;align-items:center;gap:7px}
  .mod:hover{border-color:var(--g);transform:translateY(-2px);box-shadow:0 6px 18px rgba(0,208,132,.1)}
  .mod-ico{width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center}
  .mod-t{font-size:11px;font-weight:700;line-height:1.3}
  .mod-s{font-size:10px;color:var(--txt3)}
  .desk-scroll::-webkit-scrollbar{width:4px}
  .desk-scroll::-webkit-scrollbar-thumb{background:var(--bdr);border-radius:10px}
}

@media(max-width:767px){
  .sidebar,.desk-wrap{display:none!important}
  body{background:linear-gradient(160deg,#E2F5EC 0%,#EDF5FF 100%)}
  .mob-header{position:sticky;top:0;z-index:100;background:rgba(255,255,255,.88);backdrop-filter:blur(18px);border-bottom:1px solid rgba(255,255,255,.5);padding:13px 18px;display:flex;align-items:center;justify-content:space-between}
  .mob-header img{height:24px}
  .mh-r{display:flex;gap:9px;align-items:center}
  .mh-btn{width:36px;height:36px;border-radius:12px;background:rgba(255,255,255,.9);border:1px solid rgba(0,0,0,.06);display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative}
  .mh-btn svg{stroke:#4A5568}
  .mh-ndot{position:absolute;top:7px;right:7px;width:6px;height:6px;background:var(--red);border-radius:50%;border:2px solid #fff}
  .mh-logout{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2)}
  .mob-body{padding:16px 16px 20px;display:flex;flex-direction:column;gap:0}
  .m-hero{background:linear-gradient(135deg,#00D084,#006B45);border-radius:22px;padding:24px 20px;color:#fff;margin-bottom:16px;box-shadow:0 8px 32px rgba(0,208,132,.2);position:relative;overflow:hidden}
  .m-hero::before{content:'';position:absolute;top:-60px;right:-30px;width:190px;height:190px;background:rgba(255,255,255,.07);border-radius:50%;pointer-events:none}
  .mh-greet{font-size:12.5px;opacity:.9;margin-bottom:2px;position:relative}
  .mh-title{font-family:'DM Sans',sans-serif;font-size:22px;font-weight:800;margin-bottom:5px;position:relative}
  .mh-amount{font-family:'DM Sans',sans-serif;font-size:38px;font-weight:900;letter-spacing:-1px;line-height:1;position:relative}
  .mh-alabel{font-size:11px;opacity:.85;margin-top:3px;position:relative}
  .mh-stats{display:flex;gap:10px;margin-top:20px;position:relative}
  .mhs{flex:1;background:rgba(255,255,255,.15);border-radius:12px;padding:10px;text-align:center;backdrop-filter:blur(8px)}
  .mhs-v{font-family:'DM Sans',sans-serif;font-size:19px;font-weight:800}
  .mhs-l{font-size:10px;opacity:.85;margin-top:2px}
  .m-qa{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin-bottom:16px}
  .mqa{background:#fff;border-radius:16px;padding:13px 5px;text-align:center;border:1px solid #E2EDE8;box-shadow:0 2px 8px rgba(0,0,0,.04);cursor:pointer;transition:all .2s}
  .mqa:active{transform:scale(.96)}
  .mqa-ico{width:40px;height:40px;margin:0 auto 7px;border-radius:12px;display:flex;align-items:center;justify-content:center}
  .mqa-ico.g{background:linear-gradient(135deg,#10B981,#059669)}
  .mqa-ico.b{background:linear-gradient(135deg,#60A5FA,#3B82F6)}
  .mqa-ico.p{background:linear-gradient(135deg,#C084FC,#A855F7)}
  .mqa-ico.o{background:linear-gradient(135deg,#FB923C,#F97316)}
  .mqa-lbl{font-size:10.5px;font-weight:600;color:#4A5568}
  .m-stats{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px}
  .mst{background:#fff;border-radius:16px;padding:16px;border:1px solid #E2EDE8;box-shadow:0 2px 8px rgba(0,0,0,.04)}
  .mst-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}
  .mst-ico{width:38px;height:38px;border-radius:11px;display:flex;align-items:center;justify-content:center}
  .mst-tr{font-size:10.5px;font-weight:700;padding:3px 8px;border-radius:7px}
  .tu{background:rgba(0,208,132,.12);color:#00A86B}
  .td{background:rgba(255,80,85,.12);color:#FF5055}
  .tn{background:rgba(0,0,0,.05);color:#7A9A8E}
  .mst-v{font-family:'DM Sans',sans-serif;font-size:26px;font-weight:800;color:#0E1E17}
  .mst-l{font-size:12px;color:#7A9A8E;font-weight:500}
  .m-card{background:#fff;border-radius:18px;padding:16px;border:1px solid #E2EDE8;box-shadow:0 2px 8px rgba(0,0,0,.04);margin-bottom:14px}
  .mc-title{font-family:'DM Sans',sans-serif;font-size:15px;font-weight:800;margin-bottom:13px;color:#0E1E17}
  .ma{display:flex;align-items:center;gap:10px;padding:10px;background:rgba(0,0,0,.02);border-radius:12px;margin-bottom:7px}
  .ma:last-child{margin-bottom:0}
  .ma-ico{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .ma-info{flex:1;min-width:0}
  .ma-name{font-size:13px;font-weight:600;color:#0E1E17;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .ma-sub{font-size:11px;color:#7A9A8E;margin-top:2px}
  .ma-amt{font-size:13px;font-weight:700;color:#0E1E17;white-space:nowrap}
  .pill{display:inline-block;font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;text-transform:uppercase;letter-spacing:.3px}
  .sp{background:rgba(255,202,74,.2);color:#9A6A00}
  .sc{background:rgba(74,158,255,.14);color:#1460AA}
  .sk{background:rgba(0,208,132,.14);color:#00A86B}
  .sx{background:rgba(255,80,85,.12);color:#FF5055}
  .si{background:rgba(155,127,255,.14);color:#5B3FBB}
  .mmod{display:flex;align-items:center;gap:12px;padding:12px;background:rgba(0,0,0,.015);border-radius:13px;cursor:pointer;transition:all .2s;text-decoration:none;margin-bottom:9px}
  .mmod:last-child{margin-bottom:0}
  .mmod:active{transform:translateX(3px)}
  .mmod-ico{width:46px;height:46px;border-radius:13px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .mmod-t{font-size:13.5px;font-weight:600;color:#0E1E17;margin-bottom:2px}
  .mmod-s{font-size:11px;color:#7A9A8E}
  .mmod-arr{margin-left:auto;font-size:18px;color:#7A9A8E;flex-shrink:0}
  .mob-nav{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.96);backdrop-filter:blur(20px);border-top:1px solid rgba(0,0,0,.06);padding:10px 0 18px;display:grid;grid-template-columns:repeat(4,1fr);z-index:99;box-shadow:0 -4px 20px rgba(0,0,0,.05)}
  .mn{display:flex;flex-direction:column;align-items:center;gap:3px;padding:6px;cursor:pointer;border:none;background:none;transition:all .2s}
  .mn:active{transform:scale(.95)}
  .mn-ico{width:42px;height:28px;display:flex;align-items:center;justify-content:center}
  .mn-ico svg{stroke:#718096;opacity:.5;transition:all .2s}
  .mn.active .mn-ico svg{stroke:#00D084;opacity:1}
  .mn-lbl{font-size:10px;font-weight:600;color:#718096;opacity:.7}
  .mn.active .mn-lbl{color:#00D084;opacity:1}
  body{padding-bottom:82px}
}

@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
.hero-card,.kpi,.panel,.mod,.m-hero,.mst,.m-card{animation:fadeUp .35s ease forwards}
</style>
</head>
<body>

<?php
function ico($path,$stroke='#4A5568',$size=18){
  return "<svg width='$size' height='$size' viewBox='0 0 24 24' fill='none' stroke='$stroke' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>$path</svg>";
}
$iBook  = "<rect x='3' y='4' width='18' height='18' rx='2'/><line x1='16' y1='2' x2='16' y2='6'/><line x1='8' y1='2' x2='8' y2='6'/><line x1='3' y1='10' x2='21' y2='10'/>";
$iPay   = "<rect x='1' y='4' width='22' height='16' rx='2'/><line x1='1' y1='10' x2='23' y2='10'/>";
$iCrm   = "<path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/>";
$iGps   = "<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/>";
$iBar   = "<line x1='18' y1='20' x2='18' y2='10'/><line x1='12' y1='20' x2='12' y2='4'/><line x1='6' y1='20' x2='6' y2='14'/>";
$iDoc   = "<path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><polyline points='14 2 14 8 20 8'/><line x1='16' y1='13' x2='8' y2='13'/><line x1='16' y1='17' x2='8' y2='17'/>";
$iHome  = "<path d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/><polyline points='9 22 9 12 15 12 15 22'/>";
$iTruck = "<rect x='1' y='3' width='15' height='13'/><polygon points='16 8 20 8 23 11 23 16 16 16 16 8'/><circle cx='5.5' cy='18.5' r='2.5'/><circle cx='18.5' cy='18.5' r='2.5'/>";
$iUser  = "<path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/>";
$iBell  = "<path d='M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9'/><path d='M13.73 21a2 2 0 0 1-3.46 0'/>";
$iOut   = "<path d='M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'/><polyline points='16 17 21 12 16 7'/><line x1='21' y1='12' x2='9' y2='12'/>";
$actColors=[['rgba(0,208,132,.12)','#00A86B'],['rgba(74,158,255,.12)','#4A9EFF'],['rgba(255,138,74,.12)','#FF8A4A'],['rgba(155,127,255,.12)','#9B7FFF'],['rgba(255,80,85,.12)','#FF5055']];
?>

<aside class="sidebar">
  <div class="sb-logo">
    <img src="../images/envirocab_logo.png" alt="EnviroCab" onerror="this.style.display='none'">
  </div>
  <nav class="sb-nav">
    <div class="sb-label">Main</div>
    <a href="dashboard.php" class="sb-item active">
      <div class="sb-icon"><?=ico($iHome,'#4A5568')?></div><span>Dashboard</span>
    </a>
    <a href="booking_system.php" class="sb-item">
      <div class="sb-icon"><?=ico($iBook,'#4A5568')?></div><span>Booking System</span>
      <?php if($pendingBookings>0):?><span class="sb-badge"><?=$pendingBookings?></span><?php endif;?>
    </a>
    <a href="payment_fares.php" class="sb-item">
      <div class="sb-icon"><?=ico($iPay,'#4A5568')?></div><span>Payment &amp; Fares</span>
    </a>
    <a href="crm_system.php" class="sb-item">
      <div class="sb-icon"><?=ico($iCrm,'#4A5568')?></div><span>CRM</span>
    </a>
    <a href="gps_tracking.php" class="sb-item">
      <div class="sb-icon"><?=ico($iGps,'#4A5568')?></div><span>GPS Tracking</span>
      <?php if($activeTrips>0):?><span class="sb-badge"><?=$activeTrips?></span><?php endif;?>
    </a>
    <div class="sb-label">Analytics</div>
    <a href="transport_analytics.php" class="sb-item">
      <div class="sb-icon"><?=ico($iBar,'#4A5568')?></div><span>Analytics &amp; KPIs</span>
    </a>
    <a href="sop_compliance.php" class="sb-item">
      <div class="sb-icon"><?=ico($iDoc,'#4A5568')?></div><span>SOP Compliance</span>
    </a>
  </nav>
  <div class="sb-foot">
    <div class="sb-avatar"><?=$userInitial?></div>
    <div style="flex:1;min-width:0">
      <div class="sb-uname trunc"><?=$userName?></div>
      <div class="sb-urole">Administrator</div>
    </div>
    <button class="sb-logout" onclick="if(confirm('Logout?'))window.location.href='../auth/logout.php'" title="Logout">
      <?=ico($iOut,'#EF4444',15)?>
    </button>
  </div>
</aside>

<div class="desk-wrap">
  <header class="topbar">
    <div class="tb-title">Dashboard</div>
    <div class="tb-date"><?=date('l, F j, Y')?></div>
    <div class="tb-sep"></div>
    <div class="tb-bell" onclick="alert('Notifications')">
      <?=ico($iBell,'#4A5568')?>
      <?php if($pendingBookings>0):?><div class="tb-dot"></div><?php endif;?>
    </div>
  </header>

  <div class="desk-scroll">

    <div class="g4">
      <div class="hero-card">
        <div class="hc-greet"><?=$greeting?></div>
        <div class="hc-name"><?=$userName?></div>
        <div class="hc-elabel">Today's Revenue</div>
        <div class="hc-amount"><span class="hc-peso">₱</span><?=number_format($todayEarnings,2)?></div>
        <div class="hc-stats">
          <div class="hcs"><div class="hcs-v"><?=$todayTrips?></div><div class="hcs-l">Rides Today</div></div>
          <div class="hcs"><div class="hcs-v"><?=number_format($rating,1)?>★</div><div class="hcs-l">Rating</div></div>
          <div class="hcs"><div class="hcs-v"><?=$activeTrips?></div><div class="hcs-l">Active</div></div>
        </div>
      </div>

      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(0,208,132,.12)"><?=ico($iBook,'#00A86B',20)?></div>
          <div class="kpi-trend <?=$bookingChange>=0?'tu':'td'?>"><?=$bookingChange>=0?'↑':'↓'?><?=abs($bookingChange)?>%</div>
        </div>
        <div class="kpi-val"><?=$totalBookings?></div>
        <div class="kpi-lbl">Bookings Today</div>
      </div>

      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(74,158,255,.12)"><?=ico($iPay,'#4A9EFF',20)?></div>
          <div class="kpi-trend tn">30 days</div>
        </div>
        <div class="kpi-val"><span class="peso">₱</span><?=number_format($totalPayments/1000,1)?>K</div>
        <div class="kpi-lbl">Payments Processed</div>
      </div>

      <div class="kpi">
        <div class="kpi-top">
          <div class="kpi-ico" style="background:rgba(155,127,255,.12)"><?=ico($iCrm,'#9B7FFF',20)?></div>
          <div class="kpi-trend tn">Active</div>
        </div>
        <div class="kpi-val"><?=$totalCustomers?></div>
        <div class="kpi-lbl">Customers</div>
      </div>
    </div>

    <div class="g3">

      <div class="panel">
        <div class="panel-h">Quick Actions</div>
        <div class="qa-grid">
          <a href="booking_system.php" class="qa">
            <div class="qa-ico" style="background:linear-gradient(135deg,#10B981,#059669)"><?=ico($iBook,'#fff',17)?></div>
            <div><div class="qa-t">New Booking</div><div class="qa-s"><?=$pendingBookings?> pending</div></div>
          </a>
          <a href="payment_fares.php" class="qa">
            <div class="qa-ico" style="background:linear-gradient(135deg,#60A5FA,#3B82F6)"><?=ico($iPay,'#fff',17)?></div>
            <div><div class="qa-t">Payments</div><div class="qa-s">₱<?=number_format($totalPayments/1000,1)?>K</div></div>
          </a>
          <a href="gps_tracking.php" class="qa">
            <div class="qa-ico" style="background:linear-gradient(135deg,#C084FC,#A855F7)"><?=ico($iGps,'#fff',17)?></div>
            <div><div class="qa-t">GPS Track</div><div class="qa-s"><?=$activeTrips?> active</div></div>
          </a>
          <a href="transport_analytics.php" class="qa">
            <div class="qa-ico" style="background:linear-gradient(135deg,#FB923C,#F97316)"><?=ico($iBar,'#fff',17)?></div>
            <div><div class="qa-t">Analytics</div><div class="qa-s">View reports</div></div>
          </a>
        </div>
        <div class="bstat-row">
          <div class="bstat" style="background:rgba(255,202,74,.12)">
            <div class="bstat-v" style="color:#9A6A00"><?=$pendingBookings?></div>
            <div class="bstat-l" style="color:#9A6A00">Pending</div>
          </div>
          <div class="bstat" style="background:rgba(74,158,255,.12)">
            <div class="bstat-v" style="color:#1460AA"><?=$confirmedBookings?></div>
            <div class="bstat-l" style="color:#1460AA">Confirmed</div>
          </div>
          <div class="bstat" style="background:rgba(0,208,132,.12)">
            <div class="bstat-v" style="color:#00A86B"><?=$completedBookings?></div>
            <div class="bstat-l" style="color:#00A86B">Completed</div>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-h">Recent Bookings <a href="booking_system.php">View all →</a></div>
        <div class="act-list">
          <?php if(!empty($recentBookings)):
            foreach($recentBookings as $i=>$b):
              [$bg,$stroke]=$actColors[$i%count($actColors)];
              $sc=statusClass($b['booking_status']);
          ?>
          <div class="act">
            <div class="act-ico" style="background:<?=$bg?>"><?=ico($iUser,$stroke,15)?></div>
            <div class="act-info">
              <div class="act-name trunc"><?=htmlspecialchars($b['customer_name']??'Guest')?></div>
              <div class="act-meta">
                <?=htmlspecialchars($b['booking_reference'])?>
                <span class="pill <?=$sc?>"><?=htmlspecialchars($b['booking_status'])?></span>
              </div>
            </div>
            <div class="act-amt">₱<?=number_format($b['total_amount']??0,0)?></div>
          </div>
          <?php endforeach;
          else:?>
          <div class="act">
            <div class="act-ico" style="background:rgba(0,0,0,.05)"><?=ico("<circle cx='12' cy='12' r='10'/><line x1='12' y1='8' x2='12' y2='12'/><line x1='12' y1='16' x2='12.01' y2='16'/>","#718096",15)?></div>
            <div class="act-info"><div class="act-name">No recent bookings</div><div class="act-meta">Start booking to see activity</div></div>
          </div>
          <?php endif;?>
        </div>
      </div>

      <div class="panel">
        <div class="panel-h">SOP Compliance</div>
        <?php $circ=round(2*M_PI*46*$complianceRate/100,1);?>
        <div class="ring-wrap">
          <svg width="110" height="110" viewBox="0 0 110 110">
            <circle cx="55" cy="55" r="46" fill="none" stroke="var(--bdr)" stroke-width="10"/>
            <circle cx="55" cy="55" r="46" fill="none" stroke="url(#cg)" stroke-width="10"
              stroke-dasharray="<?=$circ?> 289" stroke-dashoffset="72" stroke-linecap="round"/>
            <defs><linearGradient id="cg" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="#00D084"/><stop offset="100%" stop-color="#007A4E"/></linearGradient></defs>
            <text x="55" y="50" text-anchor="middle" font-family="Inter,sans-serif" font-size="18" font-weight="800" fill="var(--txt)"><?=$complianceRate?>%</text>
            <text x="55" y="64" text-anchor="middle" font-family="Inter,sans-serif" font-size="10" fill="var(--txt3)">Score</text>
          </svg>
          <div class="ring-label">Visitor Compliance</div>
          <div class="ring-sub">Last 30 days</div>
        </div>
        <div class="c-rows">
          <div class="c-row">
            <div class="c-row-l"><div class="c-dot" style="background:var(--yellow)"></div>Total Visitors</div>
            <div class="c-row-v"><?=$sopDocuments?></div>
          </div>
          <div class="c-row">
            <div class="c-row-l"><div class="c-dot" style="background:var(--red)"></div>Checked In</div>
            <div class="c-row-v" style="color:<?=$openIssues>0?'var(--red)':'inherit'?>"><?=$openIssues?></div>
          </div>
          <div class="c-row">
            <div class="c-row-l"><div class="c-dot" style="background:var(--g)"></div>Completed</div>
            <div class="c-row-v"><?=$completedVisits?></div>
          </div>
        </div>
      </div>
    </div>

    <div>
      <div class="mods-title">Core Modules</div>
      <div class="g6">
        <a href="booking_system.php" class="mod">
          <div class="mod-ico" style="background:linear-gradient(135deg,#00D084,#007A4E)"><?=ico($iBook,'#fff',22)?></div>
          <div class="mod-t">Booking System</div><div class="mod-s"><?=$pendingBookings?> pending</div>
        </a>
        <a href="payment_fares.php" class="mod">
          <div class="mod-ico" style="background:linear-gradient(135deg,#60A5FA,#3B82F6)"><?=ico($iPay,'#fff',22)?></div>
          <div class="mod-t">Payment &amp; Fares</div><div class="mod-s">₱<?=number_format($totalPayments/1000,1)?>K</div>
        </a>
        <a href="crm_system.php" class="mod">
          <div class="mod-ico" style="background:linear-gradient(135deg,#10B981,#059669)"><?=ico($iCrm,'#fff',22)?></div>
          <div class="mod-t">CRM</div><div class="mod-s"><?=$totalCustomers?> customers</div>
        </a>
        <a href="gps_tracking.php" class="mod">
          <div class="mod-ico" style="background:linear-gradient(135deg,#C084FC,#A855F7)"><?=ico($iGps,'#fff',22)?></div>
          <div class="mod-t">GPS Tracking</div><div class="mod-s"><?=$activeTrips?> active</div>
        </a>
        <a href="transport_analytics.php" class="mod">
          <div class="mod-ico" style="background:linear-gradient(135deg,#FB923C,#F97316)"><?=ico($iBar,'#fff',22)?></div>
          <div class="mod-t">Analytics &amp; KPIs</div><div class="mod-s">Performance</div>
        </a>
        <a href="sop_compliance.php" class="mod">
          <div class="mod-ico" style="background:linear-gradient(135deg,#F59E0B,#D97706)"><?=ico($iDoc,'#fff',22)?></div>
          <div class="mod-t">SOP Compliance</div><div class="mod-s"><?=$complianceRate?>% rate</div>
        </a>
      </div>
    </div>

  </div>
</div>

<header class="mob-header">
  <img src="../images/envirocab_logo.png" alt="EnviroCab" onerror="this.style.display='none'">
  <div class="mh-r">
    <button class="mh-btn" onclick="alert('Notifications')">
      <?=ico($iBell,'currentColor')?>
      <?php if($pendingBookings>0):?><span class="mh-ndot"></span><?php endif;?>
    </button>
    <button class="mh-btn mh-logout" onclick="if(confirm('Logout?'))window.location.href='../auth/logout.php'">
      <?=ico($iOut,'currentColor')?>
    </button>
  </div>
</header>

<div class="mob-body">
  <div class="m-hero">
    <div class="mh-greet"><?=$greeting?>, <?=$userName?>!</div>
    <div class="mh-title">Today's Revenue</div>
    <div class="mh-amount"><span class="hc-peso">₱</span><?=number_format($todayEarnings,2)?></div>
    <div class="mh-alabel">Paid Bookings</div>
    <div class="mh-stats">
      <div class="mhs"><div class="mhs-v"><?=$todayTrips?></div><div class="mhs-l">Rides</div></div>
      <div class="mhs"><div class="mhs-v"><?=number_format($rating,1)?>★</div><div class="mhs-l">Rating</div></div>
      <div class="mhs"><div class="mhs-v"><?=$activeTrips?></div><div class="mhs-l">Active</div></div>
    </div>
  </div>

  <div class="m-qa">
    <div class="mqa" onclick="window.location.href='booking_system.php'">
      <div class="mqa-ico g"><?=ico($iBook,'#fff',20)?></div><div class="mqa-lbl">Book</div>
    </div>
    <div class="mqa" onclick="window.location.href='payment_fares.php'">
      <div class="mqa-ico b"><?=ico($iPay,'#fff',20)?></div><div class="mqa-lbl">Pay</div>
    </div>
    <div class="mqa" onclick="window.location.href='gps_tracking.php'">
      <div class="mqa-ico p"><?=ico($iGps,'#fff',20)?></div><div class="mqa-lbl">Track</div>
    </div>
    <div class="mqa" onclick="window.location.href='transport_analytics.php'">
      <div class="mqa-ico o"><?=ico($iBar,'#fff',20)?></div><div class="mqa-lbl">Stats</div>
    </div>
  </div>

  <div class="m-stats">
    <div class="mst">
      <div class="mst-top">
        <div class="mst-ico" style="background:rgba(0,208,132,.12)"><?=ico($iBook,'#00A86B',20)?></div>
        <div class="mst-tr <?=$bookingChange>=0?'tu':'td'?>"><?=$bookingChange>=0?'↑':'↓'?><?=abs($bookingChange)?>%</div>
      </div>
      <div class="mst-v"><?=$totalBookings?></div><div class="mst-l">Bookings Today</div>
    </div>
    <div class="mst">
      <div class="mst-top">
        <div class="mst-ico" style="background:rgba(74,158,255,.12)"><?=ico($iPay,'#4A9EFF',20)?></div>
      </div>
      <div class="mst-v"><span class="peso">₱</span><?=number_format($totalPayments/1000,1)?>K</div><div class="mst-l">Payments</div>
    </div>
    <div class="mst">
      <div class="mst-top">
        <div class="mst-ico" style="background:rgba(155,127,255,.12)"><?=ico($iCrm,'#9B7FFF',20)?></div>
      </div>
      <div class="mst-v"><?=$totalCustomers?></div><div class="mst-l">Customers</div>
    </div>
    <div class="mst">
      <div class="mst-top">
        <div class="mst-ico" style="background:rgba(255,138,74,.12)"><?=ico("<path d='M22 11.08V12a10 10 0 1 1-5.93-9.14'/><polyline points='22 4 12 14.01 9 11.01'/>","#FF8A4A",20)?></div>
      </div>
      <div class="mst-v"><?=$completedBookings?></div><div class="mst-l">Completed</div>
    </div>
  </div>

  <div class="m-card">
    <div class="mc-title">Recent Bookings</div>
    <?php if(!empty($recentBookings)):
      foreach(array_slice($recentBookings,0,3) as $i=>$b):
        [$bg,$stroke]=$actColors[$i%3];
        $sc=statusClass($b['booking_status']);
    ?>
    <div class="ma">
      <div class="ma-ico" style="background:<?=$bg?>"><?=ico($iUser,$stroke,17)?></div>
      <div class="ma-info">
        <div class="ma-name"><?=htmlspecialchars($b['customer_name']??'Guest')?></div>
        <div class="ma-sub"><?=htmlspecialchars($b['booking_reference'])?> · <span class="pill <?=$sc?>"><?=htmlspecialchars($b['booking_status'])?></span></div>
      </div>
      <div class="ma-amt">₱<?=number_format($b['total_amount']??0,0)?></div>
    </div>
    <?php endforeach;
    else:?>
    <div class="ma">
      <div class="ma-ico" style="background:rgba(0,0,0,.05)"><?=ico("<circle cx='12' cy='12' r='10'/><line x1='12' y1='8' x2='12' y2='12'/><line x1='12' y1='16' x2='12.01' y2='16'/>","#718096",17)?></div>
      <div class="ma-info"><div class="ma-name">No recent bookings</div><div class="ma-sub">Start booking to see activity</div></div>
    </div>
    <?php endif;?>
  </div>

  <div class="m-card">
    <div class="mc-title">Core Modules</div>
    <a href="booking_system.php" class="mmod">
      <div class="mmod-ico" style="background:linear-gradient(135deg,#00D084,#007A4E)"><?=ico($iBook,'#fff',22)?></div>
      <div><div class="mmod-t">Booking System</div><div class="mmod-s"><?=$pendingBookings?> pending · <?=$confirmedBookings?> confirmed</div></div>
      <div class="mmod-arr">›</div>
    </a>
    <a href="payment_fares.php" class="mmod">
      <div class="mmod-ico" style="background:linear-gradient(135deg,#60A5FA,#3B82F6)"><?=ico($iPay,'#fff',22)?></div>
      <div><div class="mmod-t">Payment &amp; Fare Collection</div><div class="mmod-s">₱<?=number_format($totalPayments/1000,1)?>K processed</div></div>
      <div class="mmod-arr">›</div>
    </a>
    <a href="crm_system.php" class="mmod">
      <div class="mmod-ico" style="background:linear-gradient(135deg,#10B981,#059669)"><?=ico($iCrm,'#fff',22)?></div>
      <div><div class="mmod-t">Customer Relationship</div><div class="mmod-s"><?=$totalCustomers?> active customers</div></div>
      <div class="mmod-arr">›</div>
    </a>
    <a href="gps_tracking.php" class="mmod">
      <div class="mmod-ico" style="background:linear-gradient(135deg,#C084FC,#A855F7)"><?=ico($iGps,'#fff',22)?></div>
      <div><div class="mmod-t">GPS Tracking &amp; Playback</div><div class="mmod-s"><?=$activeTrips?> active rides</div></div>
      <div class="mmod-arr">›</div>
    </a>
    <a href="transport_analytics.php" class="mmod">
      <div class="mmod-ico" style="background:linear-gradient(135deg,#FB923C,#F97316)"><?=ico($iBar,'#fff',22)?></div>
      <div><div class="mmod-t">Analytics &amp; KPI Dashboard</div><div class="mmod-s">View insights &amp; performance</div></div>
      <div class="mmod-arr">›</div>
    </a>
    <a href="sop_compliance.php" class="mmod">
      <div class="mmod-ico" style="background:linear-gradient(135deg,#F59E0B,#D97706)"><?=ico($iDoc,'#fff',22)?></div>
      <div><div class="mmod-t">SOP Compliance &amp; Audit</div><div class="mmod-s"><?=$complianceRate?>% compliance rate</div></div>
      <div class="mmod-arr">›</div>
    </a>
  </div>
</div>

<nav class="mob-nav">
  <button class="mn active">
    <div class="mn-ico"><?=ico($iHome,'currentColor',22)?></div>
    <span class="mn-lbl">Home</span>
  </button>
  <button class="mn" onclick="window.location.href='booking_system.php'">
    <div class="mn-ico"><?=ico($iTruck,'currentColor',22)?></div>
    <span class="mn-lbl">Book</span>
  </button>
  <button class="mn" onclick="window.location.href='gps_tracking.php'">
    <div class="mn-ico"><?=ico($iGps,'currentColor',22)?></div>
    <span class="mn-lbl">Track</span>
  </button>
  <button class="mn" onclick="window.location.href='profile.php'">
    <div class="mn-ico"><?=ico($iUser,'currentColor',22)?></div>
    <span class="mn-lbl">Profile</span>
  </button>
</nav>

<?php include __DIR__ . '/chat_widget.php'; ?>
</body>
</html>