<?php
/**
 * my_bookings.php  —  Open booking marketplace
 * All drivers see every unclaimed Pending booking and self-select.
 * No core_booking_resources pre-assignment used.
 * Place in: C:\xampp\htdocs\CORETRANSACTION2\driver\
 */
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
if (strtolower($_SESSION['role']) !== 'driver') {
    header('Location: ../auth/login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDatabaseConnection();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$driver_id = (int) $_SESSION['user_id'];

// =============================================================================
// POST — Accept / Decline / Complete
// =============================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['booking_id'])) {
    $booking_id = (int) $_POST['booking_id'];
    $action     = $_POST['action'];
    $flash      = null;

    try {
        $pdo->beginTransaction();

        // Re-verify state before writing (race-condition guard)
        $chk = $pdo->prepare("
            SELECT b.booking_status, r.driver_id AS ride_driver
            FROM   core_bookings b
            LEFT JOIN core_rides r ON r.booking_id = b.booking_id
            WHERE  b.booking_id = ?
            LIMIT  1
        ");
        $chk->execute([$booking_id]);
        $row = $chk->fetch(PDO::FETCH_ASSOC);

        if ($action === 'accept') {
            if (!$row || $row['booking_status'] !== 'Pending') {
                throw new Exception('This booking is no longer available.');
            }
            if (!is_null($row['ride_driver']) && (int) $row['ride_driver'] !== 0) {
                throw new Exception('Another driver already claimed this booking.');
            }

            $pdo->prepare("
                UPDATE core_bookings
                SET booking_status = 'Confirmed', confirmed_by = ?, confirmed_at = NOW(), updated_at = NOW()
                WHERE booking_id = ?
            ")->execute([$driver_id, $booking_id]);

            $pdo->prepare("
                UPDATE core_rides SET driver_id = ?, ride_status = 'Accepted'
                WHERE booking_id = ?
            ")->execute([$driver_id, $booking_id]);

            $pdo->prepare("
                INSERT INTO core_booking_history
                    (booking_id, change_type, field_changed, old_value, new_value, changed_by, notes)
                VALUES (?, 'Status Change', 'booking_status', 'Pending', 'Confirmed', ?, 'Accepted by driver from marketplace')
            ")->execute([$booking_id, $driver_id]);

            $flash = ['type' => 'success', 'msg' => 'Booking accepted! Head to the pickup location.'];

        } elseif ($action === 'decline') {
            if (!$row) throw new Exception('Booking not found.');
            if (!in_array($row['booking_status'], ['Pending', 'Confirmed'])) {
                throw new Exception('Cannot cancel a ' . $row['booking_status'] . ' booking.');
            }
            // Only let a driver cancel Confirmed if it's theirs
            if ($row['booking_status'] === 'Confirmed' && (int) $row['ride_driver'] !== $driver_id) {
                throw new Exception('You can only cancel your own bookings.');
            }

            $old = $row['booking_status'];

            $pdo->prepare("
                UPDATE core_bookings
                SET booking_status = 'Cancelled', cancelled_by = ?, cancelled_at = NOW(),
                    cancellation_reason = 'Declined by driver', updated_at = NOW()
                WHERE booking_id = ?
            ")->execute([$driver_id, $booking_id]);

            $pdo->prepare("
                UPDATE core_rides SET ride_status = 'Cancelled' WHERE booking_id = ?
            ")->execute([$booking_id]);

            $pdo->prepare("
                INSERT INTO core_booking_history
                    (booking_id, change_type, field_changed, old_value, new_value, changed_by, notes)
                VALUES (?, 'Status Change', 'booking_status', ?, 'Cancelled', ?, 'Declined by driver')
            ")->execute([$booking_id, $old, $driver_id]);

            $flash = ['type' => 'success', 'msg' => 'Booking declined.'];

        } elseif ($action === 'complete') {
            if (!$row || $row['booking_status'] !== 'Confirmed') {
                throw new Exception('Only a Confirmed booking can be completed.');
            }
            if ((int) $row['ride_driver'] !== $driver_id) {
                throw new Exception('You can only complete your own rides.');
            }

            $pdo->prepare("
                UPDATE core_bookings SET booking_status = 'Completed', updated_at = NOW()
                WHERE booking_id = ?
            ")->execute([$booking_id]);

            $pdo->prepare("
                UPDATE core_rides SET ride_status = 'Completed', end_time = NOW()
                WHERE booking_id = ? AND driver_id = ?
            ")->execute([$booking_id, $driver_id]);

            $pdo->prepare("
                INSERT INTO core_booking_history
                    (booking_id, change_type, field_changed, old_value, new_value, changed_by, notes)
                VALUES (?, 'Status Change', 'booking_status', 'Confirmed', 'Completed', ?, 'Trip completed by driver')
            ")->execute([$booking_id, $driver_id]);

            $flash = ['type' => 'success', 'msg' => 'Trip marked as completed!'];
        }

        $pdo->commit();

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $flash = ['type' => 'error', 'msg' => $e->getMessage()];
        error_log("my_bookings POST error: " . $e->getMessage());
    }

    $_SESSION['flash'] = $flash;
    header('Location: my_bookings.php' . ($flash['type'] === 'success' ? '?filter=mine' : ''));
    exit;
}

// =============================================================================
// FILTER
// =============================================================================
$filter         = $_GET['filter'] ?? 'available';
$allowed        = ['available', 'mine', 'completed', 'cancelled'];
if (!in_array($filter, $allowed)) $filter = 'available';

// =============================================================================
// COUNTS (all use marketplace logic — no core_booking_resources)
// =============================================================================
$counts = ['available' => 0, 'mine' => 0, 'completed' => 0, 'cancelled' => 0];

try {
    // Available: Pending + no driver on ride yet
    $s = $pdo->query("
        SELECT COUNT(*) FROM core_bookings b
        LEFT JOIN core_rides r ON r.booking_id = b.booking_id
        WHERE b.booking_status = 'Pending'
          AND (r.driver_id IS NULL OR r.driver_id = 0)
    ");
    $counts['available'] = (int) $s->fetchColumn();

    // Mine: this driver's Confirmed or In Progress
    $s = $pdo->prepare("
        SELECT COUNT(*) FROM core_rides r
        JOIN core_bookings b ON b.booking_id = r.booking_id
        WHERE r.driver_id = ? AND b.booking_status IN ('Confirmed','In Progress')
    ");
    $s->execute([$driver_id]);
    $counts['mine'] = (int) $s->fetchColumn();

    // Completed by this driver
    $s = $pdo->prepare("
        SELECT COUNT(*) FROM core_rides r
        JOIN core_bookings b ON b.booking_id = r.booking_id
        WHERE r.driver_id = ? AND b.booking_status = 'Completed'
    ");
    $s->execute([$driver_id]);
    $counts['completed'] = (int) $s->fetchColumn();

    // Declined by this driver
    $s = $pdo->prepare("
        SELECT COUNT(*) FROM core_bookings
        WHERE cancelled_by = ? AND booking_status = 'Cancelled'
    ");
    $s->execute([$driver_id]);
    $counts['cancelled'] = (int) $s->fetchColumn();

} catch (PDOException $e) {
    error_log("my_bookings counts: " . $e->getMessage());
}

// =============================================================================
// FETCH BOOKINGS
// =============================================================================
$bookings = [];

try {
    if ($filter === 'available') {
        // Open pool — every driver sees these
        $stmt = $pdo->query("
            SELECT
                b.booking_id, b.booking_reference, b.booking_status,
                b.booking_date, b.booking_time, b.total_amount, b.payment_status,
                b.special_requirements, b.created_at,
                c.name         AS customer_name,
                c.phone        AS customer_phone,
                s.service_name, s.service_category,
                r.start_location, r.end_location,
                COALESCE(fc.total_fare, b.total_amount, 0) AS fare,
                fc.distance_km, fc.distance_rate
            FROM core_bookings b
            LEFT JOIN core_rides r             ON r.booking_id  = b.booking_id
            LEFT JOIN core_customers c         ON c.customer_id = b.customer_id
            LEFT JOIN core_services s          ON s.service_id  = b.service_id
            LEFT JOIN core_fare_computation fc ON fc.booking_id = b.booking_id
            WHERE b.booking_status = 'Pending'
              AND (r.driver_id IS NULL OR r.driver_id = 0)
            ORDER BY b.created_at ASC
        ");
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } elseif ($filter === 'mine') {
        $stmt = $pdo->prepare("
            SELECT
                b.booking_id, b.booking_reference, b.booking_status,
                b.booking_date, b.booking_time, b.total_amount, b.payment_status,
                b.special_requirements, b.created_at,
                c.name         AS customer_name,
                c.phone        AS customer_phone,
                s.service_name, s.service_category,
                r.start_location, r.end_location,
                COALESCE(fc.total_fare, b.total_amount, 0) AS fare,
                fc.distance_km, fc.distance_rate
            FROM core_rides r
            JOIN core_bookings b                ON b.booking_id  = r.booking_id
            LEFT JOIN core_customers c          ON c.customer_id = b.customer_id
            LEFT JOIN core_services s           ON s.service_id  = b.service_id
            LEFT JOIN core_fare_computation fc  ON fc.booking_id = b.booking_id
            WHERE r.driver_id = :did
              AND b.booking_status IN ('Confirmed','In Progress')
            ORDER BY b.booking_date ASC, b.booking_time ASC
        ");
        $stmt->execute([':did' => $driver_id]);
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } elseif ($filter === 'completed') {
        $stmt = $pdo->prepare("
            SELECT
                b.booking_id, b.booking_reference, b.booking_status,
                b.booking_date, b.booking_time, b.total_amount, b.payment_status,
                b.special_requirements, b.created_at,
                c.name         AS customer_name,
                c.phone        AS customer_phone,
                s.service_name, s.service_category,
                r.start_location, r.end_location,
                COALESCE(fc.total_fare, b.total_amount, 0) AS fare,
                fc.distance_km, fc.distance_rate
            FROM core_rides r
            JOIN core_bookings b                ON b.booking_id  = r.booking_id
            LEFT JOIN core_customers c          ON c.customer_id = b.customer_id
            LEFT JOIN core_services s           ON s.service_id  = b.service_id
            LEFT JOIN core_fare_computation fc  ON fc.booking_id = b.booking_id
            WHERE r.driver_id = :did AND b.booking_status = 'Completed'
            ORDER BY b.created_at DESC
        ");
        $stmt->execute([':did' => $driver_id]);
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } elseif ($filter === 'cancelled') {
        $stmt = $pdo->prepare("
            SELECT
                b.booking_id, b.booking_reference, b.booking_status,
                b.booking_date, b.booking_time, b.total_amount, b.payment_status,
                b.special_requirements, b.created_at,
                c.name         AS customer_name,
                c.phone        AS customer_phone,
                s.service_name, s.service_category,
                r.start_location, r.end_location,
                COALESCE(fc.total_fare, b.total_amount, 0) AS fare,
                fc.distance_km, fc.distance_rate
            FROM core_bookings b
            LEFT JOIN core_rides r             ON r.booking_id  = b.booking_id
            LEFT JOIN core_customers c         ON c.customer_id = b.customer_id
            LEFT JOIN core_services s          ON s.service_id  = b.service_id
            LEFT JOIN core_fare_computation fc ON fc.booking_id = b.booking_id
            WHERE b.cancelled_by = :did AND b.booking_status = 'Cancelled'
            ORDER BY b.created_at DESC
        ");
        $stmt->execute([':did' => $driver_id]);
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (PDOException $e) {
    error_log("my_bookings fetch: " . $e->getMessage());
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>Bookings – EnviroCab Driver</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }

        :root {
            --primary-green: #00D084;
            --dark-green:    #00A86B;
            --bg-gradient:   linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --white:         #FFFFFF;
            --text-dark:     #1A202C;
            --text-medium:   #4A5568;
            --text-light:    #718096;
            --border:        #E2E8F0;
            --accent-blue:   #60A5FA;
            --accent-purple: #C084FC;
            --accent-yellow: #FBBF24;
            --accent-orange: #FB923C;
            --error-red:     #EF4444;
            --success-green: #10B981;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 90px;
            -webkit-font-smoothing: antialiased;
        }

        @media (min-width: 768px) {
            body { max-width: 480px; margin: 0 auto; box-shadow: 0 0 40px rgba(0,0,0,0.1); }
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(12px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulseRing {
            0%   { box-shadow: 0 0 0 0   rgba(245,158,11,0.4); }
            70%  { box-shadow: 0 0 0 8px rgba(245,158,11,0); }
            100% { box-shadow: 0 0 0 0   rgba(245,158,11,0); }
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50%       { opacity: 0.25; }
        }

        /* ── Header (matches dashboard exactly) ── */
        .header {
            background: rgba(255,255,255,0.8);
            backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky; top: 0; z-index: 100;
            border-bottom: 1px solid rgba(255,255,255,0.5);
        }
        .header-content  { display: flex; justify-content: space-between; align-items: center; }
        .header-left     { display: flex; align-items: center; gap: 12px; }
        .back-btn {
            width: 36px; height: 36px; border-radius: 12px;
            background: rgba(255,255,255,0.9); border: 1px solid rgba(0,0,0,0.05);
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: all 0.2s;
        }
        .back-btn:active { transform: scale(0.95); }
        .back-btn svg { stroke: var(--text-medium); }
        .header-title { font-size: 18px; font-weight: 700; color: var(--text-dark); }

        .icon-btn {
            width: 36px; height: 36px; border-radius: 12px;
            background: rgba(255,255,255,0.9); border: 1px solid rgba(0,0,0,0.05);
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: all 0.2s;
        }
        .icon-btn:active { transform: scale(0.95); }
        .logout-btn { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); }

        /* ── Main ── */
        .main-content { padding: 20px; }

        /* ── Hero Card (mirrors dashboard hero-card exactly) ── */
        .hero-card {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
            border-radius: 24px; padding: 28px 24px; color: white;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0,208,132,0.2);
            position: relative; overflow: hidden;
            animation: slideUp 0.4s ease forwards;
        }
        .hero-card::before {
            content: ''; position: absolute; top: -50%; right: -20%;
            width: 200px; height: 200px;
            background: rgba(255,255,255,0.1); border-radius: 50%;
        }
        .hero-greeting  { font-size: 14px; opacity: 0.9; margin-bottom: 4px; position: relative; }
        .hero-title     { font-size: 28px; font-weight: 800; margin-bottom: 8px; position: relative; }
        .hero-label     { font-size: 13px; opacity: 0.85; position: relative; }
        .hero-stats     { display: flex; gap: 16px; margin-top: 24px; position: relative; }
        .hero-stat {
            flex: 1; background: rgba(255,255,255,0.15); backdrop-filter: blur(10px);
            padding: 12px; border-radius: 16px; text-align: center;
        }
        .hero-stat-value { font-size: 20px; font-weight: 700; margin-bottom: 4px; }
        .hero-stat-label { font-size: 11px; opacity: 0.85; }

        /* ── Flash Alert ── */
        .alert {
            padding: 14px 16px; border-radius: 14px; margin-bottom: 16px;
            font-size: 14px; font-weight: 500;
            display: flex; align-items: center; gap: 10px;
            animation: slideUp 0.3s ease forwards;
        }
        .alert svg { flex-shrink: 0; }
        .alert-success { background: rgba(16,185,129,0.1); color: var(--success-green); border: 1px solid rgba(16,185,129,0.2); }
        .alert-error   { background: rgba(239,68,68,0.1);  color: var(--error-red);     border: 1px solid rgba(239,68,68,0.2); }

        /* ── Filter Tabs (mirrors dashboard style) ── */
        .filter-scroll {
            display: flex; gap: 8px; overflow-x: auto;
            padding-bottom: 4px; margin-bottom: 16px; scrollbar-width: none;
        }
        .filter-scroll::-webkit-scrollbar { display: none; }

        .filter-tab {
            flex-shrink: 0; padding: 8px 16px; border-radius: 20px;
            font-size: 13px; font-weight: 600; cursor: pointer;
            border: 2px solid var(--border); background: white;
            color: var(--text-light); transition: all 0.2s;
            font-family: 'Inter', sans-serif;
            display: flex; align-items: center; gap: 6px;
            text-decoration: none; white-space: nowrap;
        }
        .filter-tab.active {
            background: var(--primary-green);
            border-color: var(--primary-green); color: white;
        }
        .count-badge {
            padding: 2px 7px; border-radius: 10px;
            font-size: 11px; font-weight: 700;
            background: rgba(0,0,0,0.06); color: var(--text-medium);
        }
        .filter-tab.active .count-badge { background: rgba(255,255,255,0.25); color: white; }

        /* Available tab pulse dot */
        .pulse-dot {
            width: 8px; height: 8px; border-radius: 50%;
            background: #F59E0B; flex-shrink: 0;
            animation: blink 1.2s infinite;
        }
        .filter-tab.active .pulse-dot { background: white; }

        /* ── Booking Card (mirrors dashboard booking-card layout) ── */
        .booking-card {
            background: white; border-radius: 20px;
            padding: 0; border: 1px solid var(--border);
            margin-bottom: 12px; overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            animation: slideUp 0.35s ease forwards;
        }
        .booking-card:last-child { margin-bottom: 0; }

        /* coloured top strip */
        .card-strip       { height: 4px; }
        .strip-pending    { background: #F59E0B; }
        .strip-confirmed  { background: var(--primary-green); }
        .strip-completed  { background: var(--accent-blue); }
        .strip-cancelled  { background: var(--error-red); }

        .card-inner { padding: 16px; }

        /* Head row */
        .booking-header {
            display: flex; align-items: center;
            justify-content: space-between; margin-bottom: 14px; gap: 8px;
        }
        .booking-ref   { font-size: 13px; font-weight: 700; color: var(--text-medium); font-family: monospace; }
        .booking-time  { font-size: 11px; color: var(--text-light); margin-top: 3px; }
        .status-pill {
            font-size: 11px; font-weight: 700; padding: 5px 12px; border-radius: 20px;
            white-space: nowrap; flex-shrink: 0;
        }
        .status-pending   { background: rgba(251,191,36,0.15); color: #D97706; }
        .status-confirmed { background: rgba(16,185,129,0.15); color: #10B981; }
        .status-in-progress{background: rgba(96,165,250,0.15); color: #3B82F6; }
        .status-completed { background: rgba(96,165,250,0.15); color: #3B82F6; }
        .status-cancelled { background: rgba(239,68,68,0.15);  color: #EF4444; }

        /* Customer row */
        .customer-row {
            display: flex; align-items: center; gap: 12px; margin-bottom: 14px;
        }
        .customer-avatar {
            width: 44px; height: 44px; border-radius: 14px; flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 18px; font-weight: 700;
        }
        .customer-info { flex: 1; }
        .customer-name  { font-size: 15px; font-weight: 700; color: var(--text-dark); margin-bottom: 2px; }
        .customer-phone { font-size: 12px; color: var(--text-light); }
        .fare-amount    { font-size: 20px; font-weight: 800; color: var(--primary-green); }

        /* Route block */
        .route-block {
            background: rgba(0,0,0,0.025); border-radius: 13px;
            padding: 11px 12px; margin-bottom: 14px;
            display: flex; align-items: stretch; gap: 10px;
        }
        .route-spine {
            display: flex; flex-direction: column; align-items: center; padding-top: 3px;
        }
        .dot-green {
            width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0;
            background: var(--primary-green); box-shadow: 0 0 0 3px rgba(0,208,132,0.18);
        }
        .dot-red {
            width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0;
            background: var(--error-red); box-shadow: 0 0 0 3px rgba(239,68,68,0.15);
        }
        .spine-line { width: 2px; flex: 1; background: var(--border); min-height: 18px; }
        .route-labels { flex: 1; display: flex; flex-direction: column; gap: 10px; }
        .route-lbl-head {
            font-size: 10px; font-weight: 700; color: var(--text-light);
            text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 2px;
        }
        .route-lbl-val { font-size: 12px; font-weight: 600; color: var(--text-dark); line-height: 1.35; }

        /* Details Grid (mirrors dashboard detail-item) */
        .details-grid {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 10px; margin-bottom: 14px;
        }
        .detail-item { background: rgba(0,0,0,0.02); border-radius: 12px; padding: 10px 12px; }
        .detail-label { font-size: 11px; color: var(--text-light); font-weight: 600; margin-bottom: 3px; text-transform: uppercase; letter-spacing: 0.4px; }
        .detail-value { font-size: 13px; font-weight: 700; color: var(--text-dark); }

        /* Special Req */
        .special-req {
            background: rgba(251,191,36,0.08); border: 1px solid rgba(251,191,36,0.2);
            border-radius: 12px; padding: 10px 12px; margin-bottom: 14px;
            font-size: 13px; color: #92400E; display: flex; gap: 8px; align-items: flex-start;
        }

        /* Payment */
        .payment-row {
            display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px;
        }
        .payment-badge { font-size: 12px; font-weight: 700; padding: 4px 12px; border-radius: 20px; }
        .pay-unpaid  { background: rgba(239,68,68,0.1);   color: #EF4444; }
        .pay-partial { background: rgba(251,191,36,0.1);  color: #D97706; }
        .pay-paid    { background: rgba(16,185,129,0.1);  color: #10B981; }
        .pay-refunded{ background: rgba(113,128,150,0.1); color: #718096; }
        .booking-date-info { font-size: 12px; color: var(--text-light); }

        /* Action Buttons (mirrors dashboard btn-accept / btn-decline exactly) */
        .action-row { display: flex; gap: 8px; }

        .btn-accept {
            flex: 1; padding: 12px;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            color: white; border: none; border-radius: 12px;
            font-size: 13px; font-weight: 700; cursor: pointer;
            font-family: 'Inter', sans-serif; transition: all 0.2s;
            display: flex; align-items: center; justify-content: center; gap: 6px;
        }
        .btn-complete {
            flex: 2; padding: 12px;
            background: linear-gradient(135deg, var(--accent-blue), #3B82F6);
            color: white; border: none; border-radius: 12px;
            font-size: 13px; font-weight: 700; cursor: pointer;
            font-family: 'Inter', sans-serif; transition: all 0.2s;
            display: flex; align-items: center; justify-content: center; gap: 6px;
        }
        .btn-decline {
            flex: 1; padding: 12px;
            background: rgba(239,68,68,0.08); color: #EF4444;
            border: 1px solid rgba(239,68,68,0.2); border-radius: 12px;
            font-size: 13px; font-weight: 700; cursor: pointer;
            font-family: 'Inter', sans-serif; transition: all 0.2s;
            display: flex; align-items: center; justify-content: center; gap: 6px;
        }
        .btn-accept:active, .btn-complete:active, .btn-decline:active { transform: scale(0.97); }

        /* Empty State */
        .empty-state {
            text-align: center; padding: 48px 24px; background: white;
            border-radius: 20px; border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        .empty-icon {
            width: 72px; height: 72px; border-radius: 20px;
            background: rgba(0,0,0,0.04);
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 16px;
        }
        .empty-title    { font-size: 16px; font-weight: 700; color: var(--text-dark); margin-bottom: 6px; }
        .empty-subtitle { font-size: 13px; color: var(--text-light); line-height: 1.6; }

        /* ── Bottom Nav (identical to dashboard) ── */
        .bottom-nav {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: rgba(255,255,255,0.95); backdrop-filter: blur(20px);
            border-top: 1px solid rgba(0,0,0,0.05);
            padding: 12px 0 20px;
            display: grid; grid-template-columns: repeat(4,1fr);
            z-index: 99; box-shadow: 0 -4px 24px rgba(0,0,0,0.05);
        }
        .nav-item {
            display: flex; flex-direction: column; align-items: center;
            gap: 4px; padding: 8px; cursor: pointer; border: none;
            background: none; transition: all 0.2s;
        }
        .nav-item:active { transform: scale(0.95); }
        .nav-icon { width: 48px; height: 32px; display: flex; align-items: center; justify-content: center; }
        .nav-icon svg { stroke: var(--text-light); opacity: 0.5; transition: all 0.2s; }
        .nav-item.active .nav-icon svg { stroke: var(--primary-green); opacity: 1; }
        .nav-label { font-size: 11px; font-weight: 600; color: var(--text-light); opacity: 0.7; }
        .nav-item.active .nav-label { color: var(--primary-green); opacity: 1; }
    </style>
</head>
<body>

<!-- Header -->
<div class="header">
    <div class="header-content">
        <div class="header-left">
            <button class="back-btn" onclick="window.location.href='dashboard.php'">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>
            <span class="header-title">Booking Marketplace</span>
        </div>
        <button class="icon-btn logout-btn" onclick="if(confirm('Are you sure you want to logout?')) window.location.href='../auth/logout.php'">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                <polyline points="16 17 21 12 16 7"></polyline>
                <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
        </button>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">

    <!-- Hero Card -->
    <div class="hero-card">
        <div class="hero-greeting">Hello, <?= htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']) ?>!</div>
        <div class="hero-title">Booking Marketplace</div>
        <div class="hero-label">Accept a ride — first come, first served</div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $counts['available'] ?></div>
                <div class="hero-stat-label">Available</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $counts['mine'] ?></div>
                <div class="hero-stat-label">My Active</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $counts['completed'] ?></div>
                <div class="hero-stat-label">Completed</div>
            </div>
        </div>
    </div>

    <!-- Flash -->
    <?php if (!empty($flash)): ?>
    <div class="alert alert-<?= $flash['type'] ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <?php if ($flash['type'] === 'success'): ?>
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
            <?php else: ?>
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
            <?php endif; ?>
        </svg>
        <?= htmlspecialchars($flash['msg']) ?>
    </div>
    <?php endif; ?>

    <!-- Filter Tabs -->
    <div class="filter-scroll">
        <?php
        $tabs = [
            'available' => 'Available Rides',
            'mine'      => 'My Active Rides',
            'completed' => 'Completed',
            'cancelled' => 'Declined',
        ];
        foreach ($tabs as $key => $label):
        ?>
        <a href="?filter=<?= $key ?>" class="filter-tab <?= $filter === $key ? 'active' : '' ?>" style="text-decoration:none;">
            <?php if ($key === 'available' && $counts['available'] > 0): ?>
                <span class="pulse-dot"></span>
            <?php endif; ?>
            <?= $label ?>
            <span class="count-badge"><?= $counts[$key] ?></span>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- Booking Cards -->
    <?php if (!empty($bookings)): ?>
        <?php foreach ($bookings as $idx => $b):
            $status   = $b['booking_status'];
            $stripCls = 'strip-' . strtolower(str_replace(' ', '-', $status));
            $pillCls  = 'status-' . strtolower(str_replace(' ', '-', $status));
            $initial  = strtoupper(substr($b['customer_name'] ?? 'P', 0, 1));
            $payKey   = 'pay-' . strtolower($b['payment_status'] ?? 'unpaid');
            $delay    = min($idx * 0.04, 0.30);
        ?>
        <div class="booking-card" style="animation-delay:<?= $delay ?>s;">
            <div class="card-strip <?= $stripCls ?>"></div>
            <div class="card-inner">

                <!-- Header -->
                <div class="booking-header">
                    <div>
                        <div class="booking-ref"># <?= htmlspecialchars($b['booking_reference']) ?></div>
                        <div class="booking-time">
                            <?= date('M d, Y', strtotime($b['booking_date'])) ?>
                            <?= $b['booking_time'] ? ' · ' . date('g:i A', strtotime($b['booking_time'])) : '' ?>
                        </div>
                    </div>
                    <span class="status-pill <?= $pillCls ?>"><?= htmlspecialchars($status) ?></span>
                </div>

                <!-- Customer + Fare -->
                <div class="customer-row">
                    <div class="customer-avatar"><?= $initial ?></div>
                    <div class="customer-info">
                        <div class="customer-name"><?= htmlspecialchars($b['customer_name'] ?? 'Passenger') ?></div>
                        <div class="customer-phone">
                            <?php if ($filter === 'available'): ?>
                                Accept to see contact info
                            <?php else: ?>
                                <?= htmlspecialchars($b['customer_phone'] ?? '—') ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="fare-amount">&#8369;<?= number_format((float)$b['fare'], 0) ?></div>
                </div>

                <!-- Route -->
                <?php if ($b['start_location'] || $b['end_location']): ?>
                <div class="route-block">
                    <div class="route-spine">
                        <div class="dot-green"></div>
                        <div class="spine-line"></div>
                        <div class="dot-red"></div>
                    </div>
                    <div class="route-labels">
                        <div>
                            <div class="route-lbl-head">Pickup</div>
                            <div class="route-lbl-val"><?= htmlspecialchars($b['start_location'] ?? '—') ?></div>
                        </div>
                        <div>
                            <div class="route-lbl-head">Destination</div>
                            <div class="route-lbl-val"><?= htmlspecialchars($b['end_location'] ?? '—') ?></div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Details Grid -->
                <div class="details-grid">
                    <div class="detail-item">
                        <div class="detail-label">Service</div>
                        <div class="detail-value"><?= htmlspecialchars($b['service_name'] ?? '—') ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Date</div>
                        <div class="detail-value"><?= date('M d, Y', strtotime($b['booking_date'])) ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Time</div>
                        <div class="detail-value"><?= $b['booking_time'] ? date('g:i A', strtotime($b['booking_time'])) : '—' ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Distance</div>
                        <div class="detail-value"><?= $b['distance_km'] ? number_format($b['distance_km'], 1) . ' km' : '—' ?></div>
                    </div>
                </div>

                <!-- Special Requirements -->
                <?php if (!empty($b['special_requirements'])): ?>
                <div class="special-req">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;margin-top:1px;">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <?= htmlspecialchars($b['special_requirements']) ?>
                </div>
                <?php endif; ?>

                <!-- Payment + Booked Date -->
                <div class="payment-row">
                    <span class="payment-badge <?= $payKey ?>"><?= htmlspecialchars($b['payment_status'] ?? 'Unpaid') ?></span>
                    <span class="booking-date-info">Booked <?= date('M d, g:i A', strtotime($b['created_at'])) ?></span>
                </div>

                <!-- Action Buttons -->
                <?php if ($status === 'Pending'): ?>
                <div class="action-row">
                    <form method="POST" style="flex:1;display:flex;">
                        <input type="hidden" name="booking_id" value="<?= $b['booking_id'] ?>">
                        <input type="hidden" name="action"     value="accept">
                        <button type="submit" class="btn-accept" onclick="return confirm('Accept this booking and head to pickup?')">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                            Accept Ride
                        </button>
                    </form>
                    <form method="POST" style="flex:1;display:flex;">
                        <input type="hidden" name="booking_id" value="<?= $b['booking_id'] ?>">
                        <input type="hidden" name="action"     value="decline">
                        <button type="submit" class="btn-decline" onclick="return confirm('Skip this booking?')">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                            Skip
                        </button>
                    </form>
                </div>

                <?php elseif ($status === 'Confirmed'): ?>
                <div class="action-row">
                    <form method="POST" style="flex:2;display:flex;">
                        <input type="hidden" name="booking_id" value="<?= $b['booking_id'] ?>">
                        <input type="hidden" name="action"     value="complete">
                        <button type="submit" class="btn-complete" onclick="return confirm('Mark this trip as completed?')">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                            Mark as Completed
                        </button>
                    </form>
                </div>
                <?php endif; ?>

            </div><!-- /.card-inner -->
        </div>
        <?php endforeach; ?>

    <?php else: ?>
        <div class="empty-state">
            <div class="empty-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#CBD5E0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
            </div>
            <?php if ($filter === 'available'): ?>
                <div class="empty-title">No rides available right now</div>
                <div class="empty-subtitle">New passenger bookings will appear here.<br>This page refreshes automatically.</div>
            <?php elseif ($filter === 'mine'): ?>
                <div class="empty-title">No active rides</div>
                <div class="empty-subtitle">Accept a booking from Available Rides to start a trip.</div>
            <?php elseif ($filter === 'completed'): ?>
                <div class="empty-title">No completed trips yet</div>
                <div class="empty-subtitle">Trips you complete will appear here.</div>
            <?php else: ?>
                <div class="empty-title">No declined bookings</div>
                <div class="empty-subtitle">Bookings you declined will show up here.</div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</div>

<!-- Bottom Nav -->
<nav class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
        </div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item active">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
        </div>
        <span class="nav-label">Bookings</span>
    </button>
    <button class="nav-item" onclick="window.location.href='my_trips.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
            </svg>
        </div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item" onclick="window.location.href='driver_profile.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
        </div>
        <span class="nav-label">Profile</span>
    </button>
</nav>

<script>
// Auto-refresh the available tab every 12 seconds so new bookings appear
<?php if ($filter === 'available'): ?>
let _refreshTimer = setInterval(() => location.reload(), 12000);
// Reset timer whenever the user interacts so we don't interrupt a tap
document.addEventListener('touchstart', () => { clearInterval(_refreshTimer); _refreshTimer = setInterval(() => location.reload(), 12000); });
<?php endif; ?>
</script>

</body>
</html>