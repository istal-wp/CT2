<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Only allow drivers
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (strtolower($_SESSION['role']) !== 'driver') {
    header('Location: ../auth/login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDatabaseConnection();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$driver_id = $_SESSION['user_id'];

// ── Filters ────────────────────────────────────────────────────────────────
$filterRating = $_GET['rating'] ?? 'all';
$filterDate   = $_GET['date'] ?? 'all';
$searchQuery  = $_GET['search'] ?? '';

// Date range
$dateCondition = '';
$params = ['did' => $driver_id];
switch ($filterDate) {
    case 'today':
        $dateCondition = "AND DATE(r.created_at) = CURDATE()";
        break;
    case 'week':
        $dateCondition = "AND r.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        break;
    case 'month':
        $dateCondition = "AND r.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        break;
    case '3months':
        $dateCondition = "AND r.created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)";
        break;
}

// Rating filter
$ratingCondition = '';
if ($filterRating !== 'all') {
    $ratingCondition = "AND r.rating_value = :rating";
    $params['rating'] = (int)$filterRating;
}

// Search filter
$searchCondition = '';
if (!empty($searchQuery)) {
    $searchCondition = "AND (c.name LIKE :search OR r.comment LIKE :search OR ride.start_location LIKE :search)";
    $params['search'] = '%' . $searchQuery . '%';
}

// ── Statistics ────────────────────────────────────────────────────────────
try {
    // Average rating (all time)
    $stmt = $pdo->prepare("SELECT COALESCE(AVG(rating_value), 0) as avg_rating FROM core_ratings WHERE driver_id = :did");
    $stmt->execute(['did' => $driver_id]);
    $avgRating = $stmt->fetch()['avg_rating'] ?? 0;

    // Total ratings count
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_ratings WHERE driver_id = :did");
    $stmt->execute(['did' => $driver_id]);
    $totalRatings = $stmt->fetch()['total'] ?? 0;

    // Rating breakdown (count per star)
    $stmt = $pdo->prepare("
        SELECT 
            SUM(CASE WHEN rating_value = 5 THEN 1 ELSE 0 END) as five_star,
            SUM(CASE WHEN rating_value = 4 THEN 1 ELSE 0 END) as four_star,
            SUM(CASE WHEN rating_value = 3 THEN 1 ELSE 0 END) as three_star,
            SUM(CASE WHEN rating_value = 2 THEN 1 ELSE 0 END) as two_star,
            SUM(CASE WHEN rating_value = 1 THEN 1 ELSE 0 END) as one_star
        FROM core_ratings 
        WHERE driver_id = :did
    ");
    $stmt->execute(['did' => $driver_id]);
    $ratingBreakdown = $stmt->fetch();

    // Recent 30 days average
    $stmt = $pdo->prepare("
        SELECT COALESCE(AVG(rating_value), 0) as avg_rating 
        FROM core_ratings 
        WHERE driver_id = :did 
        AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute(['did' => $driver_id]);
    $recentAvgRating = $stmt->fetch()['avg_rating'] ?? 0;

    // Fetch ratings with filters
    $sql = "
        SELECT
            r.rating_id,
            r.rating_value,
            r.comment,
            r.rating_type,
            r.created_at,
            c.name as customer_name,
            c.phone as customer_phone,
            ride.ride_id,
            ride.start_location,
            ride.end_location,
            ride.start_time,
            b.booking_reference,
            COALESCE(fc.total_fare, 0) as fare
        FROM core_ratings r
        LEFT JOIN core_customers c ON r.customer_id = c.customer_id
        LEFT JOIN core_rides ride ON r.ride_id = ride.ride_id
        LEFT JOIN core_bookings b ON ride.booking_id = b.booking_id
        LEFT JOIN core_fare_computation fc ON ride.booking_id = fc.booking_id
        WHERE r.driver_id = :did
        {$dateCondition}
        {$ratingCondition}
        {$searchCondition}
        ORDER BY r.created_at DESC
        LIMIT 50
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $ratings = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("My Ratings query error: " . $e->getMessage());
    $ratings = [];
}

// Calculate percentages for rating breakdown
$ratingPercentages = [
    5 => $totalRatings > 0 ? ($ratingBreakdown['five_star'] / $totalRatings) * 100 : 0,
    4 => $totalRatings > 0 ? ($ratingBreakdown['four_star'] / $totalRatings) * 100 : 0,
    3 => $totalRatings > 0 ? ($ratingBreakdown['three_star'] / $totalRatings) * 100 : 0,
    2 => $totalRatings > 0 ? ($ratingBreakdown['two_star'] / $totalRatings) * 100 : 0,
    1 => $totalRatings > 0 ? ($ratingBreakdown['one_star'] / $totalRatings) * 100 : 0,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>My Ratings - EnviroCab Driver</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        :root {
            --primary-green: #00D084;
            --dark-green: #00A86B;
            --bg-gradient: linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --white: #FFFFFF;
            --text-dark: #1A202C;
            --text-medium: #4A5568;
            --text-light: #718096;
            --border: #E2E8F0;
            --accent-blue: #60A5FA;
            --accent-purple: #C084FC;
            --accent-yellow: #FBBF24;
            --accent-pink: #F472B6;
            --accent-orange: #FB923C;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 90px;
            -webkit-font-smoothing: antialiased;
        }

        /* ── Header ── */
        .header {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.5);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .back-btn {
            width: 36px;
            height: 36px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .back-btn svg { stroke: var(--text-medium); }
        .back-btn:active { transform: scale(0.95); }

        .header-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-dark);
        }

        .header-actions {
            display: flex;
            gap: 8px;
        }

        .icon-btn {
            width: 36px;
            height: 36px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .icon-btn svg { stroke: var(--text-medium); }
        .icon-btn:active { transform: scale(0.95); }

        /* ── Main ── */
        .main-content { padding: 20px; }

        /* ── Rating Hero Card ── */
        .rating-hero {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
            border-radius: 24px;
            padding: 32px 24px;
            color: white;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 208, 132, 0.2);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .rating-hero::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }

        .hero-label { font-size: 14px; opacity: 0.9; margin-bottom: 8px; position: relative; }
        .hero-rating { font-size: 72px; font-weight: 900; letter-spacing: -2px; margin-bottom: 8px; position: relative; line-height: 1; }
        .hero-stars {
            display: flex;
            justify-content: center;
            gap: 6px;
            margin-bottom: 12px;
            position: relative;
        }
        .hero-subtitle { font-size: 14px; opacity: 0.85; position: relative; }

        /* ── Rating Breakdown ── */
        .breakdown-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            margin-bottom: 20px;
        }

        .breakdown-title { font-size: 18px; font-weight: 700; margin-bottom: 20px; color: var(--text-dark); }

        .breakdown-row {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }

        .breakdown-row:last-child { margin-bottom: 0; }

        .breakdown-label {
            display: flex;
            align-items: center;
            gap: 6px;
            min-width: 80px;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-medium);
        }

        .star-icon { fill: #D97706; width: 16px; height: 16px; }

        .breakdown-bar {
            flex: 1;
            height: 10px;
            background: rgba(0, 0, 0, 0.05);
            border-radius: 10px;
            overflow: hidden;
            position: relative;
        }

        .breakdown-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-green), var(--dark-green));
            border-radius: 10px;
            transition: width 0.6s ease;
        }

        .breakdown-count {
            min-width: 40px;
            text-align: right;
            font-size: 14px;
            font-weight: 700;
            color: var(--text-dark);
        }

        /* ── Stats Grid ── */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }

        .stat-icon-circle {
            width: 44px;
            height: 44px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stat-value { 
            font-size: 32px; 
            font-weight: 800; 
            color: var(--text-dark); 
            margin-bottom: 4px;
            line-height: 1;
        }
        .stat-label { font-size: 13px; color: var(--text-light); font-weight: 500; }

        .trend-badge { 
            font-size: 11px; 
            font-weight: 700; 
            padding: 4px 10px; 
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .trend-up { background: rgba(16, 185, 129, 0.15); color: #10B981; }
        .trend-neutral { background: rgba(96, 165, 250, 0.15); color: #3B82F6; }

        /* ── Filter Bar ── */
        .filter-bar {
            background: white;
            border-radius: 20px;
            padding: 16px;
            border: 1px solid var(--border);
            margin-bottom: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .filter-row {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
        }

        .filter-row:last-child { margin-bottom: 0; }

        .filter-select {
            flex: 1;
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            background: rgba(0, 0, 0, 0.02);
            cursor: pointer;
            transition: all 0.2s;
        }

        .filter-select:focus {
            outline: none;
            border-color: var(--primary-green);
            background: white;
        }

        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: rgba(0, 0, 0, 0.02);
        }

        .search-box svg { stroke: var(--text-light); flex-shrink: 0; }

        .search-input {
            flex: 1;
            border: none;
            background: none;
            font-size: 13px;
            font-weight: 500;
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
        }

        .search-input:focus { outline: none; }
        .search-input::placeholder { color: var(--text-light); }

        .btn-filter {
            padding: 10px 18px;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            font-family: 'Inter', sans-serif;
            transition: all 0.2s;
            white-space: nowrap;
        }

        .btn-filter:active { transform: scale(0.97); }

        /* ── Rating Cards ── */
        .ratings-list { display: flex; flex-direction: column; gap: 12px; }

        .rating-card {
            background: white;
            border-radius: 20px;
            padding: 18px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            transition: all 0.2s;
        }

        .rating-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .rating-customer {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .customer-avatar {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            background: linear-gradient(135deg, var(--accent-purple), var(--accent-pink));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
            font-weight: 700;
            flex-shrink: 0;
        }

        .customer-info { flex: 1; }
        .customer-name { font-size: 15px; font-weight: 700; color: var(--text-dark); margin-bottom: 2px; }
        .rating-date { font-size: 12px; color: var(--text-light); }

        .rating-stars {
            display: flex;
            gap: 4px;
        }

        .rating-comment {
            padding: 12px;
            background: rgba(0, 0, 0, 0.02);
            border-radius: 12px;
            margin-bottom: 12px;
        }

        .comment-text {
            font-size: 14px;
            color: var(--text-medium);
            line-height: 1.6;
            margin-bottom: 8px;
        }

        .comment-type {
            font-size: 11px;
            font-weight: 700;
            color: var(--text-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .rating-trip-info {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-top: 12px;
            border-top: 1px solid var(--border);
        }

        .trip-location {
            font-size: 12px;
            color: var(--text-medium);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .trip-fare {
            font-size: 14px;
            font-weight: 700;
            color: var(--primary-green);
        }

        /* ── Empty State ── */
        .empty-state {
            background: white;
            border-radius: 20px;
            padding: 48px 24px;
            border: 1px solid var(--border);
            text-align: center;
        }

        .empty-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 16px;
            border-radius: 20px;
            background: rgba(0, 0, 0, 0.03);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .empty-icon svg { stroke: var(--text-light); opacity: 0.5; }
        .empty-title { font-size: 18px; font-weight: 700; color: var(--text-dark); margin-bottom: 8px; }
        .empty-subtitle { font-size: 14px; color: var(--text-light); }

        /* ── Bottom Nav ── */
        .bottom-nav {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            padding: 12px 0 20px;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            z-index: 99;
            box-shadow: 0 -4px 24px rgba(0, 0, 0, 0.05);
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            padding: 8px;
            cursor: pointer;
            border: none;
            background: none;
            transition: all 0.2s;
        }

        .nav-item:active { transform: scale(0.95); }

        .nav-icon {
            width: 48px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .nav-icon svg { stroke: var(--text-light); opacity: 0.5; transition: all 0.2s; }
        .nav-item.active .nav-icon svg { stroke: var(--primary-green); opacity: 1; }

        .nav-label { font-size: 11px; font-weight: 600; color: var(--text-light); opacity: 0.7; }
        .nav-item.active .nav-label { color: var(--primary-green); opacity: 1; }

        /* ── Animations ── */
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .rating-hero, .breakdown-card, .stat-card, .filter-bar, .rating-card { 
            animation: slideUp 0.4s ease forwards; 
        }

        @media (min-width: 768px) {
            body { max-width: 480px; margin: 0 auto; box-shadow: 0 0 40px rgba(0, 0, 0, 0.1); }
        }
    </style>
</head>
<body>

<!-- ── Header ── -->
<div class="header">
    <div class="header-content">
        <button class="back-btn" onclick="window.location.href='dashboard.php'">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
        </button>
        <div class="header-title">My Ratings & Feedback</div>
        <div class="header-actions">
            <button class="icon-btn" onclick="window.location.reload()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
                </svg>
            </button>
        </div>
    </div>
</div>

<!-- ── Main Content ── -->
<div class="main-content">

    <!-- Rating Hero -->
    <div class="rating-hero">
        <div class="hero-label">Your Average Rating</div>
        <div class="hero-rating"><?= number_format($avgRating, 1) ?></div>
        <div class="hero-stars">
            <?php for ($i = 1; $i <= 5; $i++): ?>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="<?= $i <= round($avgRating) ? 'white' : 'none' ?>" stroke="white" stroke-width="2">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
            <?php endfor; ?>
        </div>
        <div class="hero-subtitle">Based on <?= $totalRatings ?> review<?= $totalRatings != 1 ? 's' : '' ?></div>
    </div>

    <!-- Rating Breakdown -->
    <div class="breakdown-card">
        <div class="breakdown-title">Rating Distribution</div>

        <?php 
        $starWords = ['one', 'two', 'three', 'four', 'five'];
        for ($star = 5; $star >= 1; $star--): 
            $starWord = $starWords[$star - 1];
            $count = $ratingBreakdown[$starWord . '_star'] ?? 0;
            $percentage = $ratingPercentages[$star];
        ?>
        <div class="breakdown-row">
            <div class="breakdown-label">
                <?= $star ?>
                <svg class="star-icon" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
            </div>
            <div class="breakdown-bar">
                <div class="breakdown-fill" style="width: <?= $percentage ?>%"></div>
            </div>
            <div class="breakdown-count"><?= $count ?></div>
        </div>
        <?php endfor; ?>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(16, 185, 129, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                </div>
                <?php
                $fiveStarPercentage = $totalRatings > 0 ? round(($ratingBreakdown['five_star'] / $totalRatings) * 100) : 0;
                ?>
                <div class="trend-badge trend-up"><?= $fiveStarPercentage ?>%</div>
            </div>
            <div class="stat-value"><?= $ratingBreakdown['five_star'] ?? 0 ?></div>
            <div class="stat-label">5-Star Ratings</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(96, 165, 250, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                    </svg>
                </div>
                <div class="trend-badge trend-neutral">30d</div>
            </div>
            <div class="stat-value"><?= number_format($recentAvgRating, 1) ?>★</div>
            <div class="stat-label">Recent Average</div>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="filter-bar">
        <form method="GET" action="" id="filterForm">
            <div class="filter-row">
                <select name="rating" class="filter-select" onchange="document.getElementById('filterForm').submit()">
                    <option value="all" <?= $filterRating === 'all' ? 'selected' : '' ?>>All Ratings</option>
                    <option value="5" <?= $filterRating === '5' ? 'selected' : '' ?>>⭐ 5 Stars</option>
                    <option value="4" <?= $filterRating === '4' ? 'selected' : '' ?>>⭐ 4 Stars</option>
                    <option value="3" <?= $filterRating === '3' ? 'selected' : '' ?>>⭐ 3 Stars</option>
                    <option value="2" <?= $filterRating === '2' ? 'selected' : '' ?>>⭐ 2 Stars</option>
                    <option value="1" <?= $filterRating === '1' ? 'selected' : '' ?>>⭐ 1 Star</option>
                </select>

                <select name="date" class="filter-select" onchange="document.getElementById('filterForm').submit()">
                    <option value="all" <?= $filterDate === 'all' ? 'selected' : '' ?>>All Time</option>
                    <option value="today" <?= $filterDate === 'today' ? 'selected' : '' ?>>Today</option>
                    <option value="week" <?= $filterDate === 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                    <option value="month" <?= $filterDate === 'month' ? 'selected' : '' ?>>Last 30 Days</option>
                    <option value="3months" <?= $filterDate === '3months' ? 'selected' : '' ?>>Last 3 Months</option>
                </select>
            </div>

            <div class="filter-row">
                <div class="search-box" style="flex: 1;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                    <input type="text" name="search" class="search-input" placeholder="Search feedback, customer name..." value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
                <button type="submit" class="btn-filter">Filter</button>
            </div>
        </form>
    </div>

    <!-- Ratings List -->
    <div class="ratings-list">
        <?php if (!empty($ratings)): ?>
            <?php foreach ($ratings as $rating): 
                $initials = strtoupper(substr($rating['customer_name'] ?? 'P', 0, 1));
                $hasComment = !empty($rating['comment']);
            ?>
            <div class="rating-card">
                <div class="rating-header">
                    <div class="rating-customer">
                        <div class="customer-avatar"><?= $initials ?></div>
                        <div class="customer-info">
                            <div class="customer-name"><?= htmlspecialchars($rating['customer_name'] ?? 'Passenger') ?></div>
                            <div class="rating-date"><?= date('M j, Y • g:i A', strtotime($rating['created_at'])) ?></div>
                        </div>
                    </div>
                    <div class="rating-stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="<?= $i <= $rating['rating_value'] ? '#D97706' : 'none' ?>" stroke="#D97706" stroke-width="2">
                                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                            </svg>
                        <?php endfor; ?>
                    </div>
                </div>

                <?php if ($hasComment): ?>
                <div class="rating-comment">
                    <div class="comment-text">"<?= htmlspecialchars($rating['comment']) ?>"</div>
                    <div class="comment-type"><?= $rating['rating_type'] ?></div>
                </div>
                <?php endif; ?>

                <div class="rating-trip-info">
                    <div class="trip-location">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                        <?= htmlspecialchars(substr($rating['start_location'], 0, 30)) ?><?= strlen($rating['start_location']) > 30 ? '...' : '' ?>
                    </div>
                    <?php if ($rating['fare'] > 0): ?>
                    <div class="trip-fare">₱<?= number_format($rating['fare'], 0) ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                </div>
                <div class="empty-title">No Ratings Yet</div>
                <div class="empty-subtitle">
                    <?php if (!empty($searchQuery) || $filterRating !== 'all' || $filterDate !== 'all'): ?>
                        Try adjusting your filters to see more results
                    <?php else: ?>
                        Complete trips to start receiving ratings from passengers
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- ── Bottom Navigation ── -->
<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
        </div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="window.location.href='my_bookings.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
        </div>
        <span class="nav-label">Bookings</span>
    </button>
    <button class="nav-item" onclick="window.location.href='my_trips.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
            </svg>
        </div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item active">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
        </div>
        <span class="nav-label">Profile</span>
    </button>
</div>

</body>
</html>