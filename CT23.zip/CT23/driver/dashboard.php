<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

error_log("Driver Dashboard - Session user_id: " . ($_SESSION['user_id'] ?? 'NOT SET'));
error_log("Driver Dashboard - Session logged_in: " . ($_SESSION['logged_in'] ?? 'NOT SET'));

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
if (strtolower($_SESSION['role']) !== 'driver') {
    header('Location: ../auth/login.php');
    exit;
}

error_log("Driver Dashboard - Driver logged in: " . $_SESSION['username']);

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDatabaseConnection();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$driver_id   = $_SESSION['user_id'];
$today       = date('Y-m-d');
$currentHour = (int) date('H');

$greeting = 'Good Morning';
if ($currentHour >= 12 && $currentHour < 18) $greeting = 'Good Afternoon';
elseif ($currentHour >= 18)                   $greeting = 'Good Evening';

// ── Driver stats ─────────────────────────────────────────────────────────────
$todayTrips       = 0;
$todayEarnings    = 0;
$rating           = 0;
$activeTrips      = 0;
$pendingBookings  = 0;   // open pool — unclaimed Pending bookings (any driver can take)
$acceptedBookings = 0;   // this driver's Confirmed rides
$completedToday   = 0;
$totalEarnings30  = 0;
$openReports      = 0;
$recentRides      = [];

try {
    // Today's trips
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM core_rides WHERE driver_id = :did AND DATE(start_time) = :today");
    $stmt->execute(['did' => $driver_id, 'today' => $today]);
    $todayTrips = $stmt->fetch()['count'] ?? 0;

    // Today's earnings (completed)
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(fc.total_fare), 0) as earnings
        FROM core_rides r
        LEFT JOIN core_fare_computation fc ON r.booking_id = fc.booking_id
        WHERE r.driver_id = :did AND DATE(r.start_time) = :today AND r.ride_status = 'Completed'
    ");
    $stmt->execute(['did' => $driver_id, 'today' => $today]);
    $todayEarnings = $stmt->fetch()['earnings'] ?? 0;

    // Average rating (30 days)
    $stmt = $pdo->prepare("SELECT COALESCE(AVG(rating_value), 0) as rating FROM core_ratings WHERE driver_id = :did AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $stmt->execute(['did' => $driver_id]);
    $rating = $stmt->fetch()['rating'] ?? 0;

    // Active trips (In Progress)
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM core_rides WHERE driver_id = :did AND ride_status = 'In Progress'");
    $stmt->execute(['did' => $driver_id]);
    $activeTrips = $stmt->fetch()['count'] ?? 0;

    // ── OPEN POOL: unclaimed Pending bookings visible to ALL drivers ──
    $stmt = $pdo->query("
        SELECT COUNT(*) as count
        FROM core_bookings b
        LEFT JOIN core_rides r ON r.booking_id = b.booking_id
        WHERE b.booking_status = 'Pending'
          AND (r.driver_id IS NULL OR r.driver_id = 0)
    ");
    $pendingBookings = $stmt->fetch()['count'] ?? 0;

    // ── This driver's own accepted bookings ──
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count
        FROM core_rides r
        JOIN core_bookings b ON b.booking_id = r.booking_id
        WHERE r.driver_id = :did AND b.booking_status IN ('Confirmed','In Progress')
    ");
    $stmt->execute(['did' => $driver_id]);
    $acceptedBookings = $stmt->fetch()['count'] ?? 0;

    // Completed today
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM core_rides WHERE driver_id = :did AND ride_status = 'Completed' AND DATE(start_time) = :today");
    $stmt->execute(['did' => $driver_id, 'today' => $today]);
    $completedToday = $stmt->fetch()['count'] ?? 0;

    // Earnings last 30 days
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(fc.total_fare), 0) as earnings
        FROM core_rides r
        LEFT JOIN core_fare_computation fc ON r.booking_id = fc.booking_id
        WHERE r.driver_id = :did AND r.ride_status = 'Completed'
          AND r.start_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute(['did' => $driver_id]);
    $totalEarnings30 = $stmt->fetch()['earnings'] ?? 0;

    // Open reports
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM core_reports WHERE driver_id = :did AND status = 'Open'");
    $stmt->execute(['did' => $driver_id]);
    $openReports = $stmt->fetch()['count'] ?? 0;

    // Recent rides
    $stmt = $pdo->prepare("
        SELECT
            r.ride_id, r.start_location, r.end_location, r.ride_status, r.start_time,
            c.name as customer_name,
            COALESCE(fc.total_fare, 0) as fare
        FROM core_rides r
        LEFT JOIN core_customers c         ON r.customer_id = c.customer_id
        LEFT JOIN core_fare_computation fc ON r.booking_id  = fc.booking_id
        WHERE r.driver_id = :did
        ORDER BY r.start_time DESC
        LIMIT 3
    ");
    $stmt->execute(['did' => $driver_id]);
    $recentRides = $stmt->fetchAll();

    // ── This driver's own active bookings (for the dashboard "Assigned Bookings" card)
    // Now shows THIS driver's Confirmed/In-Progress, NOT the old core_booking_resources pool
    $stmt = $pdo->prepare("
        SELECT
            b.booking_id, b.booking_reference, b.booking_status,
            b.booking_date, b.booking_time, b.total_amount,
            c.name as customer_name, c.phone as customer_phone,
            s.service_name
        FROM core_rides r
        JOIN core_bookings b          ON b.booking_id  = r.booking_id
        LEFT JOIN core_customers c   ON b.customer_id  = c.customer_id
        LEFT JOIN core_services s    ON b.service_id   = s.service_id
        WHERE r.driver_id = :did
          AND b.booking_status IN ('Confirmed','In Progress')
        ORDER BY b.booking_date ASC, b.booking_time ASC
        LIMIT 5
    ");
    $stmt->execute(['did' => $driver_id]);
    $assignedBookings = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("Driver Dashboard query error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>EnviroCab Driver Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }

        :root {
            --primary-green: #00D084;
            --dark-green:    #00A86B;
            --bg-gradient:   linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --white:         #FFFFFF;
            --text-dark:     #1A202C;
            --text-medium:   #4A5568;
            --text-light:    #718096;
            --border:        #E2E8F0;
            --accent-blue:   #60A5FA;
            --accent-purple: #C084FC;
            --accent-yellow: #FBBF24;
            --accent-pink:   #F472B6;
            --accent-orange: #FB923C;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 90px;
            -webkit-font-smoothing: antialiased;
        }

        /* ── Header ── */
        .header {
            background: rgba(255,255,255,0.8); backdrop-filter: blur(20px);
            padding: 16px 20px; position: sticky; top: 0; z-index: 100;
            border-bottom: 1px solid rgba(255,255,255,0.5);
        }
        .header-content { display: flex; justify-content: space-between; align-items: center; }
        .logo-img { height: 28px; width: auto; }
        .header-right { display: flex; align-items: center; gap: 12px; }
        .icon-btn {
            width: 36px; height: 36px; border-radius: 12px;
            background: rgba(255,255,255,0.9); border: 1px solid rgba(0,0,0,0.05);
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: all 0.2s; position: relative;
        }
        .icon-btn svg { stroke: var(--text-medium); }
        .icon-btn:active { transform: scale(0.95); }
        .notification-badge {
            position: absolute; top: 6px; right: 6px;
            width: 6px; height: 6px;
            background: #EF4444; border-radius: 50%; border: 2px solid white;
        }
        .logout-btn { background: rgba(239,68,68,0.1); color: #EF4444; border: 1px solid rgba(239,68,68,0.2); }

        /* ── Status Bar ── */
        .status-bar {
            background: white; border-bottom: 1px solid var(--border);
            padding: 10px 20px; display: flex; align-items: center; justify-content: space-between;
        }
        .status-label { font-size: 13px; font-weight: 600; color: var(--text-medium); }
        .status-toggle { display: flex; align-items: center; gap: 10px; }
        .toggle-switch { position: relative; width: 52px; height: 28px; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider {
            position: absolute; cursor: pointer; top:0;left:0;right:0;bottom:0;
            background: #CBD5E0; border-radius: 28px; transition: 0.3s;
        }
        .toggle-slider:before {
            position: absolute; content: ""; height: 20px; width: 20px;
            left: 4px; bottom: 4px; background: white;
            border-radius: 50%; transition: 0.3s; box-shadow: 0 2px 4px rgba(0,0,0,0.15);
        }
        input:checked + .toggle-slider { background: var(--primary-green); }
        input:checked + .toggle-slider:before { transform: translateX(24px); }
        .online-text  { font-size: 13px; font-weight: 700; color: var(--primary-green); }
        .offline-text { font-size: 13px; font-weight: 700; color: var(--text-light); }

        /* ── Main ── */
        .main-content { padding: 20px; }

        /* ── Hero Card ── */
        .hero-card {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
            border-radius: 24px; padding: 28px 24px; color: white;
            margin-bottom: 20px; box-shadow: 0 8px 32px rgba(0,208,132,0.2);
            position: relative; overflow: hidden;
        }
        .hero-card::before {
            content: ''; position: absolute; top:-50%; right:-20%;
            width: 200px; height: 200px;
            background: rgba(255,255,255,0.1); border-radius: 50%;
        }
        .hero-greeting { font-size:14px; opacity:0.9; margin-bottom:4px; position:relative; }
        .hero-title    { font-size:28px; font-weight:800; margin-bottom:8px; position:relative; }
        .hero-amount   { font-size:42px; font-weight:900; letter-spacing:-1px; margin-bottom:4px; position:relative; }
        .hero-label    { font-size:13px; opacity:0.85; position:relative; }
        .hero-stats    { display:flex; gap:16px; margin-top:24px; position:relative; }
        .hero-stat {
            flex:1; background:rgba(255,255,255,0.15); backdrop-filter:blur(10px);
            padding:12px; border-radius:16px; text-align:center;
        }
        .hero-stat-value { font-size:20px; font-weight:700; margin-bottom:4px; }
        .hero-stat-label { font-size:11px; opacity:0.85; }

        /* ── Quick Actions ── */
        .quick-actions { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:24px; }
        .action-btn {
            background:white; border-radius:20px; padding:16px 8px; text-align:center;
            border:1px solid var(--border); cursor:pointer; transition:all 0.2s;
            box-shadow:0 2px 8px rgba(0,0,0,0.04);
        }
        .action-btn:active { transform:translateY(-4px); box-shadow:0 4px 12px rgba(0,0,0,0.08); }
        .action-icon {
            width:44px; height:44px; margin:0 auto 8px; border-radius:14px;
            display:flex; align-items:center; justify-content:center; font-size:22px;
        }
        .action-icon.green  { background:linear-gradient(135deg,#10B981,#059669); }
        .action-icon.blue   { background:linear-gradient(135deg,#60A5FA,#3B82F6); }
        .action-icon.purple { background:linear-gradient(135deg,#C084FC,#A855F7); }
        .action-icon.orange { background:linear-gradient(135deg,#FB923C,#F97316); }
        .action-label { font-size:11px; font-weight:600; color:var(--text-medium); }

        /* ── Stats Grid ── */
        .stats-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:12px; margin-bottom:20px; }
        .stat-card {
            background:white; border-radius:20px; padding:20px;
            border:1px solid var(--border); box-shadow:0 2px 8px rgba(0,0,0,0.04);
        }
        .stat-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:16px; }
        .stat-icon-circle { width:44px; height:44px; border-radius:14px; display:flex; align-items:center; justify-content:center; }
        .trend-badge { font-size:11px; font-weight:700; padding:4px 10px; border-radius:8px; }
        .trend-up   { background:rgba(16,185,129,0.15); color:#10B981; }
        .trend-down { background:rgba(239,68,68,0.15);  color:#EF4444; }
        .stat-value { font-size:32px; font-weight:800; color:var(--text-dark); margin-bottom:4px; }
        .stat-label { font-size:13px; color:var(--text-light); font-weight:500; }

        /* ── Activity Card ── */
        .activity-card {
            background:white; border-radius:20px; padding:20px;
            border:1px solid var(--border); box-shadow:0 2px 8px rgba(0,0,0,0.04); margin-bottom:20px;
        }
        .card-title { font-size:18px; font-weight:700; margin-bottom:16px; color:var(--text-dark); }

        .activity-item {
            display:flex; align-items:center; gap:12px; padding:12px;
            background:rgba(0,0,0,0.02); border-radius:14px; margin-bottom:8px;
        }
        .activity-item:last-child { margin-bottom:0; }
        .activity-icon { width:40px; height:40px; border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .activity-info { flex:1; }
        .activity-title    { font-size:14px; font-weight:600; color:var(--text-dark); margin-bottom:2px; }
        .activity-subtitle { font-size:12px; color:var(--text-light); }
        .activity-amount   { font-size:14px; font-weight:700; color:var(--text-dark); }

        /* ── Booking Cards (accepted — in the dashboard "My Active Rides" section) ── */
        .booking-card {
            background:white; border-radius:18px; padding:16px;
            border:1px solid var(--border); display:flex; align-items:center;
            gap:14px; margin-bottom:10px; box-shadow:0 2px 8px rgba(0,0,0,0.04);
        }
        .booking-card:last-child { margin-bottom:0; }
        .booking-icon-wrap {
            width:52px; height:52px; border-radius:16px;
            display:flex; align-items:center; justify-content:center; flex-shrink:0; font-size:24px;
        }
        .booking-content { flex:1; }
        .booking-title    { font-size:15px; font-weight:600; color:var(--text-dark); margin-bottom:2px; }
        .booking-subtitle { font-size:12px; color:var(--text-light); margin-bottom:8px; }
        .booking-actions  { display:flex; gap:8px; }

        .btn-accept {
            flex:1; padding:8px 12px;
            background:linear-gradient(135deg, var(--primary-green), var(--dark-green));
            color:white; border:none; border-radius:10px;
            font-size:12px; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif; transition:all 0.2s;
        }
        .btn-decline {
            flex:1; padding:8px 12px;
            background:rgba(239,68,68,0.1); color:#EF4444;
            border:1px solid rgba(239,68,68,0.2); border-radius:10px;
            font-size:12px; font-weight:700; cursor:pointer; font-family:'Inter',sans-serif; transition:all 0.2s;
        }
        .btn-accept:active, .btn-decline:active { transform:scale(0.97); }

        .status-pill { font-size:11px; font-weight:700; padding:4px 10px; border-radius:8px; }
        .status-pending    { background:rgba(251,191,36,0.15); color:#D97706; }
        .status-confirmed  { background:rgba(16,185,129,0.15); color:#10B981; }
        .status-completed  { background:rgba(96,165,250,0.15); color:#3B82F6; }
        .status-cancelled  { background:rgba(239,68,68,0.15);  color:#EF4444; }
        .status-in-progress{ background:rgba(96,165,250,0.15); color:#3B82F6; }

        /* ── Modules ── */
        .modules-list { display:flex; flex-direction:column; gap:12px; }
        .module-item {
            background:white; border-radius:18px; padding:16px;
            border:1px solid var(--border); display:flex; align-items:center;
            gap:14px; cursor:pointer; transition:all 0.2s; box-shadow:0 2px 8px rgba(0,0,0,0.04);
        }
        .module-item:active { transform:translateX(4px); }
        .module-icon-wrap { width:52px; height:52px; border-radius:16px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .module-content  { flex:1; }
        .module-title    { font-size:15px; font-weight:600; color:var(--text-dark); margin-bottom:2px; }
        .module-subtitle { font-size:12px; color:var(--text-light); }
        .module-arrow    { color:var(--text-light); font-size:18px; }

        /* ── Bottom Nav ── */
        .bottom-nav {
            position:fixed; bottom:0; left:0; right:0;
            background:rgba(255,255,255,0.95); backdrop-filter:blur(20px);
            border-top:1px solid rgba(0,0,0,0.05);
            padding:12px 0 20px; display:grid; grid-template-columns:repeat(4,1fr);
            z-index:99; box-shadow:0 -4px 24px rgba(0,0,0,0.05);
        }
        .nav-item {
            display:flex; flex-direction:column; align-items:center;
            gap:4px; padding:8px; cursor:pointer; border:none; background:none; transition:all 0.2s;
        }
        .nav-item:active { transform:scale(0.95); }
        .nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
        .nav-icon svg { stroke:var(--text-light); opacity:0.5; transition:all 0.2s; }
        .nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
        .nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:0.7; }
        .nav-item.active .nav-label { color:var(--primary-green); opacity:1; }

        /* ── Animations ── */
        @keyframes slideUp {
            from { opacity:0; transform:translateY(20px); }
            to   { opacity:1; transform:translateY(0); }
        }
        @keyframes slideDown {
            from { opacity:0; transform:translateY(-20px); }
            to   { opacity:1; transform:translateY(0); }
        }
        @keyframes pulseRing {
            0%   { box-shadow: 0 0 0 0   rgba(245,158,11,0.45); }
            70%  { box-shadow: 0 0 0 10px rgba(245,158,11,0); }
            100% { box-shadow: 0 0 0 0   rgba(245,158,11,0); }
        }
        @keyframes blink {
            0%, 100% { opacity:1; }
            50%       { opacity:0.2; }
        }

        .hero-card, .stat-card, .activity-card, .module-item { animation:slideUp 0.4s ease forwards; }

        @media (min-width: 768px) {
            body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,0.1); }
        }

        /* ================================================================
           POPUP NOTIFICATION — new rides available
        ================================================================ */
        .popup-overlay {
            position: fixed; inset: 0; z-index: 9998;
            background: rgba(0,0,0,0.45); backdrop-filter: blur(4px);
            display: none; align-items: flex-end; justify-content: center;
        }
        .popup-overlay.open { display: flex; }

        .popup-sheet {
            background: white; width: 100%; max-width: 480px;
            border-radius: 24px 24px 0 0; padding: 0 0 32px;
            animation: slideDown 0.3s ease;
            max-height: 82vh; display: flex; flex-direction: column;
        }

        /* drag handle */
        .popup-handle-bar {
            display: flex; justify-content: center; padding: 12px 0 4px;
            flex-shrink: 0;
        }
        .popup-handle { width: 40px; height: 4px; background: var(--border); border-radius: 2px; }

        /* popup header strip */
        .popup-header {
            padding: 12px 20px 16px; flex-shrink: 0;
            border-bottom: 1px solid var(--border);
        }
        .popup-header-top {
            display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;
        }
        .popup-title-row { display: flex; align-items: center; gap: 10px; }
        .popup-icon {
            width: 40px; height: 40px; border-radius: 13px; flex-shrink: 0;
            background: linear-gradient(135deg, #F59E0B, #D97706);
            display: flex; align-items: center; justify-content: center;
            animation: pulseRing 2s infinite;
        }
        .popup-title { font-size: 17px; font-weight: 800; color: var(--text-dark); }
        .popup-sub   { font-size: 12px; color: var(--text-light); margin-top: 2px; }
        .popup-close-btn {
            width: 32px; height: 32px; border-radius: 10px;
            background: rgba(0,0,0,0.04); border: none; cursor: pointer;
            display: flex; align-items: center; justify-content: center; flex-shrink: 0;
            font-size: 18px; color: var(--text-light); transition: all 0.2s;
        }
        .popup-close-btn:active { transform: scale(0.9); }

        /* scrollable ride list inside popup */
        .popup-rides {
            flex: 1; overflow-y: auto; padding: 16px 16px 0;
            -webkit-overflow-scrolling: touch; scrollbar-width: none;
        }
        .popup-rides::-webkit-scrollbar { display: none; }

        /* each ride card inside the popup */
        .popup-ride-card {
            background: rgba(0,0,0,0.02); border: 1px solid var(--border);
            border-radius: 18px; padding: 14px; margin-bottom: 12px; overflow: hidden;
        }
        .popup-ride-card:last-child { margin-bottom: 0; }

        /* top strip */
        .popup-ride-strip { height: 3px; background: #F59E0B; border-radius: 2px; margin: -14px -14px 12px; }

        .popup-ride-head {
            display: flex; align-items: flex-start; justify-content: space-between;
            gap: 8px; margin-bottom: 10px;
        }
        .popup-ride-ref  { font-size: 13px; font-weight: 800; color: var(--text-dark); font-family: monospace; }
        .popup-ride-time { font-size: 11px; color: var(--text-light); margin-top: 2px; }
        .popup-ride-fare { font-size: 18px; font-weight: 900; color: var(--primary-green); flex-shrink: 0; }

        .popup-customer-row {
            display: flex; align-items: center; gap: 10px; margin-bottom: 10px;
        }
        .popup-avatar {
            width: 36px; height: 36px; border-radius: 11px; flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 15px; font-weight: 700;
        }
        .popup-customer-name { font-size: 14px; font-weight: 700; color: var(--text-dark); }
        .popup-service       { font-size: 11px; color: var(--text-light); margin-top: 1px; }

        /* route inside popup */
        .popup-route {
            background: white; border-radius: 12px; padding: 10px 11px;
            margin-bottom: 10px; display: flex; align-items: stretch; gap: 9px;
            border: 1px solid var(--border);
        }
        .popup-route-spine { display:flex; flex-direction:column; align-items:center; padding-top:3px; }
        .popup-dot-green { width:7px; height:7px; border-radius:50%; flex-shrink:0; background:var(--primary-green); box-shadow:0 0 0 3px rgba(0,208,132,0.2); }
        .popup-dot-red   { width:7px; height:7px; border-radius:50%; flex-shrink:0; background:#EF4444;             box-shadow:0 0 0 3px rgba(239,68,68,0.15); }
        .popup-spine-line{ width:2px; flex:1; background:var(--border); min-height:14px; }
        .popup-route-labels { flex:1; display:flex; flex-direction:column; gap:8px; }
        .popup-route-lbl { font-size:10px; font-weight:700; color:var(--text-light); text-transform:uppercase; letter-spacing:0.4px; margin-bottom:1px; }
        .popup-route-val { font-size:11px; font-weight:600; color:var(--text-dark); line-height:1.3; }

        /* popup action buttons */
        .popup-action-row { display:flex; gap:8px; }
        .popup-btn-accept {
            flex:1; padding:10px 8px;
            background:linear-gradient(135deg,var(--primary-green),var(--dark-green));
            color:white; border:none; border-radius:12px;
            font-size:13px; font-weight:700; cursor:pointer;
            font-family:'Inter',sans-serif; transition:all 0.2s;
            display:flex; align-items:center; justify-content:center; gap:5px;
        }
        .popup-btn-skip {
            flex:1; padding:10px 8px;
            background:rgba(239,68,68,0.07); color:#EF4444;
            border:1px solid rgba(239,68,68,0.2); border-radius:12px;
            font-size:13px; font-weight:700; cursor:pointer;
            font-family:'Inter',sans-serif; transition:all 0.2s;
            display:flex; align-items:center; justify-content:center; gap:5px;
        }
        .popup-btn-accept:active, .popup-btn-skip:active { transform:scale(0.97); }
        .popup-btn-accept:disabled { opacity:0.6; cursor:not-allowed; }

        /* "View All" footer button */
        .popup-footer {
            padding: 12px 16px 0; flex-shrink: 0; border-top: 1px solid var(--border); margin-top: 4px;
        }
        .popup-view-all {
            width: 100%; padding: 13px;
            background: rgba(0,208,132,0.07); color: var(--dark-green);
            border: 1.5px solid rgba(0,208,132,0.25); border-radius: 14px;
            font-size: 14px; font-weight: 700; cursor: pointer;
            font-family: 'Inter',sans-serif; transition: all 0.2s;
        }
        .popup-view-all:active { background: rgba(0,208,132,0.15); }

        /* notification bell badge counter */
        .notif-count {
            position: absolute; top: -2px; right: -2px;
            background: #EF4444; color: white; border-radius: 10px;
            font-size: 10px; font-weight: 800; min-width: 16px; height: 16px;
            display: flex; align-items: center; justify-content: center;
            padding: 0 4px; border: 2px solid white; line-height: 1;
        }
        /* blinking dot on notification bell */
        .notif-dot {
            position: absolute; top: 6px; right: 6px;
            width: 6px; height: 6px; background: #EF4444;
            border-radius: 50%; border: 2px solid white;
            animation: blink 1.2s infinite;
        }
    </style>
</head>
<body>

<!-- ── Header ── -->
<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img" onerror="this.style.display='none'">
        <div class="header-right">
            <!-- Notification bell — opens the popup -->
            <button class="icon-btn" id="notif-bell-btn" onclick="openPopup()" aria-label="New ride requests">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
                <!-- Badge shown only when there are open bookings -->
                <?php if ($pendingBookings > 0): ?>
                    <span class="notif-count" id="notif-count-badge"><?= $pendingBookings ?></span>
                <?php else: ?>
                    <span class="notif-count" id="notif-count-badge" style="display:none;">0</span>
                <?php endif; ?>
            </button>

            <button class="icon-btn logout-btn" onclick="if(confirm('Are you sure you want to logout?')) window.location.href='../auth/logout.php'">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
            </button>
        </div>
    </div>
</div>

<!-- ── Online/Offline Toggle ── -->
<div class="status-bar">
    <span class="status-label">Driver Status</span>
    <div class="status-toggle">
        <span class="offline-text" id="status-text-off">Offline</span>
        <label class="toggle-switch">
            <input type="checkbox" id="driver-status-toggle" onchange="toggleDriverStatus(this)">
            <span class="toggle-slider"></span>
        </label>
        <span class="online-text" id="status-text-on">Online</span>
    </div>
</div>

<!-- ── Main Content ── -->
<div class="main-content">

    <!-- Hero Card -->
    <div class="hero-card">
        <div class="hero-greeting"><?= $greeting ?>, <?= htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']) ?>!</div>
        <div class="hero-title">Today's Earnings</div>
        <div class="hero-amount">&#8369;<?= number_format($todayEarnings, 2) ?></div>
        <div class="hero-label">Total Earnings Today</div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $todayTrips ?></div>
                <div class="hero-stat-label">Trips</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value">
                    <?= number_format($rating, 1) ?>
                    <svg style="display:inline-block;vertical-align:middle;margin-left:2px;" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                </div>
                <div class="hero-stat-label">Rating</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?= $activeTrips ?></div>
                <div class="hero-stat-label">Active</div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
        <div class="action-btn" onclick="window.location.href='my_bookings.php'">
            <div class="action-icon green">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
            </div>
            <div class="action-label">Bookings</div>
        </div>
        <div class="action-btn" onclick="window.location.href='my_earnings.php'">
            <div class="action-icon blue" style="font-size:22px;font-weight:800;color:white;font-family:'Inter',sans-serif;">&#8369;</div>
            <div class="action-label">Earnings</div>
        </div>
        <div class="action-btn" onclick="window.location.href='my_trips.php'">
            <div class="action-icon purple">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                    <circle cx="12" cy="10" r="3"></circle>
                </svg>
            </div>
            <div class="action-label">Trips</div>
        </div>
        <div class="action-btn" onclick="window.location.href='my_ratings.php'">
            <div class="action-icon orange">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
            </div>
            <div class="action-label">Ratings</div>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background:rgba(16,185,129,0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="1" y="3" width="15" height="13"></rect>
                        <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                        <circle cx="5.5" cy="18.5" r="2.5"></circle>
                        <circle cx="18.5" cy="18.5" r="2.5"></circle>
                    </svg>
                </div>
                <div class="trend-badge trend-up">Today</div>
            </div>
            <div class="stat-value"><?= $completedToday ?></div>
            <div class="stat-label">Completed Trips</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background:rgba(96,165,250,0.15);font-size:20px;font-weight:800;color:#60A5FA;font-family:'Inter',sans-serif;">&#8369;</div>
            </div>
            <div class="stat-value">&#8369;<?= number_format($totalEarnings30 / 1000, 1) ?>K</div>
            <div class="stat-label">Earnings (30d)</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background:rgba(251,191,36,0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#D97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                </div>
                <?php if ($pendingBookings > 0): ?>
                    <div class="trend-badge" style="background:rgba(251,191,36,0.15);color:#D97706;"><?= $pendingBookings ?> new</div>
                <?php endif; ?>
            </div>
            <div class="stat-value" id="dash-pending-count"><?= $pendingBookings ?></div>
            <div class="stat-label">Available Rides</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background:rgba(192,132,252,0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#C084FC" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                </div>
            </div>
            <div class="stat-value"><?= number_format($rating, 1) ?>★</div>
            <div class="stat-label">Avg Rating (30d)</div>
        </div>
    </div>

    <!-- My Active Rides (replaces old "Assigned Bookings" from core_booking_resources) -->
    <div class="activity-card">
        <div class="card-title">My Active Rides</div>

        <?php if (!empty($assignedBookings)): ?>
            <?php foreach ($assignedBookings as $b): ?>
                <div class="booking-card">
                    <div class="booking-icon-wrap" style="background:linear-gradient(135deg,var(--primary-green),var(--dark-green));">
                        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="1" y="3" width="15" height="13"></rect>
                            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                            <circle cx="5.5" cy="18.5" r="2.5"></circle>
                            <circle cx="18.5" cy="18.5" r="2.5"></circle>
                        </svg>
                    </div>
                    <div class="booking-content">
                        <div class="booking-title">
                            <?= htmlspecialchars($b['customer_name'] ?? 'Passenger') ?>
                            <span class="status-pill status-<?= strtolower(str_replace(' ', '-', $b['booking_status'])) ?>">
                                <?= htmlspecialchars($b['booking_status']) ?>
                            </span>
                        </div>
                        <div class="booking-subtitle">
                            <?= htmlspecialchars($b['booking_reference']) ?> &bull;
                            <?= htmlspecialchars($b['service_name'] ?? 'Ride') ?> &bull;
                            &#8369;<?= number_format($b['total_amount'], 0) ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="activity-item">
                <div class="activity-icon" style="background:rgba(0,0,0,0.05);">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#718096" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                </div>
                <div class="activity-info">
                    <div class="activity-title">No active rides</div>
                    <div class="activity-subtitle">Accept a ride from the Bookings tab or tap the bell</div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Recent Rides -->
    <div class="activity-card">
        <div class="card-title">Recent Trips</div>

        <?php if (!empty($recentRides)):
            $colors     = ['rgba(16,185,129,0.15)', 'rgba(96,165,250,0.15)', 'rgba(251,146,60,0.15)'];
            $iconColors = ['#10B981', '#60A5FA', '#FB923C'];
            foreach ($recentRides as $i => $ride): ?>
            <div class="activity-item">
                <div class="activity-icon" style="background:<?= $colors[$i % 3] ?>;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="<?= $iconColors[$i % 3] ?>" stroke-width="2">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                    </svg>
                </div>
                <div class="activity-info">
                    <div class="activity-title"><?= htmlspecialchars($ride['customer_name'] ?? 'Passenger') ?></div>
                    <div class="activity-subtitle">
                        <?= htmlspecialchars(substr($ride['start_location'], 0, 22)) ?>… &bull;
                        <span class="status-pill status-<?= strtolower(str_replace(' ','-',$ride['ride_status'])) ?>"><?= $ride['ride_status'] ?></span>
                    </div>
                </div>
                <div class="activity-amount">&#8369;<?= number_format($ride['fare'], 0) ?></div>
            </div>
        <?php endforeach; else: ?>
            <div class="activity-item">
                <div class="activity-icon" style="background:rgba(0,0,0,0.05);">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#718096" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                </div>
                <div class="activity-info">
                    <div class="activity-title">No recent trips</div>
                    <div class="activity-subtitle">Your completed trips will appear here</div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Driver Modules -->
    <div class="activity-card">
        <div class="card-title">My Modules</div>
        <div class="modules-list">

            <div class="module-item" onclick="window.location.href='my_bookings.php'">
                <div class="module-icon-wrap" style="background:linear-gradient(135deg,var(--primary-green),var(--dark-green));">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                </div>
                <div class="module-content">
                    <div class="module-title">Booking Marketplace</div>
                    <div class="module-subtitle" id="mod-sub-bookings"><?= $pendingBookings ?> available &bull; <?= $acceptedBookings ?> accepted</div>
                </div>
                <div class="module-arrow">›</div>
            </div>

            <div class="module-item" onclick="window.location.href='my_trips.php'">
                <div class="module-icon-wrap" style="background:linear-gradient(135deg,#C084FC,#A855F7);">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                    </svg>
                </div>
                <div class="module-content">
                    <div class="module-title">Trip History</div>
                    <div class="module-subtitle"><?= $todayTrips ?> trips today</div>
                </div>
                <div class="module-arrow">›</div>
            </div>

            <div class="module-item" onclick="window.location.href='my_earnings.php'">
                <div class="module-icon-wrap" style="background:linear-gradient(135deg,#60A5FA,#3B82F6);">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="1" x2="12" y2="23"></line>
                        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                    </svg>
                </div>
                <div class="module-content">
                    <div class="module-title">Earnings &amp; Payments</div>
                    <div class="module-subtitle">&#8369;<?= number_format($totalEarnings30 / 1000, 1) ?>K this month</div>
                </div>
                <div class="module-arrow">›</div>
            </div>

            <div class="module-item" onclick="window.location.href='my_ratings.php'">
                <div class="module-icon-wrap" style="background:linear-gradient(135deg,#FB923C,#F97316);">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                </div>
                <div class="module-content">
                    <div class="module-title">My Ratings &amp; Feedback</div>
                    <div class="module-subtitle"><?= number_format($rating, 1) ?>★ average &bull; last 30 days</div>
                </div>
                <div class="module-arrow">›</div>
            </div>

            <div class="module-item" onclick="window.location.href='my_reports.php'">
                <div class="module-icon-wrap" style="background:linear-gradient(135deg,#F59E0B,#D97706);">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                    </svg>
                </div>
                <div class="module-content">
                    <div class="module-title">My Audit Logs</div>
                    <div class="module-subtitle"><?= $openReports > 0 ? $openReports . ' open report(s)' : 'No open reports' ?></div>
                </div>
                <div class="module-arrow">›</div>
            </div>

        </div>
    </div>

</div><!-- /.main-content -->

<!-- ── Bottom Nav ── -->
<div class="bottom-nav">
    <button class="nav-item active">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
        </div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="window.location.href='my_bookings.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
        </div>
        <span class="nav-label">Bookings</span>
    </button>
    <button class="nav-item" onclick="window.location.href='my_trips.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
            </svg>
        </div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item" onclick="window.location.href='driver_profile.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
        </div>
        <span class="nav-label">Profile</span>
    </button>
</div>

<!-- ================================================================
     POPUP NOTIFICATION SHEET
================================================================ -->
<div class="popup-overlay" id="popup-overlay" onclick="handleOverlayClick(event)">
    <div class="popup-sheet" id="popup-sheet">
        <!-- Handle -->
        <div class="popup-handle-bar"><div class="popup-handle"></div></div>

        <!-- Header -->
        <div class="popup-header">
            <div class="popup-header-top">
                <div class="popup-title-row">
                    <div class="popup-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="1" y="3" width="15" height="13"></rect>
                            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                            <circle cx="5.5" cy="18.5" r="2.5"></circle>
                            <circle cx="18.5" cy="18.5" r="2.5"></circle>
                        </svg>
                    </div>
                    <div>
                        <div class="popup-title">New Ride Requests</div>
                        <div class="popup-sub" id="popup-subtitle">Loading…</div>
                    </div>
                </div>
                <button class="popup-close-btn" onclick="closePopup()" aria-label="Close">&#x2715;</button>
            </div>
        </div>

        <!-- Ride Cards -->
        <div class="popup-rides" id="popup-rides-list">
            <!-- filled by JS -->
        </div>

        <!-- Footer -->
        <div class="popup-footer">
            <button class="popup-view-all" onclick="window.location.href='my_bookings.php?filter=available'">
                View All Available Rides &rarr;
            </button>
        </div>
    </div>
</div>

<script>
// ── Online/Offline toggle ──────────────────────────────────────────────────────
function toggleDriverStatus(checkbox) {
    const isOnline = checkbox.checked;
    document.getElementById('status-text-on').style.fontWeight  = isOnline ? '800' : '600';
    document.getElementById('status-text-off').style.opacity    = isOnline ? '0.4' : '1';

    fetch('update_driver_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'status=' + (isOnline ? 'online' : 'offline')
    }).catch(() => {});
}

// ── Popup state ───────────────────────────────────────────────────────────────
let _popupOpen   = false;
let _popupRides  = [];      // latest fetched rides
let _prevCount   = <?= $pendingBookings ?>;
let _pollTimer   = null;
let _autoOpened  = false;   // only auto-open once per page load

function openPopup() {
    _popupOpen = true;
    document.getElementById('popup-overlay').classList.add('open');
    renderPopupRides(_popupRides);
}

function closePopup() {
    _popupOpen = false;
    document.getElementById('popup-overlay').classList.remove('open');
}

function handleOverlayClick(e) {
    if (e.target === document.getElementById('popup-overlay')) closePopup();
}

// ── Render ride cards inside the popup ───────────────────────────────────────
function renderPopupRides(rides) {
    const list = document.getElementById('popup-rides-list');
    const sub  = document.getElementById('popup-subtitle');

    if (!rides || rides.length === 0) {
        sub.textContent = 'No rides available right now';
        list.innerHTML  = `
            <div style="text-align:center;padding:32px 20px;color:var(--text-light);">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 10px;display:block;opacity:0.35;">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
                <div style="font-size:14px;font-weight:600;">No rides available</div>
                <div style="font-size:12px;margin-top:4px;">Check back in a moment</div>
            </div>`;
        return;
    }

    sub.textContent = rides.length + ' ride' + (rides.length !== 1 ? 's' : '') + ' waiting for a driver';

    list.innerHTML = rides.map(r => {
        const initial  = (r.customer_name || 'P').charAt(0).toUpperCase();
        const fare     = parseFloat(r.fare || 0);
        const distTxt  = r.distance_km ? parseFloat(r.distance_km).toFixed(1) + ' km' : '';
        const timeTxt  = r.booking_time ? formatTime(r.booking_time) : '';
        const dateTxt  = r.booking_date ? formatDate(r.booking_date) : '';

        const pickup   = r.start_location || '—';
        const dropoff  = r.end_location   || '—';

        return `
        <div class="popup-ride-card" id="popup-card-${r.booking_id}">
            <div class="popup-ride-strip"></div>
            <div class="popup-ride-head">
                <div>
                    <div class="popup-ride-ref"># ${escHtml(r.booking_reference)}</div>
                    <div class="popup-ride-time">${dateTxt}${timeTxt ? ' · ' + timeTxt : ''}${distTxt ? ' · ' + distTxt : ''}</div>
                </div>
                <div class="popup-ride-fare">&#8369;${formatMoney(fare)}</div>
            </div>
            <div class="popup-customer-row">
                <div class="popup-avatar">${initial}</div>
                <div>
                    <div class="popup-customer-name">${escHtml(r.customer_name || 'Passenger')}</div>
                    <div class="popup-service">${escHtml(r.service_name || 'Ride')} · tap Accept to see contact</div>
                </div>
            </div>
            <div class="popup-route">
                <div class="popup-route-spine">
                    <div class="popup-dot-green"></div>
                    <div class="popup-spine-line"></div>
                    <div class="popup-dot-red"></div>
                </div>
                <div class="popup-route-labels">
                    <div>
                        <div class="popup-route-lbl">Pickup</div>
                        <div class="popup-route-val">${escHtml(pickup)}</div>
                    </div>
                    <div>
                        <div class="popup-route-lbl">Destination</div>
                        <div class="popup-route-val">${escHtml(dropoff)}</div>
                    </div>
                </div>
            </div>
            <div class="popup-action-row">
                <button class="popup-btn-accept" onclick="popupRespond(${r.booking_id}, 'accept', this)">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    Accept
                </button>
                <button class="popup-btn-skip" onclick="popupRespond(${r.booking_id}, 'decline', this)">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    Skip
                </button>
            </div>
        </div>`;
    }).join('');
}

// ── Accept / Skip from inside the popup ──────────────────────────────────────
async function popupRespond(bookingId, action, btn) {
    const card  = document.getElementById('popup-card-' + bookingId);
    const label = action === 'accept' ? 'Accept' : 'Skip';

    if (!confirm((action === 'accept' ? 'Accept' : 'Skip') + ' this booking?')) return;

    // Disable both buttons in this card
    if (card) card.querySelectorAll('button').forEach(b => { b.disabled = true; b.style.opacity = '0.6'; });

    try {
        const res  = await fetch('respond_booking.php', {
            method:  'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body:    `booking_id=${bookingId}&action=${action}`
        });
        const data = await res.json();

        if (data.success) {
            // Slide out the card
            if (card) {
                card.style.transition = 'all 0.3s ease';
                card.style.opacity    = '0';
                card.style.transform  = 'translateX(40px)';
                setTimeout(() => card.remove(), 300);
            }

            // If accepted, reload the page after a moment so the dashboard stats refresh
            if (action === 'accept') {
                setTimeout(() => location.reload(), 600);
            }
        } else {
            alert(data.message || 'Something went wrong.');
            if (card) card.querySelectorAll('button').forEach(b => { b.disabled = false; b.style.opacity = '1'; });
        }
    } catch (err) {
        alert('Network error. Please try again.');
        if (card) card.querySelectorAll('button').forEach(b => { b.disabled = false; b.style.opacity = '1'; });
    }
}

// ── Polling — fetch pending rides every 8 seconds ─────────────────────────────
async function pollPendingRides() {
    try {
        const res  = await fetch('pending_bookings_api.php');
        const data = await res.json();

        const count    = data.count    || 0;
        const rides    = data.bookings || [];
        _popupRides    = rides;

        // Update bell badge
        const badge = document.getElementById('notif-count-badge');
        if (count > 0) {
            badge.textContent    = count;
            badge.style.display  = 'flex';
        } else {
            badge.style.display  = 'none';
        }

        // Update "Available Rides" stat on the dashboard
        const statEl = document.getElementById('dash-pending-count');
        if (statEl) statEl.textContent = count;

        // Update module subtitle
        const modSub = document.getElementById('mod-sub-bookings');
        if (modSub) modSub.textContent = count + ' available';

        // If the popup is open, re-render it live
        if (_popupOpen) renderPopupRides(rides);

        // Auto-open the popup once when new rides appear (only on first detection)
        if (!_autoOpened && count > 0 && _prevCount === 0) {
            _autoOpened = true;
            openPopup();
        }

        _prevCount = count;

    } catch (e) {
        // Silent fail — network issue
    }
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function escHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function formatMoney(n) {
    return Math.round(n).toLocaleString();
}
function formatDate(d) {
    if (!d) return '';
    const parts = d.split('-');
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return months[parseInt(parts[1]) - 1] + ' ' + parseInt(parts[2]);
}
function formatTime(t) {
    if (!t) return '';
    const [h, m] = t.split(':');
    const hour   = parseInt(h);
    const ampm   = hour >= 12 ? 'PM' : 'AM';
    return (hour % 12 || 12) + ':' + m + ' ' + ampm;
}

// Start polling immediately, then every 8 seconds
pollPendingRides();
_pollTimer = setInterval(pollPendingRides, 8000);
</script>

</body>
</html>