<?php
/**
 * driver_location_update.php
 * Called by the driver's app/page to push their live GPS coordinates.
 * Place in: C:\xampp\htdocs\CORETRANSACTION2\driver\
 *
 * Also contains the SQL to create the core_driver_locations table (run once).
 *
 * POST params:
 *   driver_id  — int
 *   latitude   — float
 *   longitude  — float
 *   (session auth OR a driver_token can be used)
 */
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php'; // driver/ → ../config/

// ── Auth: accept session-based driver login ──
if (!isset($_SESSION['driver_id']) && !isset($_POST['driver_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$driver_id = (int)($_SESSION['driver_id'] ?? $_POST['driver_id'] ?? 0);
$latitude  = (float)($_POST['latitude']  ?? 0);
$longitude = (float)($_POST['longitude'] ?? 0);

if (!$driver_id || !$latitude || !$longitude) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $pdo = getDatabaseConnection();

    // ── Auto-create table if it doesn't exist ──
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `core_driver_locations` (
            `location_id` int(11) NOT NULL AUTO_INCREMENT,
            `driver_id`   bigint(20) NOT NULL,
            `latitude`    decimal(10,7) NOT NULL,
            `longitude`   decimal(10,7) NOT NULL,
            `accuracy`    float DEFAULT NULL,
            `updated_at`  timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`location_id`),
            UNIQUE KEY `driver_id` (`driver_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    // ── Upsert location (one row per driver, always updated) ──
    $stmt = $pdo->prepare("
        INSERT INTO core_driver_locations (driver_id, latitude, longitude)
        VALUES (:did, :lat, :lng)
        ON DUPLICATE KEY UPDATE
            latitude   = VALUES(latitude),
            longitude  = VALUES(longitude),
            updated_at = NOW()
    ");
    $stmt->execute([
        ':did' => $driver_id,
        ':lat' => $latitude,
        ':lng' => $longitude,
    ]);

    echo json_encode(['success' => true, 'driver_id' => $driver_id]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}