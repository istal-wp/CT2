<?php
/**
 * respond_booking.php
 * Driver accepts or declines a Pending booking from the open pool.
 * Called via POST (AJAX) from dashboard.php popup and my_bookings.php.
 * Place in: C:\xampp\htdocs\CORETRANSACTION2\driver\
 */
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}
if (strtolower($_SESSION['role']) !== 'driver') {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

require_once __DIR__ . '/../config/database.php';

$driver_id  = (int) $_SESSION['user_id'];
$booking_id = (int) ($_POST['booking_id'] ?? 0);
$action     = trim($_POST['action'] ?? '');

if (!$booking_id || !in_array($action, ['accept', 'decline'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

try {
    $pdo = getDatabaseConnection();
    $pdo->beginTransaction();

    // Lock-read the booking to prevent two drivers claiming simultaneously
    $chk = $pdo->prepare("
        SELECT b.booking_status, r.driver_id AS ride_driver
        FROM   core_bookings b
        LEFT JOIN core_rides r ON r.booking_id = b.booking_id
        WHERE  b.booking_id = ?
        LIMIT  1
        FOR UPDATE
    ");
    $chk->execute([$booking_id]);
    $row = $chk->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Booking not found']);
        exit;
    }

    if ($row['booking_status'] !== 'Pending') {
        $pdo->rollBack();
        echo json_encode([
            'success' => false,
            'message' => 'This booking is no longer available (' . $row['booking_status'] . ')'
        ]);
        exit;
    }

    if (!is_null($row['ride_driver']) && (int) $row['ride_driver'] !== 0) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Another driver already claimed this booking']);
        exit;
    }

    if ($action === 'accept') {
        // 1. Confirm booking
        $pdo->prepare("
            UPDATE core_bookings
            SET    booking_status = 'Confirmed',
                   confirmed_by  = ?,
                   confirmed_at  = NOW(),
                   updated_at    = NOW()
            WHERE  booking_id    = ?
        ")->execute([$driver_id, $booking_id]);

        // 2. Assign driver to ride record
        $pdo->prepare("
            UPDATE core_rides
            SET    driver_id   = ?,
                   ride_status = 'Accepted'
            WHERE  booking_id  = ?
        ")->execute([$driver_id, $booking_id]);

        // 3. Log history
        $pdo->prepare("
            INSERT INTO core_booking_history
                (booking_id, change_type, field_changed, old_value, new_value, changed_by, notes)
            VALUES (?, 'Status Change', 'booking_status', 'Pending', 'Confirmed', ?, 'Accepted by driver')
        ")->execute([$booking_id, $driver_id]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Booking accepted! Head to pickup location.']);

    } else {
        // Decline — cancel the booking
        $pdo->prepare("
            UPDATE core_bookings
            SET    booking_status       = 'Cancelled',
                   cancelled_by         = ?,
                   cancelled_at         = NOW(),
                   cancellation_reason  = 'Declined by driver',
                   updated_at           = NOW()
            WHERE  booking_id           = ?
        ")->execute([$driver_id, $booking_id]);

        $pdo->prepare("
            UPDATE core_rides
            SET    ride_status = 'Cancelled'
            WHERE  booking_id  = ?
        ")->execute([$booking_id]);

        $pdo->prepare("
            INSERT INTO core_booking_history
                (booking_id, change_type, field_changed, old_value, new_value, changed_by, notes)
            VALUES (?, 'Status Change', 'booking_status', 'Pending', 'Cancelled', ?, 'Declined by driver')
        ")->execute([$booking_id, $driver_id]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Booking declined.']);
    }

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    error_log("respond_booking error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}