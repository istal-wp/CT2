<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Only allow drivers
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (strtolower($_SESSION['role']) !== 'driver') {
    header('Location: ../auth/login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDatabaseConnection();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$driver_id = $_SESSION['user_id'];

// ── Filters ────────────────────────────────────────────────────────────────
$filterStatus = $_GET['status'] ?? 'all';
$filterDate   = $_GET['date'] ?? 'all';
$searchQuery  = $_GET['search'] ?? '';

// Date range
$dateCondition = '';
$dateParams = [];
switch ($filterDate) {
    case 'today':
        $dateCondition = "AND DATE(r.start_time) = CURDATE()";
        break;
    case 'yesterday':
        $dateCondition = "AND DATE(r.start_time) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
        break;
    case 'week':
        $dateCondition = "AND r.start_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        break;
    case 'month':
        $dateCondition = "AND r.start_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        break;
}

// Status filter
$statusCondition = '';
if ($filterStatus !== 'all') {
    $statusCondition = "AND r.ride_status = :status";
    $dateParams['status'] = ucfirst($filterStatus);
}

// Search filter
$searchCondition = '';
if (!empty($searchQuery)) {
    $searchCondition = "AND (c.name LIKE :search OR r.start_location LIKE :search OR r.end_location LIKE :search OR b.booking_reference LIKE :search)";
    $dateParams['search'] = '%' . $searchQuery . '%';
}

// ── Statistics ────────────────────────────────────────────────────────────
try {
    // Total trips
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_rides WHERE driver_id = :did");
    $stmt->execute(['did' => $driver_id]);
    $totalTrips = $stmt->fetch()['total'] ?? 0;

    // Completed trips
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_rides WHERE driver_id = :did AND ride_status = 'Completed'");
    $stmt->execute(['did' => $driver_id]);
    $completedTrips = $stmt->fetch()['total'] ?? 0;

    // In Progress trips
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_rides WHERE driver_id = :did AND ride_status = 'In Progress'");
    $stmt->execute(['did' => $driver_id]);
    $inProgressTrips = $stmt->fetch()['total'] ?? 0;

    // Cancelled trips
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_rides WHERE driver_id = :did AND ride_status = 'Cancelled'");
    $stmt->execute(['did' => $driver_id]);
    $cancelledTrips = $stmt->fetch()['total'] ?? 0;

    // Total earnings (all time)
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(fc.total_fare), 0) as total
        FROM core_rides r
        LEFT JOIN core_fare_computation fc ON r.booking_id = fc.booking_id
        WHERE r.driver_id = :did AND r.ride_status = 'Completed'
    ");
    $stmt->execute(['did' => $driver_id]);
    $totalEarnings = $stmt->fetch()['total'] ?? 0;

    // Fetch trips with filters
    $sql = "
        SELECT
            r.ride_id,
            r.booking_id,
            r.start_time,
            r.end_time,
            r.start_location,
            r.end_location,
            r.ride_status,
            c.name as customer_name,
            c.phone as customer_phone,
            c.email as customer_email,
            b.booking_reference,
            v.vehicle_make,
            v.vehicle_model,
            v.license_plate,
            COALESCE(fc.total_fare, 0) as fare,
            COALESCE(fc.base_fare, 0) as base_fare,
            COALESCE(fc.distance_km, 0) as distance_km,
            COALESCE(rt.rating_value, 0) as rating,
            rt.feedback
        FROM core_rides r
        LEFT JOIN core_customers c ON r.customer_id = c.customer_id
        LEFT JOIN core_bookings b ON r.booking_id = b.booking_id
        LEFT JOIN core_vehicles v ON r.vehicle_id = v.vehicle_id
        LEFT JOIN core_fare_computation fc ON r.booking_id = fc.booking_id
        LEFT JOIN core_ratings rt ON r.ride_id = rt.ride_id
        WHERE r.driver_id = :did
        {$dateCondition}
        {$statusCondition}
        {$searchCondition}
        ORDER BY r.start_time DESC
        LIMIT 50
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_merge(['did' => $driver_id], $dateParams));
    $trips = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("My Trips query error: " . $e->getMessage());
    $trips = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>My Trips - EnviroCab Driver</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        :root {
            --primary-green: #00D084;
            --dark-green: #00A86B;
            --bg-gradient: linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --white: #FFFFFF;
            --text-dark: #1A202C;
            --text-medium: #4A5568;
            --text-light: #718096;
            --border: #E2E8F0;
            --accent-blue: #60A5FA;
            --accent-purple: #C084FC;
            --accent-yellow: #FBBF24;
            --accent-pink: #F472B6;
            --accent-orange: #FB923C;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 90px;
            -webkit-font-smoothing: antialiased;
        }

        /* ── Header ── */
        .header {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.5);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .back-btn {
            width: 36px;
            height: 36px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .back-btn svg { stroke: var(--text-medium); }
        .back-btn:active { transform: scale(0.95); }

        .header-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-dark);
        }

        .header-actions {
            display: flex;
            gap: 8px;
        }

        .icon-btn {
            width: 36px;
            height: 36px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .icon-btn svg { stroke: var(--text-medium); }
        .icon-btn:active { transform: scale(0.95); }

        /* ── Main ── */
        .main-content { padding: 20px; }

        /* ── Stats Overview ── */
        .stats-overview {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }

        .stat-icon-circle {
            width: 44px;
            height: 44px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stat-value { 
            font-size: 32px; 
            font-weight: 800; 
            color: var(--text-dark); 
            margin-bottom: 4px;
            line-height: 1;
        }
        .stat-label { font-size: 13px; color: var(--text-light); font-weight: 500; }

        /* ── Filter Bar ── */
        .filter-bar {
            background: white;
            border-radius: 20px;
            padding: 16px;
            border: 1px solid var(--border);
            margin-bottom: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .filter-row {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
        }

        .filter-row:last-child { margin-bottom: 0; }

        .filter-select {
            flex: 1;
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            background: rgba(0, 0, 0, 0.02);
            cursor: pointer;
            transition: all 0.2s;
        }

        .filter-select:focus {
            outline: none;
            border-color: var(--primary-green);
            background: white;
        }

        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: rgba(0, 0, 0, 0.02);
        }

        .search-box svg { stroke: var(--text-light); flex-shrink: 0; }

        .search-input {
            flex: 1;
            border: none;
            background: none;
            font-size: 13px;
            font-weight: 500;
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
        }

        .search-input:focus { outline: none; }

        .search-input::placeholder { color: var(--text-light); }

        .btn-filter {
            padding: 10px 18px;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            font-family: 'Inter', sans-serif;
            transition: all 0.2s;
            white-space: nowrap;
        }

        .btn-filter:active { transform: scale(0.97); }

        /* ── Trip Cards ── */
        .trips-list { display: flex; flex-direction: column; gap: 12px; }

        .trip-card {
            background: white;
            border-radius: 20px;
            padding: 18px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            cursor: pointer;
            transition: all 0.2s;
        }

        .trip-card:active { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); }

        .trip-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .trip-customer {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .customer-avatar {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
            font-weight: 700;
            flex-shrink: 0;
        }

        .customer-info { flex: 1; }
        .customer-name { font-size: 15px; font-weight: 700; color: var(--text-dark); margin-bottom: 2px; }
        .trip-reference { font-size: 12px; color: var(--text-light); }

        .trip-badge-group {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 6px;
        }

        .status-pill {
            font-size: 11px;
            font-weight: 700;
            padding: 6px 12px;
            border-radius: 8px;
            white-space: nowrap;
        }

        .status-completed { background: rgba(16,185,129,0.15);  color: #10B981; }
        .status-in.progress { background: rgba(96,165,250,0.15);  color: #3B82F6; }
        .status-cancelled { background: rgba(239,68,68,0.15);   color: #EF4444; }
        .status-requested { background: rgba(251,191,36,0.15);  color: #D97706; }
        .status-accepted { background: rgba(192,132,252,0.15);  color: #C084FC; }

        .trip-fare {
            font-size: 16px;
            font-weight: 800;
            color: var(--primary-green);
        }

        .trip-route {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 12px;
            padding: 12px;
            background: rgba(0, 0, 0, 0.02);
            border-radius: 12px;
        }

        .route-icon {
            width: 32px;
            height: 32px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .route-details { flex: 1; }
        .route-location { 
            font-size: 13px; 
            font-weight: 600; 
            color: var(--text-dark); 
            margin-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .route-arrow { color: var(--text-light); font-size: 14px; }

        .trip-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 8px;
            padding-top: 12px;
            border-top: 1px solid var(--border);
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            color: var(--text-medium);
        }

        .meta-item svg { stroke: var(--text-light); }

        .trip-rating {
            display: flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            background: rgba(251, 191, 36, 0.15);
            border-radius: 8px;
        }

        .trip-rating svg { fill: #D97706; stroke: none; }
        .rating-value { font-size: 12px; font-weight: 700; color: #D97706; }

        /* ── Empty State ── */
        .empty-state {
            background: white;
            border-radius: 20px;
            padding: 48px 24px;
            border: 1px solid var(--border);
            text-align: center;
        }

        .empty-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 16px;
            border-radius: 20px;
            background: rgba(0, 0, 0, 0.03);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .empty-icon svg { stroke: var(--text-light); opacity: 0.5; }

        .empty-title { font-size: 18px; font-weight: 700; color: var(--text-dark); margin-bottom: 8px; }
        .empty-subtitle { font-size: 14px; color: var(--text-light); }

        /* ── Bottom Nav ── */
        .bottom-nav {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            padding: 12px 0 20px;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            z-index: 99;
            box-shadow: 0 -4px 24px rgba(0, 0, 0, 0.05);
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            padding: 8px;
            cursor: pointer;
            border: none;
            background: none;
            transition: all 0.2s;
        }

        .nav-item:active { transform: scale(0.95); }

        .nav-icon {
            width: 48px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .nav-icon svg { stroke: var(--text-light); opacity: 0.5; transition: all 0.2s; }
        .nav-item.active .nav-icon svg { stroke: var(--primary-green); opacity: 1; }

        .nav-label { font-size: 11px; font-weight: 600; color: var(--text-light); opacity: 0.7; }
        .nav-item.active .nav-label { color: var(--primary-green); opacity: 1; }

        /* ── Animations ── */
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .stat-card, .filter-bar, .trip-card { animation: slideUp 0.4s ease forwards; }

        @media (min-width: 768px) {
            body { max-width: 480px; margin: 0 auto; box-shadow: 0 0 40px rgba(0, 0, 0, 0.1); }
        }
    </style>
</head>
<body>

<!-- ── Header ── -->
<div class="header">
    <div class="header-content">
        <button class="back-btn" onclick="window.location.href='dashboard.php'">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
        </button>
        <div class="header-title">My Trips</div>
        <div class="header-actions">
            <button class="icon-btn" onclick="window.location.reload()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
                </svg>
            </button>
        </div>
    </div>
</div>

<!-- ── Main Content ── -->
<div class="main-content">

    <!-- Stats Overview -->
    <div class="stats-overview">
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(16, 185, 129, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="1" y="3" width="15" height="13"></rect>
                        <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                        <circle cx="5.5" cy="18.5" r="2.5"></circle>
                        <circle cx="18.5" cy="18.5" r="2.5"></circle>
                    </svg>
                </div>
            </div>
            <div class="stat-value"><?= $totalTrips; ?></div>
            <div class="stat-label">Total Trips</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(96, 165, 250, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                    </svg>
                </div>
            </div>
            <div class="stat-value"><?= $completedTrips; ?></div>
            <div class="stat-label">Completed</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(251, 191, 36, 0.15); font-size: 20px; font-weight: 800; color: #D97706; font-family: 'Inter', sans-serif;">
                    ₱
                </div>
            </div>
            <div class="stat-value">₱<?= number_format($totalEarnings / 1000, 1); ?>K</div>
            <div class="stat-label">Total Earnings</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(239, 68, 68, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="15" y1="9" x2="9" y2="15"></line>
                        <line x1="9" y1="9" x2="15" y2="15"></line>
                    </svg>
                </div>
            </div>
            <div class="stat-value"><?= $cancelledTrips; ?></div>
            <div class="stat-label">Cancelled</div>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="filter-bar">
        <form method="GET" action="" id="filterForm">
            <div class="filter-row">
                <select name="status" class="filter-select" onchange="document.getElementById('filterForm').submit()">
                    <option value="all" <?= $filterStatus === 'all' ? 'selected' : '' ?>>All Status</option>
                    <option value="completed" <?= $filterStatus === 'completed' ? 'selected' : '' ?>>Completed</option>
                    <option value="in progress" <?= $filterStatus === 'in progress' ? 'selected' : '' ?>>In Progress</option>
                    <option value="cancelled" <?= $filterStatus === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    <option value="requested" <?= $filterStatus === 'requested' ? 'selected' : '' ?>>Requested</option>
                    <option value="accepted" <?= $filterStatus === 'accepted' ? 'selected' : '' ?>>Accepted</option>
                </select>

                <select name="date" class="filter-select" onchange="document.getElementById('filterForm').submit()">
                    <option value="all" <?= $filterDate === 'all' ? 'selected' : '' ?>>All Time</option>
                    <option value="today" <?= $filterDate === 'today' ? 'selected' : '' ?>>Today</option>
                    <option value="yesterday" <?= $filterDate === 'yesterday' ? 'selected' : '' ?>>Yesterday</option>
                    <option value="week" <?= $filterDate === 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                    <option value="month" <?= $filterDate === 'month' ? 'selected' : '' ?>>Last 30 Days</option>
                </select>
            </div>

            <div class="filter-row">
                <div class="search-box" style="flex: 1;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                    <input type="text" name="search" class="search-input" placeholder="Search trips, customer, location..." value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
                <button type="submit" class="btn-filter">Filter</button>
            </div>
        </form>
    </div>

    <!-- Trips List -->
    <div class="trips-list">
        <?php if (!empty($trips)): ?>
            <?php foreach ($trips as $trip): 
                $statusClass = strtolower(str_replace(' ', '.', $trip['ride_status']));
                $initials = strtoupper(substr($trip['customer_name'] ?? 'P', 0, 1));
                $duration = '';
                if ($trip['end_time']) {
                    $start = new DateTime($trip['start_time']);
                    $end = new DateTime($trip['end_time']);
                    $diff = $start->diff($end);
                    $duration = $diff->h > 0 ? $diff->h . 'h ' . $diff->i . 'm' : $diff->i . 'm';
                }
            ?>
            <div class="trip-card" onclick="viewTripDetails(<?= $trip['ride_id'] ?>)">
                <div class="trip-header">
                    <div class="trip-customer">
                        <div class="customer-avatar"><?= $initials ?></div>
                        <div class="customer-info">
                            <div class="customer-name"><?= htmlspecialchars($trip['customer_name'] ?? 'Passenger') ?></div>
                            <div class="trip-reference"><?= htmlspecialchars($trip['booking_reference'] ?? 'Ride #' . $trip['ride_id']) ?></div>
                        </div>
                    </div>
                    <div class="trip-badge-group">
                        <span class="status-pill status-<?= $statusClass ?>"><?= $trip['ride_status'] ?></span>
                        <div class="trip-fare">₱<?= number_format($trip['fare'], 0) ?></div>
                    </div>
                </div>

                <div class="trip-route">
                    <div class="route-icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                    </div>
                    <div class="route-details">
                        <div class="route-location">
                            <span>📍</span>
                            <?= htmlspecialchars(substr($trip['start_location'], 0, 35)) ?><?= strlen($trip['start_location']) > 35 ? '...' : '' ?>
                        </div>
                        <div class="route-arrow">↓</div>
                        <div class="route-location">
                            <span>🎯</span>
                            <?= htmlspecialchars(substr($trip['end_location'] ?? 'Destination', 0, 35)) ?><?= strlen($trip['end_location'] ?? '') > 35 ? '...' : '' ?>
                        </div>
                    </div>
                </div>

                <div class="trip-meta">
                    <div class="meta-item">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                        <?= date('M j, Y • g:i A', strtotime($trip['start_time'])) ?>
                    </div>

                    <?php if ($duration): ?>
                    <div class="meta-item">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                        </svg>
                        <?= $duration ?>
                    </div>
                    <?php endif; ?>

                    <?php if ($trip['distance_km'] > 0): ?>
                    <div class="meta-item">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                        <?= number_format($trip['distance_km'], 1) ?> km
                    </div>
                    <?php endif; ?>

                    <?php if ($trip['rating'] > 0): ?>
                    <div class="trip-rating">
                        <svg width="14" height="14" viewBox="0 0 24 24">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                        </svg>
                        <span class="rating-value"><?= number_format($trip['rating'], 1) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="1" y="3" width="15" height="13"></rect>
                        <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                        <circle cx="5.5" cy="18.5" r="2.5"></circle>
                        <circle cx="18.5" cy="18.5" r="2.5"></circle>
                    </svg>
                </div>
                <div class="empty-title">No Trips Found</div>
                <div class="empty-subtitle">
                    <?php if (!empty($searchQuery) || $filterStatus !== 'all' || $filterDate !== 'all'): ?>
                        Try adjusting your filters to see more results
                    <?php else: ?>
                        Your completed trips will appear here
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- ── Bottom Navigation ── -->
<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
        </div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="window.location.href='my_bookings.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
        </div>
        <span class="nav-label">Bookings</span>
    </button>
    <button class="nav-item active">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
            </svg>
        </div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item" onclick="window.location.href='driver_profile.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
        </div>
        <span class="nav-label">Profile</span>
    </button>
</div>

<script>
    function viewTripDetails(rideId) {
        // Redirect to trip details page (create this page next)
        window.location.href = 'trip_details.php?ride_id=' + rideId;
    }
</script>

</body>
</html>