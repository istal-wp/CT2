<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Only allow drivers
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (strtolower($_SESSION['role']) !== 'driver') {
    header('Location: ../auth/login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDatabaseConnection();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$driver_id = $_SESSION['user_id'];

// ── Filters ────────────────────────────────────────────────────────────────
$filterStatus   = $_GET['status'] ?? 'all';
$filterSeverity = $_GET['severity'] ?? 'all';
$filterType     = $_GET['type'] ?? 'all';
$filterDate     = $_GET['date'] ?? 'all';
$searchQuery    = $_GET['search'] ?? '';

// Date range
$dateCondition = '';
$params = ['did' => $driver_id];
switch ($filterDate) {
    case 'today':
        $dateCondition = "AND DATE(r.reported_at) = CURDATE()";
        break;
    case 'week':
        $dateCondition = "AND r.reported_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        break;
    case 'month':
        $dateCondition = "AND r.reported_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        break;
    case '3months':
        $dateCondition = "AND r.reported_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)";
        break;
}

// Status filter
$statusCondition = '';
if ($filterStatus !== 'all') {
    $statusCondition = "AND r.status = :status";
    $params['status'] = ucwords(str_replace('_', ' ', $filterStatus));
}

// Severity filter
$severityCondition = '';
if ($filterSeverity !== 'all') {
    $severityCondition = "AND r.severity = :severity";
    $params['severity'] = ucfirst($filterSeverity);
}

// Type filter
$typeCondition = '';
if ($filterType !== 'all') {
    $typeCondition = "AND r.report_type = :type";
    $params['type'] = ucwords(str_replace('_', ' ', $filterType));
}

// Search filter
$searchCondition = '';
if (!empty($searchQuery)) {
    $searchCondition = "AND (c.name LIKE :search OR r.description LIKE :search OR ride.start_location LIKE :search)";
    $params['search'] = '%' . $searchQuery . '%';
}

// ── Statistics ────────────────────────────────────────────────────────────
try {
    // Total reports
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_reports WHERE driver_id = :did");
    $stmt->execute(['did' => $driver_id]);
    $totalReports = $stmt->fetch()['total'] ?? 0;

    // Open reports
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_reports WHERE driver_id = :did AND status = 'Open'");
    $stmt->execute(['did' => $driver_id]);
    $openReports = $stmt->fetch()['total'] ?? 0;

    // Under Review reports
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_reports WHERE driver_id = :did AND status = 'Under Review'");
    $stmt->execute(['did' => $driver_id]);
    $underReviewReports = $stmt->fetch()['total'] ?? 0;

    // Resolved reports
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_reports WHERE driver_id = :did AND status = 'Resolved'");
    $stmt->execute(['did' => $driver_id]);
    $resolvedReports = $stmt->fetch()['total'] ?? 0;

    // Critical severity reports
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM core_reports WHERE driver_id = :did AND severity = 'Critical' AND status IN ('Open', 'Under Review')");
    $stmt->execute(['did' => $driver_id]);
    $criticalReports = $stmt->fetch()['total'] ?? 0;

    // Reports by type breakdown
    $stmt = $pdo->prepare("
        SELECT 
            report_type,
            COUNT(*) as count
        FROM core_reports 
        WHERE driver_id = :did
        GROUP BY report_type
        ORDER BY count DESC
    ");
    $stmt->execute(['did' => $driver_id]);
    $reportsByType = $stmt->fetchAll();

    // Fetch reports with filters
    $sql = "
        SELECT
            r.report_id,
            r.report_type,
            r.description,
            r.severity,
            r.status,
            r.reported_at,
            r.resolved_at,
            c.name as customer_name,
            c.phone as customer_phone,
            ride.ride_id,
            ride.start_location,
            ride.end_location,
            ride.start_time,
            b.booking_reference
        FROM core_reports r
        LEFT JOIN core_customers c ON r.customer_id = c.customer_id
        LEFT JOIN core_rides ride ON r.ride_id = ride.ride_id
        LEFT JOIN core_bookings b ON r.booking_id = b.booking_id
        WHERE r.driver_id = :did
        {$dateCondition}
        {$statusCondition}
        {$severityCondition}
        {$typeCondition}
        {$searchCondition}
        ORDER BY r.reported_at DESC
        LIMIT 50
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $reports = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("My Reports query error: " . $e->getMessage());
    $reports = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>My Audit Logs - EnviroCab Driver</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        :root {
            --primary-green: #00D084;
            --dark-green: #00A86B;
            --bg-gradient: linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --white: #FFFFFF;
            --text-dark: #1A202C;
            --text-medium: #4A5568;
            --text-light: #718096;
            --border: #E2E8F0;
            --accent-blue: #60A5FA;
            --accent-purple: #C084FC;
            --accent-yellow: #FBBF24;
            --accent-pink: #F472B6;
            --accent-orange: #FB923C;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 90px;
            -webkit-font-smoothing: antialiased;
        }

        /* ── Header ── */
        .header {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.5);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .back-btn {
            width: 36px;
            height: 36px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .back-btn svg { stroke: var(--text-medium); }
        .back-btn:active { transform: scale(0.95); }

        .header-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-dark);
        }

        .header-actions {
            display: flex;
            gap: 8px;
        }

        .icon-btn {
            width: 36px;
            height: 36px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .icon-btn svg { stroke: var(--text-medium); }
        .icon-btn:active { transform: scale(0.95); }

        /* ── Main ── */
        .main-content { padding: 20px; }

        /* ── Alert Banner (if critical reports exist) ── */
        .alert-banner {
            background: linear-gradient(135deg, #EF4444, #DC2626);
            border-radius: 20px;
            padding: 20px;
            color: white;
            margin-bottom: 20px;
            box-shadow: 0 4px 16px rgba(239, 68, 68, 0.3);
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .alert-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            background: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .alert-content { flex: 1; }
        .alert-title { font-size: 16px; font-weight: 700; margin-bottom: 4px; }
        .alert-subtitle { font-size: 13px; opacity: 0.9; }

        /* ── Stats Grid ── */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }

        .stat-icon-circle {
            width: 44px;
            height: 44px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stat-value { 
            font-size: 32px; 
            font-weight: 800; 
            color: var(--text-dark); 
            margin-bottom: 4px;
            line-height: 1;
        }
        .stat-label { font-size: 13px; color: var(--text-light); font-weight: 500; }

        .trend-badge { 
            font-size: 11px; 
            font-weight: 700; 
            padding: 4px 10px; 
            border-radius: 8px;
        }
        .trend-critical { background: rgba(239, 68, 68, 0.15); color: #EF4444; }
        .trend-warning { background: rgba(251, 191, 36, 0.15); color: #D97706; }
        .trend-good { background: rgba(16, 185, 129, 0.15); color: #10B981; }

        /* ── Report Type Summary ── */
        .summary-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            margin-bottom: 20px;
        }

        .summary-title { font-size: 18px; font-weight: 700; margin-bottom: 20px; color: var(--text-dark); }

        .summary-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px;
            background: rgba(0, 0, 0, 0.02);
            border-radius: 12px;
            margin-bottom: 8px;
        }

        .summary-row:last-child { margin-bottom: 0; }

        .summary-label { font-size: 14px; font-weight: 600; color: var(--text-medium); }
        .summary-count { 
            font-size: 16px; 
            font-weight: 800; 
            color: var(--text-dark);
            padding: 4px 12px;
            background: rgba(0, 0, 0, 0.05);
            border-radius: 8px;
        }

        /* ── Filter Bar ── */
        .filter-bar {
            background: white;
            border-radius: 20px;
            padding: 16px;
            border: 1px solid var(--border);
            margin-bottom: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .filter-row {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
        }

        .filter-row:last-child { margin-bottom: 0; }

        .filter-select {
            flex: 1;
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            background: rgba(0, 0, 0, 0.02);
            cursor: pointer;
            transition: all 0.2s;
        }

        .filter-select:focus {
            outline: none;
            border-color: var(--primary-green);
            background: white;
        }

        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: rgba(0, 0, 0, 0.02);
        }

        .search-box svg { stroke: var(--text-light); flex-shrink: 0; }

        .search-input {
            flex: 1;
            border: none;
            background: none;
            font-size: 13px;
            font-weight: 500;
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
        }

        .search-input:focus { outline: none; }
        .search-input::placeholder { color: var(--text-light); }

        .btn-filter {
            padding: 10px 18px;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            font-family: 'Inter', sans-serif;
            transition: all 0.2s;
            white-space: nowrap;
        }

        .btn-filter:active { transform: scale(0.97); }

        /* ── Report Cards ── */
        .reports-list { display: flex; flex-direction: column; gap: 12px; }

        .report-card {
            background: white;
            border-radius: 20px;
            padding: 18px;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            transition: all 0.2s;
        }

        .report-card.severity-critical { border-left: 4px solid #EF4444; }
        .report-card.severity-high { border-left: 4px solid #F97316; }
        .report-card.severity-medium { border-left: 4px solid #F59E0B; }
        .report-card.severity-low { border-left: 4px solid #10B981; }

        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .report-type-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            font-size: 24px;
        }

        .report-info { flex: 1; margin-left: 12px; }
        .report-type { font-size: 15px; font-weight: 700; color: var(--text-dark); margin-bottom: 2px; }
        .report-date { font-size: 12px; color: var(--text-light); }

        .report-badges {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 6px;
        }

        .severity-badge, .status-badge {
            font-size: 11px;
            font-weight: 700;
            padding: 6px 12px;
            border-radius: 8px;
            white-space: nowrap;
        }

        .severity-critical { background: rgba(239, 68, 68, 0.15); color: #EF4444; }
        .severity-high { background: rgba(251, 146, 60, 0.15); color: #F97316; }
        .severity-medium { background: rgba(251, 191, 36, 0.15); color: #D97706; }
        .severity-low { background: rgba(16, 185, 129, 0.15); color: #10B981; }

        .status-open { background: rgba(239, 68, 68, 0.15); color: #EF4444; }
        .status-under.review { background: rgba(251, 191, 36, 0.15); color: #D97706; }
        .status-resolved { background: rgba(16, 185, 129, 0.15); color: #10B981; }
        .status-closed { background: rgba(96, 165, 250, 0.15); color: #3B82F6; }

        .report-description {
            padding: 12px;
            background: rgba(0, 0, 0, 0.02);
            border-radius: 12px;
            margin-bottom: 12px;
        }

        .description-text {
            font-size: 14px;
            color: var(--text-medium);
            line-height: 1.6;
        }

        .report-trip-info {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-top: 12px;
            border-top: 1px solid var(--border);
            font-size: 12px;
        }

        .trip-customer {
            display: flex;
            align-items: center;
            gap: 6px;
            color: var(--text-medium);
        }

        .trip-location {
            color: var(--text-light);
        }

        /* ── Empty State ── */
        .empty-state {
            background: white;
            border-radius: 20px;
            padding: 48px 24px;
            border: 1px solid var(--border);
            text-align: center;
        }

        .empty-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 16px;
            border-radius: 20px;
            background: rgba(16, 185, 129, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .empty-icon svg { stroke: #10B981; }
        .empty-title { font-size: 18px; font-weight: 700; color: var(--text-dark); margin-bottom: 8px; }
        .empty-subtitle { font-size: 14px; color: var(--text-light); }

        /* ── Bottom Nav ── */
        .bottom-nav {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            padding: 12px 0 20px;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            z-index: 99;
            box-shadow: 0 -4px 24px rgba(0, 0, 0, 0.05);
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            padding: 8px;
            cursor: pointer;
            border: none;
            background: none;
            transition: all 0.2s;
        }

        .nav-item:active { transform: scale(0.95); }

        .nav-icon {
            width: 48px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .nav-icon svg { stroke: var(--text-light); opacity: 0.5; transition: all 0.2s; }
        .nav-item.active .nav-icon svg { stroke: var(--primary-green); opacity: 1; }

        .nav-label { font-size: 11px; font-weight: 600; color: var(--text-light); opacity: 0.7; }
        .nav-item.active .nav-label { color: var(--primary-green); opacity: 1; }

        /* ── Animations ── */
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .alert-banner, .stat-card, .summary-card, .filter-bar, .report-card { 
            animation: slideUp 0.4s ease forwards; 
        }

        @media (min-width: 768px) {
            body { max-width: 480px; margin: 0 auto; box-shadow: 0 0 40px rgba(0, 0, 0, 0.1); }
        }
    </style>
</head>
<body>

<!-- ── Header ── -->
<div class="header">
    <div class="header-content">
        <button class="back-btn" onclick="window.location.href='dashboard.php'">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
        </button>
        <div class="header-title">My Audit Logs</div>
        <div class="header-actions">
            <button class="icon-btn" onclick="window.location.reload()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
                </svg>
            </button>
        </div>
    </div>
</div>

<!-- ── Main Content ── -->
<div class="main-content">

    <?php if ($criticalReports > 0): ?>
    <!-- Critical Alert Banner -->
    <div class="alert-banner">
        <div class="alert-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                <line x1="12" y1="9" x2="12" y2="13"></line>
                <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
        </div>
        <div class="alert-content">
            <div class="alert-title">⚠️ Critical Reports Pending</div>
            <div class="alert-subtitle"><?= $criticalReports ?> critical report<?= $criticalReports != 1 ? 's' : '' ?> requiring immediate attention</div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(239, 68, 68, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                </div>
                <?php if ($openReports > 0): ?>
                <div class="trend-badge trend-critical"><?= $openReports ?> open</div>
                <?php endif; ?>
            </div>
            <div class="stat-value"><?= $totalReports ?></div>
            <div class="stat-label">Total Reports</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(251, 191, 36, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#D97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                </div>
                <?php if ($underReviewReports > 0): ?>
                <div class="trend-badge trend-warning">Review</div>
                <?php endif; ?>
            </div>
            <div class="stat-value"><?= $underReviewReports ?></div>
            <div class="stat-label">Under Review</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(16, 185, 129, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                </div>
                <div class="trend-badge trend-good">Resolved</div>
            </div>
            <div class="stat-value"><?= $resolvedReports ?></div>
            <div class="stat-label">Resolved</div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon-circle" style="background: rgba(239, 68, 68, 0.15);">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                        <line x1="12" y1="9" x2="12" y2="13"></line>
                        <line x1="12" y1="17" x2="12.01" y2="17"></line>
                    </svg>
                </div>
            </div>
            <div class="stat-value"><?= $criticalReports ?></div>
            <div class="stat-label">Critical</div>
        </div>
    </div>

    <?php if (!empty($reportsByType)): ?>
    <!-- Report Type Summary -->
    <div class="summary-card">
        <div class="summary-title">Reports by Type</div>
        <?php foreach ($reportsByType as $typeReport): ?>
        <div class="summary-row">
            <div class="summary-label"><?= htmlspecialchars($typeReport['report_type']) ?></div>
            <div class="summary-count"><?= $typeReport['count'] ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Filter Bar -->
    <div class="filter-bar">
        <form method="GET" action="" id="filterForm">
            <div class="filter-row">
                <select name="status" class="filter-select" onchange="document.getElementById('filterForm').submit()">
                    <option value="all" <?= $filterStatus === 'all' ? 'selected' : '' ?>>All Status</option>
                    <option value="open" <?= $filterStatus === 'open' ? 'selected' : '' ?>>Open</option>
                    <option value="under_review" <?= $filterStatus === 'under_review' ? 'selected' : '' ?>>Under Review</option>
                    <option value="resolved" <?= $filterStatus === 'resolved' ? 'selected' : '' ?>>Resolved</option>
                    <option value="closed" <?= $filterStatus === 'closed' ? 'selected' : '' ?>>Closed</option>
                </select>

                <select name="severity" class="filter-select" onchange="document.getElementById('filterForm').submit()">
                    <option value="all" <?= $filterSeverity === 'all' ? 'selected' : '' ?>>All Severity</option>
                    <option value="critical" <?= $filterSeverity === 'critical' ? 'selected' : '' ?>>Critical</option>
                    <option value="high" <?= $filterSeverity === 'high' ? 'selected' : '' ?>>High</option>
                    <option value="medium" <?= $filterSeverity === 'medium' ? 'selected' : '' ?>>Medium</option>
                    <option value="low" <?= $filterSeverity === 'low' ? 'selected' : '' ?>>Low</option>
                </select>
            </div>

            <div class="filter-row">
                <select name="type" class="filter-select" onchange="document.getElementById('filterForm').submit()">
                    <option value="all" <?= $filterType === 'all' ? 'selected' : '' ?>>All Types</option>
                    <option value="safety_concern" <?= $filterType === 'safety_concern' ? 'selected' : '' ?>>Safety Concern</option>
                    <option value="poor_service" <?= $filterType === 'poor_service' ? 'selected' : '' ?>>Poor Service</option>
                    <option value="vehicle_issue" <?= $filterType === 'vehicle_issue' ? 'selected' : '' ?>>Vehicle Issue</option>
                    <option value="driver_behavior" <?= $filterType === 'driver_behavior' ? 'selected' : '' ?>>Driver Behavior</option>
                    <option value="payment_issue" <?= $filterType === 'payment_issue' ? 'selected' : '' ?>>Payment Issue</option>
                    <option value="other" <?= $filterType === 'other' ? 'selected' : '' ?>>Other</option>
                </select>

                <select name="date" class="filter-select" onchange="document.getElementById('filterForm').submit()">
                    <option value="all" <?= $filterDate === 'all' ? 'selected' : '' ?>>All Time</option>
                    <option value="today" <?= $filterDate === 'today' ? 'selected' : '' ?>>Today</option>
                    <option value="week" <?= $filterDate === 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                    <option value="month" <?= $filterDate === 'month' ? 'selected' : '' ?>>Last 30 Days</option>
                    <option value="3months" <?= $filterDate === '3months' ? 'selected' : '' ?>>Last 3 Months</option>
                </select>
            </div>

            <div class="filter-row">
                <div class="search-box" style="flex: 1;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                    <input type="text" name="search" class="search-input" placeholder="Search reports, customer, description..." value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
                <button type="submit" class="btn-filter">Filter</button>
            </div>
        </form>
    </div>

    <!-- Reports List -->
    <div class="reports-list">
        <?php if (!empty($reports)): ?>
            <?php foreach ($reports as $report): 
                $severityClass = strtolower($report['severity']);
                $statusClass = strtolower(str_replace(' ', '.', $report['status']));
                
                // Icon emoji based on report type
                $iconMap = [
                    'Safety Concern' => '⚠️',
                    'Poor Service' => '😟',
                    'Vehicle Issue' => '🚗',
                    'Driver Behavior' => '👤',
                    'Payment Issue' => '💳',
                    'Other' => '📝'
                ];
                $icon = $iconMap[$report['report_type']] ?? '📋';
            ?>
            <div class="report-card severity-<?= $severityClass ?>">
                <div class="report-header">
                    <div class="report-type-icon" style="background: rgba(0, 0, 0, 0.05);">
                        <?= $icon ?>
                    </div>
                    <div class="report-info">
                        <div class="report-type"><?= htmlspecialchars($report['report_type']) ?></div>
                        <div class="report-date"><?= date('M j, Y • g:i A', strtotime($report['reported_at'])) ?></div>
                    </div>
                    <div class="report-badges">
                        <span class="severity-badge severity-<?= $severityClass ?>"><?= $report['severity'] ?></span>
                        <span class="status-badge status-<?= $statusClass ?>"><?= $report['status'] ?></span>
                    </div>
                </div>

                <div class="report-description">
                    <div class="description-text"><?= htmlspecialchars($report['description']) ?></div>
                </div>

                <div class="report-trip-info">
                    <div class="trip-customer">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                        <?= htmlspecialchars($report['customer_name'] ?? 'Passenger') ?>
                    </div>
                    <?php if ($report['booking_reference']): ?>
                    <div class="trip-location"><?= htmlspecialchars($report['booking_reference']) ?></div>
                    <?php endif; ?>
                </div>

                <?php if ($report['resolved_at']): ?>
                <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid var(--border); font-size: 12px; color: #10B981;">
                    ✓ Resolved on <?= date('M j, Y', strtotime($report['resolved_at'])) ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                </div>
                <div class="empty-title">
                    <?php if (!empty($searchQuery) || $filterStatus !== 'all' || $filterSeverity !== 'all' || $filterType !== 'all' || $filterDate !== 'all'): ?>
                        No Reports Found
                    <?php else: ?>
                        No Reports Yet - Great Job! 🎉
                    <?php endif; ?>
                </div>
                <div class="empty-subtitle">
                    <?php if (!empty($searchQuery) || $filterStatus !== 'all' || $filterSeverity !== 'all' || $filterType !== 'all' || $filterDate !== 'all'): ?>
                        Try adjusting your filters to see more results
                    <?php else: ?>
                        You have a clean record with no reports filed against you
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- ── Bottom Navigation ── -->
<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
        </div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="window.location.href='my_bookings.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
        </div>
        <span class="nav-label">Bookings</span>
    </button>
    <button class="nav-item" onclick="window.location.href='my_trips.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
            </svg>
        </div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item active">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
        </div>
        <span class="nav-label">Profile</span>
    </button>
</div>

</body>
</html>