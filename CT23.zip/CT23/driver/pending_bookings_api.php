<?php
/**
 * pending_bookings_api.php
 * Returns all unclaimed Pending bookings for the driver popup notification.
 * Polled every 8 seconds by dashboard.php JavaScript.
 * Place in: C:\xampp\htdocs\CORETRANSACTION2\driver\
 */
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized', 'count' => 0, 'bookings' => []]);
    exit;
}
if (strtolower($_SESSION['role']) !== 'driver') {
    echo json_encode(['error' => 'Access denied', 'count' => 0, 'bookings' => []]);
    exit;
}

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDatabaseConnection();

    $stmt = $pdo->query("
        SELECT
            b.booking_id,
            b.booking_reference,
            b.booking_date,
            b.booking_time,
            b.created_at,
            COALESCE(fc.total_fare, b.total_amount, 0) AS fare,
            fc.distance_km,
            c.name          AS customer_name,
            r.start_location,
            r.end_location,
            s.service_name
        FROM core_bookings b
        LEFT JOIN core_rides r             ON r.booking_id  = b.booking_id
        LEFT JOIN core_customers c         ON c.customer_id = b.customer_id
        LEFT JOIN core_services s          ON s.service_id  = b.service_id
        LEFT JOIN core_fare_computation fc ON fc.booking_id = b.booking_id
        WHERE b.booking_status = 'Pending'
          AND (r.driver_id IS NULL OR r.driver_id = 0)
        ORDER BY b.created_at DESC
    ");

    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['count' => count($bookings), 'bookings' => $bookings]);

} catch (Exception $e) {
    error_log("pending_bookings_api: " . $e->getMessage());
    echo json_encode(['count' => 0, 'bookings' => []]);
}