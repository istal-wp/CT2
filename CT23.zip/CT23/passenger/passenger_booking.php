<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['customer_id'])) {
    header('Location: ../auth/passenger_login.php');
    exit;
}




define('SUPABASE_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');





define('SUPABASE_SERVICE_KEY', getenv('SUPABASE_SERVICE_KEY') ?: 'YOUR_SERVICE_ROLE_KEY_HERE');

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) return json_decode($res, true) ?: [];
    error_log("SB GET {$table} HTTP {$code}: {$res}");
    return [];
}


$_sb_last_error = null;

function sb_post(string $table, array $data): ?array {
    global $_sb_last_error;
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) {
        $r = json_decode($res, true);
        return is_array($r) ? ($r[0] ?? null) : null;
    }
    $decoded = json_decode($res, true);
    $_sb_last_error = ($decoded['message'] ?? $decoded['hint'] ?? $decoded['details'] ?? $res);
    error_log("SB POST {$table} HTTP {$code}: {$res}");
    return null;
}




function sb_post_service(string $table, array $data): ?array {
    global $_sb_last_error;
    $key = (defined('SUPABASE_SERVICE_KEY') && SUPABASE_SERVICE_KEY !== 'YOUR_SERVICE_ROLE_KEY_HERE')
         ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . $key,
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) {
        $r = json_decode($res, true);
        return is_array($r) ? ($r[0] ?? null) : null;
    }
    $decoded = json_decode($res, true);
    $_sb_last_error = ($decoded['message'] ?? $decoded['hint'] ?? $decoded['details'] ?? $res);
    error_log("SB POST svc {$table} HTTP {$code}: {$res}");
    return null;
}



function sb_patch_service(string $table, array $filters, array $data): bool {
    $key = (defined('SUPABASE_SERVICE_KEY') && SUPABASE_SERVICE_KEY !== 'YOUR_SERVICE_ROLE_KEY_HERE')
         ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . $key,
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code < 200 || $code >= 300) {
        error_log("SB PATCH svc {$table} HTTP {$code}: {$res}");
        return false;
    }
    return true;
}

function sb_patch(string $table, array $filters, array $data): bool {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code < 200 || $code >= 300) { error_log("SB PATCH {$table} HTTP {$code}: {$res}"); return false; }
    return true;
}

$customer_id = $_SESSION['customer_id'];





$ajax_action = $_POST['ajax_action'] ?? ($_GET['ajax_action'] ?? '');


if ($ajax_action === 'debug_status') {
    header('Content-Type: application/json');
    $booking_id = (int)($_GET['booking_id'] ?? 0);
    if (!$booking_id) { echo json_encode(['error'=>'Missing booking_id']); exit; }

    $b  = sb_get('core2_bookings', ['booking_id'=>'eq.'.$booking_id,'select'=>'booking_id,booking_status,payment_status,customer_id']);
    $r  = sb_get('core2_rides',    ['booking_id'=>'eq.'.$booking_id,'select'=>'ride_id,ride_status,driver_id,start_time']);
    $ride = $r[0] ?? [];

    $driver=$c1trips_ride=$c1trips_driver=[];
    if (!empty($ride['driver_id'])) {
        $d = sb_get('core1_drivers', ['core2_driver_id'=>'eq.'.$ride['driver_id'],'select'=>'id,driver_name,core2_driver_id']);
        $driver = $d[0] ?? [];
        if (!empty($ride['ride_id']))
            $c1trips_ride = sb_get('core1_trips',['ride_id'=>'eq.'.(int)$ride['ride_id'],'select'=>'id,status,ride_id,driver_id,created_at']);
        if (!empty($driver['id']))
            $c1trips_driver = sb_get('core1_trips',['driver_id'=>'eq.'.(int)$driver['id'],'select'=>'id,status,ride_id,created_at','order'=>'created_at.desc','limit'=>'5']);
    }

    echo json_encode([
        'booking'              => $b[0] ?? null,
        'ride'                 => $ride,
        'core1_driver'         => $driver,
        'c1trips_by_ride_id'   => $c1trips_ride,
        'c1trips_by_driver'    => $c1trips_driver,
    ], JSON_PRETTY_PRINT);
    exit;
}


if ($ajax_action === 'force_complete') {
    header('Content-Type: application/json');
    $booking_id = (int)($_POST['booking_id'] ?? $_GET['booking_id'] ?? 0);
    if (!$booking_id) { echo json_encode(['error'=>'Missing booking_id']); exit; }

    $b_rows = sb_get('core2_bookings', [
        'booking_id'  => 'eq.' . $booking_id,
        'customer_id' => 'eq.' . $customer_id,
        'select'      => 'booking_id,booking_status,total_amount',
    ]);
    if (empty($b_rows)) { echo json_encode(['error'=>'Booking not found']); exit; }
    $b = $b_rows[0];
    if ($b['booking_status'] === 'Completed') { echo json_encode(['success'=>true,'already'=>true]); exit; }

    $r_rows = sb_get('core2_rides', ['booking_id'=>'eq.'.$booking_id,'select'=>'ride_id,ride_status']);
    $r = $r_rows[0] ?? [];

    if (!empty($r['ride_id'])) {
        sb_patch_service('core2_rides',
            ['ride_id' => 'eq.' . $r['ride_id']],
            ['ride_status' => 'Completed', 'end_time' => date('c')]
        );
    }
    sb_patch_service('core2_bookings',
        ['booking_id' => 'eq.' . $booking_id],
        ['booking_status' => 'Completed', 'payment_status' => 'Paid', 'updated_at' => date('c')]
    );

    echo json_encode(['success'=>true, 'total_amount'=>$b['total_amount']]);
    exit;
}

if ($ajax_action === 'booking_status') {
    header('Content-Type: application/json');
    $booking_id = (int)($_GET['booking_id'] ?? 0);
    if (!$booking_id) { echo json_encode(['error' => 'Missing booking_id']); exit; }

    $b_rows = sb_get('core2_bookings', [
        'booking_id'  => 'eq.' . $booking_id,
        'customer_id' => 'eq.' . $customer_id,
        'select'      => 'booking_id,booking_reference,booking_status,total_amount,payment_status',
    ]);
    if (empty($b_rows)) { echo json_encode(['error' => 'Booking not found']); exit; }
    $b = $b_rows[0];

    $r_rows = sb_get('core2_rides', [
        'booking_id' => 'eq.' . $booking_id,
        'select'     => 'ride_id,ride_status,start_location,end_location,driver_id,start_time',
    ]);
    $r = $r_rows[0] ?? [];

    
    
    
    
    
    if (
        $b['booking_status'] === 'Pending' &&
        !empty($r) &&
        ($r['ride_status'] ?? '') === 'Cancelled' &&
        empty($r['driver_id'])   
    ) {
        sb_patch_service('core2_bookings',
            ['booking_id' => 'eq.' . $booking_id],
            ['booking_status' => 'Cancelled', 'updated_at' => date('c')]
        );
        sb_post_service('core2_booking_history', [
            'booking_id'    => $booking_id,
            'change_type'   => 'Cancelled',
            'field_changed' => 'booking_status',
            'old_value'     => 'Pending',
            'new_value'     => 'Cancelled',
            'changed_by'    => null,
            'notes'         => 'No available driver — trip was rejected/cancelled by driver.',
        ]);
        $b['booking_status'] = 'Cancelled';
        echo json_encode([
            'booking_id'     => $b['booking_id'],
            'booking_ref'    => $b['booking_reference'],
            'status'         => 'Rejected',
            'booking_status' => 'Cancelled',
            'ride_status'    => 'Cancelled',
            'rejected'       => true,
            'total_amount'   => $b['total_amount'],
            'payment_status' => $b['payment_status'],
            'driver_name'    => null,
            'driver_contact' => null,
            'vehicle'        => null,
            'driver_lat'     => null,
            'driver_lng'     => null,
            'core1_driver_id'=> null,
        ]);
        exit;
    }

    
    
    $driver_name    = null;
    $driver_contact = null;
    $vehicle_info   = null;
    $driver_lat     = null;
    $driver_lng     = null;
    $core1_driver_id = null;
    $driver_status  = '';
    if (!empty($r['driver_id'])) {
        $d_rows = sb_get('core1_drivers', [
            'core2_driver_id' => 'eq.' . $r['driver_id'],
            'select'          => 'id,driver_name,phone,current_lat,current_lng,status',
        ]);
        if (!empty($d_rows)) {
            $driver_name     = $d_rows[0]['driver_name']  ?? null;
            $driver_contact  = $d_rows[0]['phone']        ?? null;
            $driver_lat      = $d_rows[0]['current_lat']  ?? null;
            $driver_lng      = $d_rows[0]['current_lng']  ?? null;
            $core1_driver_id = $d_rows[0]['id']           ?? null;
            $driver_status   = strtolower($d_rows[0]['status'] ?? '');
        }
    }

    
    
    
    
    $rideStatus = $r['ride_status'] ?? '';

    if ($rideStatus !== 'Completed' && $rideStatus !== 'Cancelled') {
        $tripDone = null;

        
        if (!empty($r['ride_id'])) {
            $byRide = sb_get('core1_trips', [
                'ride_id' => 'eq.' . (int)$r['ride_id'],
                'status'  => 'eq.COMPLETED',
                'select'  => 'id,ride_id',
                'limit'   => '1',
            ]);
            if (!empty($byRide)) $tripDone = $byRide[0];
        }

        
        
        
        
        $rideAssigned = in_array($r['ride_status'] ?? '', ['Accepted', 'In Progress', 'Completed']);
        if (!$tripDone && !empty($core1_driver_id) && !empty($r['start_time']) && $rideAssigned) {
            $anchor    = date('Y-m-d H:i:s', strtotime($r['start_time']) - 300);
            $anchorEnd = date('Y-m-d H:i:s', strtotime($r['start_time']) + 14400);
            $byDriver = sb_get('core1_trips', [
                'driver_id'  => 'eq.' . (int)$core1_driver_id,
                'status'     => 'eq.COMPLETED',
                'created_at' => 'gte.' . $anchor,
                'created_at' => 'lte.' . $anchorEnd,
                'select'     => 'id,ride_id',
                'order'      => 'created_at.desc',
                'limit'      => '1',
            ]);
            if (!empty($byDriver)) $tripDone = $byDriver[0];
        }

        if ($tripDone) {
            $rideStatus = 'Completed';
            
            if (empty($tripDone['ride_id']) && !empty($r['ride_id'])) {
                sb_patch_service('core1_trips', ['id' => 'eq.' . $tripDone['id']], ['ride_id' => (int)$r['ride_id']]);
            }
        }

        
        
        if ($rideStatus !== 'Completed' && $driver_status !== '') {
            
            $driverOnTrip = in_array($driver_status, [
                'in progress','in_progress','on_trip','in_trip','busy','driving','on trip','in trip'
            ]);
            $driverAccepted = ($driver_status === 'in progress');
            
            if ($driverAccepted && in_array($rideStatus, ['Requested',''])) {
                $rideStatus = 'Accepted';
            } elseif ($driverOnTrip && $rideStatus !== 'In Progress') {
                $rideStatus = 'In Progress';
            }
        }
    }

    if ($rideStatus === 'Completed') {
        if (!empty($r['ride_id']) && ($r['ride_status'] ?? '') !== 'Completed') {
            sb_patch_service('core2_rides',
                ['ride_id' => 'eq.' . $r['ride_id']],
                ['ride_status' => 'Completed', 'end_time' => date('c')]
            );
        }
        if ($b['booking_status'] !== 'Completed') {
            sb_patch_service('core2_bookings',
                ['booking_id' => 'eq.' . $booking_id],
                ['booking_status' => 'Completed', 'payment_status' => 'Paid', 'updated_at' => date('c')]
            );
            $b['booking_status'] = 'Completed';
            $b['payment_status'] = 'Paid';
        }
        sb_patch_service('core2_payment_authorization',
            ['booking_id' => 'eq.' . $booking_id],
            ['payment_status' => 'Captured']
        );
    }

    
    
    
    if ($rideStatus === 'Accepted' && $b['booking_status'] === 'Pending') {
        sb_patch_service('core2_bookings',
            ['booking_id' => 'eq.' . $booking_id],
            ['booking_status' => 'Confirmed', 'updated_at' => date('c')]
        );
        $b['booking_status'] = 'Confirmed';
    }
    if ($rideStatus === 'In Progress' && in_array($b['booking_status'], ['Pending','Confirmed'])) {
        sb_patch_service('core2_bookings',
            ['booking_id' => 'eq.' . $booking_id],
            ['booking_status' => 'In Progress', 'updated_at' => date('c')]
        );
        $b['booking_status'] = 'In Progress';
    }

    $statusMap = [
        'Requested'   => 'Pending',
        'Accepted'    => 'Confirmed',
        'In Progress' => 'In Progress',
        'Completed'   => 'Completed',
        'Cancelled'   => 'Cancelled',
    ];
    $effectiveStatus = $statusMap[$rideStatus] ?? $b['booking_status'];

    echo json_encode([
        'booking_id'     => $b['booking_id'],
        'booking_ref'    => $b['booking_reference'],
        'status'         => $effectiveStatus,
        'booking_status' => $b['booking_status'],
        'ride_status'    => $rideStatus,
        'total_amount'   => $b['total_amount'],
        'payment_status' => $b['payment_status'],
        'driver_name'    => $driver_name,
        'driver_contact' => $driver_contact,
        'vehicle'        => $vehicle_info,
        'driver_lat'     => $driver_lat !== null ? (float)$driver_lat : null,
        'driver_status'  => $driver_status,
        'driver_lng'     => $driver_lng !== null ? (float)$driver_lng : null,
        'core1_driver_id'=> $core1_driver_id,
    ]);
    exit;
}


if ($ajax_action === 'cancel_booking') {
    header('Content-Type: application/json');
    $booking_id = (int)($_POST['booking_id'] ?? 0);
    if (!$booking_id) { echo json_encode(['success' => false, 'message' => 'Missing booking_id']); exit; }

    
    $b_rows = sb_get('core2_bookings', [
        'booking_id'  => 'eq.' . $booking_id,
        'customer_id' => 'eq.' . $customer_id,
        'select'      => 'booking_id,booking_status',
    ]);
    $bk = $b_rows[0] ?? null;
    if (!$bk || !in_array($bk['booking_status'], ['Pending', 'Confirmed', 'In Progress'])) {
        echo json_encode(['success' => false, 'message' => 'Booking cannot be cancelled.']); exit;
    }
    $oldStatus = $bk['booking_status'];

    
    $patched = sb_patch_service('core2_bookings', ['booking_id' => 'eq.' . $booking_id], [
        'booking_status' => 'Cancelled',
        'cancelled_by'   => (int)$customer_id,
        'cancelled_at'   => date('c'),
        'updated_at'     => date('c'),
    ]);

    if (!$patched) {
        echo json_encode(['success' => false, 'message' => 'Failed to cancel. Please try again.']);
        exit;
    }

    sb_patch_service('core2_rides', ['booking_id' => 'eq.' . $booking_id], [
        'ride_status' => 'Cancelled',
    ]);

    
    sb_post_service('core2_booking_history', [
        'booking_id'    => $booking_id,
        'change_type'   => 'Cancelled',
        'field_changed' => 'booking_status',
        'old_value'     => $oldStatus,
        'new_value'     => 'Cancelled',
        'changed_by'    => (int)$customer_id,
        'notes'         => 'Cancelled by passenger',
    ]);

    echo json_encode(['success' => true, 'message' => 'Booking cancelled.']);
    exit;
}


if ($ajax_action === 'complete_booking') {
    header('Content-Type: application/json');
    $booking_id      = (int)($_POST['booking_id'] ?? 0);
    $core2_driver_id = (int)($_POST['driver_id']  ?? 0);
    if (!$booking_id || !$core2_driver_id) {
        echo json_encode(['success' => false, 'message' => 'Missing parameters']); exit;
    }

    $b_rows = sb_get('core2_bookings', [
        'booking_id' => 'eq.' . $booking_id,
        'select'     => 'booking_id,booking_reference,booking_status,total_amount,payment_status',
    ]);
    $b = $b_rows[0] ?? null;
    if (!$b || !in_array($b['booking_status'], ['Pending', 'Confirmed', 'In Progress'])) {
        echo json_encode(['success' => false, 'message' => 'Booking not in completable state.']); exit;
    }
    $oldStatus = $b['booking_status'];

    $r_rows = sb_get('core2_rides', [
        'booking_id' => 'eq.' . $booking_id,
        'select'     => 'ride_id,start_location,end_location,driver_id',
    ]);
    $r = $r_rows[0] ?? [];

    
    $cust_rows = sb_get('core2_customers', [
        'customer_id' => 'eq.' . $customer_id,
        'select'      => 'name',
    ]);
    $passenger_name = $cust_rows[0]['name'] ?? 'Passenger';

    sb_patch_service('core2_bookings', ['booking_id' => 'eq.' . $booking_id], [
        'booking_status' => 'Completed',
        'payment_status' => ($b['payment_status'] === 'Unpaid') ? 'Paid' : $b['payment_status'],
        'updated_at'     => date('c'),
    ]);

    sb_patch_service('core2_rides', ['booking_id' => 'eq.' . $booking_id], [
        'ride_status' => 'Completed',
        'end_time'    => date('c'),
    ]);

    sb_post_service('core2_booking_history', [
        'booking_id'    => $booking_id,
        'change_type'   => 'Status Change',
        'field_changed' => 'booking_status',
        'old_value'     => $oldStatus,
        'new_value'     => 'Completed',
        'changed_by'    => (int)$core2_driver_id,
        'notes'         => 'Trip completed by driver',
    ]);

    $row = array_merge($b, $r, ['passenger_name' => $passenger_name, 'ride_driver_id' => $core2_driver_id]);
    $synced = _syncToCore1Trips($row, $core2_driver_id);

    echo json_encode(['success' => true, 'message' => 'Trip completed.', 'core1_synced' => $synced]);
    exit;
}




function _syncToCore1Trips(array $row, int $core2DriverId = 0): bool {
    $driverId = $core2DriverId ?: (int)($row['ride_driver_id'] ?? $row['driver_id'] ?? 0);
    if (!$driverId || empty($row['ride_id'])) return false;

    
    $check = sb_get('core1_trips', ['ride_id' => 'eq.' . $row['ride_id'], 'select' => 'id']);
    if (!empty($check)) return false;

    
    $d_rows = sb_get('core1_drivers', [
        'core2_driver_id' => 'eq.' . $driverId,
        'select'          => 'id,wallet_balance',
    ]);
    if (empty($d_rows)) return false;
    $core1DriverId = (int)$d_rows[0]['id'];
    $currentBal    = (float)($d_rows[0]['wallet_balance'] ?? 0);

    $trip_id       = 'T-' . strtoupper(substr(md5(uniqid()), 0, 8));
    $passengerName = $row['passenger_name'] ?? 'Passenger';
    $origin        = $row['start_location'] ?? 'Unknown';
    $destination   = $row['end_location']   ?? 'Unknown';
    $earnings      = (float)($row['total_amount'] ?? 0);

    
    $pay_rows = sb_get('core2_payment_authorization', [
        'booking_id' => 'eq.' . $row['booking_id'],
        'select'     => 'payment_method',
        'order'      => 'created_at.desc',
        'limit'      => '1',
    ]);
    $payMap = ['E-Wallet' => 'E-WALLET', 'Cash' => 'CASH', 'Credit Card' => 'CARD', 'Debit Card' => 'CARD'];
    $c1Pay  = $payMap[$pay_rows[0]['payment_method'] ?? ''] ?? 'CASH';

    sb_post_service('core1_trips', [
        'trip_id'        => $trip_id,
        'driver_id'      => $core1DriverId,
        'passenger_name' => $passengerName,
        'origin'         => $origin,
        'destination'    => $destination,
        'earnings'       => $earnings,
        'status'         => 'COMPLETED',
        'payment_method' => $c1Pay,
        'ride_id'        => (int)$row['ride_id'],
    ]);

    $newBal = $currentBal + $earnings;
    sb_patch_service('core1_drivers', ['id' => 'eq.' . $core1DriverId], [
        'wallet_balance' => $newBal,
    ]);

    sb_post_service('core1_wallet_transactions', [
        'driver_id'     => $core1DriverId,
        'type'          => 'TRIP_EARNING',
        'amount'        => $earnings,
        'balance_after' => $newBal,
        'description'   => 'Trip earning — ' . ($row['booking_reference'] ?? ''),
    ]);

    return true;
}





$success_message = '';
$error_message   = '';
$booking_result  = null;


$services = sb_get('core2_services', ['status' => 'eq.Active', 'order' => 'service_name.asc']);
if (empty($services)) {
    sb_post_service('core2_services', [
        'service_code'     => 'TAXI-01',
        'service_name'     => 'Taxi',
        'service_category' => 'Transportation',
        'description'      => 'Standard metered taxi service',
        'unit_price'       => 50.00,
        'currency'         => 'PHP',
        'capacity'         => 4,
        'status'           => 'Active',
    ]);
    $services = sb_get('core2_services', ['status' => 'eq.Active', 'order' => 'service_name.asc']);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_booking') {

    
    $activeRows = sb_get('core2_bookings', [
        'customer_id'    => 'eq.' . $customer_id,
        'booking_status' => 'in.(Pending,Confirmed,In Progress)',
        'select'         => 'booking_id,booking_reference,booking_status',
        'order'          => 'created_at.desc',
        'limit'          => '1',
    ]);
    $activeBooking = $activeRows[0] ?? null;

    if ($activeBooking) {
        $error_message = sprintf(
            'You already have an active booking (%s — %s). Please wait for it to complete or cancel it before booking again.',
            htmlspecialchars($activeBooking['booking_reference']),
            htmlspecialchars($activeBooking['booking_status'])
        );
    } else {
        $service_id        = (int)($_POST['service_id'] ?? 0);
        $pickup_location   = trim($_POST['pickup_location']  ?? '');
        $destination       = trim($_POST['destination']      ?? '');
        $booking_date      = trim($_POST['booking_date']     ?? '');
        $booking_time      = trim($_POST['booking_time']     ?? '');
        $payment_method    = trim($_POST['payment_method']   ?? 'Cash');
        $payment_method_db = ($payment_method === 'GCash') ? 'E-Wallet' : $payment_method;
        $quantity          = max(1, (int)($_POST['quantity'] ?? 1));
        $special_req       = trim($_POST['special_requirements'] ?? '');
        $vehicle_fuel      = trim($_POST['vehicle_fuel'] ?? '');
        $ride_type         = trim($_POST['ride_type'] ?? 'Now');
        $pickup_lat        = trim($_POST['pickup_lat'] ?? '');
        $pickup_lng        = trim($_POST['pickup_lng'] ?? '');
        $dest_lat          = trim($_POST['dest_lat']   ?? '');
        $dest_lng          = trim($_POST['dest_lng']   ?? '');
        
        $pickup_loc  = ($pickup_lat !== '' && $pickup_lng !== '') ? $pickup_lat . ',' . $pickup_lng : null;
        $droppff_loc = ($dest_lat   !== '' && $dest_lng   !== '') ? $dest_lat   . ',' . $dest_lng   : null;

        
        if ($ride_type === 'Now' || $booking_date === '') {
            $booking_date = date('Y-m-d');
            $booking_time = date('H:i');
        }

        if (!$pickup_location || !$destination || !$vehicle_fuel) {
            $error_message = 'Please fill in all required fields including vehicle type.';
        } else {
            
            $service = null;
            if ($service_id) {
                $sv = sb_get('core2_services', ['service_id' => 'eq.' . $service_id, 'select' => '*']);
                $service = $sv[0] ?? null;
            }
            if (!$service && !empty($services)) $service = $services[0];
            if (!$service) {
                $service = sb_post_service('core2_services', [
                    'service_code' => 'TAXI-01', 'service_name' => 'Taxi',
                    'service_category' => 'Transportation',
                    'description' => 'Standard metered taxi service',
                    'unit_price' => 50.00, 'currency' => 'PHP', 'capacity' => 4, 'status' => 'Active',
                ]);
            }
            $service_id    = (int)($service['service_id'] ?? 0);
            $base_fare     = (float)($service['unit_price'] ?? 50.00);
            $distance_km_post = (float)($_POST['distance_km'] ?? 0);
            $distance_km   = ($distance_km_post > 0) ? round($distance_km_post, 2) : 10.0;

            if ($vehicle_fuel === 'Electric') {
                $distance_rate = 10.00;
                
            } else {
                $distance_rate = 12.00;
            }

            $surge_mult = 1.00;

            $total_amount = round(($base_fare + $distance_km * $distance_rate) * $quantity, 2);
            $booking_ref  = 'BK-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));

            
            $newBooking = sb_post_service('core2_bookings', [
                'booking_reference'    => $booking_ref,
                'customer_id'          => (int)$customer_id,
                'booking_date'         => $booking_date,
                'booking_time'         => $booking_time ?: null,
                'service_id'           => $service_id,
                'quantity'             => $quantity,
                'total_amount'         => $total_amount,
                'currency'             => 'PHP',
                'booking_status'       => 'Pending',
                'payment_status'       => 'Unpaid',
                'special_requirements' => $special_req ?: null,
                'pickup_loc'           => $pickup_loc,
                'droppff_loc'          => $droppff_loc,
                'created_by'           => (int)$customer_id,
            ]);
            $booking_id = (int)($newBooking['booking_id'] ?? 0);

            if ($booking_id) {
                
                sb_post_service('core2_rides', [
                    'booking_id'     => $booking_id,
                    'customer_id'    => (int)$customer_id,
                    'driver_id'      => null,
                    'start_time'     => $booking_date . 'T' . (strlen($booking_time) === 5 ? $booking_time . ':00' : ($booking_time ?: '00:00:00')),
                    'start_location' => $pickup_location,
                    'end_location'   => $destination,
                    'ride_status'    => 'Requested',
                ]);

                
                sb_post_service('core2_fare_computation', [
                    'booking_id'        => $booking_id,
                    'base_fare'         => $base_fare,
                    'distance_km'       => $distance_km,
                    'distance_rate'     => $distance_rate,
                    'surge_multiplier'  => $surge_mult,
                    'additional_charges'=> 0,
                    'discount'          => 0,
                    'total_fare'        => $total_amount,
                    'currency'          => 'PHP',
                ]);

                
                sb_post_service('core2_payment_authorization', [
                    'booking_id'     => $booking_id,
                    'payment_method' => $payment_method_db,
                    'payment_status' => 'Pending',
                    'amount'         => $total_amount,
                    'currency'       => 'PHP',
                ]);

                
                sb_post_service('core2_booking_history', [
                    'booking_id'    => $booking_id,
                    'change_type'   => 'Created',
                    'field_changed' => 'booking_status',
                    'old_value'     => null,
                    'new_value'     => 'Pending',
                    'changed_by'    => (int)$customer_id,
                    'notes'         => 'Booking created by passenger — awaiting driver acceptance',
                ]);

                $booking_result = [
                    'booking_ref'    => $booking_ref,
                    'booking_id'     => $booking_id,
                    'service_name'   => $service['service_name'] ?? 'Taxi',
                    'total_amount'   => $total_amount,
                    'pickup'         => $pickup_location,
                    'destination'    => $destination,
                    'booking_date'   => $booking_date,
                    'booking_time'   => $booking_time,
                    'payment_method' => $payment_method,
                    'vehicle_fuel'   => $vehicle_fuel,
                    'distance_rate'  => $distance_rate,
                    'distance_km'    => $distance_km,
                    'base_fare'      => $base_fare,
                    'surge_mult'     => $surge_mult,
                    'status'         => 'Pending',
                ];
                $success_message = 'Booking submitted! Waiting for a driver to accept.';
            } else {
                $error_message = 'Booking failed. Please try again.' . (isset($_sb_last_error) && $_sb_last_error ? ' (' . htmlspecialchars($_sb_last_error) . ')' : '');
            }
        }
    }
}


$pbRows      = sb_get('core2_bookings', [
    'customer_id'    => 'eq.' . $customer_id,
    'booking_status' => 'eq.Pending',
    'select'         => 'booking_id',
]);
$pendingBookings = count($pbRows);

$currentHour = (int)date('H');
$greeting    = 'Good Morning';
if ($currentHour >= 12 && $currentHour < 18) $greeting = 'Good Afternoon';
elseif ($currentHour >= 18)                  $greeting = 'Good Evening';

$today_min = date('Y-m-d');
$max_date  = date('Y-m-d', strtotime('+30 days'));


if (!$booking_result && empty($error_message)) {
    $activeRows = sb_get('core2_bookings', [
        'customer_id'    => 'eq.' . $customer_id,
        'booking_status' => 'in.(Pending,Confirmed,In Progress)',
        'select'         => 'booking_id,booking_reference,booking_status,total_amount',
        'order'          => 'created_at.desc',
        'limit'          => '1',
    ]);
    if (!empty($activeRows)) {
        $existingActive = $activeRows[0];
        $rideRows = sb_get('core2_rides', [
            'booking_id' => 'eq.' . $existingActive['booking_id'],
            'select'     => 'ride_id,start_location,end_location,driver_id,ride_status,start_time',
        ]);
        $rRow = $rideRows[0] ?? [];

        
        
        
        if (
            $existingActive['booking_status'] === 'Pending' &&
            !empty($rRow) &&
            ($rRow['ride_status'] ?? '') === 'Cancelled' &&
            empty($rRow['driver_id'])
        ) {
            sb_patch_service('core2_bookings',
                ['booking_id' => 'eq.' . (int)$existingActive['booking_id']],
                ['booking_status' => 'Cancelled', 'updated_at' => date('c')]
            );
            sb_post_service('core2_booking_history', [
                'booking_id'    => (int)$existingActive['booking_id'],
                'change_type'   => 'Cancelled',
                'field_changed' => 'booking_status',
                'old_value'     => 'Pending',
                'new_value'     => 'Cancelled',
                'changed_by'    => null,
                'notes'         => 'No available driver — trip was rejected/cancelled by driver.',
            ]);
            $existingActive['booking_status'] = 'Cancelled';
            
            $error_message = '⚠️ Your previous booking (' . htmlspecialchars($existingActive['booking_reference']) . ') was rejected by the driver. Please book again.';
        }

        
        
        
        $pageRideStatus = $rRow['ride_status'] ?? '';
        if ($pageRideStatus !== 'Completed' && $pageRideStatus !== 'Cancelled' && !empty($rRow['ride_id'])) {
            
            $c1ByRide = sb_get('core1_trips', [
                'ride_id' => 'eq.' . (int)$rRow['ride_id'],
                'status'  => 'eq.COMPLETED',
                'select'  => 'id,ride_id',
                'limit'   => '1',
            ]);
            if (!empty($c1ByRide)) {
                $pageRideStatus = 'Completed';
            } elseif (
                !empty($rRow['driver_id']) &&
                !empty($rRow['start_time']) &&
                in_array($pageRideStatus, ['Accepted', 'In Progress'])
            ) {
                
                $dRows = sb_get('core1_drivers', [
                    'core2_driver_id' => 'eq.' . $rRow['driver_id'],
                    'select'          => 'id',
                ]);
                $c1did = (int)($dRows[0]['id'] ?? 0);
                if ($c1did > 0) {
                    $anchor    = date('Y-m-d H:i:s', strtotime($rRow['start_time']) - 300);
                    $anchorEnd = date('Y-m-d H:i:s', strtotime($rRow['start_time']) + 14400);
                    $c1ByDrv = sb_get('core1_trips', [
                        'driver_id'  => 'eq.' . $c1did,
                        'status'     => 'eq.COMPLETED',
                        'created_at' => 'gte.' . $anchor,
                        'created_at' => 'lte.' . $anchorEnd,
                        'select'     => 'id,ride_id',
                        'order'      => 'created_at.desc',
                        'limit'      => '1',
                    ]);
                    if (!empty($c1ByDrv)) {
                        $pageRideStatus = 'Completed';
                        if (empty($c1ByDrv[0]['ride_id'])) {
                            sb_patch_service('core1_trips', ['id' => 'eq.' . $c1ByDrv[0]['id']], ['ride_id' => (int)$rRow['ride_id']]);
                        }
                    }
                }
            }
            
            if ($pageRideStatus === 'Completed') {
                sb_patch_service('core2_rides',    ['ride_id'    => 'eq.' . (int)$rRow['ride_id']],              ['ride_status' => 'Completed', 'end_time' => date('c')]);
                sb_patch_service('core2_bookings', ['booking_id' => 'eq.' . (int)$existingActive['booking_id']], ['booking_status' => 'Completed', 'payment_status' => 'Paid', 'updated_at' => date('c')]);
                $existingActive['booking_status'] = 'Completed';
            }
        }
        
        if (!in_array($pageRideStatus, ['Completed','Cancelled'])) {
            $pgDriverStatus = strtolower($rRow['driver_status'] ?? '');
            if (empty($pgDriverStatus) && !empty($rRow['driver_id'])) {
                $pgDrvRows = sb_get('core1_drivers', [
                    'core2_driver_id' => 'eq.' . $rRow['driver_id'],
                    'select'          => 'status',
                ]);
                $pgDriverStatus = strtolower($pgDrvRows[0]['status'] ?? '');
            }
            if (in_array($pgDriverStatus, ['in progress','in_progress']) && in_array($pageRideStatus, ['Requested',''])) {
                $pageRideStatus = 'Accepted'; 
            }
        }

        
        $statusMap = ['Requested'=>'Pending','Accepted'=>'Confirmed','In Progress'=>'In Progress','Completed'=>'Completed','Cancelled'=>'Cancelled'];
        $displayStatus = $statusMap[$pageRideStatus] ?? $existingActive['booking_status'];

        
        if ($pageRideStatus === 'Accepted' && $existingActive['booking_status'] === 'Pending') {
            sb_patch_service('core2_bookings', ['booking_id' => 'eq.' . (int)$existingActive['booking_id']], ['booking_status' => 'Confirmed', 'updated_at' => date('c')]);
            $existingActive['booking_status'] = 'Confirmed';
        }
        if ($pageRideStatus === 'In Progress' && in_array($existingActive['booking_status'], ['Pending','Confirmed'])) {
            sb_patch_service('core2_bookings', ['booking_id' => 'eq.' . (int)$existingActive['booking_id']], ['booking_status' => 'In Progress', 'updated_at' => date('c')]);
            $existingActive['booking_status'] = 'In Progress';
        }

        
        if (!in_array($displayStatus, ['Completed', 'Cancelled'])) {
            $booking_result = [
                'booking_ref'    => $existingActive['booking_reference'],
                'booking_id'     => $existingActive['booking_id'],
                'service_name'   => 'Taxi',
                'total_amount'   => $existingActive['total_amount'],
                'pickup'         => $rRow['start_location'] ?? '',
                'destination'    => $rRow['end_location']   ?? '',
                'booking_date'   => '', 'booking_time'   => '',
                'payment_method' => '', 'vehicle_fuel'   => '',
                'distance_rate'  => 0,  'distance_km'    => 0,
                'base_fare'      => 0,  'surge_mult'     => 1,
                'status'         => $displayStatus,
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>EnviroCab - Book a Trip</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
    <style>
        :root,
        [data-theme="light"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --card-bg:         #FFFFFF;
            --card-border:     #E2E8F0;
            --header-bg:       rgba(255,255,255,0.85);
            --header-border:   rgba(255,255,255,0.5);
            --text-dark:       #1A202C;
            --text-medium:     #4A5568;
            --text-light:      #718096;
            --input-bg:        #FAFAFA;
            --input-border:    #E2E8F0;
            --row-border:      rgba(0,0,0,0.04);
            --nav-bg:          rgba(255,255,255,0.95);
            --icon-btn-bg:     rgba(255,255,255,0.9);
            --icon-btn-border: rgba(0,0,0,0.05);
            --shadow-card:     0 2px 8px rgba(0,0,0,0.04);
            --shadow-hero:     0 8px 32px rgba(0,208,132,0.2);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.05);
            --danger:          #EF4444;
            --accent-blue:     #60A5FA;
            --accent-orange:   #FB923C;
            --accent-yellow:   #FBBF24;
            --white:           #FFFFFF;
        }
        [data-theme="dark"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #0D1F1A 0%, #0F172A 100%);
            --card-bg:         #1A2820;
            --card-border:     #263330;
            --header-bg:       rgba(15,24,18,0.94);
            --header-border:   rgba(0,208,132,0.1);
            --text-dark:       #E8F5F1;
            --text-medium:     #9FC4AE;
            --text-light:      #607D6B;
            --input-bg:        #111E18;
            --input-border:    #263330;
            --row-border:      rgba(255,255,255,0.05);
            --nav-bg:          rgba(15,24,18,0.97);
            --icon-btn-bg:     rgba(255,255,255,0.06);
            --icon-btn-border: rgba(255,255,255,0.08);
            --shadow-card:     0 2px 12px rgba(0,0,0,0.35);
            --shadow-hero:     0 8px 40px rgba(0,208,132,0.12);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.5);
            --danger:          #EF4444;
            --accent-blue:     #60A5FA;
            --accent-orange:   #FB923C;
            --accent-yellow:   #FBBF24;
            --white:           #FFFFFF;
        }
        *::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        *, *::before, *::after { transition: background-color .3s ease, border-color .25s ease, color .2s ease, box-shadow .3s ease; }
        input, button, svg, img { transition: none; }
        input:focus { transition: border-color .15s, box-shadow .15s; }
        .submit-btn, .cancel-btn, .icon-btn, .nav-item, .fuel-tab, .pay-option, .ride-tab,
        .qty-btn, .gps-btn, .clear-btn { transition: background .2s, transform .15s, opacity .2s, border-color .2s, box-shadow .2s; }
        body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; background: var(--bg-gradient); color: var(--text-dark); min-height: 100vh; padding-bottom: 100px; -webkit-font-smoothing: antialiased;     transition:opacity .15s ease;
}
        .header { background: var(--header-bg); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); padding: 16px 20px; position: sticky; top: 0; z-index: 100; border-bottom: 1px solid var(--header-border); }
        .header-content { display:flex; justify-content:space-between; align-items:center; }
        .header-right { display:flex; align-items:center; gap:10px; }
        .header-title { font-size:18px; font-weight:700; color:var(--text-dark); }
        .icon-btn { width:36px; height:36px; border-radius:12px; background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border); display:flex; align-items:center; justify-content:center; cursor:pointer; position:relative; }
        .icon-btn svg { stroke:var(--text-medium); }
        .icon-btn:active { transform:scale(0.93); }
        .logout-btn { background:rgba(239,68,68,0.12) !important; border-color:rgba(239,68,68,0.2) !important; }
        .logout-btn svg { stroke:#EF4444 !important; }
        .icon-btn svg { stroke:var(--text-medium); }
        .icon-btn:active { transform:scale(0.93); }
        .back-btn { display:flex; align-items:center; gap:6px; font-size:14px; font-weight:600; color:var(--text-medium); cursor:pointer; border:none; background:none; padding:4px 0; }
        .back-btn svg { stroke:var(--text-medium); }
        .theme-btn { width:36px; height:36px; border-radius:12px; background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border); display:flex; align-items:center; justify-content:center; cursor:pointer; position:relative; overflow:hidden; }
        .theme-btn:active { transform:scale(0.93); }
        .t-sun, .t-moon { position:absolute; transition: opacity .35s ease, transform .4s cubic-bezier(.34,1.56,.64,1) !important; }
        [data-theme="light"] .t-sun  { opacity:1; transform:rotate(0deg) scale(1); }
        [data-theme="light"] .t-moon { opacity:0; transform:rotate(90deg) scale(.6); }
        [data-theme="dark"]  .t-sun  { opacity:0; transform:rotate(-90deg) scale(.6); }
        [data-theme="dark"]  .t-moon { opacity:1; transform:rotate(0deg) scale(1); }
        .notification-badge { position:absolute; top:6px; right:6px; width:6px; height:6px; background:#EF4444; border-radius:50%; border:2px solid var(--card-bg); }
        .main-content { padding:20px; }
        .hero-card { background: linear-gradient(135deg,var(--primary-green) 0%,var(--dark-green) 100%); border-radius:24px; padding:28px 24px; color:white; margin-bottom:20px; box-shadow:var(--shadow-hero); position:relative; overflow:hidden; }
        .hero-card::before { content:''; position:absolute; top:-50%; right:-20%; width:200px; height:200px; background:rgba(255,255,255,0.1); border-radius:50%; }
        .hero-greeting  { font-size:14px; opacity:0.9; margin-bottom:4px; position:relative; }
        .hero-title     { font-size:26px; font-weight:800; margin-bottom:6px; position:relative; }
        .hero-subtitle  { font-size:13px; opacity:0.85; position:relative; }
        .steps-bar { display:flex; align-items:center; margin-bottom:20px; background:var(--card-bg); border-radius:18px; padding:16px 20px; border:1px solid var(--card-border); box-shadow:var(--shadow-card); }
        .step-item { display:flex; flex-direction:column; align-items:center; flex:1; gap:6px; }
        .step-circle { width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:13px; font-weight:700; }
        .step-circle.done   { background:var(--primary-green); color:white; }
        .step-circle.active { background:var(--dark-green); color:white; box-shadow:0 0 0 4px rgba(0,208,132,0.2); }
        .step-circle.pending{ background:var(--input-border); color:var(--text-light); }
        .step-label { font-size:10px; font-weight:600; color:var(--text-light); text-align:center; }
        .step-label.active-label { color:var(--dark-green); }
        .step-connector { flex:1; height:2px; background:var(--input-border); margin:0 4px; margin-bottom:20px; }
        .step-connector.done { background:var(--primary-green); }
        .form-card { background:var(--card-bg); border-radius:20px; padding:20px; border:1px solid var(--card-border); box-shadow:var(--shadow-card); margin-bottom:16px; }
        .card-title { font-size:17px; font-weight:700; margin-bottom:16px; color:var(--text-dark); display:flex; align-items:center; gap:8px; }
        .card-title-icon { width:36px; height:36px; border-radius:11px; display:flex; align-items:center; justify-content:center; }
        .alert { padding:14px 16px; border-radius:14px; font-size:13px; font-weight:500; margin-bottom:16px; display:flex; align-items:flex-start; gap:10px; }
        .alert svg { flex-shrink:0; margin-top:1px; }
        .alert-error   { background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#B91C1C; }
        .alert-success { background:rgba(0,208,132,0.1); border:1px solid rgba(0,208,132,0.25); color:#065F46; }
        [data-theme="dark"] .alert-error   { color:#FCA5A5; }
        [data-theme="dark"] .alert-success { color:#6EE7B7; }
        .field-group { margin-bottom:14px; }
        .field-label { font-size:12px; font-weight:700; color:var(--text-medium); text-transform:uppercase; letter-spacing:0.5px; margin-bottom:6px; display:block; }
        .field-required { color:var(--danger); margin-left:2px; }
        .field-input { width:100%; padding:13px 16px; border-radius:14px; border:1.5px solid var(--input-border); font-size:14px; font-weight:500; color:var(--text-dark); background:var(--input-bg); outline:none; font-family:'Inter', sans-serif; }
        .field-input:focus { border-color:var(--primary-green); box-shadow:0 0 0 3px rgba(0,208,132,0.12); background:var(--card-bg); }
        .field-input::placeholder { color:var(--text-light); font-weight:400; }
        .location-field-wrap { position:relative; }
        .loc-label { display:flex; align-items:center; gap:8px; font-size:11px; font-weight:700; color:var(--text-medium); text-transform:uppercase; letter-spacing:0.5px; margin-bottom:8px; }
        .loc-dot { width:10px; height:10px; border-radius:50%; flex-shrink:0; }
        .pickup-dot { background:var(--primary-green); box-shadow:0 0 0 3px rgba(0,208,132,0.2); }
        .dest-dot   { background:var(--danger); box-shadow:0 0 0 3px rgba(239,68,68,0.15); }
        .route-connector { display:flex; justify-content:flex-start; padding-left:4px; height:12px; }
        .connector-line  { width:2px; height:100%; background:var(--input-border); margin-left:4px; }
        .autocomplete-wrap { position:relative; }
        .autocomplete-input-row { display:flex; align-items:center; gap:8px; }
        .ac-input { flex:1; }
        .ac-input:focus { border-color:var(--primary-green); box-shadow:0 0 0 3px rgba(0,208,132,0.12); }
        .gps-btn { width:46px; height:46px; flex-shrink:0; border-radius:14px; background:rgba(0,208,132,0.1); border:1.5px solid rgba(0,208,132,0.3); color:var(--dark-green); display:flex; align-items:center; justify-content:center; cursor:pointer; }
        .gps-btn:active { transform:scale(0.94); background:rgba(0,208,132,0.2); }
        .gps-btn.loading { animation:pulse-gps 1s infinite; }
        @keyframes pulse-gps { 0%,100%{opacity:1} 50%{opacity:0.4} }
        .clear-btn { width:32px; height:32px; flex-shrink:0; border-radius:50%; background:rgba(0,0,0,0.05); border:none; color:var(--text-light); display:flex; align-items:center; justify-content:center; cursor:pointer; }
        [data-theme="dark"] .clear-btn { background:rgba(255,255,255,0.08); }
        .ac-dropdown { position:absolute; top:calc(100% + 4px); left:0; right:0; background:var(--card-bg); border:1.5px solid var(--card-border); border-radius:16px; box-shadow:0 8px 24px rgba(0,0,0,0.12); z-index:200; overflow:hidden; display:none; max-height:240px; overflow-y:auto; }
        [data-theme="dark"] .ac-dropdown { box-shadow:0 8px 24px rgba(0,0,0,0.4); }
        .ac-dropdown.open { display:block; }
        .ac-item { display:flex; align-items:flex-start; gap:10px; padding:12px 14px; cursor:pointer; border-bottom:1px solid var(--row-border); }
        .ac-item:last-child { border-bottom:none; }
        .ac-item:active { background:rgba(0,208,132,0.06); }
        .ac-item-icon { width:32px; height:32px; border-radius:10px; background:rgba(0,208,132,0.1); display:flex; align-items:center; justify-content:center; flex-shrink:0; margin-top:1px; }
        .ac-item-icon svg { stroke:var(--dark-green); }
        .ac-item-text  { flex:1; min-width:0; }
        .ac-item-name  { font-size:13px; font-weight:600; color:var(--text-dark); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .ac-item-addr  { font-size:11px; color:var(--text-light); margin-top:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .ac-loading    { padding:16px 14px; text-align:center; font-size:12px; color:var(--text-light); display:flex; align-items:center; justify-content:center; gap:8px; }
        .ac-no-results { padding:14px; text-align:center; font-size:12px; color:var(--text-light); }
        .map-container { width:100%; height:220px; border-radius:16px; overflow:hidden; border:1.5px solid var(--card-border); margin-top:14px; position:relative; background:var(--input-bg); }
        #booking-map { width:100%; height:100%; z-index:1; }
        
        .map-status { position:absolute; bottom:10px; left:50%; transform:translateX(-50%); background:rgba(255,255,255,0.95); backdrop-filter:blur(8px); border:1px solid var(--card-border); border-radius:20px; padding:5px 14px; font-size:11px; font-weight:600; color:var(--text-medium); z-index:10; white-space:nowrap; pointer-events:none; box-shadow:0 2px 8px rgba(0,0,0,0.08); }
        [data-theme="dark"] .map-status { background:rgba(26,40,32,0.95); }
        .map-status.geocoding { color:var(--dark-green); }
        .map-status.error { color:var(--danger); }
        
        @keyframes pinDrop3d {
            0%   { transform:perspective(600px) rotateX(60deg) scale(0.3) translateY(-60px); opacity:0; }
            50%  { transform:perspective(600px) rotateX(-8deg) scale(1.15) translateY(6px);  opacity:1; }
            70%  { transform:perspective(600px) rotateX(4deg)  scale(0.95) translateY(-3px); opacity:1; }
            85%  { transform:perspective(600px) rotateX(-2deg) scale(1.04) translateY(2px);  opacity:1; }
            100% { transform:perspective(600px) rotateX(0deg)  scale(1)    translateY(0);    opacity:1; }
        }
        @keyframes rippleOut {
            0%   { transform:scale(0.5); opacity:0.7; }
            100% { transform:scale(3.5); opacity:0; }
        }
        @keyframes overlayFadeOut {
            0%   { opacity:1; }
            100% { opacity:0; pointer-events:none; }
        }
        .map-flyover-overlay {
            position:absolute; inset:0; z-index:50; pointer-events:none;
            display:flex; align-items:center; justify-content:center;
            background:rgba(0,0,0,0.14); backdrop-filter:blur(2px);
        }
        .map-flyover-overlay.fade-out { animation:overlayFadeOut 0.5s ease forwards; }
        .map-flyover-pin { display:flex; flex-direction:column; align-items:center; position:relative; }
        .map-flyover-pin-head {
            width:44px; height:44px; border-radius:50% 50% 50% 0;
            display:flex; align-items:center; justify-content:center;
            box-shadow:0 8px 24px rgba(0,0,0,0.28); transform:rotate(-45deg);
            animation:pinDrop3d 0.7s cubic-bezier(0.34,1.4,0.64,1) forwards;
        }
        .map-flyover-pin-head svg { transform:rotate(45deg); }
        .map-flyover-pin-tail {
            width:4px; height:18px; margin-top:-3px; border-radius:0 0 4px 4px;
            animation:pinDrop3d 0.7s cubic-bezier(0.34,1.4,0.64,1) forwards;
        }
        .map-flyover-ripple {
            position:absolute; bottom:6px; width:28px; height:12px;
            border-radius:50%; opacity:0;
            animation:rippleOut 0.8s ease-out 0.25s forwards;
        }
        .map-flyover-label {
            margin-top:10px; padding:5px 14px; border-radius:20px;
            font-size:12px; font-weight:700; white-space:nowrap; max-width:200px;
            overflow:hidden; text-overflow:ellipsis;
            box-shadow:0 4px 14px rgba(0,0,0,0.18); background:white; color:#1A202C;
            animation:pinDrop3d 0.7s cubic-bezier(0.34,1.4,0.64,1) 0.1s both;
        }
        .ride-tabs { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:16px; }
        .ride-tab { padding:12px; border-radius:14px; border:2px solid var(--card-border); text-align:center; cursor:pointer; background:var(--card-bg); }
        .ride-tab.selected { border-color:var(--primary-green); background:rgba(0,208,132,0.08); }
        .ride-tab-icon { width:28px; height:28px; margin:0 auto 8px; display:flex; align-items:center; justify-content:center; color:var(--text-medium); }
        .ride-tab-label { font-size:13px; font-weight:600; color:var(--text-medium); }
        .ride-tab.selected .ride-tab-label { color:var(--dark-green); }
        .ride-tab.selected .ride-tab-icon  { color:var(--dark-green); }
        .fuel-tabs { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:4px; }
        .fuel-tab { border:2px solid var(--card-border); border-radius:18px; padding:18px 12px; text-align:center; cursor:pointer; background:var(--card-bg); position:relative; overflow:hidden; }
        .fuel-tab::before { content:''; position:absolute; inset:0; opacity:0; border-radius:16px; }
        .fuel-tab.electric::before { background:linear-gradient(135deg,rgba(0,208,132,0.08),rgba(96,165,250,0.08)); }
        .fuel-tab.gasoline::before { background:linear-gradient(135deg,rgba(251,146,60,0.08),rgba(251,191,36,0.08)); }
        .fuel-tab.electric.selected { border-color:var(--primary-green); }
        .fuel-tab.electric.selected::before { opacity:1; }
        .fuel-tab.gasoline.selected { border-color:var(--accent-orange); }
        .fuel-tab.gasoline.selected::before { opacity:1; }
        .fuel-tab input[type="radio"] { display:none; }
        .fuel-tab-icon  { width:44px; height:44px; margin:0 auto 8px; display:flex; align-items:center; justify-content:center; position:relative; color:var(--text-medium); }
        .fuel-tab-name  { font-size:15px; font-weight:800; color:var(--text-dark); margin-bottom:3px; position:relative; }
        .fuel-tab-desc  { font-size:11px; color:var(--text-light); font-weight:500; position:relative; line-height:1.4; }
        .fuel-tab.electric.selected .fuel-tab-name { color:var(--dark-green); }
        .fuel-tab.gasoline.selected .fuel-tab-name { color:#C2410C; }
        [data-theme="dark"] .fuel-tab.gasoline.selected .fuel-tab-name { color:#FB923C; }
        .fuel-eco-tag { display:inline-block; background:rgba(0,208,132,0.15); color:#065F46; font-size:10px; font-weight:700; padding:2px 7px; border-radius:6px; margin-top:4px; position:relative; }
        [data-theme="dark"] .fuel-eco-tag { color:#6EE7B7; }
        .fuel-tab-check { position:absolute; top:10px; right:10px; width:20px; height:20px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:11px; opacity:0; }
        .fuel-tab.electric.selected .fuel-tab-check { background:var(--primary-green); color:white; opacity:1; }
        .fuel-tab.gasoline.selected .fuel-tab-check { background:var(--accent-orange); color:white; opacity:1; }
        .fuel-note { border-radius:12px; padding:10px 14px; font-size:12px; font-weight:500; margin-top:10px; display:flex; align-items:center; gap:8px; }
        .fuel-note.electric { background:rgba(0,208,132,0.08); color:#065F46; border:1px solid rgba(0,208,132,0.2); }
        .fuel-note.gasoline { background:rgba(251,146,60,0.08); color:#9A3412; border:1px solid rgba(251,146,60,0.2); }
        [data-theme="dark"] .fuel-note.electric { color:#6EE7B7; }
        [data-theme="dark"] .fuel-note.gasoline { color:#FB923C; }
        .payment-methods { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
        .pay-option { border:2px solid var(--card-border); border-radius:16px; padding:18px 12px; cursor:pointer; text-align:center; background:var(--card-bg); }
        .pay-option.selected { border-color:var(--accent-blue); background:rgba(96,165,250,0.08); }
        .pay-option input[type="radio"] { display:none; }
        .pay-icon { width:32px; height:32px; margin:0 auto 6px; display:flex; align-items:center; justify-content:center; color:var(--text-medium); }
        .pay-option.selected .pay-icon { color:#3B82F6; }
        .pay-label { font-size:13px; font-weight:700; color:var(--text-medium); }
        .pay-option.selected .pay-label { color:#1D4ED8; }
        [data-theme="dark"] .pay-option.selected .pay-label { color:#93C5FD; }
        .fare-preview { background:rgba(0,208,132,0.06); border:1.5px solid rgba(0,208,132,0.2); border-radius:16px; padding:16px; margin-top:4px; }
        [data-theme="dark"] .fare-preview { background:rgba(0,208,132,0.04); }
        .fare-row { display:flex; justify-content:space-between; align-items:center; font-size:13px; color:var(--text-medium); margin-bottom:8px; }
        .fare-row:last-child { margin-bottom:0; }
        .fare-row.total { font-size:16px; font-weight:800; color:var(--text-dark); border-top:1.5px solid rgba(0,208,132,0.2); padding-top:10px; margin-top:4px; }
        .fare-row.total span:last-child { color:var(--dark-green); }
        .taxi-banner { display:flex; align-items:center; gap:14px; background:linear-gradient(135deg,rgba(0,208,132,0.08),rgba(96,165,250,0.06)); border:1.5px solid rgba(0,208,132,0.2); border-radius:16px; padding:16px; margin-bottom:14px; }
        .taxi-banner-icon { width:52px; height:52px; border-radius:16px; flex-shrink:0; background:linear-gradient(135deg,var(--primary-green),var(--dark-green)); display:flex; align-items:center; justify-content:center; }
        .taxi-banner-info { flex:1; }
        .taxi-banner-name  { font-size:16px; font-weight:800; color:var(--text-dark); }
        .taxi-banner-desc  { font-size:12px; color:var(--text-light); margin-top:2px; }
        .taxi-banner-price { text-align:right; }
        .taxi-price-label  { font-size:10px; color:var(--text-light); font-weight:600; text-transform:uppercase; letter-spacing:0.4px; }
        .taxi-price-value  { font-size:18px; font-weight:800; color:var(--dark-green); }
        .taxi-perks        { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:16px; }
        .perk-item         { display:flex; align-items:center; gap:6px; font-size:12px; font-weight:600; color:var(--text-medium); }
        .qty-row { display:flex; align-items:center; gap:0; background:rgba(0,0,0,0.02); border:1.5px solid var(--card-border); border-radius:16px; padding:6px; width:fit-content; margin-top:8px; }
        [data-theme="dark"] .qty-row { background:rgba(255,255,255,0.03); }
        .qty-btn { width:40px; height:40px; border-radius:12px; border:none; background:var(--card-bg); box-shadow:0 1px 4px rgba(0,0,0,0.08); display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--text-dark); }
        .qty-btn:active { transform:scale(0.92); }
        .qty-display    { min-width:90px; text-align:center; position:relative; padding:0 12px; }
        #qty-display-val{ font-size:22px; font-weight:800; color:var(--text-dark); display:block; }
        .qty-sub        { font-size:11px; color:var(--text-light); font-weight:500; display:block; margin-top:-2px; }
        .submit-btn { width:100%; padding:16px; border-radius:18px; background:linear-gradient(135deg,var(--primary-green),var(--dark-green)); color:white; font-size:16px; font-weight:800; border:none; cursor:pointer; box-shadow:0 4px 16px rgba(0,208,132,0.3); display:flex; align-items:center; justify-content:center; gap:8px; letter-spacing:0.3px; }
        .submit-btn:active  { transform:scale(0.98); }
        .submit-btn:disabled{ opacity:0.6; pointer-events:none; }
        .spinner { display:inline-block; width:18px; height:18px; border:2px solid rgba(255,255,255,0.4); border-radius:50%; border-top-color:white; animation:spin 0.7s linear infinite; }
        @keyframes spin { to { transform:rotate(360deg); } }
        .submit-btn .spinner { display:none; }
        .submit-btn.loading .spinner { display:inline-block; }
        .submit-btn.loading .btn-text { display:none; }
        .pending-hero { background:linear-gradient(135deg,#F59E0B,#D97706); border-radius:24px; padding:28px 24px; color:white; margin-bottom:16px; text-align:center; box-shadow:0 8px 32px rgba(245,158,11,0.3); animation: slideUp 0.4s ease forwards; }
        .pending-icon { width:72px; height:72px; margin:0 auto 14px; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,0.2); border-radius:50%; animation: pulse-ring 2s infinite; }
        @keyframes pulse-ring { 0%{box-shadow:0 0 0 0 rgba(255,255,255,0.4)} 70%{box-shadow:0 0 0 18px rgba(255,255,255,0)} 100%{box-shadow:0 0 0 0 rgba(255,255,255,0)} }
        .pending-ref    { font-size:26px; font-weight:900; letter-spacing:1px; margin-bottom:6px; }
        .pending-status { font-size:14px; opacity:0.9; margin-bottom:14px; }
        .pending-dots   { display:flex; justify-content:center; gap:6px; }
        .dot-bounce { width:8px; height:8px; background:rgba(255,255,255,0.8); border-radius:50%; animation:bounce-dot 1.2s infinite ease-in-out; }
        .dot-bounce:nth-child(2) { animation-delay:0.2s; }
        .dot-bounce:nth-child(3) { animation-delay:0.4s; }
        @keyframes bounce-dot { 0%,80%,100%{transform:scale(0.8);opacity:0.5} 40%{transform:scale(1.2);opacity:1} }
        .confirmed-hero { background:linear-gradient(135deg,var(--primary-green),var(--dark-green)); border-radius:24px; padding:24px; color:white; margin-bottom:16px; box-shadow:0 8px 32px rgba(0,208,132,0.25); animation:slideUp 0.4s ease forwards; }
        .confirmed-header { display:flex; align-items:center; gap:14px; }
        .confirmed-check { width:52px; height:52px; background:rgba(255,255,255,0.2); border-radius:50%; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .confirmed-info { flex:1; }
        .confirmed-ref   { font-size:20px; font-weight:900; letter-spacing:0.5px; }
        .confirmed-label { font-size:13px; opacity:0.88; margin-top:2px; }
        .tracking-map-container { width:100%; border-radius:20px; overflow:hidden; border:1.5px solid var(--card-border); margin-bottom:16px; box-shadow:0 4px 16px rgba(0,0,0,0.08); position:relative; }
        #tracking-map { width:100%; height:320px; }
        
        @keyframes routeFlow { from { stroke-dashoffset: 60; } to { stroke-dashoffset: 0; } }
        .route-flow-line path { animation: routeFlow 1.1s linear infinite; }
        
        @keyframes driverPulse { 0%,100%{box-shadow:0 4px 16px rgba(0,208,132,0.55),0 0 0 0 rgba(0,208,132,0.35)} 50%{box-shadow:0 4px 16px rgba(0,208,132,0.55),0 0 0 10px rgba(0,208,132,0)} }
        .tracking-badge { position:absolute; top:12px; left:12px; z-index:10; background:rgba(255,255,255,0.95); backdrop-filter:blur(8px); border-radius:20px; padding:6px 14px; font-size:12px; font-weight:700; color:var(--dark-green); border:1px solid rgba(0,208,132,0.3); display:flex; align-items:center; gap:6px; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
        [data-theme="dark"] .tracking-badge { background:rgba(26,40,32,0.95); }
        .live-dot { width:8px; height:8px; background:var(--primary-green); border-radius:50%; animation:blink-dot 1s infinite; }
        @keyframes blink-dot { 0%,100%{opacity:1} 50%{opacity:0.3} }
        .driver-card { background:var(--card-bg); border-radius:20px; border:1px solid var(--card-border); box-shadow:var(--shadow-card); overflow:hidden; margin-bottom:16px; }
        .driver-card-header { background:linear-gradient(135deg,rgba(0,208,132,0.06),rgba(96,165,250,0.04)); padding:16px 18px; border-bottom:1px solid var(--card-border); display:flex; align-items:center; gap:14px; }
        .driver-avatar { width:52px; height:52px; border-radius:16px; flex-shrink:0; background:linear-gradient(135deg,var(--primary-green),var(--dark-green)); display:flex; align-items:center; justify-content:center; font-size:22px; font-weight:800; color:white; }
        .driver-meta { flex:1; }
        .driver-name { font-size:16px; font-weight:800; color:var(--text-dark); }
        .driver-sub  { font-size:12px; color:var(--text-light); margin-top:2px; }
        .driver-contact-row { display:flex; align-items:center; gap:6px; margin-top:2px; color:var(--dark-green); font-size:12px; font-weight:600; }
        .driver-contact-row svg { flex-shrink:0; }
        .driver-eta  { background:rgba(0,208,132,0.1); border:1.5px solid rgba(0,208,132,0.25); border-radius:12px; padding:8px 12px; text-align:center; }
        .eta-val    { font-size:20px; font-weight:900; color:var(--dark-green); display:block; }
        .eta-label  { font-size:10px; color:var(--text-light); font-weight:600; display:block; text-transform:uppercase; letter-spacing:0.3px; }
        .detail-row { display:flex; align-items:center; gap:14px; padding:14px 18px; border-bottom:1px solid var(--row-border); }
        .detail-row:last-child { border-bottom:none; }
        .detail-icon-circle { width:40px; height:40px; border-radius:12px; flex-shrink:0; display:flex; align-items:center; justify-content:center; }
        .detail-info  { flex:1; }
        .detail-label { font-size:11px; color:var(--text-light); font-weight:600; margin-bottom:2px; }
        .detail-value { font-size:14px; font-weight:700; color:var(--text-dark); }
        .cancel-btn { width:100%; padding:14px; border-radius:18px; background:var(--card-bg); color:#EF4444; font-size:15px; font-weight:700; border:2px solid rgba(239,68,68,0.3); cursor:pointer; margin-bottom:10px; }
        .cancel-btn:active { background:rgba(239,68,68,0.05); }
        .bottom-nav { position:fixed; bottom:0; left:0; right:0; background:var(--nav-bg); backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px); border-top:1px solid var(--card-border); padding:12px 0 20px; display:grid; grid-template-columns:repeat(4,1fr); z-index:99; box-shadow:var(--shadow-nav); }
        .nav-item { display:flex; flex-direction:column; align-items:center; gap:4px; padding:8px; cursor:pointer; border:none; background:none; }
        .nav-item:active { transform:scale(0.95); }
        .nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
        .nav-icon svg { stroke:var(--text-light); opacity:0.5; }
        .nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
        .nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:0.7; }
        .nav-item.active .nav-label { color:var(--primary-green); opacity:1; }
        @keyframes slideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        .hero-card, .form-card, .steps-bar { animation:slideUp 0.4s ease forwards; }
        @media(min-width:768px) {
            body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,0.1); }
            .bottom-nav { max-width:480px; left:50%; transform:translateX(-50%); }
        }
    
    
    .notif-panel-wrap{position:relative;}
    .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:310px;max-height:400px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.15);z-index:999;display:none;flex-direction:column;overflow:hidden;}
    .notif-panel.open{display:flex;}
    .notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);flex-shrink:0;}
    .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
    .notif-mark-read{font-size:11px;font-weight:600;color:var(--dark-green);background:none;border:none;cursor:pointer;padding:0;}
    .notif-list{overflow-y:auto;flex:1;padding:4px 0;}
    .notif-item{display:flex;align-items:flex-start;gap:10px;padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--row-border);transition:background .15s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,208,132,0.06);}
    .notif-item.unread{background:rgba(0,208,132,0.04);}
    .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
    .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
    .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
    .notif-item-body{flex:1;min-width:0;}
    .notif-item-title{font-size:12px;font-weight:700;color:var(--text-dark);margin-bottom:2px;}
    .notif-item-sub{font-size:11px;color:var(--text-light);line-height:1.4;}
    .notif-item-time{font-size:10px;color:var(--text-light);margin-top:3px;}
    .notif-empty{padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;}
    .notif-spinner{width:20px;height:20px;border:2px solid var(--card-border);border-top-color:#00D084;border-radius:50%;animation:nspin .7s linear infinite;margin:16px auto;}
    @keyframes nspin{to{transform:rotate(360deg);}}
    .notif-count-badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 3px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:9px;font-weight:800;color:#fff;display:none;align-items:center;justify-content:center;line-height:1;}
    
    .logout-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center;padding:24px;}
    .logout-overlay.open{display:flex;}
    .logout-modal{background:var(--card-bg);border-radius:24px;padding:28px 24px 24px;width:100%;max-width:320px;box-shadow:0 16px 48px rgba(0,0,0,0.18);animation:lmodalIn .25s cubic-bezier(.34,1.56,.64,1);}
    @keyframes lmodalIn{from{transform:scale(.88);opacity:0;}to{transform:scale(1);opacity:1;}}
    .logout-modal-icon{width:52px;height:52px;border-radius:16px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
    .logout-modal-title{font-size:17px;font-weight:800;color:var(--text-dark);text-align:center;margin-bottom:6px;}
    .logout-modal-sub{font-size:13px;color:var(--text-light);text-align:center;line-height:1.5;margin-bottom:22px;}
    .logout-modal-btns{display:flex;gap:10px;}
    .logout-cancel-btn{flex:1;padding:13px;border-radius:14px;background:var(--input-bg);border:1px solid var(--card-border);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;}
    .logout-confirm-btn{flex:1;padding:13px;border-radius:14px;background:#EF4444;border:none;font-size:14px;font-weight:700;color:#fff;cursor:pointer;}
</style>
</head>
<body>

<script>
(function(){
    var t = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>

<div class="header">
    <div class="header-content">
        <button class="back-btn" onclick="history.back()">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
            Back
        </button>
        <span class="header-title">Book a Trip</span>
        <div class="header-right">
            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="5"/>
                    <line x1="12" y1="1"  x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
                    <line x1="4.22"  y1="4.22"  x2="5.64"  y2="5.64"/>
                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
                    <line x1="1"  y1="12" x2="3"  y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
                    <line x1="4.22"  y1="19.78" x2="5.64"  y2="18.36"/>
                    <line x1="18.36" y1="5.64"  x2="19.78" y2="4.22"/>
                </svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                </svg>
            </button>
            <button class="icon-btn" onclick="window.location.href='dashboard.php'" title="Home">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                    <polyline points="9 22 9 12 15 12 15 22"/>
                </svg>
            </button>
            <div class="notif-panel-wrap">
            <button class="icon-btn" id="notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications" style="position:relative;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <span class="notif-count-badge" id="notif-count-badge"></span>
            </button>
            <div class="notif-panel" id="notif-panel">
                <div class="notif-panel-head">
                    <span class="notif-panel-title">Notifications</span>
                    <button class="notif-mark-read" onclick="markAllRead()">Mark all read</button>
                </div>
                <div class="notif-list" id="notif-list"><div class="notif-spinner"></div></div>
            </div>
        </div>
            <button class="icon-btn logout-btn"
                    onclick="openLogout()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                    <polyline points="16 17 21 12 16 7"/>
                    <line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

<?php if ($booking_result): ?>

<?php
    $initialStatus = $booking_result['status'];
    $showPending   = in_array($initialStatus, ['Pending']);
    $showConfirmed = in_array($initialStatus, ['Confirmed', 'In Progress']);
?>

<div id="pending-screen" <?= $showConfirmed ? 'style="display:none;"' : '' ?>>
    <div class="pending-hero">
        <div class="pending-icon">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
        </div>
        <div class="pending-ref"><?= htmlspecialchars($booking_result['booking_ref']) ?></div>
        <div class="pending-status">Looking for a nearby driver…</div>
        <div style="display:flex;align-items:center;justify-content:center;gap:6px;margin-bottom:12px;"><span style="width:8px;height:8px;background:#00D084;border-radius:50%;display:inline-block;animation:blink-dot 1s infinite;"></span><span style="font-size:11px;font-weight:700;color:rgba(255,255,255,0.8);letter-spacing:.5px;">LIVE UPDATES ON</span></div>
        <div class="pending-dots">
            <div class="dot-bounce"></div>
            <div class="dot-bounce"></div>
            <div class="dot-bounce"></div>
        </div>
    </div>

    <div class="form-card">
        <?php if ($booking_result['pickup']): ?>
        <div class="detail-row">
            <div class="detail-icon-circle" style="background:rgba(16,185,129,0.12);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            </div>
            <div class="detail-info">
                <div class="detail-label">Pickup</div>
                <div class="detail-value"><?= htmlspecialchars($booking_result['pickup']) ?></div>
            </div>
        </div>
        <?php endif; ?>
        <?php if ($booking_result['destination']): ?>
        <div class="detail-row">
            <div class="detail-icon-circle" style="background:rgba(239,68,68,0.1);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--danger)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 8 8 12 12 16"></polyline><line x1="16" y1="12" x2="8" y2="12"></line></svg>
            </div>
            <div class="detail-info">
                <div class="detail-label">Destination</div>
                <div class="detail-value"><?= htmlspecialchars($booking_result['destination']) ?></div>
            </div>
        </div>
        <?php endif; ?>
        <div class="detail-row">
            <div class="detail-icon-circle" style="background:rgba(0,208,132,0.12);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--dark-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
            </div>
            <div class="detail-info">
                <div class="detail-label">Total Fare</div>
                <div class="detail-value" id="pending-fare-display" style="color:var(--dark-green);">&#8369;<?= number_format($booking_result['total_amount'], 2) ?></div>
            </div>
        </div>
    </div>

    <button class="cancel-btn" onclick="cancelBooking(<?= (int)$booking_result['booking_id'] ?>)">
        Cancel Booking
    </button>
</div>

<div id="confirmed-screen" <?= $showPending ? 'style="display:none;"' : '' ?>>
    <div class="confirmed-hero">
        <div class="confirmed-header">
            <div class="confirmed-check">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            </div>
            <div class="confirmed-info">
                <div class="confirmed-ref"><?= htmlspecialchars($booking_result['booking_ref']) ?></div>
                <div class="confirmed-label" id="confirmed-status-label">Driver is on the way!</div>
            </div>
        </div>
    </div>

    <div class="tracking-map-container">
        <div id="tracking-map"></div>
        <div class="tracking-badge">
            <div class="live-dot"></div>
            LIVE TRACKING
        </div>
    </div>

    <div class="driver-card">
        <div class="driver-card-header">
            <div class="driver-avatar" id="driver-avatar-initial">?</div>
            <div class="driver-meta">
                <div class="driver-name" id="driver-name-display">Assigning…</div>
                <div class="driver-sub" id="driver-vehicle-display">—</div>
                <div class="driver-contact-row" id="driver-contact-display" style="display:none;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                    <span id="driver-contact-number"></span>
                </div>
            </div>
            <div class="driver-eta">
                <span class="eta-val" id="eta-minutes">—</span>
                <span class="eta-label">min away</span>
            </div>
        </div>
        <?php if ($booking_result['pickup']): ?>
        <div class="detail-row">
            <div class="detail-icon-circle" style="background:rgba(16,185,129,0.12);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            </div>
            <div class="detail-info">
                <div class="detail-label">Pickup</div>
                <div class="detail-value"><?= htmlspecialchars($booking_result['pickup']) ?></div>
            </div>
        </div>
        <?php endif; ?>
        <?php if ($booking_result['destination']): ?>
        <div class="detail-row">
            <div class="detail-icon-circle" style="background:rgba(239,68,68,0.1);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--danger)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 8 8 12 12 16"></polyline><line x1="16" y1="12" x2="8" y2="12"></line></svg>
            </div>
            <div class="detail-info">
                <div class="detail-label">Destination</div>
                <div class="detail-value"><?= htmlspecialchars($booking_result['destination']) ?></div>
            </div>
        </div>
        <?php endif; ?>
        <div class="detail-row">
            <div class="detail-icon-circle" style="background:rgba(0,208,132,0.12);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--dark-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
            </div>
            <div class="detail-info">
                <div class="detail-label">Total Fare</div>
                <div class="detail-value" id="confirmed-fare-display" style="color:var(--dark-green);">&#8369;<?= number_format($booking_result['total_amount'], 2) ?></div>
            </div>
        </div>
    </div>

    <div id="force-complete-wrap" style="padding:0 16px 16px;">
        <button id="force-complete-btn" onclick="forceComplete()" style="
            width:100%;padding:14px;border-radius:16px;
            background:transparent;color:#00A86B;
            font-size:14px;font-weight:700;
            border:2px solid rgba(0,208,132,0.35);
            cursor:pointer;display:none;">
            ✓ Driver said trip is done? Tap to confirm
        </button>
    </div>
</div>

<script>
const BOOKING_ID  = <?= (int)$booking_result['booking_id'] ?>;
const PICKUP_ADDR = <?= json_encode($booking_result['pickup']) ?>;
const DEST_ADDR   = <?= json_encode($booking_result['destination']) ?>;
const API_BASE    = 'passenger_booking.php';

let trackingMap   = null;
let driverMarker  = null;
let pickupMarker  = null;
let destMarker    = null;
let routePolyline = null;
let isConfirmed   = <?= $showConfirmed ? 'true' : 'false' ?>;
let lastDriverLat = null;
let lastDriverLng = null;


const Poller = (() => {
    let _timer    = null;
    let _interval = 4000;   
    let _stopped  = false;
    let _lastStatus = null;
    const MIN_MS  = 4000;
    const MAX_MS  = 12000;
    const STEP_MS = 2000;

    
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) { _pause(); }
        else if (!_stopped)  { _scheduleNext(1000); }
    });

    function _pause() { clearTimeout(_timer); _timer = null; }

    function _scheduleNext(ms) {
        clearTimeout(_timer);
        _timer = setTimeout(_tick, ms ?? _interval);
    }

    async function _tick() {
        if (_stopped || document.hidden) return;
        try {
            const res  = await fetch(`${API_BASE}?ajax_action=booking_status&booking_id=${BOOKING_ID}`, { cache:'no-store' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            _handleData(data);
            
            if (data.status !== _lastStatus) {
                _interval = MIN_MS;
            } else {
                _interval = Math.min(_interval + STEP_MS, MAX_MS);
            }
            _lastStatus = data.status;
        } catch(e) {
            console.warn('[Poller] error:', e);
            _interval = Math.min(_interval + STEP_MS, MAX_MS);
        }
        if (!_stopped) _scheduleNext(_interval);
    }

    function _handleData(data) {
        
        if (data.total_amount) syncFareDisplay(data.total_amount);

        if (data.status === 'Confirmed' || data.status === 'In Progress') {
            if (!isConfirmed) showConfirmedScreen(data);
            _updateConfirmedUI(data);
            
            const fcBtn = document.getElementById('force-complete-btn');
            if (fcBtn && data.status === 'In Progress') fcBtn.style.display = 'block';
        } else if (data.status === 'Pending') {
            
        } else if (data.status === 'Rejected') {
            stop();
            _showRejectedBanner();
            setTimeout(() => { window.location.href = 'passenger_booking.php'; }, 3500);
        } else if (data.status === 'Cancelled') {
            stop();
            _showCancelledBanner();
            setTimeout(() => { window.location.href = 'passenger_booking.php'; }, 3000);
        } else if (data.status === 'Completed') {
            stop();
            showTripDoneOverlay(data);
        }
    }

    function _updateConfirmedUI(data) {
        const lbl = document.getElementById('confirmed-status-label');
        if (lbl) lbl.textContent = data.status === 'In Progress' ? 'Trip in progress…' : 'Driver is on the way!';

        if (data.driver_name) {
            const nameEl = document.getElementById('driver-name-display');
            const initEl = document.getElementById('driver-avatar-initial');
            if (nameEl && nameEl.textContent === 'Assigning…') {
                nameEl.textContent = data.driver_name;
                if (initEl) initEl.textContent = data.driver_name.charAt(0).toUpperCase();
            }
        }
        if (data.driver_contact) {
            const crow = document.getElementById('driver-contact-display');
            const cnum = document.getElementById('driver-contact-number');
            if (crow && cnum && crow.style.display === 'none') {
                cnum.textContent   = data.driver_contact;
                crow.style.display = 'flex';
            }
        }
        if (data.driver_lat && data.driver_lng && trackingMap) {
            const dlat = parseFloat(data.driver_lat);
            const dlng = parseFloat(data.driver_lng);
            updateDriverMarker(dlat, dlng);
            if (lastDriverLat !== null) {
                const R    = 6371;
                const dφ   = (dlat - lastDriverLat) * Math.PI / 180;
                const dλ   = (dlng - lastDriverLng) * Math.PI / 180;
                const a    = Math.sin(dφ/2)**2 + Math.cos(lastDriverLat*Math.PI/180)*Math.cos(dlat*Math.PI/180)*Math.sin(dλ/2)**2;
                const dist = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                const etaEl = document.getElementById('eta-minutes');
                if (etaEl) etaEl.textContent = Math.max(1, Math.round(dist / 0.5));
            }
        }
    }

    function _showCancelledBanner() {
        const el = document.createElement('div');
        el.style.cssText = 'position:fixed;top:80px;left:50%;transform:translateX(-50%);background:#EF4444;color:white;border-radius:16px;padding:14px 22px;font-weight:700;font-size:14px;z-index:9999;box-shadow:0 8px 24px rgba(239,68,68,.4);';
        el.textContent = 'Booking was cancelled. Redirecting…';
        document.body.appendChild(el);
    }

    function _showRejectedBanner() {
        const el = document.createElement('div');
        el.style.cssText = 'position:fixed;top:80px;left:50%;transform:translateX(-50%);background:#F59E0B;color:white;border-radius:16px;padding:14px 22px;font-weight:700;font-size:14px;z-index:9999;box-shadow:0 8px 24px rgba(245,158,11,.45);max-width:90%;text-align:center;';
        el.innerHTML = '⚠️ No driver accepted your booking. Redirecting to book again…';
        document.body.appendChild(el);
    }

    function start()  { _stopped = false; _scheduleNext(800); }
    function stop()   { _stopped = true;  clearTimeout(_timer); }

    return { start, stop };
})();


const DRIVER_ICON = L.divIcon({
    html: `<div style="
        width:42px;height:42px;background:linear-gradient(135deg,#00D084,#00A86B);
        border-radius:50%;border:3px solid white;
        box-shadow:0 4px 16px rgba(0,208,132,0.55);
        display:flex;align-items:center;justify-content:center;
        animation:driverPulse 2s ease-in-out infinite;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="1" y="3" width="15" height="13"></rect>
            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
            <circle cx="5.5" cy="18.5" r="2.5"></circle>
            <circle cx="18.5" cy="18.5" r="2.5"></circle>
        </svg>
    </div>`,
    iconSize:[42,42], iconAnchor:[21,21], className:''
});
const PICKUP_ICON_T = L.divIcon({
    html: `<div style="display:flex;flex-direction:column;align-items:center;filter:drop-shadow(0 4px 10px rgba(0,208,132,0.45));">
        <div style="width:32px;height:32px;border-radius:50% 50% 50% 0;background:linear-gradient(135deg,#00D084,#00A86B);transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;border:2.5px solid white;">
            <div style="width:8px;height:8px;background:white;border-radius:50%;transform:rotate(45deg);"></div>
        </div>
        <div style="width:3px;height:8px;background:#00A86B;margin-top:-2px;border-radius:0 0 3px 3px;"></div>
    </div>`,
    iconSize:[32,44], iconAnchor:[16,44], className:''
});
const DEST_ICON_T = L.divIcon({
    html: `<div style="display:flex;flex-direction:column;align-items:center;filter:drop-shadow(0 4px 10px rgba(239,68,68,0.45));">
        <div style="width:32px;height:32px;border-radius:50% 50% 50% 0;background:linear-gradient(135deg,#EF4444,#DC2626);transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;border:2.5px solid white;">
            <div style="width:8px;height:8px;background:white;border-radius:50%;transform:rotate(45deg);"></div>
        </div>
        <div style="width:3px;height:8px;background:#DC2626;margin-top:-2px;border-radius:0 0 3px 3px;"></div>
    </div>`,
    iconSize:[32,44], iconAnchor:[16,44], className:''
});

function initTrackingMap() {
    if (trackingMap) return;
    trackingMap = L.map('tracking-map', { zoomControl:true, scrollWheelZoom:false })
                   .setView([14.5995, 120.9842], 13);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OSM &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 20
    }).addTo(trackingMap);
}

function geocodeAddress(addr) {
    return fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(addr)}&limit=1&countrycodes=ph`)
        .then(r => r.json())
        .then(d => d[0] ? { lat: parseFloat(d[0].lat), lng: parseFloat(d[0].lon) } : null);
}

async function placeStaticMarkers() {
    const pu = PICKUP_ADDR ? await geocodeAddress(PICKUP_ADDR) : null;
    const ds = DEST_ADDR   ? await geocodeAddress(DEST_ADDR)   : null;
    if (pu) pickupMarker = L.marker([pu.lat, pu.lng], {icon: PICKUP_ICON_T}).addTo(trackingMap).bindPopup('<b>Pickup</b>');
    if (ds) destMarker   = L.marker([ds.lat, ds.lng], {icon: DEST_ICON_T}).addTo(trackingMap).bindPopup('<b>Destination</b>');
    if (pu && ds) {
        if (routePolyline) {
            if (Array.isArray(routePolyline)) routePolyline.forEach(l => trackingMap.removeLayer(l));
            else trackingMap.removeLayer(routePolyline);
        }
        const pts = [[pu.lat,pu.lng],[ds.lat,ds.lng]];
        const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${pu.lng},${pu.lat};${ds.lng},${ds.lat}?overview=full&geometries=geojson`;
        let routeCoords = pts;
        try {
            const osrmRes  = await fetch(osrmUrl);
            const osrmData = await osrmRes.json();
            if (osrmData.routes && osrmData.routes[0]) {
                routeCoords = osrmData.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
            }
        } catch(e) {  }
        const shadow = L.polyline(routeCoords, {color:'rgba(0,168,107,0.15)', weight:16, lineCap:'round', lineJoin:'round'}).addTo(trackingMap);
        const glow   = L.polyline(routeCoords, {color:'rgba(0,208,132,0.28)', weight:9,  lineCap:'round', lineJoin:'round'}).addTo(trackingMap);
        const main   = L.polyline(routeCoords, {color:'#00D084', weight:5, lineCap:'round', lineJoin:'round', opacity:1}).addTo(trackingMap);
        const flow   = L.polyline(routeCoords, {color:'rgba(255,255,255,0.7)', weight:3, dashArray:'12 18', lineCap:'round', lineJoin:'round', className:'route-flow-line'}).addTo(trackingMap);
        routePolyline = [shadow, glow, main, flow];
        trackingMap.fitBounds(L.latLngBounds(routeCoords).pad(0.2));
    } else if (pu) {
        trackingMap.setView([pu.lat,pu.lng],15);
    }
}

function updateDriverMarker(lat, lng) {
    if (!trackingMap) return;
    if (driverMarker) {
        driverMarker.setLatLng([lat, lng]);
    } else {
        driverMarker = L.marker([lat, lng], {icon: DRIVER_ICON, zIndexOffset:1000})
                        .addTo(trackingMap).bindPopup('<b>Your Driver</b>');
    }
    if (!lastDriverLat) trackingMap.setView([lat, lng], 15);
    lastDriverLat = lat;
    lastDriverLng = lng;
}


function syncFareDisplay(amount) {
    const fmt = '₱' + parseFloat(amount).toLocaleString('en-PH', {minimumFractionDigits:2, maximumFractionDigits:2});
    const pending   = document.getElementById('pending-fare-display');
    const confirmed = document.getElementById('confirmed-fare-display');
    if (pending)   pending.textContent   = fmt;
    if (confirmed) confirmed.textContent = fmt;
}

function showConfirmedScreen(data) {
    document.getElementById('pending-screen').style.display   = 'none';
    document.getElementById('confirmed-screen').style.display = 'block';

    
    if (data.total_amount) syncFareDisplay(data.total_amount);

    const dName = data.driver_name || 'Your Driver';
    document.getElementById('driver-name-display').textContent    = dName;
    document.getElementById('driver-avatar-initial').textContent  = dName.charAt(0).toUpperCase();
    document.getElementById('driver-vehicle-display').textContent = data.vehicle || '—';

    const contactRow = document.getElementById('driver-contact-display');
    const contactNum = document.getElementById('driver-contact-number');
    if (data.driver_contact) {
        contactNum.textContent   = data.driver_contact;
        contactRow.style.display = 'flex';
    } else {
        contactRow.style.display = 'none';
    }

    document.getElementById('eta-minutes').textContent = (data.driver_lat && data.driver_lng) ? '—' : '~5';

    initTrackingMap();
    setTimeout(() => {
        trackingMap.invalidateSize();
        placeStaticMarkers();
        if (data.driver_lat && data.driver_lng) {
            updateDriverMarker(parseFloat(data.driver_lat), parseFloat(data.driver_lng));
        }
    }, 200);

    isConfirmed = true;
}




function showTripDoneOverlay(d) {
    if (document.getElementById('ec-td')) return;
    var peso = String.fromCharCode(8369);
    var fare = d.total_amount ? peso + parseFloat(d.total_amount).toLocaleString('en-PH',{minimumFractionDigits:2}) : '';
    var fbox = fare ? '<div style="background:rgba(0,208,132,.08);border:1.5px solid rgba(0,208,132,.3);border-radius:16px;padding:14px 20px;margin-bottom:20px;"><div style="font-size:11px;color:#718096;font-weight:700;text-transform:uppercase;margin-bottom:4px;">Total Fare</div><div style="font-size:30px;font-weight:900;color:#00A86B;">'+fare+'</div></div>' : '';
    var ov = document.createElement('div');
    ov.id = 'ec-td';
    ov.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.65);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:24px;';
    ov.innerHTML = '<div style="background:#fff;border-radius:28px;padding:36px 28px 28px;text-align:center;max-width:320px;width:100%;box-shadow:0 24px 60px rgba(0,0,0,.25);">'
        +'<div style="width:72px;height:72px;background:linear-gradient(135deg,#00D084,#00A86B);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;box-shadow:0 8px 24px rgba(0,208,132,.4);"><svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div>'
        +'<div style="font-size:22px;font-weight:900;color:#1A202C;margin-bottom:6px;">Trip Completed!</div>'
        +'<div style="font-size:14px;color:#718096;margin-bottom:20px;">Your ride has ended. Thank you for riding with EnviroCab!</div>'
        +fbox
        +'<button onclick="location.href=\'passenger_trips.php\'" style="width:100%;padding:14px;border-radius:16px;background:linear-gradient(135deg,#00D084,#00A86B);color:#fff;font-size:15px;font-weight:800;border:none;cursor:pointer;box-shadow:0 4px 16px rgba(0,208,132,.35);margin-bottom:10px;">View Trip Details</button>'
        +'<button onclick="location.href=\'passenger_booking.php\'" style="width:100%;padding:14px;border-radius:16px;background:transparent;color:#00A86B;font-size:15px;font-weight:700;border:2px solid rgba(0,208,132,.3);cursor:pointer;">Book Another Ride</button>'
        +'</div>';
    document.body.appendChild(ov);
}

document.addEventListener('DOMContentLoaded', () => {
    if (isConfirmed) {
        initTrackingMap();
        setTimeout(() => { trackingMap.invalidateSize(); placeStaticMarkers(); }, 300);
        
        var fcBtn = document.getElementById('force-complete-btn');
        if (fcBtn) fcBtn.style.display = 'block';
    }
    Poller.start();
});


function cancelBooking(bookingId) {
    
    let modal = document.getElementById('cancelConfirmModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'cancelConfirmModal';
        modal.style.cssText = 'position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,0.6);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:24px;';
        modal.innerHTML = `<div style="background:#fff;border-radius:24px;padding:32px 24px 24px;text-align:center;max-width:300px;width:100%;box-shadow:0 24px 60px rgba(0,0,0,.3);">
            <div style="width:60px;height:60px;border-radius:50%;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
            </div>
            <div style="font-size:18px;font-weight:800;color:#1A202C;margin-bottom:8px;">Cancel Booking?</div>
            <div style="font-size:13px;color:#718096;margin-bottom:24px;line-height:1.5;">Are you sure you want to cancel? This cannot be undone.</div>
            <button id="cancelConfirmYes" style="width:100%;padding:13px;border-radius:14px;background:linear-gradient(135deg,#EF4444,#DC2626);color:#fff;font-size:14px;font-weight:700;border:none;cursor:pointer;margin-bottom:10px;">Yes, Cancel Booking</button>
            <button id="cancelConfirmNo" style="width:100%;padding:13px;border-radius:14px;background:transparent;color:#718096;font-size:14px;font-weight:600;border:2px solid #E2E8F0;cursor:pointer;">Keep Booking</button>
        </div>`;
        document.body.appendChild(modal);
        document.getElementById('cancelConfirmNo').onclick  = () => { modal.style.display = 'none'; };
        modal.addEventListener('click', e => { if (e.target === modal) modal.style.display = 'none'; });
    }
    modal.style.display = 'flex';

    document.getElementById('cancelConfirmYes').onclick = async () => {
        modal.style.display = 'none';

        
        let overlay = document.getElementById('cancellingOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'cancellingOverlay';
            overlay.style.cssText = 'position:fixed;inset:0;z-index:10001;background:rgba(0,0,0,0.65);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;';
            overlay.innerHTML = `<div style="background:#fff;border-radius:24px;padding:36px 28px;text-align:center;max-width:300px;width:90%;box-shadow:0 24px 60px rgba(0,0,0,.3);">
                <div id="cancelOvIconWrap" style="width:64px;height:64px;border-radius:50%;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                </div>
                <div id="cancelOvMsg" style="font-size:16px;font-weight:700;color:#1A202C;margin-bottom:8px;">Cancelling Booking…</div>
                <div id="cancelOvSub" style="font-size:13px;color:#718096;">Please wait a moment</div>
                <div style="margin-top:20px;display:flex;justify-content:center;gap:6px;">
                    <span style="width:8px;height:8px;background:#EF4444;border-radius:50%;display:inline-block;animation:dotBounce 1.2s infinite 0s;"></span>
                    <span style="width:8px;height:8px;background:#EF4444;border-radius:50%;display:inline-block;animation:dotBounce 1.2s infinite 0.2s;"></span>
                    <span style="width:8px;height:8px;background:#EF4444;border-radius:50%;display:inline-block;animation:dotBounce 1.2s infinite 0.4s;"></span>
                </div>
            </div>`;
            document.body.appendChild(overlay);
            if (!document.getElementById('cancelOverlayStyle')) {
                const st = document.createElement('style'); st.id = 'cancelOverlayStyle';
                st.textContent = '@keyframes dotBounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-10px)}}';
                document.head.appendChild(st);
            }
        }
        overlay.style.display = 'flex';

        try {
            const res  = await fetch(API_BASE, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: `ajax_action=cancel_booking&booking_id=${bookingId}`
            });
            const data = await res.json();
            if (data.success) {
                
                document.getElementById('cancelOvMsg').textContent = 'Booking Cancelled';
                document.getElementById('cancelOvSub').textContent = 'Redirecting you…';
                document.getElementById('cancelOvIconWrap').style.background = 'rgba(16,185,129,0.1)';
                document.getElementById('cancelOvIconWrap').innerHTML = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
                Poller.stop();
                setTimeout(() => { window.location.href = 'passenger_booking.php'; }, 1200);
            } else {
                overlay.style.display = 'none';
                document.getElementById('cancelConfirmModal').style.display = 'flex';
                document.getElementById('cancelConfirmYes').textContent = 'Yes, Cancel Booking';
                document.getElementById('cancelConfirmYes').disabled = false;
                alert(data.message || 'Could not cancel. Please try again.');
            }
        } catch(e) {
            overlay.style.display = 'none';
            alert('Network error. Please try again.');
        }
    };
}


async function forceComplete() {
    const btn = document.getElementById('force-complete-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Confirming…'; }
    try {
        const res  = await fetch(API_BASE, {
            method: 'POST',
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body: `ajax_action=force_complete&booking_id=${BOOKING_ID}`
        });
        const data = await res.json();
        if (data.success) {
            Poller.stop();
            showTripDoneOverlay(data);
        } else {
            alert(data.error || 'Could not complete. Please try again.');
            if (btn) { btn.disabled = false; btn.textContent = '✓ Driver said trip is done? Tap to confirm'; }
        }
    } catch(e) {
        alert('Network error. Please try again.');
        if (btn) { btn.disabled = false; btn.textContent = '✓ Driver said trip is done? Tap to confirm'; }
    }
}
</script>

<?php else: ?>

<div class="hero-card">
    <div class="hero-greeting"><?= $greeting ?>, <?= htmlspecialchars($_SESSION['name'] ?? $_SESSION['username']) ?>!</div>
    <div class="hero-title">Where to today?</div>
    <div class="hero-subtitle">Book a smart, eco-friendly ride in seconds.</div>
</div>

<div class="steps-bar">
    <div class="step-item">
        <div class="step-circle active" id="step1-circle">1</div>
        <div class="step-label active-label" id="step1-label">Route</div>
    </div>
    <div class="step-connector" id="conn1"></div>
    <div class="step-item">
        <div class="step-circle pending" id="step2-circle">2</div>
        <div class="step-label" id="step2-label">Service</div>
    </div>
    <div class="step-connector" id="conn2"></div>
    <div class="step-item">
        <div class="step-circle pending" id="step3-circle">3</div>
        <div class="step-label" id="step3-label">Payment</div>
    </div>
    <div class="step-connector" id="conn3"></div>
    <div class="step-item">
        <div class="step-circle pending" id="step4-circle">4</div>
        <div class="step-label" id="step4-label">Confirm</div>
    </div>
</div>

<?php if ($error_message): ?>
<div class="alert alert-error">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#B91C1C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="8" x2="12" y2="12"></line>
        <line x1="12" y1="16" x2="12.01" y2="16"></line>
    </svg>
    <?= htmlspecialchars($error_message) ?>
</div>
<?php endif; ?>

<form method="POST" id="bookingForm" onsubmit="handleSubmit(event)">
    <input type="hidden" name="action" value="create_booking">
    <input type="hidden" name="ride_type" id="ride_type_input" value="Now">
    <input type="hidden" name="distance_km" id="distance_km_input" value="0">

    <div class="form-card" id="section-route">
        <div class="card-title">
            <div class="card-title-icon" style="background:rgba(0,208,132,0.12);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            </div>
            Where are you going?
        </div>

        <div class="ride-tabs">
            <div class="ride-tab selected" id="tab-now" onclick="setRideType('Now')">
                <div class="ride-tab-icon">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
                </div>
                <div class="ride-tab-label">Ride Now</div>
            </div>
            <div class="ride-tab" id="tab-scheduled" onclick="setRideType('Scheduled')">
                <div class="ride-tab-icon">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                </div>
                <div class="ride-tab-label">Schedule</div>
            </div>
        </div>

        <div class="location-field-wrap" style="margin-bottom:10px;">
            <div class="loc-label"><span class="loc-dot pickup-dot"></span>Pickup</div>
            <div class="autocomplete-wrap" id="pickup-wrap">
                <div class="autocomplete-input-row">
                    <input type="text" name="pickup_location" id="pickup_input" class="field-input ac-input"
                        placeholder="Search pickup location…" required autocomplete="off"
                        value="<?= htmlspecialchars($_POST['pickup_location'] ?? '') ?>"
                        oninput="acSearch('pickup')" onfocus="acSearch('pickup')">
                    <button type="button" class="gps-btn" id="gps-btn" onclick="useMyLocation()" title="Use my location">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M12 1v3M12 20v3M4.22 4.22l2.12 2.12M17.66 17.66l2.12 2.12M1 12h3M20 12h3M4.22 19.78l2.12-2.12M17.66 6.34l2.12-2.12"></path></svg>
                    </button>
                </div>
                <input type="hidden" name="pickup_lat" id="pickup_lat" value="<?= htmlspecialchars($_POST['pickup_lat'] ?? '') ?>">
                <input type="hidden" name="pickup_lng" id="pickup_lng" value="<?= htmlspecialchars($_POST['pickup_lng'] ?? '') ?>">
                <input type="hidden" name="dest_lat" id="dest_lat" value="<?= htmlspecialchars($_POST['dest_lat'] ?? '') ?>">
                <input type="hidden" name="dest_lng" id="dest_lng" value="<?= htmlspecialchars($_POST['dest_lng'] ?? '') ?>">
                <div class="ac-dropdown" id="pickup-dropdown"></div>
            </div>
        </div>

        <div class="route-connector"><div class="connector-line"></div></div>

        <div class="location-field-wrap" style="margin-top:10px;">
            <div class="loc-label"><span class="loc-dot dest-dot"></span>Destination</div>
            <div class="autocomplete-wrap" id="destination-wrap">
                <div class="autocomplete-input-row">
                    <input type="text" name="destination" id="destination_input" class="field-input ac-input"
                        placeholder="Search destination…" required autocomplete="off"
                        value="<?= htmlspecialchars($_POST['destination'] ?? '') ?>"
                        oninput="acSearch('destination')" onfocus="acSearch('destination')">
                    <button type="button" class="clear-btn" id="dest-clear" onclick="clearField('destination')" style="display:none;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    </button>
                </div>
                <div class="ac-dropdown" id="destination-dropdown"></div>
            </div>
        </div>

        <div class="map-container">
            <div id="booking-map"></div>
            <div class="map-status" id="map-status">Enter locations above to preview route</div>
            <div id="map-flyover-overlay" class="map-flyover-overlay" style="display:none;"></div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:16px;">
            <div class="field-group" style="margin-bottom:0;" id="date-group">
                <label class="field-label">Date <span class="field-required">*</span></label>
                <input type="date" name="booking_date" id="booking_date" class="field-input"
                    min="<?= $today_min ?>" max="<?= $max_date ?>"
                    value="<?= htmlspecialchars($_POST['booking_date'] ?? $today_min) ?>"
                    required oninput="updateFarePreview()">
            </div>
            <div class="field-group" style="margin-bottom:0;" id="time-group">
                <label class="field-label">Time</label>
                <input type="time" name="booking_time" id="booking_time" class="field-input"
                    value="<?= htmlspecialchars($_POST['booking_time'] ?? date('H:i')) ?>"
                    oninput="updateFarePreview()">
            </div>
        </div>

    </div>

    <div class="form-card" id="section-fuel">
        <div class="card-title">
            <div class="card-title-icon" style="background:rgba(251,146,60,0.12);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--accent-orange)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
            </div>
            Vehicle Type <span class="field-required">*</span>
        </div>
        <div class="fuel-tabs">
            <label class="fuel-tab electric <?= (($_POST['vehicle_fuel'] ?? '') === 'Electric') ? 'selected' : '' ?>"
                   id="fuel-electric" onclick="selectFuel('Electric')">
                <input type="radio" name="vehicle_fuel" value="Electric" <?= (($_POST['vehicle_fuel'] ?? '') === 'Electric') ? 'checked' : '' ?>>
                <div class="fuel-tab-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
                <div class="fuel-tab-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg></div>
                <div class="fuel-tab-name">Electric</div>
                <div class="fuel-tab-desc">Zero emissions, quiet &amp; smooth</div>
                <div class="fuel-eco-tag">ECO FRIENDLY</div>
            </label>
            <label class="fuel-tab gasoline <?= (($_POST['vehicle_fuel'] ?? '') === 'Gasoline') ? 'selected' : '' ?>"
                   id="fuel-gasoline" onclick="selectFuel('Gasoline')">
                <input type="radio" name="vehicle_fuel" value="Gasoline" <?= (($_POST['vehicle_fuel'] ?? '') === 'Gasoline') ? 'checked' : '' ?>>
                <div class="fuel-tab-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
                <div class="fuel-tab-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 22V8l9-6 9 6v14H3z"></path><path d="M15 22v-6a3 3 0 0 0-3-3 3 3 0 0 0-3 3v6"></path><path d="M9 8h6"></path></svg></div>
                <div class="fuel-tab-name">Gasoline</div>
                <div class="fuel-tab-desc">Standard fuel-powered vehicle</div>
            </label>
        </div>
        <div class="fuel-note electric" id="fuel-note-electric" style="<?= (($_POST['vehicle_fuel'] ?? '') !== 'Electric') ? 'display:none;' : '' ?>">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
            Electric rate: &#8369;10/km — save more per trip &amp; reduce your carbon footprint!
        </div>
        <div class="fuel-note gasoline" id="fuel-note-gasoline" style="<?= (($_POST['vehicle_fuel'] ?? '') !== 'Gasoline') ? 'display:none;' : '' ?>">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 22V8l9-6 9 6v14H3z"></path><path d="M15 22v-6a3 3 0 0 0-3-3 3 3 0 0 0-3 3v6"></path></svg>
            Standard rate: &#8369;12/km — reliable and widely available.
        </div>
    </div>

    <div class="form-card" id="section-service">
        <?php
        $taxi_service = !empty($services) ? $services[0] : ['service_id' => 1, 'service_name' => 'Taxi', 'unit_price' => 50.00];
        $taxi_price   = $taxi_service['unit_price']  ?? 50.00;
        $taxi_id      = $taxi_service['service_id']  ?? 1;
        ?>
        <input type="hidden" name="service_id" value="<?= $taxi_id ?>">
        <div class="card-title">
            <div class="card-title-icon" style="background:rgba(96,165,250,0.12);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--accent-blue)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
            </div>
            Your Ride
        </div>
        <div class="taxi-banner">
            <div class="taxi-banner-icon">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
            </div>
            <div class="taxi-banner-info">
                <div class="taxi-banner-name">EnviroCab Taxi</div>
                <div class="taxi-banner-desc">Professional, metered taxi service</div>
            </div>
            <div class="taxi-banner-price">
                <div class="taxi-price-label">Base fare</div>
                <div class="taxi-price-value">&#8369;<?= number_format($taxi_price, 2) ?></div>
            </div>
        </div>
        <div class="taxi-perks">
            <div class="perk-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--dark-green)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg><span>Licensed driver</span></div>
            <div class="perk-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--dark-green)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg><span>Metered fare</span></div>
            <div class="perk-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--dark-green)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg><span>Live tracking</span></div>
            <div class="perk-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--dark-green)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg><span>24/7 available</span></div>
        </div>
        <div style="border-top:1px solid var(--card-border); padding-top:16px; margin-top:4px;">
            <label class="field-label">Number of Passengers</label>
            <div class="qty-row">
                <button type="button" class="qty-btn" onclick="adjustQty(-1)">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                </button>
                <div class="qty-display">
                    <input type="number" name="quantity" id="qty" value="<?= htmlspecialchars($_POST['quantity'] ?? 1) ?>" min="1" max="6" oninput="updateFarePreview()" style="position:absolute;opacity:0;pointer-events:none;">
                    <span id="qty-display-val"><?= $_POST['quantity'] ?? 1 ?></span>
                    <span class="qty-sub">passenger<?= (($_POST['quantity'] ?? 1) == 1) ? '' : 's' ?></span>
                </div>
                <button type="button" class="qty-btn" onclick="adjustQty(1)">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                </button>
            </div>
        </div>
        <div class="field-group" style="margin-top:14px;">
            <label class="field-label">Notes for driver <span style="color:var(--text-light); font-weight:400; text-transform:none;">(optional)</span></label>
            <textarea name="special_requirements" class="field-input" rows="2"
                placeholder="e.g. I'll be waiting at the lobby, extra luggage, etc."
                style="resize:none; font-family:'Inter',sans-serif;"><?= htmlspecialchars($_POST['special_requirements'] ?? '') ?></textarea>
        </div>
    </div>

    <div class="form-card" id="section-payment">
        <div class="card-title">
            <div class="card-title-icon" style="background:rgba(16,185,129,0.12);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
            </div>
            Payment Method
        </div>
        <div class="payment-methods">
            <?php
            $payMethods = [
                ['value' => 'Cash',  'label' => 'Cash',  'desc' => 'Pay driver on arrival',
                 'svg' => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"></rect><circle cx="12" cy="12" r="2"></circle><path d="M6 12h.01M18 12h.01"></path></svg>'],
                ['value' => 'GCash', 'label' => 'GCash', 'desc' => 'Pay via GCash e-wallet',
                 'svg' => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line><line x1="9" y1="7" x2="15" y2="7"></line></svg>'],
            ];
            $defaultPay = $_POST['payment_method'] ?? 'Cash';
            foreach ($payMethods as $pm):
                $sel = ($defaultPay === $pm['value']) ? 'selected' : '';
            ?>
            <label class="pay-option <?= $sel ?>" onclick="selectPayment(this)">
                <input type="radio" name="payment_method" value="<?= $pm['value'] ?>" <?= $sel ? 'checked' : '' ?>>
                <div class="pay-icon"><?= $pm['svg'] ?></div>
                <div class="pay-label"><?= $pm['label'] ?></div>
                <div style="font-size:10px;color:var(--text-light);margin-top:3px;font-weight:500;"><?= $pm['desc'] ?></div>
            </label>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="form-card" id="section-confirm">
        <div class="card-title">
            <div class="card-title-icon" style="background:rgba(0,208,132,0.12);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            </div>
            Fare Estimate
        </div>
        <div class="fare-preview">
            <div class="fare-row"><span>Base Fare</span><span id="preview-base">&#8369;50.00</span></div>
            <div class="fare-row"><span>Distance (est.)</span><span id="preview-distance">~&#8369;0.00</span></div>
            <div class="fare-row total"><span>Estimated Total</span><span id="preview-total">&#8369;50.00</span></div>
        </div>
        <p style="font-size:11px;color:var(--text-light);margin-top:10px;text-align:center;line-height:1.5;">
            Final fare may vary based on actual distance &amp; wait time.<br>
            A nearby driver will be notified to accept your booking.
        </p>
    </div>

    <button type="submit" class="submit-btn" id="submitBtn">
        <div class="spinner"></div>
        <span class="btn-text" style="display:flex;align-items:center;gap:8px;">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
            Request a Ride
        </span>
    </button>
</form>

<script>
(function(){
    var t = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();

let selectedBaseFare  = <?= !empty($services) ? (float)($services[0]['unit_price'] ?? 50) : 50 ?>;
const EST_DISTANCE    = 10;
let EST_DISTANCE_LIVE = null;
let map, pickupMarker, destMarker, routeLine;
let acTimers = { pickup: null, destination: null };

function setRideType(type) {
    document.getElementById('ride_type_input').value = type;
    document.getElementById('tab-now').classList.toggle('selected', type === 'Now');
    document.getElementById('tab-scheduled').classList.toggle('selected', type === 'Scheduled');
    const tg  = document.getElementById('time-group');
    const dg  = document.getElementById('date-group');
    const dtInput = document.getElementById('booking_date');
    if (type === 'Now') {
        const now = new Date();
        document.getElementById('booking_time').value = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
        dtInput.value = now.toISOString().slice(0,10);
        
        tg.style.opacity = '0.45'; tg.style.pointerEvents = 'none';
        dg.style.opacity = '0.45'; dg.style.pointerEvents = 'none';
        dtInput.readOnly = true;
        
        let badge = document.getElementById('ride-now-badge');
        if (!badge) {
            badge = document.createElement('div');
            badge.id = 'ride-now-badge';
            badge.style.cssText = 'margin-top:8px;padding:7px 12px;border-radius:10px;background:rgba(0,208,132,0.1);border:1px solid rgba(0,208,132,0.25);color:var(--dark-green);font-size:11px;font-weight:700;display:flex;align-items:center;gap:6px;';
            badge.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>Ride Now — date & time set to right now';
            dg.closest('[style*="grid"]').after(badge);
        }
        badge.style.display = 'flex';
    } else {
        dtInput.disabled = false;
        dtInput.readOnly = false;
        tg.style.opacity = '1'; tg.style.pointerEvents = 'auto';
        dg.style.opacity = '1'; dg.style.pointerEvents = 'auto';
        const badge = document.getElementById('ride-now-badge');
        if (badge) badge.style.display = 'none';
    }
    updateFarePreview();
}
(function(){
    const now = new Date();
    document.getElementById('booking_time').value = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
    document.getElementById('time-group').style.opacity = '0.45';
    document.getElementById('time-group').style.pointerEvents = 'none';
    document.getElementById('date-group').style.opacity = '0.45';
    document.getElementById('date-group').style.pointerEvents = 'none';
    document.getElementById('booking_date').readOnly = true;
})();

document.addEventListener('DOMContentLoaded', () => { updateFarePreview(); initMap(); });

function selectPayment(el) {
    document.querySelectorAll('.pay-option').forEach(e => e.classList.remove('selected'));
    el.classList.add('selected');
}

function adjustQty(delta) {
    const hidden  = document.getElementById('qty');
    const display = document.getElementById('qty-display-val');
    const sub     = document.querySelector('.qty-sub');
    const val     = Math.min(6, Math.max(1, parseInt(hidden.value || 1) + delta));
    hidden.value  = val;
    if (display) display.textContent = val;
    if (sub)     sub.textContent = val === 1 ? 'passenger' : 'passengers';
    updateFarePreview();
}

function isSurgeHour(timeStr) {
    return false;
}

function selectFuel(type) {
    document.querySelector('[name="vehicle_fuel"][value="' + type + '"]').checked = true;
    document.getElementById('fuel-electric').classList.toggle('selected', type === 'Electric');
    document.getElementById('fuel-gasoline').classList.toggle('selected', type === 'Gasoline');
    document.getElementById('fuel-note-electric').style.display = (type === 'Electric') ? 'flex' : 'none';
    document.getElementById('fuel-note-gasoline').style.display = (type === 'Gasoline') ? 'flex' : 'none';
    updateFarePreview();
}

function updateFarePreview() {
    const timeVal    = document.getElementById('booking_time').value;
    const qty        = parseInt(document.getElementById('qty').value) || 1;
    const fuelRadio  = document.querySelector('[name="vehicle_fuel"]:checked');
    const isElectric = fuelRadio && fuelRadio.value === 'Electric';
    const rate       = isElectric ? 10 : 12;
    const km         = EST_DISTANCE_LIVE || EST_DISTANCE;
    const distCost   = km * rate;
    const total      = (selectedBaseFare + distCost) * qty;
    document.getElementById('preview-base').textContent     = '₱' + parseFloat(selectedBaseFare).toFixed(2);
    document.getElementById('preview-distance').textContent = '~₱' + distCost.toFixed(2) + (isElectric ? ' (₱10/km · EV)' : ' (₱12/km · Gas)');
    document.getElementById('preview-total').textContent    = '₱' + total.toLocaleString('en-PH', {minimumFractionDigits:2, maximumFractionDigits:2});
    updateStepVisual();
}

function updateFarePreviewWithDistance(km) {
    EST_DISTANCE_LIVE = km;
    const distInput = document.getElementById('distance_km_input');
    if (distInput) distInput.value = km;
    updateFarePreview();
    const fuelRadio  = document.querySelector('[name="vehicle_fuel"]:checked');
    const isElectric = fuelRadio && fuelRadio.value === 'Electric';
    const rate       = isElectric ? 10 : 12;
    document.getElementById('preview-distance').textContent = '~₱' + (km * rate).toFixed(2) + ' (' + km + ' km · ' + (isElectric ? '₱10/km · EV' : '₱12/km · Gas') + ')';
}

function updateStepVisual() {
    const pickup  = document.getElementById('pickup_input')?.value?.trim();
    const dest    = document.getElementById('destination_input')?.value?.trim();
    const fuelSel = document.querySelector('[name="vehicle_fuel"]:checked');
    const s1done  = !!(pickup && dest && fuelSel);
    setStep(1, s1done ? 'done' : 'active');
    setStep(2, s1done ? 'done' : 'pending');
    setStep(3, s1done ? 'done' : 'pending');
    setStep(4, s1done ? 'active' : 'pending');
    document.getElementById('conn1').classList.toggle('done', s1done);
    document.getElementById('conn2').classList.toggle('done', s1done);
    document.getElementById('conn3').classList.toggle('done', s1done);
}
function setStep(n, state) {
    const circ  = document.getElementById('step' + n + '-circle');
    const label = document.getElementById('step' + n + '-label');
    if (!circ) return;
    circ.className = 'step-circle ' + state;
    if (state === 'done') {
        circ.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>';
    } else {
        circ.textContent = n;
    }
    if (label) label.className = 'step-label' + (state === 'active' ? ' active-label' : '');
}

function handleSubmit(e) {
    
    
    const distInput = document.getElementById('distance_km_input');
    if (distInput) {
        const currentKm = EST_DISTANCE_LIVE || EST_DISTANCE;
        distInput.value = currentKm;
    }
    const btn = document.getElementById('submitBtn');
    btn.classList.add('loading');
    btn.disabled = true;
}


const PICKUP_ICON = L.divIcon({
    html: `<div style="
        display:flex;flex-direction:column;align-items:center;
        filter:drop-shadow(0 4px 10px rgba(0,208,132,0.45));">
        <div style="
            width:36px;height:36px;border-radius:50% 50% 50% 0;
            background:linear-gradient(135deg,#00D084,#00A86B);
            transform:rotate(-45deg);
            display:flex;align-items:center;justify-content:center;
            border:3px solid white;">
            <svg style="transform:rotate(45deg)" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="10" r="3" fill="white" stroke="none"/>
            </svg>
        </div>
        <div style="width:3px;height:10px;background:#00A86B;margin-top:-2px;border-radius:0 0 3px 3px;"></div>
    </div>`,
    iconSize: [36, 50], iconAnchor: [18, 50], className: ''
});
const DEST_ICON = L.divIcon({
    html: `<div style="
        display:flex;flex-direction:column;align-items:center;
        filter:drop-shadow(0 4px 10px rgba(239,68,68,0.45));">
        <div style="
            width:36px;height:36px;border-radius:50% 50% 50% 0;
            background:linear-gradient(135deg,#EF4444,#DC2626);
            transform:rotate(-45deg);
            display:flex;align-items:center;justify-content:center;
            border:3px solid white;">
            <div style="width:8px;height:8px;background:white;border-radius:50%;transform:rotate(45deg);"></div>
        </div>
        <div style="width:3px;height:10px;background:#DC2626;margin-top:-2px;border-radius:0 0 3px 3px;"></div>
    </div>`,
    iconSize: [36, 50], iconAnchor: [18, 50], className: ''
});

function initMap() {
    if (!document.getElementById('booking-map')) return;
    map = L.map('booking-map', {
        zoomControl: true,
        scrollWheelZoom: false,
        attributionControl: true
    }).setView([14.5995, 120.9842], 12);

    
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
    }).addTo(map);

    const pu = document.getElementById('pickup_input')?.value;
    const ds = document.getElementById('destination_input')?.value;
    if (pu || ds) setTimeout(refreshMapMarkers, 400);
}
function acSearch(field) {
    const inputEl = document.getElementById(field + '_input');
    const val     = inputEl.value.trim();
    if (field === 'destination') {
        const cb = document.getElementById('dest-clear');
        if (cb) cb.style.display = val ? 'flex' : 'none';
    }
    if (acTimers[field]) clearTimeout(acTimers[field]);
    if (val.length < 2) { closeDropdown(field); return; }
    showLoading(field);
    acTimers[field] = setTimeout(() => fetchSuggestions(field, val), 500);
}
async function fetchSuggestions(field, query) {
    try {
        const url  = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&countrycodes=ph&addressdetails=1`;
        const res  = await fetch(url, { headers:{ 'Accept-Language':'en' } });
        const data = await res.json();
        renderDropdown(field, data);
    } catch(e) { closeDropdown(field); }
}
function renderDropdown(field, results) {
    const dd = document.getElementById(field + '-dropdown');
    if (!dd) return;
    if (!results || results.length === 0) {
        dd.innerHTML = `<div class="ac-no-results">No locations found. Try a different search.</div>`;
        dd.classList.add('open'); return;
    }
    dd.innerHTML = results.map(r => {
        const name = r.namedetails?.name || r.display_name.split(',')[0];
        const addr = r.display_name;
        return `<div class="ac-item" onclick="selectLocation('${field}', ${r.lat}, ${r.lon}, '${escQ(addr)}')">
            <div class="ac-item-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></div>
            <div class="ac-item-text"><div class="ac-item-name">${escH(name)}</div><div class="ac-item-addr">${escH(addr)}</div></div>
        </div>`;
    }).join('');
    dd.classList.add('open');
}
function selectLocation(field, lat, lon, displayName) {
    const inputEl = document.getElementById(field + '_input');
    inputEl.value = displayName;
    closeDropdown(field);
    if (field === 'destination') {
        const cb = document.getElementById('dest-clear');
        if (cb) cb.style.display = 'flex';
    }
    inputEl.dataset.lat = lat;
    inputEl.dataset.lon = lon;
    
    if (field === 'pickup') {
        const latEl = document.getElementById('pickup_lat');
        const lngEl = document.getElementById('pickup_lng');
        if (latEl) latEl.value = lat;
        if (lngEl) lngEl.value = lon;
    } else if (field === 'destination') {
        const latEl = document.getElementById('dest_lat');
        const lngEl = document.getElementById('dest_lng');
        if (latEl) latEl.value = lat;
        if (lngEl) lngEl.value = lon;
    }
    
    showLocationFlyover(field, displayName, () => {
        refreshMapMarkers();
    });
    updateFarePreview();
    updateStepVisual();
}

function showLocationFlyover(field, label, callback) {
    const overlay = document.getElementById('map-flyover-overlay');
    if (!overlay) { if(callback) callback(); return; }
    const isPickup = field === 'pickup';
    const color    = isPickup ? '#00D084' : '#EF4444';
    const tailColor= isPickup ? '#00A86B' : '#DC2626';
    const ripColor = isPickup ? 'rgba(0,208,132,0.35)' : 'rgba(239,68,68,0.3)';
    const shortLabel = label.split(',')[0].trim().slice(0, 28) + (label.split(',')[0].trim().length > 28 ? '…' : '');
    overlay.innerHTML = `
        <div class="map-flyover-pin">
            <div class="map-flyover-pin-head" style="background:${color};">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                    <circle cx="12" cy="10" r="3" fill="white" stroke="none"/>
                </svg>
            </div>
            <div class="map-flyover-pin-tail" style="background:${tailColor};"></div>
            <div class="map-flyover-ripple" style="background:${ripColor};"></div>
            <div class="map-flyover-label">${shortLabel}</div>
        </div>`;
    overlay.style.display = 'flex';
    overlay.classList.remove('fade-out');
    
    if (map) {
        const lat = parseFloat(document.getElementById(field + '_input').dataset.lat);
        const lon = parseFloat(document.getElementById(field + '_input').dataset.lon);
        if (!isNaN(lat) && !isNaN(lon)) {
            map.flyTo([lat, lon], 15, { duration: 0.9, easeLinearity: 0.3 });
        }
    }
    
    setTimeout(() => {
        overlay.classList.add('fade-out');
        setTimeout(() => {
            overlay.style.display = 'none';
            overlay.classList.remove('fade-out');
            if (callback) callback();
        }, 500);
    }, 1400);
}
function closeDropdown(field) { const dd = document.getElementById(field + '-dropdown'); if (dd) dd.classList.remove('open'); }
function showLoading(field) {
    const dd = document.getElementById(field + '-dropdown');
    if (dd) {
        dd.innerHTML = `<div class="ac-loading"><div class="spinner" style="border-color:rgba(0,168,107,0.3);border-top-color:var(--dark-green);width:14px;height:14px;"></div> Searching...</div>`;
        dd.classList.add('open');
    }
}
function clearField(field) {
    const inputEl = document.getElementById(field + '_input');
    inputEl.value = ''; delete inputEl.dataset.lat; delete inputEl.dataset.lon;
    closeDropdown(field);
    if (field === 'destination') { const cb = document.getElementById('dest-clear'); if (cb) cb.style.display = 'none'; }
    refreshMapMarkers(); updateFarePreview();
}
document.addEventListener('click', e => {
    ['pickup','destination'].forEach(f => {
        const wrap = document.getElementById(f + '-wrap');
        if (wrap && !wrap.contains(e.target)) closeDropdown(f);
    });
});
function useMyLocation() {
    const btn = document.getElementById('gps-btn');
    if (!navigator.geolocation) { alert('Geolocation is not supported.'); return; }
    btn.classList.add('loading');
    setMapStatus('Getting your location…', 'geocoding');
    navigator.geolocation.getCurrentPosition(async pos => {
        const { latitude: lat, longitude: lon } = pos.coords;
        btn.classList.remove('loading');
        try {
            const url  = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=17&addressdetails=1`;
            const res  = await fetch(url, { headers:{ 'Accept-Language':'en' } });
            const data = await res.json();
            const inputEl = document.getElementById('pickup_input');
            inputEl.value = data.display_name;
            inputEl.dataset.lat = lat; inputEl.dataset.lon = lon;
            
            const latField = document.getElementById('pickup_lat');
            const lngField = document.getElementById('pickup_lng');
            if (latField) latField.value = lat;
            if (lngField) lngField.value = lon;
            refreshMapMarkers(); updateFarePreview(); updateStepVisual();
        } catch(e) { btn.classList.remove('loading'); alert('Could not get address. Type it manually.'); }
    }, err => {
        btn.classList.remove('loading');
        if (err.code === err.PERMISSION_DENIED) alert('Location access denied. Type your pickup address.');
        else alert('Could not detect location. Type your pickup address.');
    }, { timeout: 10000 });
}
function refreshMapMarkers() {
    if (!map) return;
    const puEl = document.getElementById('pickup_input');
    const dsEl = document.getElementById('destination_input');
    const puLat = parseFloat(puEl?.dataset.lat), puLon = parseFloat(puEl?.dataset.lon);
    const dsLat = parseFloat(dsEl?.dataset.lat), dsLon = parseFloat(dsEl?.dataset.lon);
    if (pickupMarker) { map.removeLayer(pickupMarker); pickupMarker = null; }
    if (destMarker)   { map.removeLayer(destMarker);   destMarker   = null; }
    if (routeLine)    {
        
        if (Array.isArray(routeLine)) { routeLine.forEach(l => map.removeLayer(l)); }
        else { map.removeLayer(routeLine); }
        routeLine = null;
    }
    const pts = [];
    if (!isNaN(puLat) && !isNaN(puLon)) { pts.push([puLat, puLon]); }
    if (!isNaN(dsLat) && !isNaN(dsLon)) { pts.push([dsLat, dsLon]); }

    if (pts.length === 2) {
        const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${puLon},${puLat};${dsLon},${dsLat}?overview=full&geometries=geojson`;
        fetch(osrmUrl)
            .then(r => r.json())
            .then(data => {
                if (!map) return;
                if (routeLine) {
                    if (Array.isArray(routeLine)) routeLine.forEach(l => map.removeLayer(l));
                    else map.removeLayer(routeLine);
                    routeLine = null;
                }
                let routeCoords;
                if (data.routes && data.routes[0]) {
                    routeCoords = data.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
                    const distKm = Math.round(data.routes[0].distance / 100) / 10;
                    setMapStatus('~' + distKm + ' km · Road route', 'geocoding');
                    updateFarePreviewWithDistance(distKm);
                } else {
                    routeCoords = pts;
                    const distKm = Math.round(map.distance(pts[0], pts[1]) / 100) / 10;
                    setMapStatus('~' + distKm + ' km · Route preview', 'geocoding');
                    updateFarePreviewWithDistance(distKm);
                }
                const shadow = L.polyline(routeCoords, {color:'rgba(0,168,107,0.15)', weight:18, lineCap:'round', lineJoin:'round'}).addTo(map);
                const glow   = L.polyline(routeCoords, {color:'rgba(0,208,132,0.3)',  weight:10, lineCap:'round', lineJoin:'round'}).addTo(map);
                const main   = L.polyline(routeCoords, {color:'#00D084', weight:5, lineCap:'round', lineJoin:'round', opacity:1}).addTo(map);
                const flow   = L.polyline(routeCoords, {color:'rgba(255,255,255,0.75)', weight:3, dashArray:'12 18', dashOffset:'0', lineCap:'round', lineJoin:'round', className:'route-flow-line'}).addTo(map);
                routeLine = [shadow, glow, main, flow];
                if (pickupMarker) map.removeLayer(pickupMarker);
                if (destMarker)   map.removeLayer(destMarker);
                pickupMarker = L.marker([puLat, puLon], {icon: PICKUP_ICON}).addTo(map);
                destMarker   = L.marker([dsLat, dsLon], {icon: DEST_ICON}).addTo(map);
                map.fitBounds(L.latLngBounds(routeCoords).pad(0.18));
            })
            .catch(() => {
                if (routeLine) {
                    if (Array.isArray(routeLine)) routeLine.forEach(l => map.removeLayer(l));
                    else map.removeLayer(routeLine);
                    routeLine = null;
                }
                const shadow = L.polyline(pts, {color:'rgba(0,168,107,0.15)', weight:18, lineCap:'round', lineJoin:'round'}).addTo(map);
                const glow   = L.polyline(pts, {color:'rgba(0,208,132,0.3)',  weight:10, lineCap:'round', lineJoin:'round'}).addTo(map);
                const main   = L.polyline(pts, {color:'#00D084', weight:5, lineCap:'round', lineJoin:'round', opacity:1}).addTo(map);
                const flow   = L.polyline(pts, {color:'rgba(255,255,255,0.75)', weight:3, dashArray:'12 18', lineCap:'round', lineJoin:'round', className:'route-flow-line'}).addTo(map);
                routeLine = [shadow, glow, main, flow];
                pickupMarker = L.marker([puLat, puLon], {icon: PICKUP_ICON}).addTo(map);
                destMarker   = L.marker([dsLat, dsLon], {icon: DEST_ICON}).addTo(map);
                const distKm = Math.round(map.distance(pts[0], pts[1]) / 100) / 10;
                map.fitBounds(L.latLngBounds(pts).pad(0.18));
                setMapStatus('~' + distKm + ' km · Route preview', 'geocoding');
                updateFarePreviewWithDistance(distKm);
            });
        pickupMarker = L.marker([puLat, puLon], {icon: PICKUP_ICON}).addTo(map);
        destMarker   = L.marker([dsLat, dsLon], {icon: DEST_ICON}).addTo(map);
        map.fitBounds(L.latLngBounds(pts).pad(0.18));
        setMapStatus('Loading road route…', 'geocoding');

    } else if (pts.length === 1) {
        if (!isNaN(puLat) && !isNaN(puLon)) {
            pickupMarker = L.marker([puLat, puLon], {icon: PICKUP_ICON}).addTo(map);
            map.setView([puLat, puLon], 15);
        } else {
            destMarker = L.marker([dsLat, dsLon], {icon: DEST_ICON}).addTo(map);
            map.setView([dsLat, dsLon], 15);
        }
        setMapStatus(pickupMarker ? 'Pickup set' : 'Destination set', 'geocoding');
    } else {
        setMapStatus('Enter locations above to preview route', '');
    }
}
function setMapStatus(text, cls) {
    const el = document.getElementById('map-status');
    if (!el) return;
    el.textContent = text;
    el.className   = 'map-status' + (cls ? ' ' + cls : '');
}
function escQ(s) { return s.replace(/'/g, "\\'").replace(/"/g, '&quot;'); }
function escH(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
</script>

<?php endif; ?>
</div>

<script>
(function(){
    var t = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
function toggleTheme() {
    const html = document.documentElement;
    const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('envirocab_theme', next);
}
</script>

<nav class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
        </div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item active">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
        </div>
        <span class="nav-label">Book</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_trips.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
        </div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_profile.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
        </div>
        <span class="nav-label">Profile</span>
    </button>
        
</nav>
<script>
const CUSTOMER_ID = <?= (int)$customer_id ?>;

const SB_URL = 'https://kyhndwabhbkduoaxeunq.supabase.co';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
let _notifOpen = false, _notifData = [], _notifTimer = null;
let _seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');

const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};

function toggleNotifPanel(e) {
    e.stopPropagation();
    _notifOpen = !_notifOpen;
    document.getElementById('notif-panel').classList.toggle('open', _notifOpen);
    if (_notifOpen) { fetchNotifs(); _notifTimer = setInterval(fetchNotifs, 8000); }
    else clearInterval(_notifTimer);
}

async function fetchNotifs() {
    try {
        const r = await fetch(SB_URL + '/rest/v1/core2_bookings?customer_id=eq.' + CUSTOMER_ID +
            '&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=15',
            {headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        _notifData = await r.json();
        renderNotifs();
        updateBadge();
    } catch(e) {}
}

function renderNotifs() {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!_notifData.length) { list.innerHTML = '<div class="notif-empty">No notifications yet.</div>'; return; }
    list.innerHTML = _notifData.map(b => {
        const cfg = STATUS_CFG[b.booking_status] || {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key = b.booking_id + '_' + b.booking_status;
        const unread = !_seen.includes(key);
        const amt = '\u20B1' + parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t = timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
}

function updateBadge() {
    const cnt = _notifData.filter(b => !_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    const el = document.getElementById('notif-count-badge');
    if (!el) return;
    if (cnt > 0) { el.textContent = cnt > 9 ? '9+' : cnt; el.style.display = 'flex'; }
    else el.style.display = 'none';
}

function goNotif(page, bid, key) {
    if (!_seen.includes(key)) { _seen.push(key); localStorage.setItem(SEEN_KEY, JSON.stringify(_seen)); }
    window.location.href = page + '?booking_id=' + bid;
}

function markAllRead() {
    _seen = _notifData.map(b => b.booking_id+'_'+b.booking_status);
    localStorage.setItem(SEEN_KEY, JSON.stringify(_seen));
    renderNotifs(); updateBadge();
}

function timeAgo(iso) {
    if (!iso) return '';
    const s = Math.floor((Date.now() - new Date(iso))/1000);
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s/60)+'m ago';
    if (s < 86400) return Math.floor(s/3600)+'h ago';
    return Math.floor(s/86400)+'d ago';
}

function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function openLogout() { document.getElementById('logout-overlay').classList.add('open'); }

document.addEventListener('click', function(e) {
    const panel = document.getElementById('notif-panel');
    const btn   = document.getElementById('notif-bell-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        _notifOpen = false; panel.classList.remove('open'); clearInterval(_notifTimer);
    }
});

document.addEventListener('DOMContentLoaded', () => { if (CUSTOMER_ID) fetchNotifs(); });
</script>


<div class="logout-overlay" id="logout-overlay" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="logout-modal">
        <div class="logout-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </div>
        <div class="logout-modal-title">Log out?</div>
        <div class="logout-modal-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-modal-btns">
            <button class="logout-cancel-btn" onclick="document.getElementById('logout-overlay').classList.remove('open')">Cancel</button>
            <button class="logout-confirm-btn" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{ once:true });
      a.addEventListener('touchstart',function(){ prerender(href); },{ once:true, passive:true });
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{ once:true });
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
</body>
</html>