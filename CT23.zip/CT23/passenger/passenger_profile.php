<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['customer_id'])) {
    header('Location: ../auth/passenger_login.php');
    exit;
}

define('SUPABASE_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get($table, $params = []) {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) return json_decode($res, true) ?: [];
    error_log("SB GET {$table} HTTP {$code}: {$res}");
    return [];
}

function sb_patch($table, $filters, $data) {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code >= 200 && $code < 300);
}

$customer_id     = $_SESSION['customer_id'];
$success_message = '';
$error_message   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] === 'update_profile') {
        $name    = trim($_POST['name']    ?? '');
        $email   = trim($_POST['email']   ?? '');
        $phone   = trim($_POST['phone']   ?? '');
        $address = trim($_POST['address'] ?? '');

        if (empty($name)) {
            $error_message = 'Full name is required.';
        } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = 'Please enter a valid email address.';
        } else {
            $ok = sb_patch('core2_customers', ['customer_id' => 'eq.' . $customer_id], [
                'name'    => $name,
                'email'   => $email ?: null,
                'phone'   => $phone ?: null,
                'address' => $address ?: null,
            ]);
            if ($ok) {
                $_SESSION['name'] = $_SESSION['username'] = $name;
                $success_message  = 'Profile updated successfully.';
            } else {
                $error_message = 'Failed to update profile. Please try again.';
            }
        }
    }

    if ($_POST['action'] === 'change_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password     = $_POST['new_password']     ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error_message = 'All password fields are required.';
        } elseif ($new_password !== $confirm_password) {
            $error_message = 'New passwords do not match.';
        } elseif (strlen($new_password) < 6) {
            $error_message = 'Password must be at least 6 characters.';
        } else {
            $rows = sb_get('core2_customers', ['customer_id' => 'eq.' . $customer_id, 'select' => 'password']);
            $stored = $rows[0]['password'] ?? '';
            $is_valid = $stored && (password_verify($current_password, $stored) || $stored === $current_password);
            if (!$is_valid) {
                $error_message = 'Current password is incorrect.';
            } else {
                $ok = sb_patch('core2_customers', ['customer_id' => 'eq.' . $customer_id], [
                    'password' => password_hash($new_password, PASSWORD_DEFAULT),
                ]);
                $success_message = $ok ? 'Password changed successfully.' : 'Failed to change password.';
                if (!$ok) $error_message = 'Failed to change password. Please try again.';
            }
        }
    }

    if ($_POST['action'] === 'upload_avatar') {
        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $file     = $_FILES['avatar'];
            $maxSize  = 2 * 1024 * 1024;
            $allowed  = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $finfo    = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($file['tmp_name']);

            if ($file['size'] > $maxSize) {
                $error_message = 'Image must be under 2MB.';
            } elseif (!in_array($mimeType, $allowed)) {
                $error_message = 'Only JPG, PNG, GIF, and WEBP images are allowed.';
            } else {
                $uploadDir = __DIR__ . '/../uploads/avatars/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $filename = 'avatar_' . $customer_id . '_' . time() . '.' . $ext;
                $dest     = $uploadDir . $filename;

                if (move_uploaded_file($file['tmp_name'], $dest)) {
                    $old_rows = sb_get('core2_customers', ['customer_id' => 'eq.' . $customer_id, 'select' => 'contact_person']);
                    $old_avatar = $old_rows[0]['contact_person'] ?? null;
                    if ($old_avatar) {
                        $old_file = __DIR__ . '/../uploads/avatars/' . basename($old_avatar);
                        if (file_exists($old_file)) @unlink($old_file);
                    }
                    
                    $ok = sb_patch('core2_customers', ['customer_id' => 'eq.' . $customer_id], ['contact_person' => $filename]);
                    if ($ok) { $_SESSION['avatar'] = $filename; $success_message = 'Profile picture updated successfully.'; }
                    else { $error_message = 'Failed to save avatar.'; }
                } else {
                    $error_message = 'Upload failed. Check folder permissions (uploads/avatars/).';
                }
            }
        } else {
            $error_message = 'No image selected or upload error occurred.';
        }
    }

    if ($_POST['action'] === 'remove_avatar') {
        $old_rows = sb_get('core2_customers', ['customer_id' => 'eq.' . $customer_id, 'select' => 'contact_person']);
        $old_avatar = $old_rows[0]['contact_person'] ?? null;
        if ($old_avatar) {
            $old_file = __DIR__ . '/../uploads/avatars/' . basename($old_avatar);
            if (file_exists($old_file)) @unlink($old_file);
        }
        $ok = sb_patch('core2_customers', ['customer_id' => 'eq.' . $customer_id], ['contact_person' => null]);
        if ($ok) { $_SESSION['avatar'] = null; $success_message = 'Profile picture removed.'; }
        else { $error_message = 'Failed to remove avatar.'; }
    }
}

$profile     = [];
$totalTrips  = 0;
$totalSpent  = 0;
$memberSince = '';
$avgRating   = 0;

$profile_rows = sb_get('core2_customers', ['customer_id' => 'eq.' . $customer_id]);
$profile      = $profile_rows[0] ?? [];

$booking_rows = sb_get('core2_bookings', [
    'customer_id' => 'eq.' . $customer_id,
    'select'      => 'booking_status,total_amount,payment_status',
]);
foreach ($booking_rows as $brow) {
    if ($brow['booking_status'] === 'Completed') $totalTrips++;
    if ($brow['payment_status'] === 'Paid') $totalSpent += (float)($brow['total_amount'] ?? 0);
}

if (!empty($profile['created_at'])) {
    $memberSince = date('F Y', strtotime($profile['created_at']));
}

$rating_rows = sb_get('core2_ratings', ['customer_id' => 'eq.' . $customer_id, 'select' => 'rating_value']);
if (!empty($rating_rows)) {
    $avg = array_sum(array_column($rating_rows, 'rating_value')) / count($rating_rows);
    $avgRating = round($avg, 1);
}


$avatarPath = null;
$avatarDebug = '';
if (!empty($profile['contact_person'])) {
    $raw = $profile['contact_person'];
    $filename_only = basename($raw); 
    $disk_path = __DIR__ . '/../uploads/avatars/' . $filename_only;
    $avatarDebug = "DB raw: {$raw} | filename: {$filename_only} | disk exists: " . (file_exists($disk_path) ? 'YES' : 'NO');
    if (file_exists($disk_path)) {
        $avatarPath = '../uploads/avatars/' . $filename_only . '?v=' . filemtime($disk_path);
    }
}

$completenessFields = ['name', 'email', 'phone', 'address'];
$completedFields    = 0;
foreach ($completenessFields as $f) { if (!empty($profile[$f])) $completedFields++; }
$completenessScore = min(100, round(($completedFields / count($completenessFields)) * 100));
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>EnviroCab – My Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        
        :root,
        [data-theme="light"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --card-bg:         #FFFFFF;
            --card-border:     #E2E8F0;
            --header-bg:       rgba(255,255,255,0.85);
            --header-border:   rgba(255,255,255,0.5);
            --text-dark:       #1A202C;
            --text-medium:     #4A5568;
            --text-light:      #718096;
            --input-bg:        #FAFAFA;
            --input-border:    #E2E8F0;
            --row-border:      rgba(0,0,0,0.04);
            --nav-bg:          rgba(255,255,255,0.95);
            --icon-btn-bg:     rgba(255,255,255,0.9);
            --icon-btn-border: rgba(0,0,0,0.05);
            --toggle-track:    #E2E8F0;
            --shadow-card:     0 2px 8px rgba(0,0,0,0.04);
            --shadow-hero:     0 8px 32px rgba(0,208,132,0.2);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.05);
            --danger-bg:       rgba(239,68,68,0.04);
            --danger-border:   rgba(239,68,68,0.15);
            --overlay-bg:      rgba(0,0,0,0.45);
            --sheet-bg:        #FFFFFF;
            --avatar-ring:     rgba(255,255,255,0.4);
            --cancel-btn-bg:   #F1F5F9;
            --cancel-btn-color:#4A5568;
        }

        [data-theme="dark"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #0D1F1A 0%, #0F172A 100%);
            --card-bg:         #1A2820;
            --card-border:     #263330;
            --header-bg:       rgba(15,24,18,0.94);
            --header-border:   rgba(0,208,132,0.1);
            --text-dark:       #E8F5F1;
            --text-medium:     #9FC4AE;
            --text-light:      #607D6B;
            --input-bg:        #111E18;
            --input-border:    #263330;
            --row-border:      rgba(255,255,255,0.05);
            --nav-bg:          rgba(15,24,18,0.97);
            --icon-btn-bg:     rgba(255,255,255,0.06);
            --icon-btn-border: rgba(255,255,255,0.08);
            --toggle-track:    #263330;
            --shadow-card:     0 2px 12px rgba(0,0,0,0.35);
            --shadow-hero:     0 8px 40px rgba(0,208,132,0.12);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.5);
            --danger-bg:       rgba(239,68,68,0.07);
            --danger-border:   rgba(239,68,68,0.2);
            --overlay-bg:      rgba(0,0,0,0.72);
            --sheet-bg:        #1A2820;
            --avatar-ring:     rgba(0,208,132,0.4);
            --cancel-btn-bg:   #263330;
            --cancel-btn-color:#9FC4AE;
        }

        
        *::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
* {
            margin:0; padding:0; box-sizing:border-box;
            -webkit-tap-highlight-color:transparent;
        }
        
        *, *::before, *::after {
            transition: background-color .3s ease, border-color .25s ease, color .2s ease, box-shadow .3s ease;
        }
        
        input, button, svg, img { transition: none; }
        input:focus { transition: border-color .15s, box-shadow .15s; }
        .btn-primary, .btn-outline, .icon-btn, .nav-item, .action-btn, .module-item,
        .toggle-slider, .toggle-slider:before, .bar-fill {
            transition: background .2s, transform .15s, opacity .2s, border-color .2s, box-shadow .2s;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 100px;
            -webkit-font-smoothing: antialiased;
            transition:opacity .15s ease;
}

        
        .header {
            background: var(--header-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky; top: 0; z-index: 100;
            border-bottom: 1px solid var(--header-border);
        }
        .header-content { display:flex; justify-content:space-between; align-items:center; }
        .logo-img { height:28px; width:auto; }
        .header-right { display:flex; align-items:center; gap:10px; }

        .icon-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
            position:relative;
        }
        .icon-btn svg { stroke:var(--text-medium); }
        .icon-btn:active { transform:scale(0.93); }
        .logout-btn {
            background:rgba(239,68,68,0.12) !important;
            border-color:rgba(239,68,68,0.2) !important;
        }
        .logout-btn svg { stroke:#EF4444 !important; }

        
        .theme-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
            position:relative; overflow:hidden;
        }
        .theme-btn:active { transform:scale(0.93); }
        .t-sun, .t-moon {
            position:absolute;
            transition: opacity .35s ease, transform .4s cubic-bezier(.34,1.56,.64,1) !important;
        }
        [data-theme="light"] .t-sun  { opacity:1; transform:rotate(0deg) scale(1); }
        [data-theme="light"] .t-moon { opacity:0; transform:rotate(90deg) scale(.6); }
        [data-theme="dark"]  .t-sun  { opacity:0; transform:rotate(-90deg) scale(.6); }
        [data-theme="dark"]  .t-moon { opacity:1; transform:rotate(0deg) scale(1); }

        
        .main-content { padding:20px; }

        
        .hero-card {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
            border-radius:24px; padding:28px 24px; color:white;
            margin-bottom:20px; box-shadow:var(--shadow-hero);
            position:relative; overflow:hidden;
        }
        .hero-card::before {
            content:''; position:absolute; top:-50%; right:-20%;
            width:200px; height:200px;
            background:rgba(255,255,255,0.1); border-radius:50%;
        }
        .hero-card::after {
            content:''; position:absolute; bottom:-30%; left:-10%;
            width:150px; height:150px;
            background:rgba(255,255,255,0.06); border-radius:50%;
        }
        .profile-header-row { display:flex; align-items:center; gap:16px; position:relative; }

        
        .avatar-wrap { position:relative; flex-shrink:0; cursor:pointer; }
        .avatar-circle {
            width:76px; height:76px; border-radius:22px;
            background:rgba(255,255,255,0.2);
            backdrop-filter:blur(10px);
            border:2.5px solid var(--avatar-ring);
            display:flex; align-items:center; justify-content:center;
            overflow:hidden;
        }
        .avatar-circle img { width:100%; height:100%; object-fit:cover; border-radius:20px; }
        .avatar-initials { font-size:26px; font-weight:800; color:white; letter-spacing:-1px; user-select:none; }
        .avatar-overlay {
            position:absolute; inset:0; border-radius:22px;
            background:rgba(0,0,0,0.45);
            display:flex; align-items:center; justify-content:center;
            opacity:0; transition:opacity .2s !important;
        }
        .avatar-wrap:hover .avatar-overlay { opacity:1; }
        .avatar-badge {
            position:absolute; bottom:-4px; right:-4px;
            width:24px; height:24px; border-radius:8px;
            background:white; display:flex; align-items:center; justify-content:center;
            box-shadow:0 2px 8px rgba(0,0,0,0.2);
        }
        .avatar-badge svg { stroke:var(--dark-green); }

        .profile-name-block { flex:1; }
        .profile-name { font-size:22px; font-weight:800; margin-bottom:4px; }
        .profile-code { font-size:12px; opacity:.8; font-weight:500; margin-bottom:6px; }
        .verified-badge {
            display:inline-flex; align-items:center; gap:4px;
            background:rgba(255,255,255,0.2); border-radius:8px; padding:3px 10px;
            font-size:11px; font-weight:600;
        }
        .hero-stats { display:flex; gap:12px; margin-top:20px; position:relative; }
        .hero-stat {
            flex:1; background:rgba(255,255,255,0.15);
            backdrop-filter:blur(10px); padding:12px; border-radius:16px; text-align:center;
        }
        .hero-stat-value { font-size:20px; font-weight:700; margin-bottom:4px; }
        .hero-stat-label { font-size:11px; opacity:.85; }

        
        .completeness-card {
            background:var(--card-bg); border-radius:20px; padding:18px 20px;
            border:1px solid var(--card-border); box-shadow:var(--shadow-card); margin-bottom:20px;
        }
        .completeness-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
        .completeness-title { font-size:14px; font-weight:600; color:var(--text-dark); display:flex; align-items:center; gap:8px; }
        .completeness-pct  { font-size:14px; font-weight:700; color:var(--primary-green); }
        .bar-track { height:8px; background:var(--input-border); border-radius:8px; overflow:hidden; }
        .bar-fill  { height:100%; border-radius:8px; background:linear-gradient(90deg,var(--primary-green),var(--dark-green)); width:<?php echo $completenessScore; ?>%; }

        
        .toast {
            border-radius:16px; padding:14px 18px; margin-bottom:16px;
            font-size:14px; font-weight:500; display:flex; align-items:center; gap:10px;
        }
        .toast.success { background:rgba(16,185,129,0.12); color:#065F46; border:1px solid rgba(16,185,129,0.25); }
        .toast.error   { background:rgba(239,68,68,0.10);  color:#991B1B; border:1px solid rgba(239,68,68,0.2); }
        [data-theme="dark"] .toast.success { color:#6EE7B7; }
        [data-theme="dark"] .toast.error   { color:#FCA5A5; }

        
        .section-label {
            font-size:12px; font-weight:700; color:var(--text-light);
            text-transform:uppercase; letter-spacing:.08em; margin:24px 0 10px;
        }

        
        .form-card {
            background:var(--card-bg); border-radius:20px; padding:20px;
            border:1px solid var(--card-border); box-shadow:var(--shadow-card); margin-bottom:16px;
        }
        .form-card-header { display:flex; align-items:center; gap:12px; margin-bottom:18px; }
        .form-card-icon {
            width:44px; height:44px; border-radius:14px;
            display:flex; align-items:center; justify-content:center; flex-shrink:0;
        }
        .form-card-title    { font-size:16px; font-weight:700; color:var(--text-dark); }
        .form-card-subtitle { font-size:12px; color:var(--text-light); margin-top:2px; }

        
        .field-group { margin-bottom:14px; }
        .field-label {
            font-size:12px; font-weight:600; color:var(--text-medium);
            margin-bottom:6px; display:flex; align-items:center; gap:6px;
        }
        .field-input {
            width:100%; padding:12px 14px;
            border:1.5px solid var(--input-border); border-radius:12px;
            font-size:14px; font-family:'Inter',sans-serif;
            color:var(--text-dark); background:var(--input-bg); outline:none;
        }
        .field-input:focus {
            border-color:var(--primary-green); background:var(--card-bg);
            box-shadow:0 0 0 3px rgba(0,208,132,0.12);
        }
        .field-input::placeholder { color:var(--text-light); }

        
        .btn-primary {
            width:100%; padding:14px;
            background:linear-gradient(135deg,var(--primary-green),var(--dark-green));
            color:white; border:none; border-radius:14px;
            font-size:15px; font-weight:700; cursor:pointer;
            font-family:'Inter',sans-serif; margin-top:4px;
            display:flex; align-items:center; justify-content:center; gap:8px;
        }
        .btn-primary:active { transform:scale(0.98); opacity:.92; }
        .btn-outline {
            width:100%; padding:12px;
            background:transparent; color:#EF4444;
            border:1.5px solid rgba(239,68,68,0.3); border-radius:14px;
            font-size:14px; font-weight:600; cursor:pointer;
            font-family:'Inter',sans-serif; margin-top:8px;
            display:flex; align-items:center; justify-content:center; gap:8px;
        }
        .btn-outline:hover { background:rgba(239,68,68,0.06); }

        
        .info-row {
            display:flex; align-items:center; justify-content:space-between;
            padding:12px 0; border-bottom:1px solid var(--row-border);
        }
        .info-row:last-child { border-bottom:none; padding-bottom:0; }
        .info-left  { display:flex; align-items:center; gap:10px; }
        .info-icon  { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; }
        .info-key   { font-size:12px; color:var(--text-light); margin-bottom:2px; }
        .info-value { font-size:14px; font-weight:600; color:var(--text-dark); }
        .info-badge { font-size:11px; font-weight:700; padding:3px 10px; border-radius:8px; }
        .badge-green  { background:rgba(16,185,129,0.12); color:#10B981; }
        .badge-yellow { background:rgba(251,191,36,0.15);  color:#D97706; }
        .badge-blue   { background:rgba(96,165,250,0.15);  color:#3B82F6; }
        [data-theme="dark"] .badge-green  { background:rgba(16,185,129,0.2); color:#34D399; }
        [data-theme="dark"] .badge-yellow { background:rgba(251,191,36,0.2); color:#FBBF24; }
        [data-theme="dark"] .badge-blue   { background:rgba(96,165,250,0.2); color:#60A5FA; }

        
        .toggle-row {
            display:flex; align-items:center; justify-content:space-between;
            padding:14px 0; border-bottom:1px solid var(--row-border);
        }
        .toggle-row:last-child { border-bottom:none; padding-bottom:0; }
        .toggle-left { display:flex; align-items:center; gap:12px; }
        .toggle-icon { width:40px; height:40px; border-radius:12px; display:flex; align-items:center; justify-content:center; }
        .toggle-text-title { font-size:14px; font-weight:600; color:var(--text-dark); }
        .toggle-text-sub   { font-size:12px; color:var(--text-light); margin-top:2px; }
        .toggle { position:relative; width:44px; height:26px; cursor:pointer; flex-shrink:0; }
        .toggle input { opacity:0; width:0; height:0; }
        .toggle-slider {
            position:absolute; top:0; left:0; right:0; bottom:0;
            background:var(--toggle-track); border-radius:26px;
        }
        .toggle-slider:before {
            content:''; position:absolute;
            height:20px; width:20px; left:3px; bottom:3px;
            background:white; border-radius:50%; box-shadow:0 2px 4px rgba(0,0,0,0.2);
        }
        .toggle input:checked + .toggle-slider { background:var(--primary-green); }
        .toggle input:checked + .toggle-slider:before { transform:translateX(18px); }

        
        .danger-card {
            background:var(--danger-bg); border:1.5px solid var(--danger-border);
            border-radius:20px; padding:20px; margin-bottom:16px;
        }
        .danger-card-header { display:flex; align-items:center; gap:12px; margin-bottom:16px; }
        .danger-card-icon   { width:44px; height:44px; border-radius:14px; background:rgba(239,68,68,0.12); display:flex; align-items:center; justify-content:center; }
        .danger-card-title  { font-size:16px; font-weight:700; color:#DC2626; }
        .danger-card-sub    { font-size:12px; color:#EF4444; opacity:.8; margin-top:2px; }
        .danger-action      { display:flex; align-items:center; justify-content:space-between; padding:12px 0; border-bottom:1px solid rgba(239,68,68,0.1); cursor:pointer; }
        .danger-action:last-child { border-bottom:none; padding-bottom:0; }
        .danger-action-left { display:flex; align-items:center; gap:10px; }
        .danger-action-title{ font-size:14px; font-weight:600; color:#DC2626; }
        .danger-action-sub  { font-size:12px; color:#EF4444; opacity:.75; margin-top:2px; }

        
        .bottom-nav {
            position:fixed; bottom:0; left:0; right:0;
            background:var(--nav-bg);
            backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
            border-top:1px solid var(--card-border);
            padding:12px 0 20px;
            display:grid; grid-template-columns:repeat(4,1fr);
            z-index:99; box-shadow:var(--shadow-nav);
        }
        .nav-item {
            display:flex; flex-direction:column; align-items:center; gap:4px;
            padding:8px; cursor:pointer; border:none; background:none;
        }
        .nav-item:active { transform:scale(0.95); }
        .nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
        .nav-icon svg { stroke:var(--text-light); opacity:.5; }
        .nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
        .nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:.7; }
        .nav-item.active .nav-label { color:var(--primary-green); opacity:1; }

        
        .modal-overlay {
            display:none; position:fixed; inset:0;
            background:var(--overlay-bg);
            backdrop-filter:blur(5px); -webkit-backdrop-filter:blur(5px);
            z-index:200; align-items:center; justify-content:center;
            padding:24px;
        }
        .modal-overlay.open { display:flex; }
        .modal-sheet {
            background:var(--sheet-bg); border-radius:28px;
            padding:24px 20px 28px; width:100%; max-width:420px;
            animation:sheetUp .32s cubic-bezier(.34,1.56,.64,1);
        }
        @keyframes sheetUp {
            from { transform:translateY(100%); opacity:0; }
            to   { transform:translateY(0);    opacity:1; }
        }
        .modal-handle { width:40px; height:4px; background:var(--card-border); border-radius:4px; margin:0 auto 22px; }
        .modal-title    { font-size:18px; font-weight:700; color:var(--text-dark); margin-bottom:4px; }
        .modal-subtitle { font-size:13px; color:var(--text-light); margin-bottom:20px; }

        
        .avatar-preview-ring {
            width:100px; height:100px; border-radius:28px;
            overflow:hidden; border:3px solid var(--primary-green);
            margin:0 auto 20px; display:flex; align-items:center; justify-content:center;
            background:var(--input-bg);
            box-shadow:0 0 0 6px rgba(0,208,132,0.1);
        }
        .avatar-preview-ring img { width:100%; height:100%; object-fit:cover; }
        .avatar-preview-initials { font-size:36px; font-weight:800; color:var(--primary-green); }

        
        .upload-drop-zone {
            border:2px dashed var(--primary-green); border-radius:16px;
            padding:28px 20px; text-align:center; cursor:pointer;
            background:rgba(0,208,132,0.04); margin-bottom:16px;
        }
        .upload-drop-zone:hover { background:rgba(0,208,132,0.08); }
        .upload-drop-zone.drag-over { background:rgba(0,208,132,0.12); border-color:var(--dark-green); }
        .upload-drop-icon {
            width:52px; height:52px; background:rgba(0,208,132,0.1);
            border-radius:16px; margin:0 auto 12px;
            display:flex; align-items:center; justify-content:center;
        }
        .upload-drop-title { font-size:15px; font-weight:600; color:var(--text-dark); margin-bottom:4px; }
        .upload-drop-sub   { font-size:12px; color:var(--text-light); }
        #avatarFileInput { display:none; }

        .modal-cancel-btn {
            width:100%; padding:12px;
            background:var(--cancel-btn-bg); border:1px solid var(--card-border);
            border-radius:14px; font-size:14px; font-weight:600;
            color:var(--cancel-btn-color); cursor:pointer; margin-top:8px;
            font-family:inherit;
        }

        
        .pwd-strength { margin-top:6px; display:flex; gap:4px; }
        .pwd-bar { flex:1; height:4px; border-radius:4px; background:var(--input-border); }
        .pwd-bar.weak   { background:#EF4444; }
        .pwd-bar.medium { background:#FBBF24; }
        .pwd-bar.strong { background:var(--primary-green); }
        .pwd-hint { font-size:11px; color:var(--text-light); margin-top:4px; }

        
        @media (min-width:768px) {
            body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,0.12); }
            .bottom-nav { max-width:480px; left:50%; transform:translateX(-50%); }
        }
        @keyframes slideUp {
            from { opacity:0; transform:translateY(20px); }
            to   { opacity:1; transform:translateY(0); }
        }
        .hero-card, .completeness-card, .form-card, .danger-card { animation:slideUp .4s ease forwards; }
    
    
    .notif-panel-wrap{position:relative;}
    .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:310px;max-height:400px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.15);z-index:999;display:none;flex-direction:column;overflow:hidden;}
    .notif-panel.open{display:flex;}
    .notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);flex-shrink:0;}
    .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
    .notif-mark-read{font-size:11px;font-weight:600;color:var(--dark-green);background:none;border:none;cursor:pointer;padding:0;}
    .notif-list{overflow-y:auto;flex:1;padding:4px 0;}
    .notif-item{display:flex;align-items:flex-start;gap:10px;padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--row-border);transition:background .15s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,208,132,0.06);}
    .notif-item.unread{background:rgba(0,208,132,0.04);}
    .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
    .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
    .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
    .notif-item-body{flex:1;min-width:0;}
    .notif-item-title{font-size:12px;font-weight:700;color:var(--text-dark);margin-bottom:2px;}
    .notif-item-sub{font-size:11px;color:var(--text-light);line-height:1.4;}
    .notif-item-time{font-size:10px;color:var(--text-light);margin-top:3px;}
    .notif-empty{padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;}
    .notif-spinner{width:20px;height:20px;border:2px solid var(--card-border);border-top-color:#00D084;border-radius:50%;animation:nspin .7s linear infinite;margin:16px auto;}
    @keyframes nspin{to{transform:rotate(360deg);}}
    .notif-count-badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 3px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:9px;font-weight:800;color:#fff;display:none;align-items:center;justify-content:center;line-height:1;}
    
    .logout-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center;padding:24px;}
    .logout-overlay.open{display:flex;}
    .logout-modal{background:var(--card-bg);border-radius:24px;padding:28px 24px 24px;width:100%;max-width:320px;box-shadow:0 16px 48px rgba(0,0,0,0.18);animation:lmodalIn .25s cubic-bezier(.34,1.56,.64,1);}
    @keyframes lmodalIn{from{transform:scale(.88);opacity:0;}to{transform:scale(1);opacity:1;}}
    .logout-modal-icon{width:52px;height:52px;border-radius:16px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
    .logout-modal-title{font-size:17px;font-weight:800;color:var(--text-dark);text-align:center;margin-bottom:6px;}
    .logout-modal-sub{font-size:13px;color:var(--text-light);text-align:center;line-height:1.5;margin-bottom:22px;}
    .logout-modal-btns{display:flex;gap:10px;}
    .logout-cancel-btn{flex:1;padding:13px;border-radius:14px;background:var(--input-bg);border:1px solid var(--card-border);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;}
    .logout-confirm-btn{flex:1;padding:13px;border-radius:14px;background:#EF4444;border:none;font-size:14px;font-weight:700;color:#fff;cursor:pointer;}
</style>
</head>
<body>


<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img"
             onerror="this.style.display='none'">
                        <div class="header-right">
            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            </button>
            <button class="icon-btn" onclick="window.location.href='dashboard.php'" title="Home">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </button>
            <div class="notif-panel-wrap">
            <button class="icon-btn" id="notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications" style="position:relative;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <span class="notif-count-badge" id="notif-count-badge"></span>
            </button>
            <div class="notif-panel" id="notif-panel">
                <div class="notif-panel-head">
                    <span class="notif-panel-title">Notifications</span>
                    <button class="notif-mark-read" onclick="markAllRead()">Mark all read</button>
                </div>
                <div class="notif-list" id="notif-list"><div class="notif-spinner"></div></div>
            </div>
        </div>
            <button class="icon-btn logout-btn" onclick="openLogout()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

    <?php if ($success_message): ?>
    <div class="toast success">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        <?php echo htmlspecialchars($success_message); ?>
    </div>
    <?php endif; ?>
    <?php if ($error_message): ?>
    <div class="toast error">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
    <?php endif; ?>

    <div class="hero-card">
        <div class="profile-header-row">
            <div class="avatar-wrap" onclick="openAvatarModal()" tabindex="0" role="button" aria-label="Change profile picture">
                <div class="avatar-circle" id="heroAvatarCircle">
                    <?php if ($avatarPath): ?>
                        <img src="<?php echo $avatarPath; ?>" alt="Profile" id="heroAvatarImg"
                             onerror="this.style.display='none';document.getElementById('heroInitialsEl').style.display='block';">
                        <span class="avatar-initials" id="heroInitialsEl" style="display:none;"><?php echo htmlspecialchars($initials); ?></span>
                    <?php else: ?>
                        <span class="avatar-initials" id="heroInitialsEl"><?php echo htmlspecialchars($initials); ?></span>
                    <?php endif; ?>
                </div>
                <div class="avatar-overlay">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>
                    </svg>
                </div>
                <div class="avatar-badge">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#00A86B" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>
                    </svg>
                </div>
            </div>

            <div class="profile-name-block">
                <div class="profile-name"><?php echo htmlspecialchars($profile['name'] ?? 'Passenger'); ?></div>
                <div class="profile-code"><?php echo htmlspecialchars($profile['customer_code'] ?? ''); ?></div>
                <div class="verified-badge">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <?php echo htmlspecialchars(ucfirst(strtolower($profile['status'] ?? 'Active'))); ?> Account
                </div>
            </div>
        </div>

        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-value"><?php echo $totalTrips; ?></div>
                <div class="hero-stat-label">Trips Done</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value">₱<?php echo number_format($totalSpent, 0); ?></div>
                <div class="hero-stat-label">Total Spent</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value">
                    <?php echo $avgRating > 0 ? number_format($avgRating,1) : '—'; ?>
                    <?php if ($avgRating > 0): ?>
                    <svg style="display:inline-block;vertical-align:middle;margin-left:2px;" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                    <?php endif; ?>
                </div>
                <div class="hero-stat-label">My Rating</div>
            </div>
        </div>
    </div>

    <div class="completeness-card">
        <div class="completeness-header">
            <div class="completeness-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                Profile Health Score
            </div>
            <div class="completeness-pct"><?php echo $completenessScore; ?>%</div>
        </div>
        <div class="bar-track"><div class="bar-fill"></div></div>
        <?php if ($completenessScore < 100): ?>
        <div style="font-size:12px;color:var(--text-light);margin-top:8px;">
            <?php echo !$avatarPath ? 'Add a profile photo to boost your score.' : 'Complete remaining fields to reach 100%.'; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="section-label">Account Overview</div>
    <div class="form-card">
        <div class="info-row">
            <div class="info-left">
                <div class="info-icon" style="background:rgba(96,165,250,0.12);">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                </div>
                <div><div class="info-key">Customer Type</div><div class="info-value"><?php echo htmlspecialchars($profile['customer_type'] ?? '—'); ?></div></div>
            </div>
            <span class="info-badge badge-blue"><?php echo htmlspecialchars($profile['status'] ?? 'Active'); ?></span>
        </div>
        <div class="info-row">
            <div class="info-left">
                <div class="info-icon" style="background:rgba(16,185,129,0.12);">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                </div>
                <div><div class="info-key">Member Since</div><div class="info-value"><?php echo $memberSince ?: '—'; ?></div></div>
            </div>
            <span class="info-badge badge-green">Verified</span>
        </div>
        <div class="info-row">
            <div class="info-left">
                <div class="info-icon" style="background:rgba(251,146,60,0.12);">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FB923C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <div><div class="info-key">Completed Trips</div><div class="info-value"><?php echo $totalTrips; ?> trips</div></div>
            </div>
            <span class="info-badge badge-yellow">Passenger</span>
        </div>
    </div>

    <div class="section-label">Personal Information</div>
    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:linear-gradient(135deg,var(--primary-green),var(--dark-green));">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <div><div class="form-card-title">Edit Profile</div><div class="form-card-subtitle">Update your personal details</div></div>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="update_profile">
            <div class="field-group">
                <label class="field-label"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> Full Name</label>
                <input type="text" name="name" class="field-input" value="<?php echo htmlspecialchars($profile['name'] ?? ''); ?>" placeholder="Enter your full name" required>
            </div>
            <div class="field-group">
                <label class="field-label"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg> Email Address</label>
                <input type="email" name="email" class="field-input" value="<?php echo htmlspecialchars($profile['email'] ?? ''); ?>" placeholder="your@email.com">
            </div>
            <div class="field-group">
                <label class="field-label"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg> Phone Number</label>
                <input type="tel" name="phone" class="field-input" value="<?php echo htmlspecialchars($profile['phone'] ?? ''); ?>" placeholder="09XXXXXXXXX">
            </div>
            <div class="field-group">
                <label class="field-label"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg> Home Address</label>
                <input type="text" name="address" class="field-input" value="<?php echo htmlspecialchars($profile['address'] ?? ''); ?>" placeholder="Enter your address">
            </div>
            <button type="submit" class="btn-primary">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Save Changes
            </button>
        </form>
    </div>

    <div class="section-label">Appearance</div>
    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:linear-gradient(135deg,#818CF8,#6366F1);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="5"/>
                    <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
                    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
                    <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
                    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
                </svg>
            </div>
            <div><div class="form-card-title">Theme</div><div class="form-card-subtitle">Personalize your visual experience</div></div>
        </div>
        <div class="toggle-row">
            <div class="toggle-left">
                <div class="toggle-icon" style="background:rgba(129,140,248,0.12);">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#818CF8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
                </div>
                <div><div class="toggle-text-title">Dark Mode</div><div class="toggle-text-sub">Switch to dark theme</div></div>
            </div>
            <label class="toggle">
                <input type="checkbox" id="darkModeToggle" onchange="toggleTheme()">
                <span class="toggle-slider"></span>
            </label>
        </div>
    </div>

    <div class="section-label">Account Preferences</div>
    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:linear-gradient(135deg,#60A5FA,#3B82F6);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
            </div>
            <div><div class="form-card-title">Notifications &amp; Ride Preferences</div><div class="form-card-subtitle">Customize your experience</div></div>
        </div>
        <?php
        $prefs = [
            ['c'=>'#10B981','bg'=>'rgba(16,185,129,0.1)','i'=>'<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>','t'=>'Booking Alerts','s'=>'Get notified when booking is confirmed','on'=>true],
            ['c'=>'#60A5FA','bg'=>'rgba(96,165,250,0.1)','i'=>'<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>','t'=>'Driver Arrival Alerts','s'=>'Notify when driver is nearby','on'=>true],
            ['c'=>'#FBBF24','bg'=>'rgba(251,191,36,0.1)','i'=>'<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>','t'=>'Payment Receipts','s'=>'Auto-send receipt after each trip','on'=>true],
            ['c'=>'#C084FC','bg'=>'rgba(192,132,252,0.1)','i'=>'<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>','t'=>'Promotions &amp; Offers','s'=>'Receive exclusive deals','on'=>false],
            ['c'=>'#FB923C','bg'=>'rgba(251,146,60,0.1)','i'=>'<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>','t'=>'Quiet Ride Mode','s'=>'Request silent trip from driver','on'=>false],
        ];
        foreach ($prefs as $p): ?>
        <div class="toggle-row">
            <div class="toggle-left">
                <div class="toggle-icon" style="background:<?php echo $p['bg']; ?>">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="<?php echo $p['c']; ?>" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo $p['i']; ?></svg>
                </div>
                <div><div class="toggle-text-title"><?php echo $p['t']; ?></div><div class="toggle-text-sub"><?php echo $p['s']; ?></div></div>
            </div>
            <label class="toggle"><input type="checkbox" <?php echo $p['on']?'checked':''; ?>><span class="toggle-slider"></span></label>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="section-label">Security &amp; Privacy</div>
    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:linear-gradient(135deg,#C084FC,#A855F7);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            </div>
            <div><div class="form-card-title">Change Password</div><div class="form-card-subtitle">Secure your account with a strong password</div></div>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="change_password">
            <div class="field-group">
                <label class="field-label"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> Current Password</label>
                <input type="password" name="current_password" class="field-input" placeholder="Enter current password">
            </div>
            <div class="field-group">
                <label class="field-label"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> New Password</label>
                <input type="password" name="new_password" id="new_password" class="field-input" placeholder="At least 6 characters" oninput="checkPwdStrength(this.value)">
                <div class="pwd-strength"><div class="pwd-bar" id="bar1"></div><div class="pwd-bar" id="bar2"></div><div class="pwd-bar" id="bar3"></div></div>
                <div class="pwd-hint" id="pwd-hint">Enter a new password</div>
            </div>
            <div class="field-group">
                <label class="field-label"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg> Confirm New Password</label>
                <input type="password" name="confirm_password" class="field-input" placeholder="Repeat new password">
            </div>
            <button type="submit" class="btn-primary" style="background:linear-gradient(135deg,#C084FC,#A855F7);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                Update Password
            </button>
        </form>
    </div>

    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:linear-gradient(135deg,#FB923C,#F97316);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            </div>
            <div><div class="form-card-title">Privacy Controls</div><div class="form-card-subtitle">Manage your data &amp; visibility</div></div>
        </div>
        <?php
        $pvt = [
            ['c'=>'#FB923C','bg'=>'rgba(251,146,60,0.1)','i'=>'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>','t'=>'Hide Phone from Driver','s'=>'Only show masked number','on'=>false],
            ['c'=>'#C084FC','bg'=>'rgba(192,132,252,0.1)','i'=>'<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>','t'=>'Location Permissions','s'=>'Allow GPS tracking during trip','on'=>true],
            ['c'=>'#60A5FA','bg'=>'rgba(96,165,250,0.1)','i'=>'<path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/>','t'=>'Data Sharing','s'=>'Help improve service quality','on'=>true],
        ];
        foreach ($pvt as $p): ?>
        <div class="toggle-row">
            <div class="toggle-left">
                <div class="toggle-icon" style="background:<?php echo $p['bg']; ?>">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="<?php echo $p['c']; ?>" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo $p['i']; ?></svg>
                </div>
                <div><div class="toggle-text-title"><?php echo $p['t']; ?></div><div class="toggle-text-sub"><?php echo $p['s']; ?></div></div>
            </div>
            <label class="toggle"><input type="checkbox" <?php echo $p['on']?'checked':''; ?>><span class="toggle-slider"></span></label>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="section-label">Account Activity</div>
    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:linear-gradient(135deg,#F59E0B,#D97706);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
            <div><div class="form-card-title">Login History</div><div class="form-card-subtitle">Recent account access</div></div>
        </div>
        <div class="info-row">
            <div class="info-left">
                <div class="info-icon" style="background:rgba(16,185,129,0.1);">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
                </div>
                <div><div class="info-key">Current Session</div><div class="info-value">Mobile Browser</div></div>
            </div>
            <span class="info-badge badge-green">Active Now</span>
        </div>
        <div class="info-row">
            <div class="info-left">
                <div class="info-icon" style="background:rgba(96,165,250,0.1);">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                </div>
                <div><div class="info-key">Last Login — <?php echo date('M d, Y'); ?></div><div class="info-value"><?php echo date('h:i A'); ?></div></div>
            </div>
            <span class="info-badge badge-blue">Today</span>
        </div>
        <div style="margin-top:14px;">
            <button class="btn-primary" style="background:linear-gradient(135deg,#F59E0B,#D97706);" onclick="alert('Logout from all devices – feature coming soon.')">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout All Devices
            </button>
        </div>
    </div>

    <div class="section-label">Safety Features</div>
    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:linear-gradient(135deg,#F472B6,#EC4899);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <div><div class="form-card-title">Trusted Contacts</div><div class="form-card-subtitle">Emergency sharing during trips</div></div>
        </div>
        <div style="background:rgba(244,114,182,0.07);border-radius:14px;padding:14px;margin-bottom:14px;border:1px solid rgba(244,114,182,0.15);">
            <div style="font-size:13px;color:var(--text-medium);line-height:1.6;">Add trusted contacts who will automatically receive your real-time trip location for safety during rides.</div>
        </div>
        <button class="btn-primary" style="background:linear-gradient(135deg,#F472B6,#EC4899);" onclick="alert('Trusted Contacts — feature coming soon.')">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
            Add Trusted Contact
        </button>
    </div>

    <div class="form-card">
        <div class="form-card-header">
            <div class="form-card-icon" style="background:linear-gradient(135deg,#60A5FA,#3B82F6);">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            </div>
            <div><div class="form-card-title">Data &amp; Privacy Export</div><div class="form-card-subtitle">Download a copy of your personal data</div></div>
        </div>
        <button class="btn-primary" style="background:linear-gradient(135deg,#60A5FA,#3B82F6);" onclick="alert('Data export — feature coming soon.')">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Export My Data
        </button>
    </div>

    <div class="section-label">Danger Zone</div>
    <div class="danger-card">
        <div class="danger-card-header">
            <div class="danger-card-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            </div>
            <div><div class="danger-card-title">Danger Zone</div><div class="danger-card-sub">Irreversible account actions</div></div>
        </div>
        <div class="danger-action" onclick="if(confirm('Deactivate account? You can reactivate anytime.')) alert('Deactivation request submitted.')">
            <div class="danger-action-left">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                <div><div class="danger-action-title">Deactivate Account</div><div class="danger-action-sub">Temporarily suspend your account</div></div>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
        <div class="danger-action" onclick="if(confirm('Permanently delete your account? This cannot be undone.')) alert('Deletion request submitted. Our team will process it within 7 days.')">
            <div class="danger-action-left">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
                <div><div class="danger-action-title">Delete Account</div><div class="danger-action-sub">Permanently remove all your data</div></div>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
    </div>

</div>
<div class="modal-overlay" id="avatarModal" onclick="handleOverlayClick(event)">
    <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="modal-title">Profile Picture</div>
        <div class="modal-subtitle">Upload a new photo or remove the current one</div>

        <div class="avatar-preview-ring" id="previewRing">
            <?php if ($avatarPath): ?>
                <img src="<?php echo $avatarPath; ?>" id="previewImg" alt="Preview">
            <?php else: ?>
                <span class="avatar-preview-initials" id="previewInitials"><?php echo htmlspecialchars($initials); ?></span>
            <?php endif; ?>
        </div>

        <form method="POST" enctype="multipart/form-data" id="avatarForm">
            <input type="hidden" name="action" value="upload_avatar">
            <input type="file" name="avatar" id="avatarFileInput"
                   accept="image/jpeg,image/png,image/gif,image/webp"
                   onchange="previewAvatar(event)">

            <div class="upload-drop-zone" id="dropZone"
                 onclick="document.getElementById('avatarFileInput').click()"
                 ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)" ondrop="handleDrop(event)">
                <div class="upload-drop-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--primary-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>
                    </svg>
                </div>
                <div class="upload-drop-title" id="dropZoneTitle">Tap to choose a photo</div>
                <div class="upload-drop-sub">JPG, PNG, WEBP — Max 2MB</div>
            </div>

            <button type="submit" class="btn-primary" id="uploadSubmitBtn" style="display:none;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                Upload Photo
            </button>
        </form>

        <?php if ($avatarPath): ?>
        <form method="POST" style="margin-top:0;">
            <input type="hidden" name="action" value="remove_avatar">
            <button type="submit" class="btn-outline">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
                Remove Photo
            </button>
        </form>
        <?php endif; ?>

        <button class="modal-cancel-btn" onclick="closeAvatarModal()">Cancel</button>
    </div>
</div>

<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_trips.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_trips.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div>
        <span class="nav-label">Book</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_trips.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item active">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <span class="nav-label">Profile</span>
    </button>
</div>

<script>

(function () {
    const saved = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);

    document.addEventListener('DOMContentLoaded', function () {
        const chk = document.getElementById('darkModeToggle');
        if (chk) chk.checked = (saved === 'dark');
    });
})();

function toggleTheme() {
    const html    = document.documentElement;
    const current = html.getAttribute('data-theme');
    const next    = current === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('envirocab_theme', next);
    const chk = document.getElementById('darkModeToggle');
    if (chk) chk.checked = (next === 'dark');
}

function openAvatarModal() {
    document.getElementById('avatarModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeAvatarModal() {
    document.getElementById('avatarModal').classList.remove('open');
    document.body.style.overflow = '';
}
function handleOverlayClick(e) {
    if (e.target === document.getElementById('avatarModal')) closeAvatarModal();
}

function previewAvatar(event) {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
        alert('Image must be under 2MB. Please choose a smaller file.');
        event.target.value = ''; return;
    }
    const allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowed.includes(file.type)) {
        alert('Only JPG, PNG, GIF, and WEBP are supported.');
        event.target.value = ''; return;
    }

    const reader = new FileReader();
    reader.onload = function (e) {
        const ring = document.getElementById('previewRing');
        ring.innerHTML = '<img src="' + e.target.result + '" alt="Preview" style="width:100%;height:100%;object-fit:cover;">';

        const heroCircle = document.getElementById('heroAvatarCircle');
        heroCircle.innerHTML = '<img src="' + e.target.result + '" alt="Profile" style="width:100%;height:100%;object-fit:cover;border-radius:20px;">';

        document.getElementById('uploadSubmitBtn').style.display = 'flex';
        document.getElementById('dropZoneTitle').textContent = file.name;
        document.getElementById('dropZone').style.borderStyle = 'solid';
        document.getElementById('dropZone').style.background   = 'rgba(0,208,132,0.08)';
    };
    reader.readAsDataURL(file);
}

function handleDragOver(e) {
    e.preventDefault(); e.currentTarget.classList.add('drag-over');
}
function handleDragLeave(e) {
    e.currentTarget.classList.remove('drag-over');
}
function handleDrop(e) {
    e.preventDefault(); e.currentTarget.classList.remove('drag-over');
    const input = document.getElementById('avatarFileInput');
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        try {
            const dt = new DataTransfer();
            dt.items.add(e.dataTransfer.files[0]);
            input.files = dt.files;
        } catch(err) { input.files = e.dataTransfer.files; }
        previewAvatar({ target: input });
    }
}

function checkPwdStrength(val) {
    const bars = ['bar1','bar2','bar3'].map(id => document.getElementById(id));
    const hint = document.getElementById('pwd-hint');
    bars.forEach(b => b.className = 'pwd-bar');

    if (!val) { hint.textContent = 'Enter a new password'; return; }

    let score = 0;
    if (val.length >= 6)  score++;
    if (val.length >= 10) score++;
    if (/[A-Z]/.test(val) && /[0-9]/.test(val)) score++;

    if (score === 1) {
        bars[0].classList.add('weak');
        hint.textContent = 'Weak — add numbers or uppercase letters';
    } else if (score === 2) {
        bars[0].classList.add('medium'); bars[1].classList.add('medium');
        hint.textContent = 'Medium — almost there';
    } else {
        bars.forEach(b => b.classList.add('strong'));
        hint.textContent = 'Strong password';
    }
}
</script>
<script>
const CUSTOMER_ID = <?= (int)$customer_id ?>;

const SB_URL = 'https://kyhndwabhbkduoaxeunq.supabase.co';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
let _notifOpen = false, _notifData = [], _notifTimer = null;
let _seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');

const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};

function toggleNotifPanel(e) {
    e.stopPropagation();
    _notifOpen = !_notifOpen;
    document.getElementById('notif-panel').classList.toggle('open', _notifOpen);
    if (_notifOpen) { fetchNotifs(); _notifTimer = setInterval(fetchNotifs, 8000); }
    else clearInterval(_notifTimer);
}

async function fetchNotifs() {
    try {
        const r = await fetch(SB_URL + '/rest/v1/core2_bookings?customer_id=eq.' + CUSTOMER_ID +
            '&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=15',
            {headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        _notifData = await r.json();
        renderNotifs();
        updateBadge();
    } catch(e) {}
}

function renderNotifs() {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!_notifData.length) { list.innerHTML = '<div class="notif-empty">No notifications yet.</div>'; return; }
    list.innerHTML = _notifData.map(b => {
        const cfg = STATUS_CFG[b.booking_status] || {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key = b.booking_id + '_' + b.booking_status;
        const unread = !_seen.includes(key);
        const amt = '\u20B1' + parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t = timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
}

function updateBadge() {
    const cnt = _notifData.filter(b => !_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    const el = document.getElementById('notif-count-badge');
    if (!el) return;
    if (cnt > 0) { el.textContent = cnt > 9 ? '9+' : cnt; el.style.display = 'flex'; }
    else el.style.display = 'none';
}

function goNotif(page, bid, key) {
    if (!_seen.includes(key)) { _seen.push(key); localStorage.setItem(SEEN_KEY, JSON.stringify(_seen)); }
    window.location.href = page + '?booking_id=' + bid;
}

function markAllRead() {
    _seen = _notifData.map(b => b.booking_id+'_'+b.booking_status);
    localStorage.setItem(SEEN_KEY, JSON.stringify(_seen));
    renderNotifs(); updateBadge();
}

function timeAgo(iso) {
    if (!iso) return '';
    const s = Math.floor((Date.now() - new Date(iso))/1000);
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s/60)+'m ago';
    if (s < 86400) return Math.floor(s/3600)+'h ago';
    return Math.floor(s/86400)+'d ago';
}

function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function openLogout() { document.getElementById('logout-overlay').classList.add('open'); }

document.addEventListener('click', function(e) {
    const panel = document.getElementById('notif-panel');
    const btn   = document.getElementById('notif-bell-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        _notifOpen = false; panel.classList.remove('open'); clearInterval(_notifTimer);
    }
});

document.addEventListener('DOMContentLoaded', () => { if (CUSTOMER_ID) fetchNotifs(); });
</script>


<div class="logout-overlay" id="logout-overlay" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="logout-modal">
        <div class="logout-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </div>
        <div class="logout-modal-title">Log out?</div>
        <div class="logout-modal-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-modal-btns">
            <button class="logout-cancel-btn" onclick="document.getElementById('logout-overlay').classList.remove('open')">Cancel</button>
            <button class="logout-confirm-btn" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{ once:true });
      a.addEventListener('touchstart',function(){ prerender(href); },{ once:true, passive:true });
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{ once:true });
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
</body>
</html>