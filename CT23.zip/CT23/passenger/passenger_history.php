<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['customer_id'])) {
    header('Location: ../auth/passenger_login.php');
    exit;
}

define('SUPABASE_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get($table, $params = []) {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'apikey: ' . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) return json_decode($res, true) ?: [];
    error_log("SB GET {$table} HTTP {$code}: {$res}");
    return [];
}

$customer_id   = $_SESSION['customer_id'];
$filter_status = $_GET['status'] ?? 'all';
$filter_month  = $_GET['month']  ?? '';
$search_q      = trim($_GET['search'] ?? '');

$hr = (int)date('H');
$greeting = $hr < 12 ? 'Good Morning' : ($hr < 18 ? 'Good Afternoon' : 'Good Evening');

function shortLoc(string $location): string {
    $parts = explode(',', $location);
    return trim($parts[0] ?? $location);
}

function tripDur(?string $start, ?string $end): string {
    if (!$start || !$end) return '—';
    $d = strtotime($end) - strtotime($start);
    if ($d <= 0) return '—';
    $h = floor($d / 3600); $m = floor(($d % 3600) / 60);
    return $h > 0 ? "{$h}h {$m}m" : "{$m} min";
}

$all_rides_raw = sb_get('core2_rides', [
    'customer_id' => 'eq.' . $customer_id,
    'select'       => 'ride_id,booking_id,start_time,end_time,start_location,end_location,ride_status,driver_id,created_at',
    'order'        => 'start_time.desc',
]);


$all_ride_ids = array_filter(array_unique(array_column($all_rides_raw, 'ride_id')));
$completed_trip_ids = [];
if (!empty($all_ride_ids)) {
    $rids = implode(',', $all_ride_ids);
    foreach (sb_get('core1_trips', ['ride_id' => 'in.(' . $rids . ')', 'select' => 'ride_id,status', 'status' => 'eq.COMPLETED']) as $t) {
        $completed_trip_ids[(int)$t['ride_id']] = true;
    }
}


$all_rides = [];
foreach ($all_rides_raw as $r) {
    if (!in_array($r['ride_status'], ['Completed','Cancelled']) && isset($completed_trip_ids[(int)$r['ride_id']])) {
        $r['ride_status'] = 'Completed';
    }
    $all_rides[] = $r;
}

$all_rides = array_values(array_filter($all_rides, fn($r) => in_array($r['ride_status'], ['Completed','Cancelled'])));

$stats = ['total_rides' => 0, 'completed' => 0, 'cancelled' => 0, 'total_spent' => 0, 'total_km' => 0, 'avg_fare' => 0];
$monthly_map = [];
$months_set  = [];
$rides       = [];

foreach ($all_rides as $r) {
    $bid = $r['booking_id'];

    $b_rows = sb_get('core2_bookings', ['booking_id' => 'eq.' . $bid, 'select' => 'booking_id,booking_reference,booking_status,booking_date,total_amount,payment_status']);
    $b = $b_rows[0] ?? [];

    $fare_rows = sb_get('core2_fare_computation', ['booking_id' => 'eq.' . $bid, 'select' => 'distance_km,base_fare,distance_rate,surge_multiplier,additional_charges,discount,total_fare']);
    $fare = $fare_rows[0] ?? [];

    $pay_rows = sb_get('core2_payment_authorization', ['booking_id' => 'eq.' . $bid, 'select' => 'payment_method,authorization_code,transaction_reference,payment_gateway,authorized_at']);
    $pay = $pay_rows[0] ?? [];

    $driver_name  = null;
    $driver_phone = null;
    $license      = null;
    if (!empty($r['driver_id'])) {
        $dr = sb_get('core1_drivers', ['core2_driver_id' => 'eq.' . $r['driver_id'], 'select' => 'driver_name,license_number,phone']);
        $driver_name  = $dr[0]['driver_name']  ?? null;
        $driver_phone = $dr[0]['phone']         ?? null;
        $license      = $dr[0]['license_number'] ?? null;
    }

    $plate     = null;
    $make      = null;
    $veh_type  = null;
    if (!empty($r['vehicle_id'])) {
        $vr = sb_get('core1_vehicles', ['id' => 'eq.' . $r['vehicle_id'], 'select' => 'plate_number,make_model,vehicle_type']);
        $plate    = $vr[0]['plate_number'] ?? null;
        $make     = $vr[0]['make_model']   ?? null;
        $veh_type = $vr[0]['vehicle_type'] ?? null;
    }

    $stats['total_rides']++;
    if ($r['ride_status'] === 'Completed') $stats['completed']++;
    if ($r['ride_status'] === 'Cancelled') $stats['cancelled']++;
    $stats['total_spent'] += (float)($b['total_amount'] ?? 0);
    $stats['total_km']    += (float)($fare['distance_km'] ?? 0);

    $month_key   = $r['start_time'] ? substr($r['start_time'], 0, 7) : null;
    $month_short = $r['start_time'] ? date('M', strtotime($r['start_time'])) : null;
    if ($month_key && strtotime($r['start_time']) >= strtotime('-6 months')) {
        if (!isset($monthly_map[$month_key])) $monthly_map[$month_key] = ['month_key' => $month_key, 'month_short' => $month_short, 'spent' => 0, 'trips' => 0];
        $monthly_map[$month_key]['spent'] += (float)($b['total_amount'] ?? 0);
        $monthly_map[$month_key]['trips']++;
    }
    if ($month_key && !isset($months_set[$month_key])) {
        $months_set[$month_key] = ['month_value' => $month_key, 'label' => date('M Y', strtotime($r['start_time']))];
    }

    if ($filter_status !== 'all' && $r['ride_status'] !== ucfirst($filter_status)) continue;
    if ($filter_month !== '' && $month_key !== $filter_month) continue;
    if ($search_q !== '') {
        $haystack = ($b['booking_reference'] ?? '') . ($driver_name ?? '') . ($r['start_location'] ?? '') . ($r['end_location'] ?? '');
        if (stripos($haystack, $search_q) === false) continue;
    }

    $rides[] = array_merge($r, $b, $fare, $pay, [
        'driver_name'  => $driver_name,
        'driver_phone' => $driver_phone,
        'license_number' => $license,
        'plate_number' => $plate,
        'make_model'   => $make,
        'vehicle_type' => $veh_type,
    ]);
}

$completed_fares = array_filter($rides, fn($r) => ($r['ride_status'] ?? '') === 'Completed');
$stats['avg_fare'] = count($completed_fares) > 0
    ? array_sum(array_column(array_values($completed_fares), 'total_amount')) / count($completed_fares)
    : 0;

ksort($monthly_map);
$monthly      = array_values($monthly_map);
$max_spend    = 0;
foreach ($monthly as $m) { if ((float)$m['spent'] > $max_spend) $max_spend = (float)$m['spent']; }

krsort($months_set);
$months_avail = array_values($months_set);
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>EnviroCab – Trip History</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        
        :root,
        [data-theme="light"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --card-bg:         #FFFFFF;
            --card-border:     #E2E8F0;
            --header-bg:       rgba(255,255,255,0.85);
            --header-border:   rgba(255,255,255,0.5);
            --text-dark:       #1A202C;
            --text-medium:     #4A5568;
            --text-light:      #718096;
            --input-bg:        #FAFAFA;
            --input-border:    #E2E8F0;
            --row-border:      rgba(0,0,0,0.04);
            --stripe-bg:       rgba(0,0,0,0.025);
            --nav-bg:          rgba(255,255,255,0.95);
            --icon-btn-bg:     rgba(255,255,255,0.9);
            --icon-btn-border: rgba(0,0,0,0.05);
            --shadow-card:     0 2px 8px rgba(0,0,0,0.04);
            --shadow-hero:     0 8px 32px rgba(0,208,132,0.2);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.05);
            --overlay-bg:      rgba(0,0,0,0.45);
            --modal-bg:        #FFFFFF;
            --chip-bg:         #FFFFFF;
            --chip-color:      #4A5568;
            --meta-chip-bg:    rgba(0,0,0,0.04);
            --select-bg:       #FFFFFF;
            --bar-dim:         #E2E8F0;
            --dashed-line:     #E2E8F0;
            --modal-close-bg:  rgba(0,0,0,0.06);
        }

        [data-theme="dark"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #0D1F1A 0%, #0F172A 100%);
            --card-bg:         #1A2820;
            --card-border:     #263330;
            --header-bg:       rgba(15,24,18,0.94);
            --header-border:   rgba(0,208,132,0.1);
            --text-dark:       #E8F5F1;
            --text-medium:     #9FC4AE;
            --text-light:      #607D6B;
            --input-bg:        #111E18;
            --input-border:    #263330;
            --row-border:      rgba(255,255,255,0.05);
            --stripe-bg:       rgba(255,255,255,0.025);
            --nav-bg:          rgba(15,24,18,0.97);
            --icon-btn-bg:     rgba(255,255,255,0.06);
            --icon-btn-border: rgba(255,255,255,0.08);
            --shadow-card:     0 2px 12px rgba(0,0,0,0.35);
            --shadow-hero:     0 8px 40px rgba(0,208,132,0.12);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.5);
            --overlay-bg:      rgba(0,0,0,0.72);
            --modal-bg:        #1A2820;
            --chip-bg:         #1A2820;
            --chip-color:      #9FC4AE;
            --meta-chip-bg:    rgba(255,255,255,0.06);
            --select-bg:       #111E18;
            --bar-dim:         #263330;
            --dashed-line:     #263330;
            --modal-close-bg:  rgba(255,255,255,0.07);
        }

        
        *::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        *, *::before, *::after {
            transition: background-color .3s ease, border-color .25s ease,
                        color .2s ease, box-shadow .3s ease;
        }
        
        input, button, svg, img, select { transition: none; }
        input:focus, select:focus { transition: border-color .15s, box-shadow .15s; }
        .btn-primary, .icon-btn, .theme-btn, .nav-item, .filter-chip,
        .ride-card, .view-btn, .modal-action-btn {
            transition: background .2s, transform .15s, opacity .2s,
                        border-color .2s, box-shadow .2s, color .15s !important;
        }
        .toggle-slider, .toggle-slider:before { transition: background .3s, transform .3s !important; }
        .bar-fill { transition: none !important; }
        .t-sun, .t-moon {
            transition: opacity .35s ease,
                        transform .4s cubic-bezier(.34,1.56,.64,1) !important;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 100px;
            -webkit-font-smoothing: antialiased;
            transition:opacity .15s ease;
}

        
        .header {
            background: var(--header-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky; top: 0; z-index: 100;
            border-bottom: 1px solid var(--header-border);
        }
        .header-content { display:flex; justify-content:space-between; align-items:center; }
        .logo-img { height:28px; width:auto; }
        .header-right { display:flex; align-items:center; gap:10px; }

        
        .icon-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
        }
        .icon-btn svg { stroke:var(--text-medium); }
        .icon-btn:active { transform:scale(0.93); }
        .logout-btn {
            background:rgba(239,68,68,0.12) !important;
            border-color:rgba(239,68,68,0.2) !important;
        }
        .logout-btn svg { stroke:#EF4444 !important; }

        
        .theme-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center;
            cursor:pointer; position:relative; overflow:hidden;
        }
        .theme-btn:active { transform:scale(0.93); }
        .t-sun, .t-moon { position:absolute; }
        [data-theme="light"] .t-sun  { opacity:1;  transform:rotate(0deg)   scale(1);  }
        [data-theme="light"] .t-moon { opacity:0;  transform:rotate(90deg)  scale(.6); }
        [data-theme="dark"]  .t-sun  { opacity:0;  transform:rotate(-90deg) scale(.6); }
        [data-theme="dark"]  .t-moon { opacity:1;  transform:rotate(0deg)   scale(1);  }

        
        .main-content { padding:20px; }
        .section-title { font-size:18px; font-weight:700; margin-bottom:14px; color:var(--text-dark); }

        
        .hero-card {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
            border-radius:24px; padding:28px 24px; color:white;
            margin-bottom:20px; box-shadow:var(--shadow-hero);
            position:relative; overflow:hidden;
            animation: slideUp .4s ease forwards;
        }
        .hero-card::before {
            content:''; position:absolute; top:-50%; right:-20%;
            width:200px; height:200px; background:rgba(255,255,255,0.1); border-radius:50%;
        }
        .hero-greeting   { font-size:14px; opacity:.9; margin-bottom:4px; position:relative; }
        .hero-title      { font-size:24px; font-weight:800; margin-bottom:8px; position:relative; }
        .hero-amount     { font-size:42px; font-weight:900; letter-spacing:-1px; margin-bottom:4px; position:relative; }
        .hero-label      { font-size:13px; opacity:.85; position:relative; }
        .hero-stats      { display:flex; gap:12px; margin-top:24px; position:relative; }
        .hero-stat       { flex:1; background:rgba(255,255,255,.15); backdrop-filter:blur(10px); padding:12px; border-radius:16px; text-align:center; }
        .hero-stat-value { font-size:20px; font-weight:700; margin-bottom:4px; }
        .hero-stat-label { font-size:11px; opacity:.85; }

        
        .analytics-card {
            background:var(--card-bg); border-radius:20px;
            border:1px solid var(--card-border); box-shadow:var(--shadow-card);
            padding:20px; margin-bottom:20px;
            animation: slideUp .4s ease .08s forwards; opacity:0;
        }

        .stats-mini-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:20px; }

        .stat-mini {
            background:var(--stripe-bg); border:1px solid var(--card-border);
            border-radius:16px; padding:14px;
        }
        .stat-mini-icon  { width:36px; height:36px; border-radius:11px; display:flex; align-items:center; justify-content:center; margin-bottom:10px; }
        .stat-mini-val   { font-size:22px; font-weight:800; color:var(--text-dark); margin-bottom:2px; }
        .stat-mini-label { font-size:12px; color:var(--text-light); font-weight:500; }

        
        .chart-label { font-size:14px; font-weight:700; color:var(--text-dark); margin-bottom:12px; }
        .bar-chart   { display:flex; align-items:flex-end; gap:8px; height:80px; }
        .bar-col     { display:flex; flex-direction:column; align-items:center; flex:1; gap:5px; }
        .bar-fill {
            width:100%; border-radius:6px 6px 0 0; min-height:4px;
            background:linear-gradient(180deg, var(--primary-green), var(--dark-green));
            position:relative; cursor:default;
        }
        .bar-fill.dim { background:var(--bar-dim); }
        .bar-fill:hover::after {
            content:attr(data-tip); position:absolute;
            bottom:calc(100% + 6px); left:50%; transform:translateX(-50%);
            background:var(--text-dark); color:var(--card-bg);
            font-size:11px; font-weight:700; padding:4px 8px; border-radius:7px;
            white-space:nowrap; pointer-events:none; z-index:10;
        }
        .bar-month { font-size:10px; color:var(--text-light); font-weight:600; }

        
        .filter-scroll {
            display:flex; gap:8px; overflow-x:auto; padding-bottom:4px;
            margin-bottom:12px; scrollbar-width:none;
        }
        .filter-scroll::-webkit-scrollbar { display:none; }

        .filter-chip {
            flex-shrink:0; padding:8px 16px; border-radius:50px;
            font-size:13px; font-weight:600; cursor:pointer;
            border:1.5px solid var(--card-border);
            background:var(--chip-bg); color:var(--chip-color);
            white-space:nowrap; text-decoration:none; display:inline-block; line-height:1;
        }
        .filter-chip.active { background:var(--primary-green); border-color:var(--primary-green); color:white; }

        .month-wrap { position:relative; margin-bottom:12px; }
        .month-select {
            width:100%; padding:11px 40px 11px 16px; border-radius:14px;
            border:1.5px solid var(--input-border);
            background:var(--select-bg); color:var(--text-dark);
            font-size:14px; font-family:inherit; appearance:none; outline:none; cursor:pointer;
        }
        .month-select:focus { border-color:var(--primary-green); }
        .month-arrow { position:absolute; right:14px; top:50%; transform:translateY(-50%); pointer-events:none; color:var(--text-light); }

        .search-wrap { position:relative; margin-bottom:20px; }
        .search-input {
            width:100%; padding:12px 16px 12px 44px; border-radius:16px;
            border:1.5px solid var(--input-border);
            background:var(--input-bg); color:var(--text-dark);
            font-size:14px; font-family:inherit; outline:none;
        }
        .search-input:focus { border-color:var(--primary-green); box-shadow:0 0 0 3px rgba(0,208,132,.1); }
        .search-input::placeholder { color:var(--text-light); }
        .search-icon { position:absolute; left:14px; top:50%; transform:translateY(-50%); pointer-events:none; }

        
        .ride-list { display:flex; flex-direction:column; gap:12px; margin-bottom:24px; }

        .ride-card {
            background:var(--card-bg); border-radius:20px;
            border:1.5px solid var(--card-border); box-shadow:var(--shadow-card);
            overflow:hidden; cursor:pointer;
            animation: slideUp .4s ease forwards; opacity:0;
        }
        .ride-card:active { transform:scale(0.99); }
        .ride-card:hover  { border-color:rgba(0,208,132,.35); box-shadow:0 4px 18px rgba(0,0,0,.07); }

        .ride-card-header { display:flex; align-items:center; gap:14px; padding:16px 16px 0; }
        .ride-status-icon { width:48px; height:48px; border-radius:16px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .ride-card-info   { flex:1; min-width:0; }
        .ride-ref         { font-size:15px; font-weight:700; color:var(--text-dark); }
        .ride-driver      { font-size:12px; color:var(--text-light); margin-top:2px; }
        .ride-right       { text-align:right; flex-shrink:0; }
        .ride-amount      { font-size:16px; font-weight:800; color:var(--text-dark); }
        .ride-date        { font-size:11px; color:var(--text-light); margin-top:3px; }

        .ride-route-strip { display:flex; align-items:center; gap:8px; padding:12px 16px; }
        .rdot             { width:8px; height:8px; border-radius:50%; flex-shrink:0; }
        .rdot.pickup      { background:var(--primary-green); }
        .rdot.dropoff     { background:#EF4444; }
        .rarrow {
            flex:1; height:1px; background:var(--card-border); position:relative; margin:0 2px;
        }
        .rarrow::after {
            content:''; position:absolute; right:-1px; top:-3px;
            border:4px solid transparent; border-left:6px solid var(--card-border);
        }
        .rloc { font-size:12px; color:var(--text-medium); font-weight:500; max-width:38%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }

        .ride-card-footer {
            border-top:1px solid var(--card-border); padding:10px 16px;
            display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px;
        }
        .chip-row { display:flex; align-items:center; gap:6px; flex-wrap:wrap; }

        .meta-chip {
            font-size:11px; font-weight:600; color:var(--text-medium);
            background:var(--meta-chip-bg); padding:4px 9px; border-radius:7px;
            display:flex; align-items:center; gap:4px;
        }

        .status-badge { display:inline-flex; align-items:center; gap:5px; padding:4px 10px; border-radius:8px; font-size:11px; font-weight:700; }
        .badge-completed { background:rgba(16,185,129,0.12); color:#10B981; }
        .badge-cancelled { background:rgba(113,128,150,0.1);  color:#718096; }
        [data-theme="dark"] .badge-cancelled { background:rgba(113,128,150,0.18); color:#94A3B8; }

        .timeline-badge { display:inline-flex; align-items:center; gap:5px; padding:3px 10px; border-radius:7px; font-size:11px; font-weight:700; margin-top:6px; }
        .tb-paid     { background:rgba(16,185,129,0.12); color:#10B981; }
        .tb-unpaid   { background:rgba(239,68,68,0.12);  color:#EF4444; }
        .tb-refunded { background:rgba(96,165,250,0.15);  color:#3B82F6; }
        [data-theme="dark"] .tb-paid     { background:rgba(16,185,129,0.2); color:#34D399; }
        [data-theme="dark"] .tb-refunded { background:rgba(96,165,250,0.2); color:#60A5FA; }

        .view-btn {
            padding:7px 16px; border-radius:10px; border:none;
            background:rgba(0,208,132,0.1); color:var(--dark-green);
            font-size:12px; font-weight:700; cursor:pointer; font-family:inherit;
        }
        .view-btn:active { transform:scale(0.97); }
        [data-theme="dark"] .view-btn { background:rgba(0,208,132,0.15); color:var(--primary-green); }

        
        .empty-state {
            text-align:center; padding:44px 20px;
            background:var(--card-bg); border-radius:20px; border:1px solid var(--card-border);
        }
        .empty-icon  { margin-bottom:12px; display:flex; justify-content:center; }
        .empty-title { font-size:16px; font-weight:700; color:var(--text-dark); margin-bottom:6px; }
        .empty-sub   { font-size:13px; color:var(--text-light); }

        
        .modal-overlay {
            position:fixed; inset:0; background:var(--overlay-bg);
            backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px);
            z-index:200; display:flex; align-items:center; justify-content:center;
            padding:20px; opacity:0; pointer-events:none;
        }
        .modal-overlay.open { opacity:1; pointer-events:auto; }

        .modal-sheet {
            background:var(--modal-bg); width:100%; max-width:440px;
            border-radius:24px; padding:0 0 28px;
            transform:scale(0.96) translateY(10px);
            max-height:90vh; overflow-y:auto;
            border:1px solid var(--card-border);
        }
        
        .modal-sheet { transition: transform .3s ease !important; }
        .modal-overlay { transition: opacity .25s !important; }
        .modal-overlay.open .modal-sheet { transform:scale(1) translateY(0); }

        .modal-inner-hdr { padding:20px 20px 0; display:flex; justify-content:space-between; align-items:center; }
        .modal-title     { font-size:20px; font-weight:800; color:var(--text-dark); }
        .modal-close     { width:32px; height:32px; border-radius:10px; background:var(--modal-close-bg); border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; }
        .modal-close svg { stroke:var(--text-medium); }
        .modal-body      { padding:20px; }

        .receipt-hdr { background:linear-gradient(135deg,var(--primary-green),var(--dark-green)); border-radius:16px; padding:20px; color:white; text-align:center; margin-bottom:20px; }
        .receipt-icon { display:flex; justify-content:center; margin-bottom:8px; }
        .receipt-ref  { font-size:18px; font-weight:800; margin-bottom:3px; }
        .receipt-date { font-size:13px; opacity:.9; }
        .receipt-pill { display:inline-flex; align-items:center; gap:5px; background:rgba(255,255,255,.2); padding:4px 12px; border-radius:20px; font-size:12px; font-weight:700; margin-top:8px; }

        .modal-route-block { background:var(--stripe-bg); border:1px solid var(--card-border); border-radius:14px; padding:14px; margin-bottom:16px; }
        .modal-route-row   { display:flex; align-items:flex-start; gap:10px; padding:5px 0; }
        .mricon { width:28px; height:28px; border-radius:9px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .mrlbl  { font-size:11px; font-weight:600; color:var(--text-light); margin-bottom:2px; }
        .mrval  { font-size:13px; font-weight:600; color:var(--text-dark); line-height:1.4; }
        .mrdivider { width:2px; height:10px; background:var(--card-border); border-radius:1px; margin-left:13px; }

        .modal-driver-card { background:linear-gradient(135deg,rgba(0,208,132,.07),rgba(0,168,107,.04)); border:1.5px solid rgba(0,208,132,.2); border-radius:14px; padding:14px; display:flex; align-items:center; gap:12px; margin-bottom:16px; }
        .drv-avatar { width:44px; height:44px; border-radius:14px; background:linear-gradient(135deg,var(--primary-green),var(--dark-green)); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .drv-name   { font-size:14px; font-weight:700; color:var(--text-dark); }
        .drv-sub    { font-size:12px; color:var(--text-light); margin-top:2px; }

        .modal-info-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:16px; }
        .modal-info-box  { background:var(--stripe-bg); border-radius:14px; padding:12px; border:1px solid var(--card-border); }
        .milbl { font-size:11px; color:var(--text-light); font-weight:500; margin-bottom:4px; }
        .mival { font-size:15px; font-weight:700; color:var(--text-dark); }

        .fare-row { display:flex; justify-content:space-between; align-items:center; padding:11px 0; border-bottom:1px dashed var(--dashed-line); }
        .fare-row:last-child { border-bottom:none; }
        .fare-lbl { font-size:13px; color:var(--text-light); }
        .fare-val { font-size:14px; font-weight:600; color:var(--text-dark); }
        .fare-total-row { display:flex; justify-content:space-between; align-items:center; padding:14px 0 0; border-top:2px solid var(--card-border); margin-top:4px; }
        .fare-total-lbl { font-size:15px; font-weight:700; color:var(--text-dark); }
        .fare-total-val { font-size:22px; font-weight:900; color:var(--primary-green); }

        .auth-box  { background:rgba(0,208,132,.07); border:1.5px dashed var(--primary-green); border-radius:14px; padding:14px; text-align:center; margin-top:16px; }
        .auth-lbl  { font-size:11px; color:var(--text-light); margin-bottom:4px; }
        .auth-code { font-size:18px; font-weight:800; color:var(--primary-green); letter-spacing:2px; }

        .modal-actions { display:flex; gap:10px; margin-top:16px; flex-wrap:wrap; }
        .modal-action-btn { flex:1; min-width:0; padding:12px; border-radius:14px; border:none; font-size:13px; font-weight:700; cursor:pointer; font-family:inherit; display:flex; align-items:center; justify-content:center; gap:7px; }
        .modal-action-btn:active { transform:scale(0.97); }
        .btn-green   { background:linear-gradient(135deg,var(--primary-green),var(--dark-green)); color:white; }
        .btn-outline { background:var(--stripe-bg); color:var(--text-medium); border:1.5px solid var(--card-border) !important; }
        .btn-red     { background:rgba(239,68,68,.1); color:#EF4444; border:1.5px solid rgba(239,68,68,.2) !important; }

        
        .bottom-nav {
            position:fixed; bottom:0; left:0; right:0;
            background:var(--nav-bg);
            backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
            border-top:1px solid var(--card-border);
            padding:12px 0 20px;
            display:grid; grid-template-columns:repeat(4,1fr);
            z-index:99; box-shadow:var(--shadow-nav);
        }
        .nav-item {
            display:flex; flex-direction:column; align-items:center; gap:4px;
            padding:8px; cursor:pointer; border:none; background:none;
        }
        .nav-item:active { transform:scale(0.95); }
        .nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
        .nav-icon svg { stroke:var(--text-light); opacity:.5; }
        .nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
        .nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:.7; }
        .nav-item.active .nav-label { color:var(--primary-green); opacity:1; }

        
        @media (min-width:768px) {
            body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,0.12); }
            .bottom-nav { max-width:480px; left:50%; transform:translateX(-50%); }
        }
        @keyframes slideUp {
            from { opacity:0; transform:translateY(20px); }
            to   { opacity:1; transform:translateY(0); }
        }
    
    
    .notif-panel-wrap{position:relative;}
    .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:310px;max-height:400px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.15);z-index:999;display:none;flex-direction:column;overflow:hidden;}
    .notif-panel.open{display:flex;}
    .notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);flex-shrink:0;}
    .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
    .notif-mark-read{font-size:11px;font-weight:600;color:var(--dark-green);background:none;border:none;cursor:pointer;padding:0;}
    .notif-list{overflow-y:auto;flex:1;padding:4px 0;}
    .notif-item{display:flex;align-items:flex-start;gap:10px;padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--row-border);transition:background .15s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,208,132,0.06);}
    .notif-item.unread{background:rgba(0,208,132,0.04);}
    .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
    .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
    .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
    .notif-item-body{flex:1;min-width:0;}
    .notif-item-title{font-size:12px;font-weight:700;color:var(--text-dark);margin-bottom:2px;}
    .notif-item-sub{font-size:11px;color:var(--text-light);line-height:1.4;}
    .notif-item-time{font-size:10px;color:var(--text-light);margin-top:3px;}
    .notif-empty{padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;}
    .notif-spinner{width:20px;height:20px;border:2px solid var(--card-border);border-top-color:#00D084;border-radius:50%;animation:nspin .7s linear infinite;margin:16px auto;}
    @keyframes nspin{to{transform:rotate(360deg);}}
    .notif-count-badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 3px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:9px;font-weight:800;color:#fff;display:none;align-items:center;justify-content:center;line-height:1;}
    
    .logout-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center;padding:24px;}
    .logout-overlay.open{display:flex;}
    .logout-modal{background:var(--card-bg);border-radius:24px;padding:28px 24px 24px;width:100%;max-width:320px;box-shadow:0 16px 48px rgba(0,0,0,0.18);animation:lmodalIn .25s cubic-bezier(.34,1.56,.64,1);}
    @keyframes lmodalIn{from{transform:scale(.88);opacity:0;}to{transform:scale(1);opacity:1;}}
    .logout-modal-icon{width:52px;height:52px;border-radius:16px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
    .logout-modal-title{font-size:17px;font-weight:800;color:var(--text-dark);text-align:center;margin-bottom:6px;}
    .logout-modal-sub{font-size:13px;color:var(--text-light);text-align:center;line-height:1.5;margin-bottom:22px;}
    .logout-modal-btns{display:flex;gap:10px;}
    .logout-cancel-btn{flex:1;padding:13px;border-radius:14px;background:var(--input-bg);border:1px solid var(--card-border);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;}
    .logout-confirm-btn{flex:1;padding:13px;border-radius:14px;background:#EF4444;border:none;font-size:14px;font-weight:700;color:#fff;cursor:pointer;}
</style>
</head>
<body>

<script>
(function(){
    var t = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>

<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img"
             onerror="this.style.display='none'">
                        <div class="header-right">
            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            </button>
            <button class="icon-btn" onclick="window.location.href='dashboard.php'" title="Home">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </button>
            <div class="notif-panel-wrap">
            <button class="icon-btn" id="notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications" style="position:relative;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <span class="notif-count-badge" id="notif-count-badge"></span>
            </button>
            <div class="notif-panel" id="notif-panel">
                <div class="notif-panel-head">
                    <span class="notif-panel-title">Notifications</span>
                    <button class="notif-mark-read" onclick="markAllRead()">Mark all read</button>
                </div>
                <div class="notif-list" id="notif-list"><div class="notif-spinner"></div></div>
            </div>
        </div>
            <button class="icon-btn logout-btn" onclick="openLogout()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

    <div class="hero-card">
        <div class="hero-greeting"><?php echo $greeting; ?>, <?php echo htmlspecialchars($_SESSION['name'] ?? $_SESSION['username']); ?>!</div>
        <div class="hero-title">Trip History</div>
        <div class="hero-amount">₱<?php echo number_format((float)$stats['total_spent'],2); ?></div>
        <div class="hero-label">Total Lifetime Spending</div>
        <div class="hero-stats">
            <div class="hero-stat"><div class="hero-stat-value"><?php echo (int)$stats['total_rides']; ?></div><div class="hero-stat-label">Total Rides</div></div>
            <div class="hero-stat"><div class="hero-stat-value"><?php echo number_format((float)$stats['total_km'],1); ?></div><div class="hero-stat-label">Total KM</div></div>
            <div class="hero-stat"><div class="hero-stat-value"><?php echo (int)$stats['completed']; ?></div><div class="hero-stat-label">Completed</div></div>
        </div>
    </div>

    <div class="analytics-card">
        <div class="section-title" style="margin-bottom:16px;">Ride Analytics</div>
        <div class="stats-mini-grid">
            <div class="stat-mini">
                <div class="stat-mini-icon" style="background:rgba(0,208,132,.12)">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--primary-green)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <div class="stat-mini-val"><?php echo (int)$stats['completed']; ?></div>
                <div class="stat-mini-label">Completed</div>
            </div>
            <div class="stat-mini">
                <div class="stat-mini-icon" style="background:rgba(239,68,68,.1)">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                </div>
                <div class="stat-mini-val"><?php echo (int)$stats['cancelled']; ?></div>
                <div class="stat-mini-label">Cancelled</div>
            </div>
            <div class="stat-mini">
                <div class="stat-mini-icon" style="background:rgba(96,165,250,.14)">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                </div>
                <div class="stat-mini-val"><?php echo number_format((float)$stats['total_km'],1); ?><span style="font-size:13px;font-weight:600"> km</span></div>
                <div class="stat-mini-label">Total Distance</div>
            </div>
            <div class="stat-mini">
                <div class="stat-mini-icon" style="background:rgba(192,132,252,.12)">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#C084FC" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7H17"/><line x1="8" y1="9" x2="18" y2="9"/><line x1="8" y1="12" x2="18" y2="12"/></svg>
                </div>
                <div class="stat-mini-val">₱<?php echo number_format((float)$stats['avg_fare'],0); ?></div>
                <div class="stat-mini-label">Avg Trip Fare</div>
            </div>
        </div>

        <?php if (!empty($monthly)): ?>
        <div class="chart-label">Monthly Spending — Last 6 Months</div>
        <div class="bar-chart">
            <?php foreach ($monthly as $month):
                $pct   = $max_spend > 0 ? max(5, round(((float)$month['spent']/$max_spend)*100)) : 5;
                $empty = (float)$month['spent'] == 0;
                $tip   = '₱'.number_format((float)$month['spent'],0).' · '.$month['trips'].' trip'.($month['trips']!=1?'s':'');
            ?>
            <div class="bar-col">
                <div class="bar-fill <?php echo $empty?'dim':''; ?>"
                     style="height:<?php echo $pct; ?>%" data-tip="<?php echo htmlspecialchars($tip); ?>"></div>
                <div class="bar-month"><?php echo htmlspecialchars($month['month_short']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="filter-scroll">
        <?php foreach (['all'=>'All Trips','Completed'=>'Completed','Cancelled'=>'Cancelled'] as $k=>$lbl):
            $url='?status='.$k.'&month='.urlencode($filter_month).'&search='.urlencode($search_q); ?>
        <a href="<?php echo $url; ?>" class="filter-chip <?php echo $filter_status===$k?'active':''; ?>">
            <?php echo $lbl; ?>
        </a>
        <?php endforeach; ?>
    </div>

    <?php if (!empty($months_avail)): ?>
    <div class="month-wrap">
        <select class="month-select"
                onchange="window.location.href='?status=<?php echo urlencode($filter_status); ?>&month='+this.value+'&search=<?php echo urlencode($search_q); ?>'">
            <option value="">All Months</option>
            <?php foreach ($months_avail as $mo): ?>
            <option value="<?php echo htmlspecialchars($mo['month_value']); ?>"
                    <?php echo $filter_month===$mo['month_value']?'selected':''; ?>>
                <?php echo htmlspecialchars($mo['label']); ?>
            </option>
            <?php endforeach; ?>
        </select>
        <span class="month-arrow">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="6 9 12 15 18 9"/>
            </svg>
        </span>
    </div>
    <?php endif; ?>

    <form method="GET" class="search-wrap">
        <input type="hidden" name="status" value="<?php echo htmlspecialchars($filter_status); ?>">
        <input type="hidden" name="month"  value="<?php echo htmlspecialchars($filter_month); ?>">
        <span class="search-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)"
                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
        </span>
        <input type="text" name="search" class="search-input"
               placeholder="Search ref, driver, or location…"
               value="<?php echo htmlspecialchars($search_q); ?>">
    </form>

    <div class="section-title">
        <?php echo count($rides); ?> Trip<?php echo count($rides)!==1?'s':''; ?>
        <?php if ($filter_month||$search_q||$filter_status!=='all'): ?>
        <span style="font-size:13px;font-weight:500;color:var(--text-light)"> · filtered</span>
        <?php endif; ?>
    </div>

    <?php if (empty($rides)): ?>
    <div class="empty-state">
        <div class="empty-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none"
                 stroke="var(--text-light)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
        </div>
        <div class="empty-title">No trips found</div>
        <div class="empty-sub">
            <?php echo ($filter_month||$search_q||$filter_status!=='all')
                ?'Try adjusting your filters or search.'
                :'Your completed and cancelled trips will appear here.'; ?>
        </div>
    </div>
    <?php else: ?>
    <div class="ride-list">
        <?php foreach ($rides as $idx => $ride):
            $isC  = $ride['ride_status']==='Completed';
            $isPd = $ride['payment_status']==='Paid';
            $isRf = $ride['payment_status']==='Refunded';
            $ibg  = $isC?'rgba(16,185,129,.12)':'rgba(113,128,150,.1)';
            $ic   = $isC?'#10B981':'#718096';
            $bc   = $isC?'badge-completed':'badge-cancelled';
            $dur  = tripDur($ride['start_time'],$ride['end_time']);
            $from = shortLoc($ride['start_location']);
            $to   = shortLoc($ride['end_location']??'—');
            $pm   = $ride['payment_method']??'—';
            $pml  = $pm==='E-Wallet'?'GCash':($pm?:'—');
            $del  = min($idx*0.06,0.5);
            $tbc  = $isPd?'tb-paid':($isRf?'tb-refunded':'tb-unpaid');
            $tbl  = $isPd?'Paid':($isRf?'Refunded':($ride['payment_status']??'Unpaid'));
        ?>
        <div class="ride-card"
             style="animation-delay:<?php echo $del; ?>s"
             onclick="openDetail(<?php echo htmlspecialchars(json_encode($ride),ENT_QUOTES); ?>)">

            <div class="ride-card-header">
                <div class="ride-status-icon" style="background:<?php echo $ibg; ?>">
                    <?php if ($isC): ?>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="<?php echo $ic; ?>" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    <?php else: ?>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="<?php echo $ic; ?>" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                    <?php endif; ?>
                </div>
                <div class="ride-card-info">
                    <div class="ride-ref"><?php echo htmlspecialchars($ride['booking_reference']); ?></div>
                    <div class="ride-driver"><?php echo htmlspecialchars($ride['driver_name']??'Driver N/A'); ?></div>
                    <span class="timeline-badge <?php echo $tbc; ?>">
                        <svg width="7" height="7" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
                        <?php echo htmlspecialchars($tbl); ?>
                    </span>
                </div>
                <div class="ride-right">
                    <div class="ride-amount">₱<?php echo number_format((float)$ride['total_amount'],2); ?></div>
                    <div class="ride-date"><?php echo date('M d, Y',strtotime($ride['start_time'])); ?></div>
                </div>
            </div>

            <div class="ride-route-strip">
                <div class="rdot pickup"></div>
                <div class="rloc"><?php echo htmlspecialchars($from); ?></div>
                <div class="rarrow"></div>
                <div class="rloc" style="text-align:right"><?php echo htmlspecialchars($to); ?></div>
                <div class="rdot dropoff"></div>
            </div>

            <div class="ride-card-footer">
                <div class="chip-row">
                    <span class="status-badge <?php echo $bc; ?>">
                        <svg width="7" height="7" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
                        <?php echo $ride['ride_status']; ?>
                    </span>
                    <?php if ($dur!=='—'): ?>
                    <span class="meta-chip">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        <?php echo $dur; ?>
                    </span>
                    <?php endif; ?>
                    <?php if ($ride['distance_km']): ?>
                    <span class="meta-chip">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/></svg>
                        <?php echo number_format((float)$ride['distance_km'],1); ?> km
                    </span>
                    <?php endif; ?>
                    <span class="meta-chip">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                        <?php echo htmlspecialchars($pml); ?>
                    </span>
                </div>
                <button class="view-btn"
                        onclick="event.stopPropagation();openDetail(<?php echo htmlspecialchars(json_encode($ride),ENT_QUOTES); ?>)">
                    Details
                </button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

</div>
<div class="modal-overlay" id="detailModal">
    <div class="modal-sheet">
        <div class="modal-inner-hdr">
            <div class="modal-title">Trip Details</div>
            <button class="modal-close" onclick="closeDetail()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6"  x2="6"  y2="18"/>
                    <line x1="6"  y1="6"  x2="18" y2="18"/>
                </svg>
            </button>
        </div>
        <div class="modal-body" id="detailBody"></div>
    </div>
</div>

<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_profile.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_profile.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div>
        <span class="nav-label">Home</span>
    </button>

    <button class="nav-item" onclick="window.location.href='passenger_booking.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8"  x2="12" y2="16"/>
                <line x1="8"  y1="12" x2="16" y2="12"/>
            </svg>
        </div>
        <span class="nav-label">Book</span>
    </button>

    <button class="nav-item" onclick="window.location.href='passenger_trips.php'">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                <line x1="16" y1="2"  x2="16" y2="6"/>
                <line x1="8"  y1="2"  x2="8"  y2="6"/>
                <line x1="3"  y1="10" x2="21" y2="10"/>
            </svg>
        </div>
        <span class="nav-label">Trips</span>
    </button>

    <button class="nav-item active">
        <div class="nav-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
            </svg>
        </div>
        <span class="nav-label">History</span>
    </button>

</div>

<script>

function toggleTheme() {
    var html = document.documentElement;
    var next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('envirocab_theme', next);
}

function esc(s) {
    return String(s||'')
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function peso(v) {
    return '₱'+parseFloat(v||0).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2});
}
function fmtDate(s) {
    if (!s) return '—';
    var d = new Date(s.replace(' ','T'));
    return d.toLocaleDateString('en-PH',{year:'numeric',month:'short',day:'numeric'})
           +' '+d.toLocaleTimeString('en-PH',{hour:'2-digit',minute:'2-digit'});
}
function fmtTime(s) {
    if (!s) return '—';
    return new Date(s.replace(' ','T')).toLocaleTimeString('en-PH',{hour:'2-digit',minute:'2-digit'});
}
function calcDur(a,b) {
    if (!a||!b) return '—';
    var d=(new Date(b.replace(' ','T'))-new Date(a.replace(' ','T')))/1000;
    if (d<=0) return '—';
    var h=Math.floor(d/3600),m=Math.floor((d%3600)/60);
    return h>0?h+'h '+m+'m':m+' min';
}
function frRow(lbl,val) {
    return '<div class="fare-row"><div class="fare-lbl">'+lbl+'</div><div class="fare-val">'+val+'</div></div>';
}
function inBox(lbl,val) {
    return '<div class="modal-info-box"><div class="milbl">'+lbl+'</div><div class="mival">'+esc(String(val))+'</div></div>';
}

function openDetail(r) {
    if (typeof r==='string') r=JSON.parse(r);
    var isC=r.ride_status==='Completed', isPd=r.payment_status==='Paid', isRf=r.payment_status==='Refunded';
    var method=r.payment_method||'—', mLbl=method==='E-Wallet'?'GCash':method;
    var dur=calcDur(r.start_time,r.end_time);

    var fr='';
    fr+=frRow('Payment Method',esc(mLbl));
    var pc=isPd?'#10B981':(isRf?'#3B82F6':'#EF4444');
    fr+=frRow('Payment Status','<span style="font-weight:700;color:'+pc+'">'+esc(r.payment_status||'—')+'</span>');
    if (r.base_fare!=null)     fr+=frRow('Base Fare',peso(r.base_fare));
    if (r.distance_km!=null)   fr+=frRow('Distance',parseFloat(r.distance_km).toFixed(2)+' km');
    if (r.distance_rate!=null) fr+=frRow('Rate / km',peso(r.distance_rate));
    if (r.surge_multiplier!=null&&parseFloat(r.surge_multiplier)!==1)
        fr+=frRow('Surge','×'+parseFloat(r.surge_multiplier).toFixed(2));
    if (r.additional_charges!=null&&parseFloat(r.additional_charges)>0)
        fr+=frRow('Additional Charges',peso(r.additional_charges));
    if (r.discount!=null&&parseFloat(r.discount)>0)
        fr+=frRow('Discount','−'+peso(r.discount));
    if (method==='E-Wallet'&&r.transaction_reference)
        fr+=frRow('GCash Reference',esc(r.transaction_reference));

    var auth=r.authorization_code
        ?'<div class="auth-box"><div class="auth-lbl">Authorization Code</div><div class="auth-code">'+esc(r.authorization_code)+'</div></div>':'';

    var drv='';
    if (r.driver_name) {
        var plate=r.plate_number?esc(r.plate_number)+(r.make_model?' · '+esc(r.make_model):''):'No vehicle assigned';
        drv='<div class="modal-driver-card">'
           +'<div class="drv-avatar"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>'
           +'<div><div class="drv-name">'+esc(r.driver_name)+'</div><div class="drv-sub">'+plate+'</div></div>'
           +'</div>';
    }

    var acts='<div class="modal-actions">';
    if (isPd) {
        acts+='<button class="modal-action-btn btn-green" onclick="printReceipt()">'
             +'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/></svg> Receipt</button>';
    } else if (isC&&!isRf) {
        acts+='<button class="modal-action-btn btn-green" onclick="closeDetail();window.location.href=\'passenger_payments.php\'">'
             +'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg> Pay Now</button>';
    }
    if (!isRf) {
        acts+='<button class="modal-action-btn btn-red" onclick="closeDetail();window.location.href=\'passenger_feedback.php\'">'
             +'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> Report</button>';
    }
    acts+='<button class="modal-action-btn btn-outline" onclick="closeDetail()">'
         +'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Close</button>';
    acts+='</div>';

    var html=
        '<div class="receipt-hdr">'
       +'<div class="receipt-icon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg></div>'
       +'<div class="receipt-ref">'+esc(r.booking_reference)+'</div>'
       +'<div class="receipt-date">'+fmtDate(r.start_time)+'</div>'
       +'<div class="receipt-pill"><svg width="7" height="7" viewBox="0 0 10 10" fill="white"><circle cx="5" cy="5" r="5"/></svg>'+esc(r.ride_status)+'</div>'
       +'</div>'

       +'<div class="modal-route-block">'
       +'<div class="modal-route-row"><div class="mricon" style="background:rgba(0,208,132,.12)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--primary-green)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3"/></svg></div>'
       +'<div><div class="mrlbl">Pickup</div><div class="mrval">'+esc(r.start_location)+'</div></div></div>'
       +'<div class="mrdivider"></div>'
       +'<div class="modal-route-row"><div class="mricon" style="background:rgba(239,68,68,.1)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>'
       +'<div><div class="mrlbl">Destination</div><div class="mrval">'+esc(r.end_location||'—')+'</div></div></div>'
       +'</div>'

       +drv

       +'<div class="modal-info-grid">'
       +inBox('Distance',r.distance_km?parseFloat(r.distance_km).toFixed(1)+' km':'—')
       +inBox('Duration',dur)
       +inBox('Start',fmtTime(r.start_time))
       +inBox('End',fmtTime(r.end_time))
       +'</div>'

       +'<div class="section-title" style="font-size:15px;margin-bottom:8px">Fare Breakdown</div>'
       +'<div class="fare-section">'+fr+'</div>'
       +'<div class="fare-total-row"><div class="fare-total-lbl">Total Fare</div><div class="fare-total-val">'+peso(r.total_amount)+'</div></div>'
       +auth+acts;

    document.getElementById('detailBody').innerHTML=html;
    document.getElementById('detailModal').classList.add('open');
    document.body.style.overflow='hidden';
    window._r=r;
}

function closeDetail() {
    document.getElementById('detailModal').classList.remove('open');
    document.body.style.overflow='';
}
document.getElementById('detailModal').addEventListener('click',function(e){
    if (e.target===this) closeDetail();
});

function printReceipt() {
    var r=window._r; if (!r) return;
    var ml=r.payment_method==='E-Wallet'?'GCash':r.payment_method||'—';
    var dur=calcDur(r.start_time,r.end_time);
    var w=window.open('','_blank','width=440,height=680');
    w.document.write('<html><head><title>Receipt – '+esc(r.booking_reference)+'</title>');
    w.document.write('<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:sans-serif;padding:32px;font-size:14px;color:#1a202c}.logo{font-size:20px;font-weight:800;color:#00A86B;margin-bottom:2px}.sub{font-size:12px;color:#718096;margin-bottom:20px}hr{border:none;border-top:1px dashed #e2e8f0;margin:14px 0}table{width:100%;border-collapse:collapse}td{padding:8px 0;vertical-align:top}td:last-child{text-align:right;font-weight:600}.total-row td{font-size:18px;font-weight:800;padding-top:14px;border-top:2px solid #e2e8f0}.total-row td:last-child{color:#00A86B}.footer{font-size:11px;color:#a0aec0;text-align:center;margin-top:24px;line-height:1.6}</style></head><body>');
    w.document.write('<div class="logo">EnviroCab</div><div class="sub">Official Trip Receipt</div><hr><table>');
    w.document.write('<tr><td>Booking Ref</td><td>'+esc(r.booking_reference)+'</td></tr>');
    w.document.write('<tr><td>Date</td><td>'+fmtDate(r.start_time)+'</td></tr>');
    w.document.write('<tr><td>Trip Status</td><td>'+esc(r.ride_status)+'</td></tr>');
    w.document.write('<tr><td>Driver</td><td>'+esc(r.driver_name||'—')+'</td></tr>');
    if (r.plate_number) w.document.write('<tr><td>Vehicle</td><td>'+esc(r.plate_number+(r.make_model?' – '+r.make_model:''))+'</td></tr>');
    w.document.write('</table><hr><table>');
    w.document.write('<tr><td>Pickup</td><td>'+esc(r.start_location)+'</td></tr>');
    w.document.write('<tr><td>Destination</td><td>'+esc(r.end_location||'—')+'</td></tr>');
    if (r.distance_km) w.document.write('<tr><td>Distance</td><td>'+parseFloat(r.distance_km).toFixed(2)+' km</td></tr>');
    if (dur!=='—') w.document.write('<tr><td>Duration</td><td>'+esc(dur)+'</td></tr>');
    w.document.write('</table><hr><table>');
    w.document.write('<tr><td>Payment Method</td><td>'+esc(ml)+'</td></tr>');
    w.document.write('<tr><td>Payment Status</td><td>'+esc(r.payment_status||'—')+'</td></tr>');
    if (r.base_fare!=null)    w.document.write('<tr><td>Base Fare</td><td>'+peso(r.base_fare)+'</td></tr>');
    if (r.distance_rate!=null) w.document.write('<tr><td>Rate/km</td><td>'+peso(r.distance_rate)+'</td></tr>');
    if (r.surge_multiplier!=null&&parseFloat(r.surge_multiplier)!==1)
        w.document.write('<tr><td>Surge</td><td>×'+parseFloat(r.surge_multiplier).toFixed(2)+'</td></tr>');
    if (r.discount!=null&&parseFloat(r.discount)>0)
        w.document.write('<tr><td>Discount</td><td>−'+peso(r.discount)+'</td></tr>');
    if (r.authorization_code)
        w.document.write('<tr><td>Auth Code</td><td>'+esc(r.authorization_code)+'</td></tr>');
    if (r.transaction_reference&&r.payment_method==='E-Wallet')
        w.document.write('<tr><td>GCash Ref</td><td>'+esc(r.transaction_reference)+'</td></tr>');
    w.document.write('<tr class="total-row"><td>TOTAL FARE</td><td>'+peso(r.total_amount)+'</td></tr></table>');
    w.document.write('<div class="footer">Thank you for riding with EnviroCab!<br>Generated '+new Date().toLocaleString('en-PH')+'</div>');
    w.document.write('<script>
const CUSTOMER_ID = <?= (int)$customer_id ?>;

const SB_URL = 'https:
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
let _notifOpen = false, _notifData = [], _notifTimer = null;
let _seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');

const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};

function toggleNotifPanel(e) {
    e.stopPropagation();
    _notifOpen = !_notifOpen;
    document.getElementById('notif-panel').classList.toggle('open', _notifOpen);
    if (_notifOpen) { fetchNotifs(); _notifTimer = setInterval(fetchNotifs, 8000); }
    else clearInterval(_notifTimer);
}

async function fetchNotifs() {
    try {
        const r = await fetch(SB_URL + '/rest/v1/core2_bookings?customer_id=eq.' + CUSTOMER_ID +
            '&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=15',
            {headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        _notifData = await r.json();
        renderNotifs();
        updateBadge();
    } catch(e) {}
}

function renderNotifs() {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!_notifData.length) { list.innerHTML = '<div class="notif-empty">No notifications yet.</div>'; return; }
    list.innerHTML = _notifData.map(b => {
        const cfg = STATUS_CFG[b.booking_status] || {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key = b.booking_id + '_' + b.booking_status;
        const unread = !_seen.includes(key);
        const amt = '\u20B1' + parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t = timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
}

function updateBadge() {
    const cnt = _notifData.filter(b => !_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    const el = document.getElementById('notif-count-badge');
    if (!el) return;
    if (cnt > 0) { el.textContent = cnt > 9 ? '9+' : cnt; el.style.display = 'flex'; }
    else el.style.display = 'none';
}

function goNotif(page, bid, key) {
    if (!_seen.includes(key)) { _seen.push(key); localStorage.setItem(SEEN_KEY, JSON.stringify(_seen)); }
    window.location.href = page + '?booking_id=' + bid;
}

function markAllRead() {
    _seen = _notifData.map(b => b.booking_id+'_'+b.booking_status);
    localStorage.setItem(SEEN_KEY, JSON.stringify(_seen));
    renderNotifs(); updateBadge();
}

function timeAgo(iso) {
    if (!iso) return '';
    const s = Math.floor((Date.now() - new Date(iso))/1000);
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s/60)+'m ago';
    if (s < 86400) return Math.floor(s/3600)+'h ago';
    return Math.floor(s/86400)+'d ago';
}

function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function openLogout() { document.getElementById('logout-overlay').classList.add('open'); }

document.addEventListener('click', function(e) {
    const panel = document.getElementById('notif-panel');
    const btn   = document.getElementById('notif-bell-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        _notifOpen = false; panel.classList.remove('open'); clearInterval(_notifTimer);
    }
});

document.addEventListener('DOMContentLoaded', () => { if (CUSTOMER_ID) fetchNotifs(); });
</script>


<div class="logout-overlay" id="logout-overlay" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="logout-modal">
        <div class="logout-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </div>
        <div class="logout-modal-title">Log out?</div>
        <div class="logout-modal-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-modal-btns">
            <button class="logout-cancel-btn" onclick="document.getElementById('logout-overlay').classList.remove('open')">Cancel</button>
            <button class="logout-confirm-btn" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{ once:true });
      a.addEventListener('touchstart',function(){ prerender(href); },{ once:true, passive:true });
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{ once:true });
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
</body></html>');
    w.document.close(); w.focus();
    setTimeout(function(){ w.print(); },400);
}
</script>
</body>