<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['customer_id'])) {
    header('Location: ../auth/passenger_login.php');
    exit;
}

if (!defined('SUPABASE_URL'))      define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
if (!defined('SUPABASE_ANON_KEY')) define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) return json_decode($res, true) ?: [];
    error_log("SB GET {$table} HTTP {$code}: {$res}");
    return [];
}

function sb_post(string $table, array $data): ?array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) {
        $r = json_decode($res, true);
        return is_array($r) ? ($r[0] ?? null) : null;
    }
    error_log("SB POST {$table} HTTP {$code}: {$res}");
    return null;
}

$customer_id     = $_SESSION['customer_id'];
$success_message = '';
$error_message   = '';
$view_mode       = $_GET['view'] ?? 'submit';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['action']) && $_POST['action'] === 'submit_feedback') {
        $ride_id             = (int)($_POST['ride_id']             ?? 0);
        $driver_id           = (int)($_POST['driver_id']           ?? 0);
        $rating_value        = (int)($_POST['rating_value']        ?? 0);
        $driver_behavior     = (int)($_POST['driver_behavior']     ?? 0);
        $vehicle_cleanliness = (int)($_POST['vehicle_cleanliness'] ?? 0);
        $ride_comfort        = (int)($_POST['ride_comfort']        ?? 0);
        $punctuality         = (int)($_POST['punctuality']         ?? 0);
        $comment             = trim($_POST['comment'] ?? '');

        if ($ride_id && $driver_id && $rating_value) {
            $detailed = "[Detailed Ratings] Driver Behavior: {$driver_behavior}/5 | Vehicle Cleanliness: {$vehicle_cleanliness}/5 | Ride Comfort: {$ride_comfort}/5 | Punctuality: {$punctuality}/5";
            $full_comment = $comment ? $comment . "\n" . $detailed : $detailed;

            $result = sb_post('core2_ratings', [
                'ride_id'     => $ride_id,
                'driver_id'   => $driver_id,
                'customer_id' => (int)$customer_id,
                'rating_value'=> $rating_value,
                'comment'     => $full_comment,
                'rating_type' => 'Driver Rating',
            ]);
            if ($result) {
                $success_message = 'Thank you for your feedback! Your rating has been submitted successfully.';
            } else {
                $error_message = 'Error submitting feedback. Please try again.';
            }
        } else {
            $error_message = 'Please fill in all required fields.';
        }
    }

    if (isset($_POST['action']) && $_POST['action'] === 'submit_complaint') {
        $ride_id       = (int)($_POST['ride_id']    ?? 0);
        $driver_id     = (int)($_POST['driver_id']  ?? 0);
        $booking_id    = (int)($_POST['booking_id'] ?? 0);
        $report_type   = trim($_POST['report_type']   ?? '');
        $description   = trim($_POST['description']   ?? '');
        $evidence_note = trim($_POST['evidence_note'] ?? '');

        if ($ride_id && $driver_id && $report_type && $description) {
            $severity = 'Medium';
            $dl = strtolower($description);
            if (preg_match('/\b(unsafe|danger|accident|threat|harass|assault|emergency)\b/', $dl))  $severity = 'Critical';
            elseif (preg_match('/\b(rude|aggressive|speeding|reckless|refused|discriminat)\b/', $dl)) $severity = 'High';
            elseif (preg_match('/\b(minor|small|slight)\b/', $dl))                                    $severity = 'Low';

            $full_description = $description . ($evidence_note ? "\n\n[Evidence Note]: " . $evidence_note : '');

            $result = sb_post('core2_reports', [
                'customer_id' => (int)$customer_id,
                'driver_id'   => $driver_id,
                'ride_id'     => $ride_id,
                'booking_id'  => $booking_id ?: null,
                'report_type' => $report_type,
                'description' => $full_description,
                'severity'    => $severity,
                'status'      => 'Open',
            ]);
            if ($result) {
                $ticket_id       = 'TICKET-' . strtoupper(substr(md5(uniqid()), 0, 8));
                $success_message = "Complaint submitted successfully! Ticket ID: {$ticket_id}. Our team will review it within 24-48 hours.";
            } else {
                $error_message = 'Error submitting complaint. Please try again.';
            }
        } else {
            $error_message = 'Please fill in all required fields.';
        }
    }
}


$completed_trips = [];
$raw_rides = sb_get('core2_rides', [
    'customer_id' => 'eq.' . $customer_id,
    'ride_status' => 'eq.Completed',
    'select'      => 'ride_id,booking_id,driver_id,start_time,end_time,start_location,end_location',
    'order'       => 'end_time.desc',
    'limit'       => '20',
]);
foreach ($raw_rides as $r) {
    $b = sb_get('core2_bookings', ['booking_id' => 'eq.' . $r['booking_id'], 'select' => 'booking_reference,total_amount']);

    
    
    $driverRow = [];
    if (!empty($r['driver_id'])) {
        $driverRow = sb_get('core1_drivers', [
            'core2_driver_id' => 'eq.' . (int)$r['driver_id'],
            'select'          => 'id,driver_name,phone,license_number',
            'limit'           => '1',
        ]);
    }

    
    
    $fallbackCore2DriverId = null;
    if (empty($driverRow) && !empty($r['ride_id'])) {
        $c1Trip = sb_get('core1_trips', [
            'ride_id' => 'eq.' . (int)$r['ride_id'],
            'select'  => 'driver_id',
            'limit'   => '1',
        ]);
        if (!empty($c1Trip[0]['driver_id'])) {
            $driverRow = sb_get('core1_drivers', [
                'id'     => 'eq.' . (int)$c1Trip[0]['driver_id'],
                'select' => 'id,driver_name,phone,license_number,core2_driver_id',
                'limit'  => '1',
            ]);
            
            $fallbackCore2DriverId = $driverRow[0]['core2_driver_id'] ?? null;
        }
    }

    $has_fb = sb_get('core2_ratings', ['ride_id' => 'eq.' . $r['ride_id'], 'customer_id' => 'eq.' . $customer_id, 'select' => 'rating_id']);

    $completed_trips[] = array_merge($r, [
        'booking_reference' => $b[0]['booking_reference']     ?? '',
        'total_amount'      => $b[0]['total_amount']           ?? 0,
        'driver_name'       => $driverRow[0]['driver_name']    ?? 'Unknown Driver',
        'driver_phone'      => $driverRow[0]['phone']          ?? '',
        'license_number'    => $driverRow[0]['license_number'] ?? '',
        'plate_number'      => '',
        'make_model'        => '',
        
        'core1_driver_id'    => $driverRow[0]['id'] ?? null,
        
        
        'core2_driver_id_for_report' => !empty($r['driver_id']) ? (int)$r['driver_id'] : ($fallbackCore2DriverId ?? null),
        'has_feedback'       => !empty($has_fb) ? 1 : 0,
    ]);
}


$feedback_history = [];
$fb_rows = sb_get('core2_ratings', [
    'customer_id' => 'eq.' . $customer_id,
    'select'      => 'rating_id,rating_value,comment,created_at,ride_id,driver_id',
    'order'       => 'created_at.desc',
    'limit'       => '10',
]);
foreach ($fb_rows as $fb) {
    $r = sb_get('core2_rides',    ['ride_id'    => 'eq.' . $fb['ride_id'],    'select' => 'start_location,end_location,booking_id']);
    $b = !empty($r[0]['booking_id']) ? sb_get('core2_bookings', ['booking_id' => 'eq.' . $r[0]['booking_id'], 'select' => 'booking_reference']) : [];
    
    $d = !empty($fb['driver_id']) ? sb_get('core1_drivers', ['id' => 'eq.' . $fb['driver_id'], 'select' => 'driver_name']) : [];
    $feedback_history[] = array_merge($fb, [
        'start_location'    => $r[0]['start_location']    ?? '',
        'end_location'      => $r[0]['end_location']      ?? '',
        'booking_reference' => $b[0]['booking_reference'] ?? '',
        'driver_name'       => $d[0]['driver_name']       ?? 'Unknown Driver',
    ]);
}


$complaint_history = [];
$cp_rows = sb_get('core2_reports', [
    'customer_id' => 'eq.' . $customer_id,
    'select'      => 'report_id,report_type,description,severity,status,reported_at,resolved_at,ride_id,booking_id,driver_id',
    'order'       => 'reported_at.desc',
    'limit'       => '15',
]);
foreach ($cp_rows as $cp) {
    $b = !empty($cp['booking_id']) ? sb_get('core2_bookings', ['booking_id' => 'eq.' . $cp['booking_id'], 'select' => 'booking_reference']) : [];
    
    
    $d = !empty($cp['driver_id'])  ? sb_get('core1_drivers',  ['core2_driver_id' => 'eq.' . $cp['driver_id'], 'select' => 'driver_name']) : [];
    $complaint_history[] = array_merge($cp, [
        'booking_reference' => $b[0]['booking_reference'] ?? '',
        'driver_name'       => $d[0]['driver_name']       ?? 'Unknown Driver',
    ]);
}

$stats = [
    'total_feedback'     => count($feedback_history),
    'total_complaints'   => count($complaint_history),
    'pending_complaints' => 0,
    'avg_rating'         => 0,
];
foreach ($complaint_history as $c) {
    if (in_array($c['status'], ['Open', 'Under Review'])) $stats['pending_complaints']++;
}
if (!empty($feedback_history)) {
    $stats['avg_rating'] = round(array_sum(array_column($feedback_history, 'rating_value')) / count($feedback_history), 1);
}

$hr       = (int)(new DateTime('now', new DateTimeZone('Asia/Manila')))->format('H');
$greeting = $hr < 12 ? 'Good Morning' : ($hr < 18 ? 'Good Afternoon' : 'Good Evening');
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>EnviroCab – Feedback &amp; Reports</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root,
        [data-theme="light"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --card-bg:         #FFFFFF;
            --card-border:     #E2E8F0;
            --header-bg:       rgba(255,255,255,0.85);
            --header-border:   rgba(255,255,255,0.5);
            --text-dark:       #1A202C;
            --text-medium:     #4A5568;
            --text-light:      #718096;
            --input-bg:        #FAFAFA;
            --input-border:    #E2E8F0;
            --row-border:      rgba(0,0,0,0.04);
            --nav-bg:          rgba(255,255,255,0.95);
            --icon-btn-bg:     rgba(255,255,255,0.9);
            --icon-btn-border: rgba(0,0,0,0.05);
            --shadow-card:     0 2px 8px rgba(0,0,0,0.04);
            --shadow-hero:     0 8px 32px rgba(0,208,132,0.2);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.05);
            --overlay-bg:      rgba(0,0,0,0.45);
            --sheet-bg:        #FFFFFF;
            --cancel-btn-bg:   #F1F5F9;
            --cancel-btn-color:#4A5568;
            --stripe-bg:       rgba(0,0,0,0.02);
        }
        [data-theme="dark"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #0D1F1A 0%, #0F172A 100%);
            --card-bg:         #1A2820;
            --card-border:     #263330;
            --header-bg:       rgba(15,24,18,0.94);
            --header-border:   rgba(0,208,132,0.1);
            --text-dark:       #E8F5F1;
            --text-medium:     #9FC4AE;
            --text-light:      #607D6B;
            --input-bg:        #111E18;
            --input-border:    #263330;
            --row-border:      rgba(255,255,255,0.05);
            --nav-bg:          rgba(15,24,18,0.97);
            --icon-btn-bg:     rgba(255,255,255,0.06);
            --icon-btn-border: rgba(255,255,255,0.08);
            --shadow-card:     0 2px 12px rgba(0,0,0,0.35);
            --shadow-hero:     0 8px 40px rgba(0,208,132,0.12);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.5);
            --overlay-bg:      rgba(0,0,0,0.72);
            --sheet-bg:        #1A2820;
            --cancel-btn-bg:   #263330;
            --cancel-btn-color:#9FC4AE;
            --stripe-bg:       rgba(255,255,255,0.025);
        }

        *::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        *, *::before, *::after {
            transition: background-color .3s ease, border-color .25s ease, color .2s ease, box-shadow .3s ease;
        }
        input, button, svg, img, select, textarea { transition: none; }
        input:focus, select:focus, textarea:focus { transition: border-color .15s, box-shadow .15s; }
        .btn-primary, .btn-outline, .btn-danger, .icon-btn, .theme-btn, .nav-item, .tab-btn, .trip-card {
            transition: background .2s, transform .15s, opacity .2s, border-color .2s, box-shadow .2s !important;
        }
        .t-sun, .t-moon {
            transition: opacity .35s ease, transform .4s cubic-bezier(.34,1.56,.64,1) !important;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 100px;
            -webkit-font-smoothing: antialiased;
            transition:opacity .15s ease;
}

        
        .header {
            background: var(--header-bg);
            backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky; top: 0; z-index: 100;
            border-bottom: 1px solid var(--header-border);
        }
        .header-content { display:flex; justify-content:space-between; align-items:center; }
        .logo-img { height:28px; width:auto; }
        .header-right { display:flex; align-items:center; gap:10px; }

        .icon-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
        }
        .icon-btn svg { stroke:var(--text-medium); }
        .icon-btn:active { transform:scale(0.93); }
        .logout-btn { background:rgba(239,68,68,0.12) !important; border-color:rgba(239,68,68,0.2) !important; }
        .logout-btn svg { stroke:#EF4444 !important; }

        .theme-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
            position:relative; overflow:hidden;
        }
        .theme-btn:active { transform:scale(0.93); }
        .t-sun, .t-moon { position:absolute; }
        [data-theme="light"] .t-sun  { opacity:1; transform:rotate(0deg) scale(1); }
        [data-theme="light"] .t-moon { opacity:0; transform:rotate(90deg) scale(.6); }
        [data-theme="dark"]  .t-sun  { opacity:0; transform:rotate(-90deg) scale(.6); }
        [data-theme="dark"]  .t-moon { opacity:1; transform:rotate(0deg) scale(1); }

        
        .main-content { padding:20px; }

        
        .hero-card {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
            border-radius:24px; padding:28px 24px; color:white;
            margin-bottom:20px; box-shadow:var(--shadow-hero);
            position:relative; overflow:hidden;
        }
        .hero-card::before {
            content:''; position:absolute; top:-50%; right:-20%;
            width:200px; height:200px; background:rgba(255,255,255,0.1); border-radius:50%;
        }
        .hero-card::after {
            content:''; position:absolute; bottom:-30%; left:-10%;
            width:150px; height:150px; background:rgba(255,255,255,0.06); border-radius:50%;
        }
        .hero-greeting { font-size:14px; opacity:.9; margin-bottom:4px; position:relative; }
        .hero-title    { font-size:28px; font-weight:800; margin-bottom:8px; position:relative; }
        .hero-subtitle { font-size:14px; opacity:.9; position:relative; line-height:1.6; }
        .hero-stats    { display:flex; gap:12px; margin-top:24px; position:relative; }
        .hero-stat {
            flex:1; background:rgba(255,255,255,0.15);
            backdrop-filter:blur(10px); padding:12px; border-radius:16px; text-align:center;
        }
        .hero-stat-value { font-size:20px; font-weight:700; margin-bottom:4px; }
        .hero-stat-label { font-size:11px; opacity:.85; }

        
        .toast {
            border-radius:16px; padding:14px 18px; margin-bottom:16px;
            font-size:14px; font-weight:500; display:flex; align-items:center; gap:10px;
        }
        .toast.success { background:rgba(16,185,129,0.12); color:#065F46; border:1px solid rgba(16,185,129,0.25); }
        .toast.error   { background:rgba(239,68,68,0.10);  color:#991B1B; border:1px solid rgba(239,68,68,0.2); }
        [data-theme="dark"] .toast.success { color:#6EE7B7; }
        [data-theme="dark"] .toast.error   { color:#FCA5A5; }

        
        .tab-nav {
            display:flex; gap:8px; margin-bottom:20px;
            overflow-x:auto; scrollbar-width:none;
        }
        .tab-nav::-webkit-scrollbar { display:none; }
        .tab-btn {
            flex-shrink:0; padding:10px 18px;
            border-radius:50px; border:1.5px solid var(--card-border);
            background:var(--card-bg); color:var(--text-medium);
            font-size:13px; font-weight:600; cursor:pointer; font-family:inherit;
            white-space:nowrap;
        }
        .tab-btn.active {
            background:var(--primary-green); border-color:var(--primary-green); color:white;
        }
        .tab-btn:active { transform:scale(0.97); }

        
        .section-label {
            font-size:12px; font-weight:700; color:var(--text-light);
            text-transform:uppercase; letter-spacing:.08em; margin:24px 0 10px;
        }

        
        .trip-card {
            background:var(--card-bg); border-radius:20px;
            border:1px solid var(--card-border); box-shadow:var(--shadow-card);
            margin-bottom:12px; overflow:hidden;
        }
        .trip-card-header {
            display:flex; justify-content:space-between; align-items:flex-start;
            padding:16px 16px 0;
        }
        .trip-ref  { font-size:15px; font-weight:700; color:var(--text-dark); }
        .trip-date { font-size:12px; color:var(--text-light); margin-top:2px; }

        .trip-badge {
            font-size:11px; font-weight:700; padding:4px 10px; border-radius:20px;
            display:inline-flex; align-items:center; gap:4px; flex-shrink:0;
        }
        .badge-rated   { background:rgba(16,185,129,0.12);  color:#10B981; }
        .badge-pending { background:rgba(245,158,11,0.12);  color:#B45309; }
        [data-theme="dark"] .badge-rated   { background:rgba(16,185,129,0.2);  color:#34D399; }
        [data-theme="dark"] .badge-pending { background:rgba(245,158,11,0.2);  color:#FBBF24; }

        .trip-route {
            display:flex; align-items:center; gap:6px;
            padding:12px 16px;
        }
        .route-dot { width:8px; height:8px; border-radius:50%; flex-shrink:0; }
        .route-dot.pickup  { background:var(--primary-green); }
        .route-dot.dropoff { background:#EF4444; }
        .route-arrow {
            flex:1; height:1px; background:var(--card-border);
            position:relative; margin:0 4px;
        }
        .route-arrow::after {
            content:''; position:absolute; right:-1px; top:-3px;
            border:4px solid transparent; border-left:6px solid var(--card-border);
        }
        .route-location {
            font-size:12px; color:var(--text-medium); font-weight:500;
            max-width:40%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
        }

        .trip-meta {
            display:flex; gap:12px; padding:0 16px 12px; flex-wrap:wrap;
        }
        .trip-meta-item {
            display:flex; align-items:center; gap:5px;
            font-size:12px; color:var(--text-medium);
        }
        .trip-meta-item svg { stroke:var(--text-light); }

        .trip-actions {
            border-top:1px solid var(--card-border);
            padding:12px 16px; display:flex; gap:8px;
        }
        .btn-primary {
            flex:1; padding:11px;
            background:linear-gradient(135deg,var(--primary-green),var(--dark-green));
            color:white; border:none; border-radius:12px;
            font-size:13px; font-weight:700; cursor:pointer; font-family:inherit;
            display:flex; align-items:center; justify-content:center; gap:6px;
        }
        .btn-primary:active { transform:scale(0.98); opacity:.92; }
        .btn-danger {
            flex:1; padding:11px;
            background:rgba(239,68,68,0.08); color:#EF4444;
            border:1.5px solid rgba(239,68,68,0.2); border-radius:12px;
            font-size:13px; font-weight:700; cursor:pointer; font-family:inherit;
            display:flex; align-items:center; justify-content:center; gap:6px;
        }
        .btn-danger:active { transform:scale(0.98); }
        .btn-outline {
            flex:1; padding:11px;
            background:transparent; color:var(--text-medium);
            border:1.5px solid var(--card-border); border-radius:12px;
            font-size:13px; font-weight:700; cursor:pointer; font-family:inherit;
            display:flex; align-items:center; justify-content:center; gap:6px;
        }

        
        .history-card {
            background:var(--card-bg); border-radius:20px;
            border:1px solid var(--card-border); box-shadow:var(--shadow-card);
            padding:16px; margin-bottom:12px;
        }
        .history-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px; }
        .history-ref  { font-size:14px; font-weight:700; color:var(--text-dark); margin-bottom:3px; }
        .history-route{ font-size:12px; color:var(--text-light); }
        .history-rating {
            display:flex; align-items:center; gap:4px;
            font-size:18px; font-weight:700; color:#FBBF24; flex-shrink:0;
        }
        .history-comment {
            padding:12px; background:var(--stripe-bg); border-radius:12px;
            font-size:13px; color:var(--text-medium); line-height:1.6; margin-bottom:10px;
        }
        .history-meta {
            display:flex; gap:10px; font-size:11px; color:var(--text-light); flex-wrap:wrap;
            align-items:center;
        }
        .history-meta svg { display:inline; vertical-align:middle; stroke:var(--text-light); }

        
        .status-badge, .severity-badge {
            font-size:11px; font-weight:700; padding:4px 10px; border-radius:8px;
            display:inline-flex; align-items:center; gap:4px;
        }
        .status-open    { background:rgba(251,146,60,0.12); color:#FB923C; }
        .status-review  { background:rgba(96,165,250,0.15);  color:#3B82F6; }
        .status-resolved{ background:rgba(16,185,129,0.12);  color:#10B981; }
        .status-closed  { background:rgba(113,128,150,0.1);  color:#718096; }
        .severity-low     { background:rgba(96,165,250,0.15);  color:#3B82F6; }
        .severity-medium  { background:rgba(251,146,60,0.12);  color:#FB923C; }
        .severity-high    { background:rgba(239,68,68,0.12);   color:#EF4444; }
        .severity-critical{ background:rgba(220,38,38,0.15);   color:#DC2626; }

        
        .empty-state {
            text-align:center; padding:56px 20px;
            background:var(--card-bg); border-radius:20px;
            border:1px solid var(--card-border);
        }
        .empty-icon {
            width:72px; height:72px; margin:0 auto 16px;
            border-radius:20px; background:var(--stripe-bg);
            display:flex; align-items:center; justify-content:center;
        }
        .empty-title { font-size:17px; font-weight:700; color:var(--text-dark); margin-bottom:6px; }
        .empty-sub   { font-size:13px; color:var(--text-light); line-height:1.6; }

        
        .modal-overlay {
            display:none; position:fixed; inset:0;
            background:var(--overlay-bg);
            backdrop-filter:blur(5px); -webkit-backdrop-filter:blur(5px);
            z-index:200; align-items:flex-end; justify-content:center;
        }
        .modal-overlay.open { display:flex; }
        
        #complaintModal { align-items:center; padding:20px; }
        #complaintModal .modal-sheet {
            border-radius:24px;
            animation:fadeScaleIn .3s cubic-bezier(.34,1.56,.64,1);
        }
        @keyframes fadeScaleIn {
            from { opacity:0; transform:scale(.94); }
            to   { opacity:1; transform:scale(1); }
        }
        .modal-sheet {
            background:var(--sheet-bg); border-radius:28px 28px 0 0;
            width:100%; max-width:480px;
            animation:sheetUp .32s cubic-bezier(.34,1.56,.64,1);
            max-height:92vh; overflow-y:auto;
            scrollbar-width:none;
            -ms-overflow-style:none;
        }
        .modal-sheet::-webkit-scrollbar { display:none; }
        @keyframes sheetUp {
            from { transform:translateY(100%); opacity:0; }
            to   { transform:translateY(0);    opacity:1; }
        }
        .modal-handle { width:40px; height:4px; background:var(--card-border); border-radius:4px; margin:20px auto 0; }
        .modal-header {
            padding:16px 20px; display:flex; justify-content:space-between; align-items:center;
            border-bottom:1px solid var(--card-border);
        }
        .modal-title    { font-size:18px; font-weight:800; color:var(--text-dark); }
        .modal-close {
            width:32px; height:32px; border-radius:10px;
            background:var(--stripe-bg); border:none; cursor:pointer;
            display:flex; align-items:center; justify-content:center;
        }
        .modal-close svg { stroke:var(--text-medium); }
        .modal-body   { padding:20px; }
        .modal-footer { padding:0 20px 28px; display:flex; gap:10px; }
        .modal-footer .btn-primary, .modal-footer .btn-outline { margin-top:0; }

        
        .form-group { margin-bottom:18px; }
        .form-label {
            display:block; font-size:13px; font-weight:600; color:var(--text-dark); margin-bottom:8px;
        }
        .form-label .required { color:#EF4444; }
        .form-input, .form-select, .form-textarea {
            width:100%; padding:12px 14px;
            border-radius:12px; border:1.5px solid var(--input-border);
            background:var(--input-bg); font-size:14px; color:var(--text-dark);
            font-family:inherit; outline:none;
        }
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            border-color:var(--primary-green); box-shadow:0 0 0 3px rgba(0,208,132,0.12);
            background:var(--card-bg);
        }
        .form-textarea { min-height:120px; resize:vertical; }
        .form-help { font-size:12px; color:var(--text-light); margin-top:6px; }

        .trip-info-box {
            padding:12px; background:var(--stripe-bg);
            border:1px solid var(--card-border); border-radius:12px;
            margin-bottom:18px; font-size:13px; color:var(--text-medium); line-height:1.6;
        }
        .complaint-info-box {
            padding:12px; background:rgba(239,68,68,0.05);
            border:1px solid rgba(239,68,68,0.2); border-radius:12px;
            margin-bottom:18px; font-size:13px; color:var(--text-medium); line-height:1.6;
        }
        .ai-notice {
            padding:12px; background:rgba(96,165,250,0.08);
            border:1px solid rgba(96,165,250,0.2); border-radius:12px;
            font-size:12px; color:var(--text-medium); margin-top:4px;
            display:flex; align-items:flex-start; gap:8px;
        }
        .ai-notice svg { stroke:#60A5FA; flex-shrink:0; margin-top:1px; }

        
        .issue-type-grid {
            display:grid; grid-template-columns:1fr 1fr; gap:8px;
        }
        .issue-type-btn {
            display:flex; align-items:center; gap:8px;
            padding:10px 12px; border-radius:12px;
            border:1.5px solid var(--input-border);
            background:var(--input-bg); color:var(--text-medium);
            font-size:12px; font-weight:600; cursor:pointer;
            font-family:inherit; text-align:left;
            transition:border-color .15s, background .15s, color .15s !important;
        }
        .issue-type-btn svg { stroke:var(--text-light); flex-shrink:0; }
        .issue-type-btn:active { transform:scale(.97); }
        .issue-type-btn.selected {
            border-color:#EF4444; background:rgba(239,68,68,0.07);
            color:#EF4444;
        }
        .issue-type-btn.selected svg { stroke:#EF4444; }

        
        .star-rating {
            display:flex; flex-direction:row-reverse; justify-content:flex-end;
            gap:8px; margin-bottom:8px;
        }
        .star-rating input { display:none; }
        .star-rating label {
            font-size:36px; color:var(--input-border); cursor:pointer;
        }
        .star-rating input:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label { color:#FBBF24; }

        
        .detail-rating { display:flex; align-items:center; gap:12px; margin-bottom:14px; }
        .detail-rating-label { flex:1; font-size:13px; font-weight:600; color:var(--text-medium); }
        .detail-rating-value { font-size:15px; font-weight:700; color:var(--primary-green); min-width:36px; text-align:center; }
        .detail-rating input[type="range"] {
            flex:2; height:6px; border-radius:3px;
            background:var(--input-border); outline:none; -webkit-appearance:none; appearance:none;
        }
        .detail-rating input[type="range"]::-webkit-slider-thumb {
            -webkit-appearance:none; width:20px; height:20px;
            border-radius:50%; background:var(--primary-green); cursor:pointer;
        }
        .detail-rating input[type="range"]::-moz-range-thumb {
            width:20px; height:20px; border-radius:50%;
            background:var(--primary-green); cursor:pointer; border:none;
        }

        
        .bottom-nav {
            position:fixed; bottom:0; left:0; right:0;
            background:var(--nav-bg);
            backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
            border-top:1px solid var(--card-border);
            padding:12px 0 20px;
            display:grid; grid-template-columns:repeat(4,1fr);
            z-index:99; box-shadow:var(--shadow-nav);
        }
        .nav-item {
            display:flex; flex-direction:column; align-items:center; gap:4px;
            padding:8px; cursor:pointer; border:none; background:none;
        }
        .nav-item:active { transform:scale(0.95); }
        .nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
        .nav-icon svg { stroke:var(--text-light); opacity:.5; }
        .nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
        .nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:.7; }
        .nav-item.active .nav-label { color:var(--primary-green); opacity:1; }

        @media (min-width:768px) {
            body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,0.12); }
            .bottom-nav { max-width:480px; left:50%; transform:translateX(-50%); }
        }
        @keyframes slideUp {
            from { opacity:0; transform:translateY(20px); }
            to   { opacity:1; transform:translateY(0); }
        }
        .hero-card, .trip-card, .history-card { animation:slideUp .4s ease forwards; }
    
    
    .notif-panel-wrap{position:relative;}
    .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:310px;max-height:400px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.15);z-index:999;display:none;flex-direction:column;overflow:hidden;}
    .notif-panel.open{display:flex;}
    .notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);flex-shrink:0;}
    .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
    .notif-mark-read{font-size:11px;font-weight:600;color:var(--dark-green);background:none;border:none;cursor:pointer;padding:0;}
    .notif-list{overflow-y:auto;flex:1;padding:4px 0;}
    .notif-item{display:flex;align-items:flex-start;gap:10px;padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--row-border);transition:background .15s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,208,132,0.06);}
    .notif-item.unread{background:rgba(0,208,132,0.04);}
    .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
    .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
    .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
    .notif-item-body{flex:1;min-width:0;}
    .notif-item-title{font-size:12px;font-weight:700;color:var(--text-dark);margin-bottom:2px;}
    .notif-item-sub{font-size:11px;color:var(--text-light);line-height:1.4;}
    .notif-item-time{font-size:10px;color:var(--text-light);margin-top:3px;}
    .notif-empty{padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;}
    .notif-spinner{width:20px;height:20px;border:2px solid var(--card-border);border-top-color:#00D084;border-radius:50%;animation:nspin .7s linear infinite;margin:16px auto;}
    @keyframes nspin{to{transform:rotate(360deg);}}
    .notif-count-badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 3px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:9px;font-weight:800;color:#fff;display:none;align-items:center;justify-content:center;line-height:1;}
    
    .logout-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center;padding:24px;}
    .logout-overlay.open{display:flex;}
    .logout-modal{background:var(--card-bg);border-radius:24px;padding:28px 24px 24px;width:100%;max-width:320px;box-shadow:0 16px 48px rgba(0,0,0,0.18);animation:lmodalIn .25s cubic-bezier(.34,1.56,.64,1);}
    @keyframes lmodalIn{from{transform:scale(.88);opacity:0;}to{transform:scale(1);opacity:1;}}
    .logout-modal-icon{width:52px;height:52px;border-radius:16px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
    .logout-modal-title{font-size:17px;font-weight:800;color:var(--text-dark);text-align:center;margin-bottom:6px;}
    .logout-modal-sub{font-size:13px;color:var(--text-light);text-align:center;line-height:1.5;margin-bottom:22px;}
    .logout-modal-btns{display:flex;gap:10px;}
    .logout-cancel-btn{flex:1;padding:13px;border-radius:14px;background:var(--input-bg);border:1px solid var(--card-border);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;}
    .logout-confirm-btn{flex:1;padding:13px;border-radius:14px;background:#EF4444;border:none;font-size:14px;font-weight:700;color:#fff;cursor:pointer;}
</style>
</head>
<body>

<script>
(function(){
    var t = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', t);
})();
</script>

<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img"
             onerror="this.style.display='none'">
                        <div class="header-right">
            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            </button>
            <button class="icon-btn" onclick="window.location.href='dashboard.php'" title="Home">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </button>
            <div class="notif-panel-wrap">
            <button class="icon-btn" id="notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications" style="position:relative;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <span class="notif-count-badge" id="notif-count-badge"></span>
            </button>
            <div class="notif-panel" id="notif-panel">
                <div class="notif-panel-head">
                    <span class="notif-panel-title">Notifications</span>
                    <button class="notif-mark-read" onclick="markAllRead()">Mark all read</button>
                </div>
                <div class="notif-list" id="notif-list"><div class="notif-spinner"></div></div>
            </div>
        </div>
            <button class="icon-btn logout-btn" onclick="openLogout()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

    <div class="hero-card">
        <div class="hero-greeting"><?php echo $greeting; ?>, <?php echo htmlspecialchars($_SESSION['name'] ?? $_SESSION['username'] ?? ''); ?>!</div>
        <div class="hero-title">Share Your Experience</div>
        <div class="hero-subtitle">Your feedback helps us improve our service and maintain high standards for all passengers.</div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-value"><?php echo $stats['total_feedback']; ?></div>
                <div class="hero-stat-label">Feedback</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?php echo $stats['total_complaints']; ?></div>
                <div class="hero-stat-label">Reports</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value">
                    <?php echo $stats['avg_rating']; ?>
                    <svg style="display:inline-block;vertical-align:middle;" width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                </div>
                <div class="hero-stat-label">Avg Rating</div>
            </div>
        </div>
    </div>

    <?php if ($success_message): ?>
    <div class="toast success">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
        </svg>
        <?php echo htmlspecialchars($success_message); ?>
    </div>
    <?php endif; ?>
    <?php if ($error_message): ?>
    <div class="toast error">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
    <?php endif; ?>

    <div class="tab-nav">
        <button class="tab-btn <?php echo $view_mode === 'submit' ? 'active' : ''; ?>"
                onclick="window.location.href='?view=submit'">
            Submit Feedback
        </button>
        <button class="tab-btn <?php echo $view_mode === 'history' ? 'active' : ''; ?>"
                onclick="window.location.href='?view=history'">
            My Feedback
        </button>
        <button class="tab-btn <?php echo $view_mode === 'complaints' ? 'active' : ''; ?>"
                onclick="window.location.href='?view=complaints'">
            My Reports (<?php echo $stats['pending_complaints']; ?>)
        </button>
    </div>

    <?php if ($view_mode === 'submit'): ?>
        <?php if (!empty($completed_trips)): ?>
            <?php foreach ($completed_trips as $index => $trip):
                $has_feedback = (bool)$trip['has_feedback'];
                $from = trim(explode(',', $trip['start_location'])[0] ?? $trip['start_location']);
                $to   = trim(explode(',', $trip['end_location'])[0]   ?? $trip['end_location']);
            ?>
            <div class="trip-card" style="animation-delay:<?php echo $index * 0.05; ?>s">
                <div class="trip-card-header">
                    <div>
                        <div class="trip-ref"><?php echo htmlspecialchars($trip['booking_reference']); ?></div>
                        <div class="trip-date"><?php echo (new DateTime($trip['start_time'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M d, Y g:i A'); ?></div>
                    </div>
                    <span class="trip-badge <?php echo $has_feedback ? 'badge-rated' : 'badge-pending'; ?>">
                        <svg width="7" height="7" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
                        <?php echo $has_feedback ? 'Rated' : 'Awaiting'; ?>
                    </span>
                </div>

                <div class="trip-route">
                    <div class="route-dot pickup"></div>
                    <div class="route-location"><?php echo htmlspecialchars($from); ?></div>
                    <div class="route-arrow"></div>
                    <div class="route-location" style="text-align:right"><?php echo htmlspecialchars($to); ?></div>
                    <div class="route-dot dropoff"></div>
                </div>

                <div class="trip-meta">
                    <div class="trip-meta-item">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        <?php echo htmlspecialchars($trip['driver_name'] ?? 'N/A'); ?>
                    </div>
                    <div class="trip-meta-item">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke-width="2"><line x1="12" y1="2" x2="12" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7H17"/><line x1="8" y1="9" x2="18" y2="9"/><line x1="8" y1="12" x2="18" y2="12"/></svg>
                        ₱<?php echo number_format($trip['total_amount'], 2); ?>
                    </div>
                </div>

                <div class="trip-actions">
                    <?php if (!$has_feedback): ?>
                    <button class="btn-primary"
                            onclick="openFeedbackModal(<?php echo htmlspecialchars(json_encode($trip), ENT_QUOTES); ?>)">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                        Rate Trip
                    </button>
                    <?php endif; ?>
                    <button class="btn-danger"
                            onclick="openComplaintModal(<?php echo htmlspecialchars(json_encode($trip), ENT_QUOTES); ?>)">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        Report Issue
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
        <div class="empty-state">
            <div class="empty-icon">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="1.5">
                    <rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/>
                    <circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>
                </svg>
            </div>
            <div class="empty-title">No Completed Trips Yet</div>
            <div class="empty-sub">Complete your first trip to submit feedback and help us improve!</div>
        </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($view_mode === 'history'): ?>
        <?php if (!empty($feedback_history)): ?>
            <?php foreach ($feedback_history as $index => $feedback):
                $from = trim(explode(',', $feedback['start_location'])[0] ?? '');
                $to   = trim(explode(',', $feedback['end_location'])[0]   ?? '');
            ?>
            <div class="history-card" style="animation-delay:<?php echo $index * 0.05; ?>s">
                <div class="history-header">
                    <div>
                        <div class="history-ref"><?php echo htmlspecialchars($feedback['booking_reference']); ?></div>
                        <div class="history-route"><?php echo htmlspecialchars($from); ?> → <?php echo htmlspecialchars($to); ?></div>
                    </div>
                    <div class="history-rating">
                        <?php echo $feedback['rating_value']; ?>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                    </div>
                </div>
                <?php if ($feedback['comment']): ?>
                <div class="history-comment">"<?php echo htmlspecialchars($feedback['comment']); ?>"</div>
                <?php endif; ?>
                <div class="history-meta">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <?php echo htmlspecialchars($feedback['driver_name'] ?? 'N/A'); ?>
                    <span>•</span>
                    <span><?php echo (new DateTime($feedback['created_at'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M d, Y'); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
        <div class="empty-state">
            <div class="empty-icon">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="1.5">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
            </div>
            <div class="empty-title">No Feedback Submitted</div>
            <div class="empty-sub">Your feedback history will appear here after you rate your trips.</div>
        </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($view_mode === 'complaints'): ?>
        <?php if (!empty($complaint_history)): ?>
            <?php foreach ($complaint_history as $index => $complaint):
                $sc = 'status-' . strtolower(str_replace(' ', '-', $complaint['status']));
                if ($complaint['status'] === 'Under Review') $sc = 'status-review';
                $svc = 'severity-' . strtolower($complaint['severity']);
            ?>
            <div class="history-card" style="animation-delay:<?php echo $index * 0.05; ?>s">
                <div class="history-header">
                    <div>
                        <div class="history-ref"><?php echo htmlspecialchars($complaint['booking_reference']); ?></div>
                        <div class="history-route"><?php echo htmlspecialchars($complaint['report_type']); ?></div>
                    </div>
                    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:5px;">
                        <span class="status-badge <?php echo $sc; ?>">
                            <svg width="7" height="7" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
                            <?php echo $complaint['status']; ?>
                        </span>
                        <span class="severity-badge <?php echo $svc; ?>"><?php echo $complaint['severity']; ?></span>
                    </div>
                </div>
                <div class="history-comment">
                    <?php echo htmlspecialchars(substr($complaint['description'], 0, 150)); ?>
                    <?php echo strlen($complaint['description']) > 150 ? '...' : ''; ?>
                </div>
                <div class="history-meta">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <?php echo htmlspecialchars($complaint['driver_name'] ?? 'N/A'); ?>
                    <span>•</span>
                    <span><?php echo (new DateTime($complaint['reported_at'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M d, Y'); ?></span>
                    <?php if ($complaint['resolved_at']): ?>
                    <span>•</span>
                    <span>Resolved: <?php echo (new DateTime($complaint['resolved_at'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M d'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
        <div class="empty-state">
            <div class="empty-icon">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="1.5">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
            </div>
            <div class="empty-title">No Reports Submitted</div>
            <div class="empty-sub">Haven't found any issues? That's great! Your reports will appear here if needed.</div>
        </div>
        <?php endif; ?>
    <?php endif; ?>

</div>

<div class="modal-overlay" id="feedbackModal">
    <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="modal-header">
            <div class="modal-title">Rate Your Trip</div>
            <button class="modal-close" onclick="closeFeedbackModal()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        </div>
        <form id="feedbackForm" method="POST">
            <input type="hidden" name="action" value="submit_feedback">
            <input type="hidden" name="ride_id" id="feedback_ride_id">
            <input type="hidden" name="driver_id" id="feedback_driver_id">
            <input type="hidden" name="rating_value" id="rating_value">
            <div class="modal-body">
                <div class="trip-info-box" id="tripInfoDisplay"></div>

                <div class="form-group">
                    <label class="form-label">Overall Rating <span class="required">*</span></label>
                    <div class="star-rating" id="starRating">
                        <input type="radio" name="star" id="star5" value="5"><label for="star5">★</label>
                        <input type="radio" name="star" id="star4" value="4"><label for="star4">★</label>
                        <input type="radio" name="star" id="star3" value="3"><label for="star3">★</label>
                        <input type="radio" name="star" id="star2" value="2"><label for="star2">★</label>
                        <input type="radio" name="star" id="star1" value="1"><label for="star1">★</label>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Detailed Ratings</label>
                    <div class="detail-rating">
                        <div class="detail-rating-label">Driver Behavior</div>
                        <input type="range" name="driver_behavior" min="1" max="5" value="5"
                               oninput="this.nextElementSibling.textContent=this.value+'/5'">
                        <div class="detail-rating-value">5/5</div>
                    </div>
                    <div class="detail-rating">
                        <div class="detail-rating-label">Vehicle Cleanliness</div>
                        <input type="range" name="vehicle_cleanliness" min="1" max="5" value="5"
                               oninput="this.nextElementSibling.textContent=this.value+'/5'">
                        <div class="detail-rating-value">5/5</div>
                    </div>
                    <div class="detail-rating">
                        <div class="detail-rating-label">Ride Comfort</div>
                        <input type="range" name="ride_comfort" min="1" max="5" value="5"
                               oninput="this.nextElementSibling.textContent=this.value+'/5'">
                        <div class="detail-rating-value">5/5</div>
                    </div>
                    <div class="detail-rating">
                        <div class="detail-rating-label">Punctuality</div>
                        <input type="range" name="punctuality" min="1" max="5" value="5"
                               oninput="this.nextElementSibling.textContent=this.value+'/5'">
                        <div class="detail-rating-value">5/5</div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Comments (Optional)</label>
                    <textarea name="comment" class="form-textarea"
                              placeholder="Share your experience with this trip..."></textarea>
                    <div class="form-help">Your feedback helps us improve our service.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-outline" onclick="closeFeedbackModal()">Cancel</button>
                <button type="submit" class="btn-primary">Submit Rating</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="complaintModal">
    <div class="modal-sheet">
        <div class="modal-header">
            <div class="modal-title">Report an Issue</div>
            <button class="modal-close" onclick="closeComplaintModal()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        </div>
        <form id="complaintForm" method="POST">
            <input type="hidden" name="action" value="submit_complaint">
            <input type="hidden" name="ride_id" id="complaint_ride_id">
            <input type="hidden" name="driver_id" id="complaint_driver_id">
            <input type="hidden" name="booking_id" id="complaint_booking_id">
            <div class="modal-body">
                <div class="complaint-info-box" id="complaintTripInfoDisplay"></div>

                <div class="form-group">
                    <label class="form-label">Issue Type <span class="required">*</span></label>
                    <div class="issue-type-grid" id="issueTypeGrid">
                        <input type="hidden" name="report_type" id="report_type_input" required>
                        <button type="button" class="issue-type-btn" data-value="Safety Concern" onclick="selectIssueType(this)">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                            <span>Safety Concern</span>
                        </button>
                        <button type="button" class="issue-type-btn" data-value="Driver Behavior" onclick="selectIssueType(this)">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            <span>Driver Behavior</span>
                        </button>
                        <button type="button" class="issue-type-btn" data-value="Vehicle Issue" onclick="selectIssueType(this)">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
                            <span>Vehicle Issue</span>
                        </button>
                        <button type="button" class="issue-type-btn" data-value="Poor Service" onclick="selectIssueType(this)">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>Poor Service</span>
                        </button>
                        <button type="button" class="issue-type-btn" data-value="Payment Issue" onclick="selectIssueType(this)">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                            <span>Payment Issue</span>
                        </button>
                        <button type="button" class="issue-type-btn" data-value="Other" onclick="selectIssueType(this)">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                            <span>Other</span>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Describe the Issue <span class="required">*</span></label>
                    <textarea name="description" class="form-textarea"
                              placeholder="Please provide details about the issue you experienced..."
                              required></textarea>
                    <div class="form-help">Be as specific as possible. This helps us investigate and resolve the issue faster.</div>
                </div>

                <div class="form-group">
                    <label class="form-label">Additional Evidence (Optional)</label>
                    <textarea name="evidence_note" class="form-textarea" style="min-height:80px;"
                              placeholder="Add any additional details, timestamps, or evidence notes..."></textarea>
                    <div class="form-help">Note: File upload feature coming soon. For now, please describe any evidence.</div>
                </div>

                <div class="ai-notice">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:1px;"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                    <span><strong>AI Classification:</strong> Your report will be automatically classified and prioritized based on urgency. Critical issues are escalated immediately to our safety team.</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-outline" onclick="closeComplaintModal()">Cancel</button>
                <button type="submit" class="btn-danger" style="border-radius:12px;font-family:inherit;font-weight:700;padding:11px;">Submit Report</button>
            </div>
        </form>
    </div>
</div>

<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_profile.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_profile.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div>
        <span class="nav-label">Home</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div>
        <span class="nav-label">Book</span>
    </button>
    <button class="nav-item" onclick="window.location.href='passenger_trips.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
        <span class="nav-label">Trips</span>
    </button>
    <button class="nav-item active" onclick="window.location.href='passenger_feedback.php'">
        <div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
        <span class="nav-label">Feedback</span>
    </button>
</div>

<script>
function toggleTheme() {
    var html = document.documentElement;
    var next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('envirocab_theme', next);
}

function openFeedbackModal(trip) {
    if (typeof trip === 'string') trip = JSON.parse(trip);
    document.getElementById('feedback_ride_id').value  = trip.ride_id;
    document.getElementById('feedback_driver_id').value = trip.core1_driver_id || trip.driver_id; 

    var from = trip.start_location.split(',')[0].trim();
    var to   = trip.end_location.split(',')[0].trim();
    document.getElementById('tripInfoDisplay').innerHTML =
        '<strong>' + esc(trip.booking_reference) + '</strong><br>' +
        esc(from) + ' → ' + esc(to) + '<br>' +
        'Driver: ' + esc(trip.driver_name || 'N/A') + ' · ₱' + parseFloat(trip.total_amount).toFixed(2);

    document.getElementById('feedbackForm').reset();
    document.querySelectorAll('.detail-rating-value').forEach(function(el){ el.textContent = '5/5'; });
    document.getElementById('feedbackModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeFeedbackModal() {
    document.getElementById('feedbackModal').classList.remove('open');
    document.body.style.overflow = '';
}

function selectIssueType(btn) {
    document.querySelectorAll('.issue-type-btn').forEach(function(b){ b.classList.remove('selected'); });
    btn.classList.add('selected');
    document.getElementById('report_type_input').value = btn.getAttribute('data-value');
}

function openComplaintModal(trip) {
    if (typeof trip === 'string') trip = JSON.parse(trip);
    document.getElementById('complaint_ride_id').value  = trip.ride_id;
    document.getElementById('complaint_driver_id').value = trip.core2_driver_id_for_report || trip.driver_id;
    document.getElementById('complaint_booking_id').value = trip.booking_id;

    var from = trip.start_location.split(',')[0].trim();
    var to   = trip.end_location.split(',')[0].trim();
    document.getElementById('complaintTripInfoDisplay').innerHTML =
        '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">' +
        '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>' +
        '<strong>Reporting Issue for Trip</strong></div>' +
        esc(trip.booking_reference) + ' · ' + esc(from) + ' → ' + esc(to) + '<br>' +
        'Driver: ' + esc(trip.driver_name || 'N/A');

    document.getElementById('complaintForm').reset();
    document.getElementById('report_type_input').value = '';
    document.querySelectorAll('.issue-type-btn').forEach(function(b){ b.classList.remove('selected'); });
    document.getElementById('complaintModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeComplaintModal() {
    document.getElementById('complaintModal').classList.remove('open');
    document.body.style.overflow = '';
}

document.querySelectorAll('#starRating input').forEach(function(input) {
    input.addEventListener('change', function() {
        document.getElementById('rating_value').value = this.value;
    });
});

document.getElementById('feedbackForm').addEventListener('submit', function(e) {
    if (!document.getElementById('rating_value').value) {
        e.preventDefault();
        alert('Please select a star rating before submitting.');
    }
});

document.getElementById('complaintForm').addEventListener('submit', function(e) {
    if (!document.getElementById('report_type_input').value) {
        e.preventDefault();
        document.getElementById('issueTypeGrid').style.outline = '2px solid #EF4444';
        document.getElementById('issueTypeGrid').style.borderRadius = '12px';
        setTimeout(function(){ document.getElementById('issueTypeGrid').style.outline = ''; }, 2000);
    }
});

document.getElementById('feedbackModal').addEventListener('click', function(e) {
    if (e.target === this) closeFeedbackModal();
});
document.getElementById('complaintModal').addEventListener('click', function(e) {
    if (e.target === this) closeComplaintModal();
});

function esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
</script>
<script>
const CUSTOMER_ID = <?= (int)$customer_id ?>;

const SB_URL = 'https://kyhndwabhbkduoaxeunq.supabase.co';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
let _notifOpen = false, _notifData = [], _notifTimer = null;
let _seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');

const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};

function toggleNotifPanel(e) {
    e.stopPropagation();
    _notifOpen = !_notifOpen;
    document.getElementById('notif-panel').classList.toggle('open', _notifOpen);
    if (_notifOpen) { fetchNotifs(); _notifTimer = setInterval(fetchNotifs, 8000); }
    else clearInterval(_notifTimer);
}

async function fetchNotifs() {
    try {
        const r = await fetch(SB_URL + '/rest/v1/core2_bookings?customer_id=eq.' + CUSTOMER_ID +
            '&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=15',
            {headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        _notifData = await r.json();
        renderNotifs();
        updateBadge();
    } catch(e) {}
}

function renderNotifs() {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!_notifData.length) { list.innerHTML = '<div class="notif-empty">No notifications yet.</div>'; return; }
    list.innerHTML = _notifData.map(b => {
        const cfg = STATUS_CFG[b.booking_status] || {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key = b.booking_id + '_' + b.booking_status;
        const unread = !_seen.includes(key);
        const amt = '\u20B1' + parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t = timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
}

function updateBadge() {
    const cnt = _notifData.filter(b => !_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    const el = document.getElementById('notif-count-badge');
    if (!el) return;
    if (cnt > 0) { el.textContent = cnt > 9 ? '9+' : cnt; el.style.display = 'flex'; }
    else el.style.display = 'none';
}

function goNotif(page, bid, key) {
    if (!_seen.includes(key)) { _seen.push(key); localStorage.setItem(SEEN_KEY, JSON.stringify(_seen)); }
    window.location.href = page + '?booking_id=' + bid;
}

function markAllRead() {
    _seen = _notifData.map(b => b.booking_id+'_'+b.booking_status);
    localStorage.setItem(SEEN_KEY, JSON.stringify(_seen));
    renderNotifs(); updateBadge();
}

function timeAgo(iso) {
    if (!iso) return '';
    const s = Math.floor((Date.now() - new Date(iso))/1000);
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s/60)+'m ago';
    if (s < 86400) return Math.floor(s/3600)+'h ago';
    return Math.floor(s/86400)+'d ago';
}

function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function openLogout() { document.getElementById('logout-overlay').classList.add('open'); }

document.addEventListener('click', function(e) {
    const panel = document.getElementById('notif-panel');
    const btn   = document.getElementById('notif-bell-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        _notifOpen = false; panel.classList.remove('open'); clearInterval(_notifTimer);
    }
});

document.addEventListener('DOMContentLoaded', () => { if (CUSTOMER_ID) fetchNotifs(); });
</script>


<div class="logout-overlay" id="logout-overlay" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="logout-modal">
        <div class="logout-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </div>
        <div class="logout-modal-title">Log out?</div>
        <div class="logout-modal-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-modal-btns">
            <button class="logout-cancel-btn" onclick="document.getElementById('logout-overlay').classList.remove('open')">Cancel</button>
            <button class="logout-confirm-btn" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{ once:true });
      a.addEventListener('touchstart',function(){ prerender(href); },{ once:true, passive:true });
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{ once:true });
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
</body>
</html>