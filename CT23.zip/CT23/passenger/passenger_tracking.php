<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['customer_id'])) {
    header('Location: ../auth/passenger_login.php');
    exit;
}

define('SUPABASE_URL', 'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

function supabase_get(string $table, array $params = []): array {
    $url  = SUPABASE_URL . '/rest/v1/' . $table;
    if (!empty($params)) {
        $url .= '?' . http_build_query($params);
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '        . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Accept: application/json',
        ],
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || $response === false) {
        error_log("Supabase GET /{$table} failed (HTTP {$httpCode}): {$response}");
        return [];
    }
    return json_decode($response, true) ?? [];
}

$customer_id      = $_SESSION['customer_id'];
$selected_ride_id = isset($_GET['ride_id']) ? (int)$_GET['ride_id'] : 0;

$rides_raw = supabase_get('core2_rides', [
    'select'      => 'ride_id,booking_id,start_time,end_time,start_location,end_location,ride_status,created_at,driver_id',
    'customer_id' => 'eq.' . $customer_id,   
    'order'       => 'created_at.desc',
]);

$booking_ids    = array_filter(array_unique(array_column($rides_raw, 'booking_id')));
$core2_driver_ids = array_filter(array_unique(array_column($rides_raw, 'driver_id')));


$bookings_map = [];
$fares_map    = [];
if (!empty($booking_ids)) {
    $bids = implode(',', $booking_ids);
    foreach (supabase_get('core2_bookings', [
        'select'      => 'booking_id,booking_reference,booking_status,total_amount,payment_status',
        'booking_id'  => 'in.(' . $bids . ')',
        'customer_id' => 'eq.' . $customer_id,   
    ]) as $b) {
        $bookings_map[$b['booking_id']] = $b;
    }
    foreach (supabase_get('core2_fare_computation', [
        'select'     => 'booking_id,distance_km,base_fare,total_fare',
        'booking_id' => 'in.(' . $bids . ')',
    ]) as $f) {
        $fares_map[$f['booking_id']] = $f;
    }
}



$drivers_map = [];   
if (!empty($core2_driver_ids)) {
    $dids = implode(',', $core2_driver_ids);
    foreach (supabase_get('core1_drivers', [
        'select'          => 'id,driver_name,phone,current_lat,current_lng,core2_driver_id,status',
        'core2_driver_id' => 'in.(' . $dids . ')',
    ]) as $d) {
        $key = (string)($d['core2_driver_id'] ?? $d['id']);
        $drivers_map[$key] = $d;
    }
}


$ride_ids_raw = array_filter(array_unique(array_column($rides_raw, 'ride_id')));
$completed_ride_ids = [];
if (!empty($ride_ids_raw)) {
    $rids = implode(',', $ride_ids_raw);
    foreach (supabase_get('core1_trips', [
        'select'  => 'ride_id,status',
        'ride_id' => 'in.(' . $rids . ')',
        'status'  => 'eq.COMPLETED',
    ]) as $t) {
        $completed_ride_ids[(int)$t['ride_id']] = true;
    }
}

$all_rides = [];
foreach ($rides_raw as $r) {
    $bid    = $r['booking_id'] ?? null;
    $c2did  = (string)($r['driver_id'] ?? '');
    $booking = $bid ? ($bookings_map[$bid] ?? []) : [];
    $fare    = $bid ? ($fares_map[$bid]    ?? []) : [];;
    $driver  = $c2did !== '' ? ($drivers_map[$c2did] ?? []) : [];

    
    
    $rideStatus = $r['ride_status'];
    if ($rideStatus !== 'Completed' && $rideStatus !== 'Cancelled') {

        
        if (isset($completed_ride_ids[(int)$r['ride_id']])) {
            $rideStatus = 'Completed';
        }
        
        

        
        
        if ($rideStatus !== 'Completed' && $c2did !== '' && isset($drivers_map[$c2did])) {
            $driverStatus = strtolower($drivers_map[$c2did]['status'] ?? '');
            
            $driverOnTrip = in_array($driverStatus, [
                'in progress','in_progress','on_trip','in_trip','busy','driving','on trip','in trip'
            ]);
            if ($driverOnTrip) {
                $rideStatus = 'In Progress';
            }
        }

        
        if ($rideStatus === 'Completed') {
            if (!empty($r['ride_id']) && ($r['ride_status'] ?? '') !== 'Completed') {
                supabase_get('core2_rides', []); 
                $pUrl = SUPABASE_URL . '/rest/v1/core2_rides?ride_id=eq.' . (int)$r['ride_id'];
                $pch  = curl_init($pUrl);
                curl_setopt_array($pch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => 'PATCH',
                    CURLOPT_POSTFIELDS     => json_encode(['ride_status' => 'Completed', 'end_time' => date('c')]),
                    CURLOPT_HTTPHEADER     => ['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json'],
                ]);
                curl_exec($pch); curl_close($pch);
            }
            if ($bid && ($booking['booking_status'] ?? '') !== 'Completed') {
                $pUrl = SUPABASE_URL . '/rest/v1/core2_bookings?booking_id=eq.' . (int)$bid;
                $pch  = curl_init($pUrl);
                curl_setopt_array($pch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => 'PATCH',
                    CURLOPT_POSTFIELDS     => json_encode(['booking_status' => 'Completed', 'payment_status' => 'Paid', 'updated_at' => date('c')]),
                    CURLOPT_HTTPHEADER     => ['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json'],
                ]);
                curl_exec($pch); curl_close($pch);
                
                if (isset($bookings_map[$bid])) {
                    $bookings_map[$bid]['booking_status'] = 'Completed';
                    $bookings_map[$bid]['payment_status'] = 'Paid';
                    $booking = $bookings_map[$bid];
                }
                
                $paUrl = SUPABASE_URL . '/rest/v1/core2_payment_authorization?booking_id=eq.' . (int)$bid;
                $pach  = curl_init($paUrl);
                curl_setopt_array($pach, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => 'PATCH',
                    CURLOPT_POSTFIELDS     => json_encode(['payment_status' => 'Captured']),
                    CURLOPT_HTTPHEADER     => ['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json'],
                ]);
                curl_exec($pach); curl_close($pach);
            }
        }
        
        if ($rideStatus === 'Accepted' && ($booking['booking_status'] ?? '') === 'Pending') {
            $pUrl = SUPABASE_URL . '/rest/v1/core2_bookings?booking_id=eq.' . (int)$bid;
            $pch  = curl_init($pUrl);
            curl_setopt_array($pch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'PATCH',CURLOPT_POSTFIELDS=>json_encode(['booking_status'=>'Confirmed','updated_at'=>date('c')]),CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json']]);
            curl_exec($pch); curl_close($pch);
            if (isset($bookings_map[$bid])) { $bookings_map[$bid]['booking_status'] = 'Confirmed'; $booking = $bookings_map[$bid]; }
        }
        if ($rideStatus === 'In Progress' && in_array($booking['booking_status'] ?? '', ['Pending','Confirmed'])) {
            $pUrl = SUPABASE_URL . '/rest/v1/core2_bookings?booking_id=eq.' . (int)$bid;
            $pch  = curl_init($pUrl);
            curl_setopt_array($pch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'PATCH',CURLOPT_POSTFIELDS=>json_encode(['booking_status'=>'In Progress','updated_at'=>date('c')]),CURLOPT_HTTPHEADER=>['apikey: '.SUPABASE_ANON_KEY,'Authorization: Bearer '.SUPABASE_ANON_KEY,'Content-Type: application/json']]);
            curl_exec($pch); curl_close($pch);
            if (isset($bookings_map[$bid])) { $bookings_map[$bid]['booking_status'] = 'In Progress'; $booking = $bookings_map[$bid]; }
        }
    }

    $all_rides[] = [
        'ride_id'           => $r['ride_id'],
        'booking_id'        => $bid,
        'start_time'        => $r['start_time'],
        'end_time'          => $r['end_time'],
        'start_location'    => $r['start_location'],
        'end_location'      => $r['end_location'],
        'ride_status'       => $rideStatus,
        'created_at'        => $r['created_at'],
        'booking_reference' => $booking['booking_reference'] ?? '—',
        'booking_status'    => $booking['booking_status']    ?? '—',
        'total_amount'      => $booking['total_amount']      ?? 0,
        'payment_status'    => $booking['payment_status']    ?? '—',
        'driver_name'       => $driver['driver_name']        ?? null,
        'driver_phone'      => $driver['phone']              ?? null,
        'driver_lat'        => isset($driver['current_lat'])  ? (float)$driver['current_lat']  : null,
        'driver_lng'        => isset($driver['current_lng'])  ? (float)$driver['current_lng']  : null,
        'distance_km'       => $fare['distance_km']          ?? null,
        'base_fare'         => $fare['base_fare']            ?? null,
        'total_fare'        => $fare['total_fare']           ?? null,
        
        'rejected_by_driver' => (
            $rideStatus === 'Cancelled' &&
            empty($r['driver_id'])
        ),
    ];
}

$active_rides    = array_filter($all_rides, fn($r) => in_array($r['ride_status'], ['Accepted','In Progress','Requested']));
$completed_rides = array_filter($all_rides, fn($r) => in_array($r['ride_status'], ['Completed','Cancelled']));

$selected_ride = null;
if ($selected_ride_id > 0) {
    foreach ($all_rides as $r) {
        if ((int)$r['ride_id'] === $selected_ride_id) {
            $selected_ride = $r;
            break;
        }
    }
}
if (!$selected_ride && !empty($active_rides)) {
    $selected_ride = array_values($active_rides)[0];
    $selected_ride_id = (int)$selected_ride['ride_id'];
}

$active_count    = count($active_rides);
$completed_count = count($completed_rides);
$total_distance  = array_sum(array_column($all_rides, 'distance_km'));

$currentHour = (int)date('H');
$greeting = 'Good Morning';
if ($currentHour >= 12 && $currentHour < 18) $greeting = 'Good Afternoon';
elseif ($currentHour >= 18) $greeting = 'Good Evening';

function getTrackingState(array $ride): array {
    
    if (!empty($ride['rejected_by_driver'])) {
        return ['label' => 'Rejected by Driver', 'step' => 0, 'color' => '#F59E0B', 'desc' => 'No driver accepted this booking. Please book again.'];
    }
    $status = $ride['ride_status'];
    $states = [
        'Requested'   => ['label' => 'Finding Driver',   'step' => 1, 'color' => '#FBBF24', 'desc' => 'Your booking is pending driver acceptance.'],
        'Accepted'    => ['label' => 'Driver En Route',  'step' => 2, 'color' => '#60A5FA', 'desc' => 'Driver has accepted and is heading to your pickup.'],
        'In Progress' => ['label' => 'Trip Ongoing',     'step' => 3, 'color' => '#00D084', 'desc' => 'You are currently on your way to the destination.'],
        'Completed'   => ['label' => 'Trip Completed',   'step' => 4, 'color' => '#10B981', 'desc' => 'Your trip has been completed successfully.'],
        'Cancelled'   => ['label' => 'Trip Cancelled',   'step' => 0, 'color' => '#EF4444', 'desc' => 'This trip was cancelled.'],
    ];
    return $states[$status] ?? $states['Requested'];
}

function shortLocation(string $loc): string {
    $parts = explode(',', $loc);
    return trim($parts[0] ?? $loc);
}

function simulatedEta(?float $km): string {
    if (!$km) return '—';
    $mins = max(1, (int)round($km / 0.5)); 
    if ($mins >= 60) return floor($mins/60) . 'h ' . ($mins%60) . 'm';
    return $mins . ' min';
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>EnviroCab – Track Your Rides</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
    <style>
        
        :root,
        [data-theme="light"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #E8F5F1 0%, #F0F9FF 100%);
            --card-bg:         #FFFFFF;
            --card-border:     #E2E8F0;
            --header-bg:       rgba(255,255,255,0.85);
            --header-border:   rgba(255,255,255,0.5);
            --text-dark:       #1A202C;
            --text-medium:     #4A5568;
            --text-light:      #718096;
            --input-bg:        #FAFAFA;
            --input-border:    #E2E8F0;
            --row-border:      rgba(0,0,0,0.04);
            --nav-bg:          rgba(255,255,255,0.95);
            --icon-btn-bg:     rgba(255,255,255,0.9);
            --icon-btn-border: rgba(0,0,0,0.05);
            --shadow-card:     0 2px 8px rgba(0,0,0,0.04);
            --shadow-hero:     0 8px 32px rgba(0,208,132,0.2);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.05);
            --overlay-bg:      rgba(0,0,0,0.45);
            --sheet-bg:        #FFFFFF;
            --map-bg-top:      #E8F4EA;
            --map-bg-bot:      #D4EDD8;
            --map-road:        rgba(255,255,255,0.7);
            --map-grid:        rgba(0,168,107,0.08);
        }

        [data-theme="dark"] {
            --primary-green:   #00D084;
            --dark-green:      #00A86B;
            --bg-gradient:     linear-gradient(135deg, #0D1F1A 0%, #0F172A 100%);
            --card-bg:         #1A2820;
            --card-border:     #263330;
            --header-bg:       rgba(15,24,18,0.94);
            --header-border:   rgba(0,208,132,0.1);
            --text-dark:       #E8F5F1;
            --text-medium:     #9FC4AE;
            --text-light:      #607D6B;
            --input-bg:        #111E18;
            --input-border:    #263330;
            --row-border:      rgba(255,255,255,0.05);
            --nav-bg:          rgba(15,24,18,0.97);
            --icon-btn-bg:     rgba(255,255,255,0.06);
            --icon-btn-border: rgba(255,255,255,0.08);
            --shadow-card:     0 2px 12px rgba(0,0,0,0.35);
            --shadow-hero:     0 8px 40px rgba(0,208,132,0.12);
            --shadow-nav:      0 -4px 24px rgba(0,0,0,0.5);
            --overlay-bg:      rgba(0,0,0,0.72);
            --sheet-bg:        #1A2820;
            --map-bg-top:      #0D1F18;
            --map-bg-bot:      #0A1A14;
            --map-road:        rgba(0,208,132,0.12);
            --map-grid:        rgba(0,208,132,0.05);
        }

        
        *::-webkit-scrollbar{display:none;}
*{-ms-overflow-style:none;scrollbar-width:none;}
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        *, *::before, *::after {
            transition: background-color .3s ease, border-color .25s ease, color .2s ease, box-shadow .3s ease;
        }
        input, button, svg, img { transition: none; }
        .icon-btn, .nav-item, .track-btn, .safety-btn, .tab-btn, .ride-card {
            transition: background .2s, transform .15s, opacity .2s, border-color .2s, box-shadow .2s;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-gradient);
            color: var(--text-dark);
            min-height: 100vh;
            padding-bottom: 100px;
            -webkit-font-smoothing: antialiased;
            transition:opacity .15s ease;
}

        
        .header {
            background: var(--header-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 16px 20px;
            position: sticky; top: 0; z-index: 100;
            border-bottom: 1px solid var(--header-border);
        }
        .header-content { display:flex; justify-content:space-between; align-items:center; }
        .logo-img { height:28px; width:auto; }
        .header-right { display:flex; align-items:center; gap:10px; }

        .icon-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
            position:relative;
        }
        .icon-btn svg { stroke:var(--text-medium); }
        .icon-btn:active { transform:scale(0.93); }
        .logout-btn {
            background:rgba(239,68,68,0.12) !important;
            border-color:rgba(239,68,68,0.2) !important;
        }
        .logout-btn svg { stroke:#EF4444 !important; }

        
        .theme-btn {
            width:36px; height:36px; border-radius:12px;
            background:var(--icon-btn-bg); border:1px solid var(--icon-btn-border);
            display:flex; align-items:center; justify-content:center; cursor:pointer;
            position:relative; overflow:hidden;
        }
        .theme-btn:active { transform:scale(0.93); }
        .t-sun, .t-moon {
            position:absolute;
            transition: opacity .35s ease, transform .4s cubic-bezier(.34,1.56,.64,1) !important;
        }
        [data-theme="light"] .t-sun  { opacity:1; transform:rotate(0deg) scale(1); }
        [data-theme="light"] .t-moon { opacity:0; transform:rotate(90deg) scale(.6); }
        [data-theme="dark"]  .t-sun  { opacity:0; transform:rotate(-90deg) scale(.6); }
        [data-theme="dark"]  .t-moon { opacity:1; transform:rotate(0deg) scale(1); }

        
        .main-content { padding:20px; }

        
        .hero-card {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--dark-green) 100%);
            border-radius:24px; padding:28px 24px; color:white;
            margin-bottom:20px; box-shadow:var(--shadow-hero);
            position:relative; overflow:hidden;
        }
        .hero-card::before {
            content:''; position:absolute; top:-50%; right:-20%;
            width:200px; height:200px;
            background:rgba(255,255,255,0.1); border-radius:50%;
        }
        .hero-card::after {
            content:''; position:absolute; bottom:-30%; left:-10%;
            width:150px; height:150px;
            background:rgba(255,255,255,0.06); border-radius:50%;
        }
        .live-dot-wrap { display:flex; align-items:center; gap:8px; margin-bottom:6px; position:relative; }
        .live-dot {
            width:10px; height:10px; border-radius:50%;
            background:#fff; position:relative;
        }
        .live-dot::after {
            content:''; position:absolute; inset:-4px;
            border-radius:50%; border:2px solid rgba(255,255,255,.5);
            animation: pulse-ring 1.6s ease-out infinite;
        }
        @keyframes pulse-ring {
            0%   { transform:scale(.8); opacity:1; }
            100% { transform:scale(1.8); opacity:0; }
        }
        .live-label { font-size:12px; font-weight:700; opacity:.9; letter-spacing:.5px; text-transform:uppercase; }
        .hero-title  { font-size:24px; font-weight:800; margin-bottom:8px; position:relative; }
        .hero-amount { font-size:42px; font-weight:900; letter-spacing:-1px; margin-bottom:4px; position:relative; }
        .hero-label  { font-size:13px; opacity:.85; position:relative; }
        .hero-stats  { display:flex; gap:12px; margin-top:24px; position:relative; }
        .hero-stat {
            flex:1; background:rgba(255,255,255,0.15);
            backdrop-filter:blur(10px); padding:12px;
            border-radius:16px; text-align:center;
        }
        .hero-stat-value { font-size:20px; font-weight:700; margin-bottom:4px; }
        .hero-stat-label { font-size:11px; opacity:.85; }

        
        .section-title {
            font-size:12px; font-weight:700; color:var(--text-light);
            text-transform:uppercase; letter-spacing:.08em; margin:24px 0 10px;
        }

        
        .tab-bar { display:flex; gap:8px; margin-bottom:20px; }
        .tab-btn {
            flex:1; padding:10px; border-radius:14px;
            border:1.5px solid var(--card-border); background:var(--card-bg);
            font-size:13px; font-weight:700; color:var(--text-medium);
            cursor:pointer; font-family:inherit;
            display:flex; align-items:center; justify-content:center; gap:6px;
        }
        .tab-btn.active {
            background:var(--primary-green);
            border-color:var(--primary-green); color:white;
        }
        .tab-count {
            font-size:11px; font-weight:800; padding:2px 7px;
            border-radius:6px; background:rgba(0,0,0,.1);
        }
        .tab-btn.active .tab-count { background:rgba(255,255,255,.25); }

        
        .ride-list { display:flex; flex-direction:column; gap:12px; margin-bottom:24px; }

        .ride-card {
            background:var(--card-bg); border-radius:20px;
            border:1.5px solid var(--card-border);
            box-shadow:var(--shadow-card);
            overflow:hidden; cursor:pointer;
            animation:slideUp .4s ease forwards;
        }
        .ride-card.selected {
            border-color:var(--primary-green);
            box-shadow:0 4px 20px rgba(0,208,132,.15);
        }
        .ride-card:active { transform:scale(.99); }

        .ride-card-header { display:flex; align-items:center; gap:14px; padding:16px 16px 12px; }
        .ride-status-icon {
            width:48px; height:48px; border-radius:16px;
            display:flex; align-items:center; justify-content:center; flex-shrink:0;
        }
        .ride-card-info { flex:1; min-width:0; }
        .ride-ref    { font-size:15px; font-weight:700; color:var(--text-dark); }
        .ride-driver { font-size:12px; color:var(--text-light); margin-top:2px; }
        .ride-right  { text-align:right; flex-shrink:0; }
        .ride-amount { font-size:16px; font-weight:800; color:var(--text-dark); }
        .ride-date   { font-size:11px; color:var(--text-light); margin-top:3px; }

        .ride-route { padding:0 16px 14px; display:flex; flex-direction:column; gap:6px; }
        .route-point { display:flex; align-items:flex-start; gap:10px; }
        .route-dot { width:10px; height:10px; border-radius:50%; margin-top:4px; flex-shrink:0; }
        .route-dot.pickup  { background:var(--primary-green); }
        .route-dot.dropoff { background:#EF4444; }
        .route-line { width:2px; height:14px; background:var(--card-border); margin-left:4px; margin-top:-2px; margin-bottom:-2px; }
        .route-text { font-size:12px; color:var(--text-medium); line-height:1.4; }

        .ride-card-footer {
            border-top:1px solid var(--card-border); padding:10px 16px;
            display:flex; align-items:center; justify-content:space-between;
        }
        .status-badge {
            display:inline-flex; align-items:center; gap:5px;
            padding:4px 12px; border-radius:8px;
            font-size:11px; font-weight:700;
        }
        .badge-active    { background:rgba(0,208,132,.12);  color:var(--dark-green); }
        .badge-accepted  { background:rgba(96,165,250,.15); color:#3B82F6; }
        .badge-requested { background:rgba(251,191,36,.15); color:#D97706; }
        .badge-completed { background:rgba(16,185,129,.12); color:#10B981; }
        .badge-cancelled { background:rgba(113,128,150,.1); color:#718096; }
        [data-theme="dark"] .badge-active    { background:rgba(0,208,132,.2); }
        [data-theme="dark"] .badge-accepted  { background:rgba(96,165,250,.2); color:#60A5FA; }
        [data-theme="dark"] .badge-requested { background:rgba(251,191,36,.2); color:#FBBF24; }
        [data-theme="dark"] .badge-completed { background:rgba(16,185,129,.2); color:#34D399; }
        [data-theme="dark"] .badge-cancelled { background:rgba(113,128,150,.15); color:#9CA3AF; }

        .track-btn {
            padding:7px 16px; border-radius:10px; border:none;
            background:linear-gradient(135deg,var(--primary-green),var(--dark-green));
            color:white; font-size:12px; font-weight:700;
            cursor:pointer; font-family:inherit;
        }

        
        .tracking-panel {
            background:var(--card-bg); border-radius:20px;
            border:1.5px solid var(--primary-green);
            box-shadow:0 4px 20px rgba(0,208,132,.12);
            margin-bottom:20px;
            animation:slideUp .4s ease forwards;
        }

        
        
        .tracking-map-container { width:100%; border-radius:20px; overflow:hidden; border:1.5px solid var(--card-border); margin-bottom:0; box-shadow:0 4px 16px rgba(0,0,0,.08); position:relative; }
        #tracking-map { width:100%; height:320px; }
        .tracking-badge { position:absolute; top:12px; left:12px; z-index:10; background:rgba(255,255,255,.95); backdrop-filter:blur(8px); border-radius:20px; padding:6px 14px; font-size:12px; font-weight:700; color:var(--dark-green); border:1px solid rgba(0,208,132,.3); display:flex; align-items:center; gap:6px; box-shadow:0 2px 8px rgba(0,0,0,.1); }
        [data-theme="dark"] .tracking-badge { background:rgba(26,40,32,.95); }
        .live-dot { width:8px; height:8px; background:var(--primary-green); border-radius:50%; animation:blink-dot 1s infinite; }
        @keyframes blink-dot { 0%,100%{opacity:1} 50%{opacity:0.3} }
        @keyframes routeFlow { from { stroke-dashoffset: 60; } to { stroke-dashoffset: 0; } }
        .route-flow-line path { animation: routeFlow 1.1s linear infinite; }
        @keyframes driverPulse { 0%,100%{box-shadow:0 4px 16px rgba(0,208,132,0.55)} 50%{box-shadow:0 4px 24px rgba(0,208,132,0.9),0 0 0 8px rgba(0,208,132,0.15)} }

        
        .tracking-body { padding:16px; }
        .tracking-header {
            display:flex; justify-content:space-between; align-items:flex-start;
            margin-bottom:16px;
        }
        .tracking-ref    { font-size:13px; color:var(--text-light); margin-bottom:3px; }
        .tracking-status { font-size:17px; font-weight:800; color:var(--text-dark); }
        .tracking-desc   { font-size:12px; color:var(--text-light); margin-top:3px; }

        
        .progress-steps { display:flex; align-items:center; margin-bottom:20px; }
        .step-item { display:flex; flex-direction:column; align-items:center; flex:1; }
        .step-circle {
            width:32px; height:32px; border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            font-size:14px; font-weight:800; position:relative; z-index:1;
        }
        .step-circle.done   { background:var(--primary-green); color:white; }
        .step-circle.active {
            background:var(--primary-green); color:white;
            box-shadow:0 0 0 4px rgba(0,208,132,.2);
            animation:step-pulse 1.5s ease-in-out infinite;
        }
        @keyframes step-pulse {
            0%,100%{box-shadow:0 0 0 4px rgba(0,208,132,.2);}
            50%{box-shadow:0 0 0 8px rgba(0,208,132,.08);}
        }
        .step-circle.pending { background:var(--input-border); color:var(--text-light); }
        .step-label { font-size:10px; font-weight:600; color:var(--text-light); margin-top:5px; text-align:center; }
        .step-line { flex:1; height:3px; margin-bottom:18px; background:var(--input-border); border-radius:2px; }
        .step-line.done { background:var(--primary-green); }

        
        .info-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:16px; }
        .info-box {
            background:var(--input-bg); border-radius:14px;
            padding:12px; border:1px solid var(--card-border);
        }
        .info-box-label { font-size:11px; color:var(--text-light); font-weight:500; margin-bottom:4px; }
        .info-box-value { font-size:15px; font-weight:700; color:var(--text-dark); }

        
        .route-display { margin-bottom:16px; }
        .route-row {
            display:flex; align-items:flex-start; gap:12px;
            padding:10px 0; border-bottom:1px solid var(--row-border);
        }
        .route-row:last-child { border-bottom:none; }
        .route-icon-wrap {
            width:32px; height:32px; border-radius:10px;
            display:flex; align-items:center; justify-content:center; flex-shrink:0;
        }
        .route-row-label { font-size:11px; font-weight:600; color:var(--text-light); margin-bottom:2px; }
        .route-row-value { font-size:13px; font-weight:600; color:var(--text-dark); line-height:1.4; }

        
        .driver-info-card {
            background:linear-gradient(135deg,rgba(0,208,132,.07),rgba(0,168,107,.05));
            border:1.5px solid rgba(0,208,132,.2);
            border-radius:16px; padding:14px;
            display:flex; align-items:center; gap:14px;
            margin-bottom:16px;
        }
        .driver-avatar {
            width:48px; height:48px; border-radius:16px;
            background:linear-gradient(135deg,var(--primary-green),var(--dark-green));
            display:flex; align-items:center; justify-content:center; flex-shrink:0;
        }
        .driver-name  { font-size:15px; font-weight:700; color:var(--text-dark); }
        .driver-plate { font-size:12px; color:var(--text-light); margin-top:2px; }
        .driver-rating { display:flex; align-items:center; gap:4px; margin-top:4px; }
        .driver-rating svg { stroke:#FBBF24; fill:#FBBF24; }
        .driver-rating span { font-size:12px; font-weight:700; color:var(--text-dark); }
        .call-btn {
            margin-left:auto; width:40px; height:40px; border-radius:12px;
            background:var(--primary-green); border:none;
            display:flex; align-items:center; justify-content:center;
            cursor:pointer; flex-shrink:0;
        }

        
        .safety-row { display:flex; gap:10px; margin-bottom:6px; }
        .safety-btn {
            flex:1; padding:11px; border-radius:14px; border:none;
            font-size:13px; font-weight:700; cursor:pointer;
            font-family:inherit; display:flex; align-items:center;
            justify-content:center; gap:7px;
        }
        .safety-btn:active { transform:scale(.97); }
        .btn-share {
            background:rgba(96,165,250,.12); color:#3B82F6;
            border:1.5px solid rgba(96,165,250,.25);
        }
        .btn-sos {
            background:rgba(239,68,68,.1); color:#EF4444;
            border:1.5px solid rgba(239,68,68,.2);
        }

        
        .empty-state {
            text-align:center; padding:40px 20px;
            background:var(--card-bg); border-radius:20px;
            border:1px solid var(--card-border);
        }
        .empty-icon  { margin-bottom:12px; display:flex; justify-content:center; }
        .empty-title { font-size:16px; font-weight:700; color:var(--text-dark); margin-bottom:6px; }
        .empty-sub   { font-size:13px; color:var(--text-light); }

        
        .modal-overlay {
            position:fixed; inset:0; background:var(--overlay-bg);
            backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px);
            z-index:200;
            display:flex; align-items:center; justify-content:center;
            padding:20px; opacity:0; pointer-events:none;
        }
        .modal-overlay.open { opacity:1; pointer-events:auto; }
        .modal-sheet {
            background:var(--sheet-bg); width:100%; max-width:380px;
            border-radius:24px; padding:28px 24px;
            transform:scale(.96) translateY(10px);
        }
        .modal-overlay.open .modal-sheet { transform:scale(1) translateY(0); }
        .modal-title { font-size:20px; font-weight:800; color:var(--text-dark); margin-bottom:8px; }
        .modal-sub   { font-size:14px; color:var(--text-light); margin-bottom:22px; }
        .sos-big-btn {
            width:100%; padding:18px; border-radius:16px; border:none;
            background:linear-gradient(135deg,#EF4444,#DC2626);
            color:white; font-size:18px; font-weight:800;
            cursor:pointer; font-family:inherit; margin-bottom:12px;
            display:flex; align-items:center; justify-content:center; gap:10px;
        }
        .cancel-modal-btn {
            width:100%; padding:14px; border-radius:16px; border:1px solid var(--card-border);
            background:var(--input-bg); color:var(--text-medium);
            font-size:15px; font-weight:700; cursor:pointer; font-family:inherit;
        }
        .share-link-box {
            background:var(--input-bg); border-radius:14px;
            padding:14px 16px; font-size:13px; font-weight:600;
            color:var(--text-medium); border:1.5px solid var(--card-border);
            word-break:break-all; margin-bottom:16px;
            display:flex; align-items:center; justify-content:space-between; gap:10px;
        }
        .copy-btn {
            padding:8px 16px; border-radius:10px; border:none;
            background:var(--primary-green); color:white;
            font-size:12px; font-weight:700; cursor:pointer; font-family:inherit;
            flex-shrink:0;
        }
        .share-note { font-size:12px; color:var(--text-light); text-align:center; }

        
        .bottom-nav {
            position:fixed; bottom:0; left:0; right:0;
            background:var(--nav-bg);
            backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
            border-top:1px solid var(--card-border);
            padding:12px 0 20px;
            display:grid; grid-template-columns:repeat(4,1fr);
            z-index:99; box-shadow:var(--shadow-nav);
        }
        .nav-item {
            display:flex; flex-direction:column; align-items:center; gap:4px;
            padding:8px; cursor:pointer; border:none; background:none;
        }
        .nav-item:active { transform:scale(0.95); }
        .nav-icon { width:48px; height:32px; display:flex; align-items:center; justify-content:center; }
        .nav-icon svg { stroke:var(--text-light); opacity:.5; }
        .nav-item.active .nav-icon svg { stroke:var(--primary-green); opacity:1; }
        .nav-label { font-size:11px; font-weight:600; color:var(--text-light); opacity:.7; }
        .nav-item.active .nav-label { color:var(--primary-green); opacity:1; }

        
        @media(min-width:768px){
            body { max-width:480px; margin:0 auto; box-shadow:0 0 40px rgba(0,0,0,.12); }
            .bottom-nav { max-width:480px; left:50%; transform:translateX(-50%); }
        }
        @keyframes slideUp {
            from { opacity:0; transform:translateY(20px); }
            to   { opacity:1; transform:translateY(0); }
        }
        .hero-card, .tracking-panel, .ride-card { animation:slideUp .4s ease forwards; }

        
        .detail-btn {
            padding:7px 14px; border-radius:10px; border:none;
            background:var(--input-bg); color:var(--text-medium);
            font-size:12px; font-weight:700; cursor:pointer; font-family:inherit;
            border:1.5px solid var(--card-border);
            display:flex; align-items:center; gap:5px;
        }
        .detail-btn:active { transform:scale(.97); }

        .trip-detail-modal {
            position:fixed; inset:0; z-index:9000;
            background:rgba(0,0,0,.55); backdrop-filter:blur(6px);
            display:flex; align-items:flex-end; justify-content:center;
            padding:0; animation:fadeInOv .25s ease;
        }
        .trip-detail-sheet {
            background:var(--card-bg); border-radius:28px 28px 0 0;
            width:100%; max-width:480px; max-height:88vh;
            overflow-y:auto; padding:0 0 32px;
            box-shadow:0 -8px 40px rgba(0,0,0,.2);
            animation:slideUpSheet .3s cubic-bezier(.32,1.1,.7,1) forwards;
            scrollbar-width:none;
            -ms-overflow-style:none;
        }
        .trip-detail-sheet::-webkit-scrollbar { display:none; }
        @keyframes slideUpSheet {
            from { transform:translateY(100%); }
            to   { transform:translateY(0); }
        }
        .trip-detail-handle {
            width:40px; height:4px; border-radius:2px;
            background:var(--card-border); margin:12px auto 0;
        }
        .trip-detail-header {
            display:flex; align-items:center; justify-content:space-between;
            padding:16px 20px 12px;
            border-bottom:1px solid var(--card-border);
        }
        .trip-detail-title { font-size:17px; font-weight:800; color:var(--text-dark); }
        .trip-detail-close {
            width:32px; height:32px; border-radius:50%;
            border:none; background:var(--input-bg);
            display:flex; align-items:center; justify-content:center;
            cursor:pointer; color:var(--text-medium);
        }
        .trip-detail-body { padding:16px 20px; }

        .detail-section { margin-bottom:18px; }
        .detail-section-title {
            font-size:11px; font-weight:700; color:var(--text-light);
            text-transform:uppercase; letter-spacing:.07em; margin-bottom:10px;
        }
        .detail-row {
            display:flex; justify-content:space-between; align-items:flex-start;
            padding:10px 0; border-bottom:1px solid var(--row-border);
        }
        .detail-row:last-child { border-bottom:none; }
        .detail-row-label { font-size:13px; color:var(--text-light); font-weight:500; }
        .detail-row-value { font-size:13px; color:var(--text-dark); font-weight:700; text-align:right; max-width:65%; }

        .detail-status-badge {
            display:inline-flex; align-items:center; gap:5px;
            padding:4px 12px; border-radius:8px; font-size:12px; font-weight:700;
        }
        .detail-fare-box {
            background:rgba(0,208,132,.07); border:1.5px solid rgba(0,208,132,.2);
            border-radius:16px; padding:16px; text-align:center; margin-bottom:18px;
        }
        .detail-fare-label { font-size:11px; font-weight:700; color:var(--text-light); text-transform:uppercase; letter-spacing:.07em; margin-bottom:4px; }
        .detail-fare-amount { font-size:32px; font-weight:900; color:var(--dark-green); }

        .detail-route-box {
            background:var(--input-bg); border-radius:14px;
            border:1px solid var(--card-border); padding:14px; margin-bottom:18px;
        }
        .detail-route-row { display:flex; align-items:flex-start; gap:12px; }
        .detail-route-row + .detail-route-row { margin-top:12px; }
        .detail-route-dot { width:10px; height:10px; border-radius:50%; margin-top:4px; flex-shrink:0; }
        .detail-route-dot.pickup  { background:var(--primary-green); }
        .detail-route-dot.dropoff { background:#EF4444; }
        .detail-route-info-label { font-size:10px; color:var(--text-light); font-weight:600; text-transform:uppercase; }
        .detail-route-info-value { font-size:13px; color:var(--text-dark); font-weight:600; margin-top:2px; }
        .detail-divider { width:2px; height:16px; background:var(--card-border); margin-left:4px; margin:4px 0 4px 4px; }
    
    
    .notif-panel-wrap{position:relative;}
    .notif-panel{position:absolute;top:calc(100% + 10px);right:0;width:310px;max-height:400px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.15);z-index:999;display:none;flex-direction:column;overflow:hidden;}
    .notif-panel.open{display:flex;}
    .notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid var(--card-border);flex-shrink:0;}
    .notif-panel-title{font-size:14px;font-weight:700;color:var(--text-dark);}
    .notif-mark-read{font-size:11px;font-weight:600;color:var(--dark-green);background:none;border:none;cursor:pointer;padding:0;}
    .notif-list{overflow-y:auto;flex:1;padding:4px 0;}
    .notif-item{display:flex;align-items:flex-start;gap:10px;padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--row-border);transition:background .15s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,208,132,0.06);}
    .notif-item.unread{background:rgba(0,208,132,0.04);}
    .notif-dot-ind{width:8px;height:8px;border-radius:50%;background:#00D084;flex-shrink:0;margin-top:5px;}
    .notif-item:not(.unread) .notif-dot-ind{background:transparent;}
    .notif-item-icon{width:32px;height:32px;border-radius:10px;background:rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    [data-theme="dark"] .notif-item-icon{background:rgba(255,255,255,0.08);}
    .notif-item-body{flex:1;min-width:0;}
    .notif-item-title{font-size:12px;font-weight:700;color:var(--text-dark);margin-bottom:2px;}
    .notif-item-sub{font-size:11px;color:var(--text-light);line-height:1.4;}
    .notif-item-time{font-size:10px;color:var(--text-light);margin-top:3px;}
    .notif-empty{padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;}
    .notif-spinner{width:20px;height:20px;border:2px solid var(--card-border);border-top-color:#00D084;border-radius:50%;animation:nspin .7s linear infinite;margin:16px auto;}
    @keyframes nspin{to{transform:rotate(360deg);}}
    .notif-count-badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 3px;background:#EF4444;border-radius:8px;border:2px solid var(--card-bg);font-size:9px;font-weight:800;color:#fff;display:none;align-items:center;justify-content:center;line-height:1;}
    
    .logout-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;display:none;align-items:center;justify-content:center;padding:24px;}
    .logout-overlay.open{display:flex;}
    .logout-modal{background:var(--card-bg);border-radius:24px;padding:28px 24px 24px;width:100%;max-width:320px;box-shadow:0 16px 48px rgba(0,0,0,0.18);animation:lmodalIn .25s cubic-bezier(.34,1.56,.64,1);}
    @keyframes lmodalIn{from{transform:scale(.88);opacity:0;}to{transform:scale(1);opacity:1;}}
    .logout-modal-icon{width:52px;height:52px;border-radius:16px;background:rgba(239,68,68,0.1);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
    .logout-modal-title{font-size:17px;font-weight:800;color:var(--text-dark);text-align:center;margin-bottom:6px;}
    .logout-modal-sub{font-size:13px;color:var(--text-light);text-align:center;line-height:1.5;margin-bottom:22px;}
    .logout-modal-btns{display:flex;gap:10px;}
    .logout-cancel-btn{flex:1;padding:13px;border-radius:14px;background:var(--input-bg);border:1px solid var(--card-border);font-size:14px;font-weight:700;color:var(--text-medium);cursor:pointer;}
    .logout-confirm-btn{flex:1;padding:13px;border-radius:14px;background:#EF4444;border:none;font-size:14px;font-weight:700;color:#fff;cursor:pointer;}
</style>
</head>
<body>

<div class="header">
    <div class="header-content">
        <img src="../images/envirocab_logo.png" alt="EnviroCab" class="logo-img"
             onerror="this.style.display='none'">
                        <div class="header-right">
            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">
                <svg class="t-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                <svg class="t-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            </button>
            <button class="icon-btn" onclick="window.location.href='dashboard.php'" title="Home">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </button>
            <div class="notif-panel-wrap">
            <button class="icon-btn" id="notif-bell-btn" onclick="toggleNotifPanel(event)" aria-label="Notifications" style="position:relative;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <span class="notif-count-badge" id="notif-count-badge"></span>
            </button>
            <div class="notif-panel" id="notif-panel">
                <div class="notif-panel-head">
                    <span class="notif-panel-title">Notifications</span>
                    <button class="notif-mark-read" onclick="markAllRead()">Mark all read</button>
                </div>
                <div class="notif-list" id="notif-list"><div class="notif-spinner"></div></div>
            </div>
        </div>
            <button class="icon-btn logout-btn" onclick="openLogout()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </button>
        </div>
    </div>
</div>

<div class="main-content">

    
    <div class="hero-card">
        <div class="live-dot-wrap">
            <div class="live-dot"></div>
            <span class="live-label">Live Tracking</span>
        </div>
        <div class="hero-title">Track Your Rides</div>
        <div class="hero-amount"><?php echo $active_count; ?></div>
        <div class="hero-label">Active <?php echo $active_count === 1 ? 'Trip' : 'Trips'; ?> Right Now</div>

        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hero-stat-value"><?php echo $active_count; ?></div>
                <div class="hero-stat-label">Active</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?php echo $completed_count; ?></div>
                <div class="hero-stat-label">Completed</div>
            </div>
            <div class="hero-stat">
                <div class="hero-stat-value"><?php echo $total_distance > 0 ? number_format($total_distance, 1) : '0'; ?> km</div>
                <div class="hero-stat-label">Total KM</div>
            </div>
        </div>
    </div>

    <?php if ($selected_ride): ?>
    <?php
        $ts   = getTrackingState($selected_ride);
        $step = $ts['step'];
        $isActive = in_array($selected_ride['ride_status'], ['Accepted','In Progress','Requested']);
        $eta  = simulatedEta($selected_ride['distance_km']);
        $from = shortLocation($selected_ride['start_location']);
        $to   = shortLocation($selected_ride['end_location'] ?? '—');
    ?>

    
    <div class="section-title">Live Tracking</div>
    <div class="tracking-panel">

        
        <div class="tracking-map-container">
            <div id="tracking-map"></div>
            <div class="tracking-badge">
                <div class="live-dot"></div>
                LIVE TRACKING
            </div>
        </div>

        

            <div class="tracking-header">
                <div>
                    <div class="tracking-ref"><?php echo htmlspecialchars($selected_ride['booking_reference']); ?></div>
                    <div class="tracking-status"><?php echo $ts['label']; ?></div>
                    <div class="tracking-desc"><?php echo $ts['desc']; ?></div>
                </div>
                <?php
                $badgeClass = [
                    'Requested'   => 'badge-requested',
                    'Accepted'    => 'badge-accepted',
                    'In Progress' => 'badge-active',
                    'Completed'   => 'badge-completed',
                    'Cancelled'   => 'badge-cancelled',
                ][$selected_ride['ride_status']] ?? 'badge-requested';
                ?>
                <span class="status-badge <?php echo $badgeClass; ?>">
                    <svg width="8" height="8" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
                    <?php echo $selected_ride['ride_status']; ?>
                </span>
            </div>

            
            <div class="progress-steps">
                <?php
                $steps = [1=>'Requested', 2=>'En Route', 3=>'Ongoing', 4=>'Done'];
                $stepKeys = array_keys($steps);
                foreach ($stepKeys as $i => $sNum):
                    if ($selected_ride['ride_status'] === 'Cancelled') {
                        $circleClass = 'pending';
                    } elseif ($sNum < $step) {
                        $circleClass = 'done';
                    } elseif ($sNum === $step) {
                        $circleClass = 'active';
                    } else {
                        $circleClass = 'pending';
                    }
                    $lineClass = ($sNum < $step) ? 'done' : '';
                ?>
                <div class="step-item">
                    <div class="step-circle <?php echo $circleClass; ?>"><?php echo $sNum; ?></div>
                    <div class="step-label"><?php echo $steps[$sNum]; ?></div>
                </div>
                <?php if ($i < count($stepKeys)-1): ?>
                <div class="step-line <?php echo $lineClass; ?>"></div>
                <?php endif; ?>
                <?php endforeach; ?>
            </div>

            
            <div class="info-grid">
                <div class="info-box">
                    <div class="info-box-label">Distance</div>
                    <div class="info-box-value"><?php echo $selected_ride['distance_km'] ? number_format($selected_ride['distance_km'],1).' km' : '—'; ?></div>
                </div>
                <div class="info-box">
                    <div class="info-box-label">Est. Arrival</div>
                    <div class="info-box-value"><?php echo $isActive ? $eta : '—'; ?></div>
                </div>
                <div class="info-box">
                    <div class="info-box-label">Fare</div>
                    <div class="info-box-value">₱<?php echo number_format($selected_ride['total_amount'] ?? 0, 2); ?></div>
                </div>
                <div class="info-box">
                    <div class="info-box-label">Start Time</div>
                    <div class="info-box-value"><?php echo (new DateTime($selected_ride['start_time'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('h:i A'); ?></div>
                </div>
            </div>

            
            <div class="route-display">
                <div class="route-row">
                    <div class="route-icon-wrap" style="background:rgba(0,208,132,.12);">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--primary-green)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="3"/>
                            <path d="M12 2v3M12 19v3M4.22 4.22l2.12 2.12M17.66 17.66l2.12 2.12M2 12h3M19 12h3M4.22 19.78l2.12-2.12M17.66 6.34l2.12-2.12"/>
                        </svg>
                    </div>
                    <div>
                        <div class="route-row-label">Pickup</div>
                        <div class="route-row-value"><?php echo htmlspecialchars($selected_ride['start_location']); ?></div>
                    </div>
                </div>
                <div class="route-row">
                    <div class="route-icon-wrap" style="background:rgba(239,68,68,.1);">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                            <circle cx="12" cy="10" r="3"/>
                        </svg>
                    </div>
                    <div>
                        <div class="route-row-label">Destination</div>
                        <div class="route-row-value"><?php echo htmlspecialchars($selected_ride['end_location'] ?? '—'); ?></div>
                    </div>
                </div>
            </div>

            
            <?php if ($selected_ride['driver_name']): ?>
            <div class="driver-info-card">
                <div class="driver-avatar">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                        <circle cx="12" cy="7" r="4"/>
                    </svg>
                </div>
                <div style="flex:1;min-width:0;">
                    <div class="driver-name"><?php echo htmlspecialchars($selected_ride['driver_name']); ?></div>
                    <div class="driver-plate">
                        <?php echo !empty($selected_ride['plate_number']) ? htmlspecialchars($selected_ride['plate_number']) : 'No vehicle assigned'; ?>
                        <?php if (!empty($selected_ride['make_model'])): ?>
                        · <?php echo htmlspecialchars($selected_ride['make_model']); ?>
                        <?php endif; ?>
                    </div>
                    <div class="driver-rating">
                        <svg width="13" height="13" viewBox="0 0 24 24" stroke-width="0"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                        <span>Driver Assigned</span>
                    </div>
                </div>
                <?php if ($selected_ride['driver_phone'] && $isActive): ?>
                <button class="call-btn" onclick="window.location.href='tel:<?php echo htmlspecialchars($selected_ride['driver_phone']); ?>'">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
                    </svg>
                </button>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            
            <?php if ($isActive): ?>
            <div class="safety-row">
                <button class="safety-btn btn-share" onclick="openShareModal()">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/>
                        <circle cx="18" cy="19" r="3"/>
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                    </svg>
                    Share Trip
                </button>
                <button class="safety-btn btn-sos" onclick="openSosModal()">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="12" y1="8" x2="12" y2="12"/>
                        <line x1="12" y1="16" x2="12.01" y2="16"/>
                    </svg>
                    SOS Alert
                </button>
            </div>
            <?php endif; ?>

        </div>
    </div>
    <?php endif; ?>

    
    <div class="section-title">All Rides</div>
    <div class="tab-bar">
        <button class="tab-btn <?php echo (!isset($_GET['tab']) || $_GET['tab']==='active') ? 'active' : ''; ?>"
                onclick="showTab('active')">
            Active <span class="tab-count"><?php echo $active_count; ?></span>
        </button>
        <button class="tab-btn <?php echo (isset($_GET['tab']) && $_GET['tab']==='history') ? 'active' : ''; ?>"
                onclick="showTab('history')">
            History <span class="tab-count"><?php echo $completed_count; ?></span>
        </button>
    </div>

    
    <div id="tab-active">
        <?php if (empty($active_rides)): ?>
        <div class="empty-state">
            <div class="empty-icon">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                    <circle cx="12" cy="10" r="3"/>
                </svg>
            </div>
            <div class="empty-title">No active trips</div>
            <div class="empty-sub">Book a ride to start tracking in real-time.</div>
        </div>
        <?php else: ?>
        <div class="ride-list">
            <?php foreach ($active_rides as $ride):
                $ts2 = getTrackingState($ride);
                $isSelected = ((int)$ride['ride_id'] === $selected_ride_id);
                $badgeClass2 = [
                    'Requested'   => 'badge-requested',
                    'Accepted'    => 'badge-accepted',
                    'In Progress' => 'badge-active',
                ][$ride['ride_status']] ?? 'badge-requested';
            ?>
            <div class="ride-card <?php echo $isSelected ? 'selected' : ''; ?>"
                 onclick="window.location.href='passenger_tracking.php?ride_id=<?php echo $ride['ride_id']; ?>'">
                <div class="ride-card-header">
                    <div class="ride-status-icon" style="background:<?php echo $ts2['color']; ?>22;">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="<?php echo $ts2['color']; ?>" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="1" y="3" width="15" height="13"/>
                            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/>
                            <circle cx="5.5" cy="18.5" r="2.5"/>
                            <circle cx="18.5" cy="18.5" r="2.5"/>
                        </svg>
                    </div>
                    <div class="ride-card-info">
                        <div class="ride-ref"><?php echo htmlspecialchars($ride['booking_reference']); ?></div>
                        <div class="ride-driver"><?php echo htmlspecialchars($ride['driver_name'] ?? 'Assigning driver…'); ?></div>
                    </div>
                    <div class="ride-right">
                        <div class="ride-amount">₱<?php echo number_format($ride['total_amount'], 0); ?></div>
                        <div class="ride-date"><?php echo (new DateTime($ride['start_time'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M d, h:i A'); ?></div>
                    </div>
                </div>
                <div class="ride-route">
                    <div class="route-point">
                        <div class="route-dot pickup"></div>
                        <div class="route-text"><?php echo htmlspecialchars(shortLocation($ride['start_location'])); ?></div>
                    </div>
                    <div class="route-line"></div>
                    <div class="route-point">
                        <div class="route-dot dropoff"></div>
                        <div class="route-text"><?php echo htmlspecialchars(shortLocation($ride['end_location'] ?? '—')); ?></div>
                    </div>
                </div>
                <div class="ride-card-footer">
                    <span class="status-badge <?php echo $badgeClass2; ?>">
                        <svg width="7" height="7" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
                        <?php echo $ride['ride_status']; ?>
                    </span>
                    <button class="track-btn" onclick="event.stopPropagation(); window.location.href='passenger_tracking.php?ride_id=<?php echo $ride['ride_id']; ?>'">
                        Track
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    
    <div id="tab-history" style="display:none;">
        <?php if (empty($completed_rides)): ?>
        <div class="empty-state">
            <div class="empty-icon">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                </svg>
            </div>
            <div class="empty-title">No ride history yet</div>
            <div class="empty-sub">Completed trips will appear here.</div>
        </div>
        <?php else: ?>
        <div class="ride-list">
            <?php foreach ($completed_rides as $ride):
                $isRejected3 = !empty($ride['rejected_by_driver']);
                $isCancelled = $ride['ride_status'] === 'Cancelled';
                $iconColor = $isRejected3 ? '#F59E0B' : ($isCancelled ? '#718096' : '#10B981');
                $iconBg    = $isRejected3 ? 'rgba(245,158,11,.12)' : ($isCancelled ? 'rgba(113,128,150,.1)' : 'rgba(16,185,129,.12)');
                $badgeClass3 = $isRejected3 ? 'badge-cancelled' : ($isCancelled ? 'badge-cancelled' : 'badge-completed');
            ?>
            <div class="ride-card"
                 onclick="window.location.href='passenger_tracking.php?ride_id=<?php echo $ride['ride_id']; ?>'">
                <div class="ride-card-header">
                    <div class="ride-status-icon" style="background:<?php echo $iconBg; ?>;">
                        <?php if ($isRejected3): ?>
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="<?php echo $iconColor; ?>" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"/>
                            <line x1="12" y1="8" x2="12" y2="12"/>
                            <line x1="12" y1="16" x2="12.01" y2="16"/>
                        </svg>
                        <?php elseif ($isCancelled): ?>
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="<?php echo $iconColor; ?>" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"/>
                            <line x1="15" y1="9" x2="9" y2="15"/>
                            <line x1="9" y1="9" x2="15" y2="15"/>
                        </svg>
                        <?php else: ?>
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="<?php echo $iconColor; ?>" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                            <polyline points="22 4 12 14.01 9 11.01"/>
                        </svg>
                        <?php endif; ?>
                    </div>
                    <div class="ride-card-info">
                        <div class="ride-ref"><?php echo htmlspecialchars($ride['booking_reference']); ?></div>
                        <div class="ride-driver" style="<?php echo $isRejected3 ? 'color:#F59E0B;font-weight:700;' : ''; ?>">
                            <?php echo $isRejected3 ? 'Rejected by Driver' : htmlspecialchars($ride['driver_name'] ?? 'N/A'); ?>
                        </div>
                    </div>
                    <div class="ride-right">
                        <div class="ride-amount">₱<?php echo number_format($ride['total_amount'], 0); ?></div>
                        <div class="ride-date"><?php echo (new DateTime($ride['start_time'], new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M d, h:i A'); ?></div>
                    </div>
                </div>
                <div class="ride-route">
                    <div class="route-point">
                        <div class="route-dot pickup"></div>
                        <div class="route-text"><?php echo htmlspecialchars(shortLocation($ride['start_location'])); ?></div>
                    </div>
                    <div class="route-line"></div>
                    <div class="route-point">
                        <div class="route-dot dropoff"></div>
                        <div class="route-text"><?php echo htmlspecialchars(shortLocation($ride['end_location'] ?? '—')); ?></div>
                    </div>
                </div>
                <div class="ride-card-footer">
                    <span class="status-badge <?php echo $badgeClass3; ?>">
                        <svg width="7" height="7" viewBox="0 0 10 10" fill="currentColor"><circle cx="5" cy="5" r="5"/></svg>
                        <?php echo $ride['ride_status']; ?>
                    </span>
                    <button class="detail-btn" onclick="event.stopPropagation(); openTripDetail(<?php echo htmlspecialchars(json_encode([
                        'ride_id'           => $ride['ride_id'],
                        'booking_reference' => $ride['booking_reference'],
                        'ride_status'       => $ride['ride_status'],
                        'booking_status'    => $ride['booking_status'],
                        'payment_status'    => $ride['payment_status'],
                        'start_location'    => $ride['start_location'],
                        'end_location'      => $ride['end_location'] ?? '—',
                        'driver_name'       => $ride['driver_name'] ?? null,
                        'driver_phone'      => $ride['driver_phone'] ?? null,
                        'distance_km'       => $ride['distance_km'],
                        'base_fare'         => $ride['base_fare'],
                        'total_amount'      => $ride['total_amount'],
                        'total_fare'        => $ride['total_fare'],
                        'start_time'        => $ride['start_time'],
                        'end_time'          => $ride['end_time'],
                        'created_at'        => $ride['created_at'],
                        'rejected_by_driver'=> !empty($ride['rejected_by_driver']),
                    ]), ENT_QUOTES); ?>)">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        View Details
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

</div>


<div class="trip-detail-modal" id="tripDetailModal" style="display:none;" onclick="if(event.target===this)closeTripDetail()">
    <div class="trip-detail-sheet" id="tripDetailSheet">
        <div class="trip-detail-handle"></div>
        <div class="trip-detail-header">
            <div class="trip-detail-title" id="td-ref">Trip Details</div>
            <button class="trip-detail-close" onclick="closeTripDetail()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <div class="trip-detail-body">

            
            <div class="detail-fare-box">
                <div class="detail-fare-label">Total Fare</div>
                <div class="detail-fare-amount" id="td-fare">₱0.00</div>
            </div>

            
            <div class="detail-section">
                <div class="detail-section-title">Route</div>
                <div class="detail-route-box">
                    <div class="detail-route-row">
                        <div class="detail-route-dot pickup"></div>
                        <div>
                            <div class="detail-route-info-label">Pickup</div>
                            <div class="detail-route-info-value" id="td-from">—</div>
                        </div>
                    </div>
                    <div class="detail-divider" style="margin-left:4px;"></div>
                    <div class="detail-route-row">
                        <div class="detail-route-dot dropoff"></div>
                        <div>
                            <div class="detail-route-info-label">Destination</div>
                            <div class="detail-route-info-value" id="td-to">—</div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="detail-section">
                <div class="detail-section-title">Trip Info</div>
                <div class="detail-row">
                    <span class="detail-row-label">Status</span>
                    <span class="detail-row-value" id="td-status">—</span>
                </div>
                <div class="detail-row">
                    <span class="detail-row-label">Booking Ref</span>
                    <span class="detail-row-value" id="td-booking-ref">—</span>
                </div>
                <div class="detail-row">
                    <span class="detail-row-label">Ride ID</span>
                    <span class="detail-row-value" id="td-ride-id">—</span>
                </div>
                <div class="detail-row">
                    <span class="detail-row-label">Distance</span>
                    <span class="detail-row-value" id="td-distance">—</span>
                </div>
                <div class="detail-row">
                    <span class="detail-row-label">Start Time</span>
                    <span class="detail-row-value" id="td-start-time">—</span>
                </div>
                <div class="detail-row">
                    <span class="detail-row-label">End Time</span>
                    <span class="detail-row-value" id="td-end-time">—</span>
                </div>
            </div>

            
            <div class="detail-section">
                <div class="detail-section-title">Fare Breakdown</div>
                <div class="detail-row">
                    <span class="detail-row-label">Base Fare</span>
                    <span class="detail-row-value" id="td-base-fare">—</span>
                </div>
                <div class="detail-row">
                    <span class="detail-row-label">Computed Fare</span>
                    <span class="detail-row-value" id="td-computed-fare">—</span>
                </div>
                <div class="detail-row">
                    <span class="detail-row-label">Total Amount</span>
                    <span class="detail-row-value" id="td-total-amount" style="color:var(--dark-green);">—</span>
                </div>
                <div class="detail-row">
                    <span class="detail-row-label">Payment Status</span>
                    <span class="detail-row-value" id="td-payment-status">—</span>
                </div>
            </div>

            
            <div class="detail-section" id="td-driver-section">
                <div class="detail-section-title">Driver</div>
                <div class="detail-row">
                    <span class="detail-row-label">Name</span>
                    <span class="detail-row-value" id="td-driver-name">—</span>
                </div>
                <div class="detail-row" id="td-driver-phone-row">
                    <span class="detail-row-label">Contact</span>
                    <span class="detail-row-value" id="td-driver-phone">—</span>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal-overlay" id="sosModal">
    <div class="modal-sheet">
        <div class="modal-title" style="color:#EF4444;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.2" style="vertical-align:middle;margin-right:8px;">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            Emergency SOS
        </div>
        <div class="modal-sub">This will alert EnviroCab dispatch and share your current trip location immediately.</div>
        <button class="sos-big-btn" onclick="triggerSos()">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            Send SOS Alert
        </button>
        <button class="cancel-modal-btn" onclick="closeSosModal()">Cancel</button>
    </div>
</div>

<div class="modal-overlay" id="shareModal">
    <div class="modal-sheet">
        <div class="modal-title">Share Live Trip</div>
        <div class="modal-sub">Share this link with family or friends to let them track your ride in real-time.</div>
        <div class="share-link-box">
            <span id="shareUrl">https://envirocab.app/track/<?php echo $selected_ride_id ? 'TRK-' . strtoupper(dechex($selected_ride_id * 7919)) : 'TRK-XXXXXX'; ?></span>
            <button class="copy-btn" onclick="copyShareLink()">Copy</button>
        </div>
        <div class="share-note">Link expires when your trip ends. Share responsibly.</div>
        <div style="height:16px;"></div>
        <button class="cancel-modal-btn" onclick="closeShareModal()">Close</button>
    </div>
</div>

<div class="bottom-nav">
    <button class="nav-item" onclick="window.location.href='dashboard.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div><span class="nav-label">Home</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_booking.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></div><span class="nav-label">Book</span></button>
    <button class="nav-item active"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><span class="nav-label">Trips</span></button>
    <button class="nav-item" onclick="window.location.href='passenger_profile.php'"><div class="nav-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><span class="nav-label">Profile</span></button>
</div>

<script>

(function () {
    var saved = localStorage.getItem('envirocab_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
})();

function toggleTheme() {
    var html    = document.documentElement;
    var current = html.getAttribute('data-theme');
    var next    = current === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('envirocab_theme', next);
}

function showTab(tab) {
    document.getElementById('tab-active').style.display  = tab === 'active'  ? 'block' : 'none';
    document.getElementById('tab-history').style.display = tab === 'history' ? 'block' : 'none';
    document.querySelectorAll('.tab-btn').forEach(function(b, i){
        b.classList.toggle('active', (i===0 && tab==='active') || (i===1 && tab==='history'));
    });
}
(function(){
    var params = new URLSearchParams(window.location.search);
    if (params.get('tab') === 'history') showTab('history');
})();

function openSosModal()  { document.getElementById('sosModal').classList.add('open'); }
function closeSosModal() { document.getElementById('sosModal').classList.remove('open'); }


function openTripDetail(d) {
    var peso = '₱';
    var fmt  = function(v) { return v ? peso + parseFloat(v).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2}) : '—'; };
    var fmtDate = function(str) {
            if (!str) return '—';
            var dt = new Date(str);
            if (isNaN(dt)) return str;
            return dt.toLocaleDateString('en-PH', {timeZone:'Asia/Manila', month:'short', day:'numeric', year:'numeric'}) + ' ' +
                   dt.toLocaleTimeString('en-PH', {timeZone:'Asia/Manila', hour:'2-digit', minute:'2-digit'});
        };

    document.getElementById('td-ref').textContent        = d.booking_reference || 'Trip Details';
    document.getElementById('td-fare').textContent       = fmt(d.total_amount || d.total_fare);
    document.getElementById('td-from').textContent       = d.start_location || '—';
    document.getElementById('td-to').textContent         = d.end_location   || '—';

    
    var statusColors = {
        'Completed':'#10B981','Cancelled':'#718096',
        'In Progress':'#00D084','Accepted':'#3B82F6','Requested':'#D97706'
    };
    var sc = statusColors[d.ride_status] || '#718096';
    var label = d.rejected_by_driver ? 'Rejected by Driver' : (d.ride_status || '—');
    document.getElementById('td-status').innerHTML =
        '<span style="display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:7px;background:'+sc+'22;color:'+sc+';font-size:12px;font-weight:700;">' +
        '<svg width="7" height="7" viewBox="0 0 10 10" fill="'+sc+'"><circle cx="5" cy="5" r="5"/></svg>'+label+'</span>';

    document.getElementById('td-booking-ref').textContent  = d.booking_reference || '—';
    document.getElementById('td-ride-id').textContent      = '#' + (d.ride_id || '—');
    document.getElementById('td-distance').textContent     = d.distance_km ? parseFloat(d.distance_km).toFixed(1) + ' km' : '—';
    document.getElementById('td-start-time').textContent   = fmtDate(d.start_time);
    document.getElementById('td-end-time').textContent     = fmtDate(d.end_time);

    document.getElementById('td-base-fare').textContent      = fmt(d.base_fare);
    document.getElementById('td-computed-fare').textContent  = fmt(d.total_fare);
    document.getElementById('td-total-amount').textContent   = fmt(d.total_amount || d.total_fare);

    var pStatus = d.payment_status || '—';
    var pColor  = pStatus === 'Paid' || pStatus === 'Captured' ? '#10B981' : '#718096';
    document.getElementById('td-payment-status').innerHTML =
        '<span style="color:'+pColor+';font-weight:700;">'+pStatus+'</span>';

    document.getElementById('td-driver-name').textContent  = d.driver_name  || (d.rejected_by_driver ? 'No driver accepted' : '—');
    document.getElementById('td-driver-phone').textContent = d.driver_phone || '—';
    document.getElementById('td-driver-phone-row').style.display = d.driver_phone ? 'flex' : 'none';

    var modal = document.getElementById('tripDetailModal');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeTripDetail() {
    document.getElementById('tripDetailModal').style.display = 'none';
    document.body.style.overflow = '';
}
document.getElementById('sosModal').addEventListener('click', function(e){ if(e.target===this) closeSosModal(); });

function triggerSos() {
    closeSosModal();
    var btn = document.querySelector('.btn-sos');
    if(btn){ btn.textContent = 'SOS Sent!'; btn.style.background='#EF4444'; btn.style.color='#fff'; }
    setTimeout(function(){
        if(btn){ btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg> SOS Alert'; btn.style.background=''; btn.style.color=''; }
    }, 3000);
}

function openShareModal()  { document.getElementById('shareModal').classList.add('open'); }
function closeShareModal() { document.getElementById('shareModal').classList.remove('open'); }
document.getElementById('shareModal').addEventListener('click', function(e){ if(e.target===this) closeShareModal(); });

function copyShareLink() {
    var text = document.getElementById('shareUrl').textContent;
    if(navigator.clipboard){ navigator.clipboard.writeText(text); }
    var btn = document.querySelector('.copy-btn');
    btn.textContent = 'Copied!';
    setTimeout(function(){ btn.textContent = 'Copy'; }, 2000);
}

<?php if ($active_count > 0 || ($selected_ride && in_array($selected_ride['ride_status'], ['Requested','Accepted','In Progress']))): ?>

const BOOKING_ID_T    = <?= (int)($selected_ride['booking_id'] ?? 0) ?>;
const PICKUP_ADDR_T   = <?= json_encode($selected_ride['start_location'] ?? '') ?>;
const DEST_ADDR_T     = <?= json_encode($selected_ride['end_location']   ?? '') ?>;
const INIT_DRIVER_LAT = <?= $selected_ride['driver_lat'] !== null ? (float)$selected_ride['driver_lat'] : 'null' ?>;
const INIT_DRIVER_LNG = <?= $selected_ride['driver_lng'] !== null ? (float)$selected_ride['driver_lng'] : 'null' ?>;

let tMap = null, tDriverMarker = null, tPickupMarker = null, tDestMarker = null, tRoute = null;
let tLastLat = null, tLastLng = null;


const TDRIVER_ICON = L.divIcon({
    html: `<div style="width:42px;height:42px;background:linear-gradient(135deg,#00D084,#00A86B);border-radius:50%;border:3px solid white;box-shadow:0 4px 16px rgba(0,208,132,.55);display:flex;align-items:center;justify-content:center;animation:driverPulse 2s ease-in-out infinite;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
    </div>`,
    iconSize:[42,42], iconAnchor:[21,21], className:''
});
const TPICKUP_ICON = L.divIcon({
    html:`<div style="display:flex;flex-direction:column;align-items:center;filter:drop-shadow(0 4px 10px rgba(0,208,132,0.5));"><div style="width:32px;height:32px;border-radius:50% 50% 50% 0;background:linear-gradient(135deg,#00D084,#00A86B);transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;border:2.5px solid white;"><div style="width:8px;height:8px;background:white;border-radius:50%;transform:rotate(45deg);"></div></div><div style="width:3px;height:8px;background:#00A86B;margin-top:-2px;border-radius:0 0 3px 3px;"></div></div>`,
    iconSize:[32,44], iconAnchor:[16,44], className:''
});
const TDEST_ICON = L.divIcon({
    html:`<div style="display:flex;flex-direction:column;align-items:center;filter:drop-shadow(0 4px 10px rgba(239,68,68,0.5));"><div style="width:32px;height:32px;border-radius:50% 50% 50% 0;background:linear-gradient(135deg,#EF4444,#DC2626);transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;border:2.5px solid white;"><div style="width:8px;height:8px;background:white;border-radius:50%;transform:rotate(45deg);"></div></div><div style="width:3px;height:8px;background:#DC2626;margin-top:-2px;border-radius:0 0 3px 3px;"></div></div>`,
    iconSize:[32,44], iconAnchor:[16,44], className:''
});

function initTrackingMapT() {
    if (tMap) return;
    tMap = L.map('tracking-map', { zoomControl:true, scrollWheelZoom:false }).setView([14.5995, 120.9842], 13);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution:'&copy; OSM &copy; CARTO', subdomains:'abcd', maxZoom:20
    }).addTo(tMap);
}
function geocodeT(addr) {
    return fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(addr)}&limit=1&countrycodes=ph`)
        .then(r=>r.json()).then(d=>d[0]?{lat:parseFloat(d[0].lat),lng:parseFloat(d[0].lon)}:null);
}
async function placeStaticMarkersT() {
    const pu = PICKUP_ADDR_T ? await geocodeT(PICKUP_ADDR_T) : null;
    const ds = DEST_ADDR_T   ? await geocodeT(DEST_ADDR_T)   : null;
    if (pu) tPickupMarker = L.marker([pu.lat,pu.lng],{icon:TPICKUP_ICON}).addTo(tMap).bindPopup('<b>Pickup</b>');
    if (ds) tDestMarker   = L.marker([ds.lat,ds.lng],{icon:TDEST_ICON  }).addTo(tMap).bindPopup('<b>Destination</b>');
    if (pu && ds) {
        if (tRoute) { if (Array.isArray(tRoute)) tRoute.forEach(l=>tMap.removeLayer(l)); else tMap.removeLayer(tRoute); }
        const pts = [[pu.lat,pu.lng],[ds.lat,ds.lng]];
        
        const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${pu.lng},${pu.lat};${ds.lng},${ds.lat}?overview=full&geometries=geojson`;
        let routeCoords = pts;
        try {
            const osrmRes  = await fetch(osrmUrl);
            const osrmData = await osrmRes.json();
            if (osrmData.routes && osrmData.routes[0]) {
                routeCoords = osrmData.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
            }
        } catch(e) {  }
        
        const shadow = L.polyline(routeCoords, {color:'rgba(0,168,107,0.15)', weight:16, lineCap:'round', lineJoin:'round'}).addTo(tMap);
        const glow   = L.polyline(routeCoords, {color:'rgba(0,208,132,0.28)', weight:9,  lineCap:'round', lineJoin:'round'}).addTo(tMap);
        const main   = L.polyline(routeCoords, {color:'#00D084', weight:5, lineCap:'round', lineJoin:'round', opacity:1}).addTo(tMap);
        const flow   = L.polyline(routeCoords, {color:'rgba(255,255,255,0.7)', weight:3, dashArray:'12 18', lineCap:'round', lineJoin:'round', className:'route-flow-line'}).addTo(tMap);
        tRoute = [shadow, glow, main, flow];
        tMap.fitBounds(L.latLngBounds(routeCoords).pad(0.2));
    } else if (pu) { tMap.setView([pu.lat,pu.lng],15); }
}
function updateDriverMarkerT(lat, lng) {
    if (!tMap) return;
    if (tDriverMarker) { tDriverMarker.setLatLng([lat,lng]); }
    else { tDriverMarker = L.marker([lat,lng],{icon:TDRIVER_ICON,zIndexOffset:1000}).addTo(tMap).bindPopup('<b>Your Driver</b>'); }
    if (!tLastLat) tMap.setView([lat,lng],15);
    tLastLat = lat; tLastLng = lng;
}


const STATUS_MAP = {
    'Requested':   { label:'Finding Driver',  step:1, badgeClass:'badge-requested' },
    'Accepted':    { label:'Driver En Route', step:2, badgeClass:'badge-accepted'  },
    'In Progress': { label:'Trip Ongoing',    step:3, badgeClass:'badge-active'    },
    'Completed':   { label:'Trip Completed',  step:4, badgeClass:'badge-completed' },
    'Cancelled':   { label:'Trip Cancelled',  step:0, badgeClass:'badge-cancelled' },
};
const STEP_DESCS = {
    'Requested':   'Your booking is pending driver acceptance.',
    'Accepted':    'Driver has accepted and is heading to your pickup.',
    'In Progress': 'You are currently on your way to the destination.',
    'Completed':   'Your trip has been completed successfully.',
    'Cancelled':   'This trip was cancelled.',
};
function updateTrackingPanel(data) {
    const rideStatus = data.ride_status || 'Requested';
    const sm = STATUS_MAP[rideStatus] || STATUS_MAP['Requested'];

    
    const statusEl = document.getElementById('live-tracking-status');
    const descEl   = document.getElementById('live-tracking-desc');
    const badgeEl  = document.getElementById('live-status-badge');
    if (statusEl) statusEl.textContent = sm.label;
    if (descEl)   descEl.textContent   = STEP_DESCS[rideStatus] || '';
    if (badgeEl) {
        badgeEl.className = 'status-badge ' + sm.badgeClass;
        badgeEl.querySelector('span') && (badgeEl.querySelector('span').textContent = rideStatus);
    }

    
    const stepEls  = document.querySelectorAll('.progress-steps .step-circle');
    const lineEls  = document.querySelectorAll('.progress-steps .step-line');
    const step = sm.step;
    stepEls.forEach((el, i) => {
        const sNum = i + 1;
        if (rideStatus === 'Cancelled') { el.className = 'step-circle pending'; el.textContent = sNum; }
        else if (sNum < step)  { el.className = 'step-circle done';   el.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>'; }
        else if (sNum === step){ el.className = 'step-circle active'; el.textContent = sNum; }
        else                   { el.className = 'step-circle pending'; el.textContent = sNum; }
    });
    lineEls.forEach((el, i) => {
        el.classList.toggle('done', (i + 1) < step && rideStatus !== 'Cancelled');
    });

    
    if (data.driver_name) {
        const dnEl = document.getElementById('live-driver-name');
        if (dnEl && dnEl.textContent === '—') dnEl.textContent = data.driver_name;
        const daEl = document.getElementById('live-driver-avatar');
        if (daEl && daEl.textContent === '?') daEl.textContent = data.driver_name.charAt(0).toUpperCase();
    }
    if (data.driver_contact) {
        const dcEl = document.getElementById('live-driver-contact-row');
        const dnEl = document.getElementById('live-driver-contact-num');
        if (dcEl && dnEl && dcEl.style.display === 'none') {
            dnEl.textContent = data.driver_contact;
            dcEl.style.display = 'flex';
        }
    }

    
    if (data.driver_lat && data.driver_lng && tLastLat !== null) {
        const R  = 6371;
        const dφ = (parseFloat(data.driver_lat) - tLastLat) * Math.PI/180;
        const dλ = (parseFloat(data.driver_lng) - tLastLng) * Math.PI/180;
        const a  = Math.sin(dφ/2)**2 + Math.cos(tLastLat*Math.PI/180)*Math.cos(parseFloat(data.driver_lat)*Math.PI/180)*Math.sin(dλ/2)**2;
        const km = R * 2 * Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
        const etaEl = document.getElementById('live-eta');
        if (etaEl) etaEl.textContent = Math.max(1, Math.round(km / 0.5)) + ' min';
    }

    
    const heroCountEl = document.querySelector('.hero-amount');
    if (heroCountEl && (rideStatus === 'Completed' || rideStatus === 'Cancelled')) {
        const cur = parseInt(heroCountEl.textContent) || 0;
        if (cur > 0) heroCountEl.textContent = cur - 1;
    }
}

function showTripDoneOverlayT(d) {
    if (document.getElementById('ec-td-t')) return;
    const peso = String.fromCharCode(8369);
    const fare = d.total_amount ? peso + parseFloat(d.total_amount).toLocaleString('en-PH',{minimumFractionDigits:2}) : '';
    const fbox = fare ? `<div style="background:rgba(0,208,132,.08);border:1.5px solid rgba(0,208,132,.3);border-radius:16px;padding:14px 20px;margin-bottom:20px;"><div style="font-size:11px;color:#718096;font-weight:700;text-transform:uppercase;margin-bottom:4px;">Total Fare</div><div style="font-size:30px;font-weight:900;color:#00A86B;">${fare}</div></div>` : '';
    const ov = document.createElement('div');
    ov.id = 'ec-td-t';
    ov.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.65);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeInOv .3s ease;';
    ov.innerHTML = `<div style="background:#fff;border-radius:28px;padding:36px 28px 28px;text-align:center;max-width:320px;width:100%;box-shadow:0 24px 60px rgba(0,0,0,.25);">
        <div style="width:72px;height:72px;background:linear-gradient(135deg,#00D084,#00A86B);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;box-shadow:0 8px 24px rgba(0,208,132,.4);">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <div style="font-size:22px;font-weight:900;color:#1A202C;margin-bottom:6px;">Trip Completed!</div>
        <div style="font-size:14px;color:#718096;margin-bottom:20px;">Your ride has ended. Thank you for riding with EnviroCab!</div>
        ${fbox}
        <button onclick="location.href='passenger_trips.php'" style="width:100%;padding:14px;border-radius:16px;background:linear-gradient(135deg,#00D084,#00A86B);color:#fff;font-size:15px;font-weight:800;border:none;cursor:pointer;box-shadow:0 4px 16px rgba(0,208,132,.35);margin-bottom:10px;">View Trip Details</button>
        <button onclick="location.href='passenger_booking.php'" style="width:100%;padding:14px;border-radius:16px;background:transparent;color:#00A86B;font-size:15px;font-weight:700;border:2px solid rgba(0,208,132,.3);cursor:pointer;">Book Another Ride</button>
    </div>`;
    document.body.appendChild(ov);
    
    const activeCard = document.querySelector(`[data-ride-id="${d.ride_id}"]`);
    if (activeCard) {
        activeCard.style.transition = 'opacity .4s';
        activeCard.style.opacity = '0';
        setTimeout(() => activeCard.remove(), 400);
    }
}


const TrackPoller = (() => {
    let _timer    = null;
    let _interval = 4000;
    let _stopped  = false;
    const MIN_MS  = 3000;
    const MAX_MS  = 10000;
    const STEP_MS = 1500;

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) { clearTimeout(_timer); }
        else if (!_stopped)  { _scheduleNext(500); }
    });

    function _scheduleNext(ms) { clearTimeout(_timer); _timer = setTimeout(_tick, ms ?? _interval); }

    async function _tick() {
        if (_stopped || document.hidden || !BOOKING_ID_T) return;
        try {
            const res  = await fetch(`passenger_booking.php?ajax_action=booking_status&booking_id=${BOOKING_ID_T}`, { cache:'no-store' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();

            
            if (data.driver_lat && data.driver_lng) {
                updateDriverMarkerT(parseFloat(data.driver_lat), parseFloat(data.driver_lng));
            }

            
            updateTrackingPanel(data);

            if (data.status === 'Completed') {
                stop(); showTripDoneOverlayT(data);
            } else if (data.status === 'Cancelled') {
                stop();
                updateTrackingPanel(data);
                
                const tp = document.querySelector('.tracking-panel');
                if (tp && !document.getElementById('cancel-notice')) {
                    const note = document.createElement('div');
                    note.id = 'cancel-notice';
                    note.style.cssText = 'background:rgba(239,68,68,.1);border:1.5px solid rgba(239,68,68,.25);border-radius:14px;padding:14px 16px;margin:12px 16px;font-size:13px;font-weight:600;color:#EF4444;text-align:center;';
                    note.textContent = 'This trip was cancelled.';
                    tp.appendChild(note);
                }
                _interval = MIN_MS; 
            } else {
                
                const moved = data.driver_lat && tLastLat && Math.abs(parseFloat(data.driver_lat) - tLastLat) > 0.0001;
                _interval = moved ? MIN_MS : Math.min(_interval + STEP_MS, MAX_MS);
            }
        } catch(e) {
            console.warn('[TrackPoller] error:', e);
            _interval = Math.min(_interval + STEP_MS, MAX_MS);
        }
        if (!_stopped) _scheduleNext(_interval);
    }

    function start() { _stopped = false; _scheduleNext(800); }
    function stop()  { _stopped = true;  clearTimeout(_timer); }
    return { start, stop };
})();

document.addEventListener('DOMContentLoaded', function() {
    initTrackingMapT();
    setTimeout(function() {
        tMap.invalidateSize();
        placeStaticMarkersT();
        if (INIT_DRIVER_LAT && INIT_DRIVER_LNG) updateDriverMarkerT(INIT_DRIVER_LAT, INIT_DRIVER_LNG);
    }, 300);
    TrackPoller.start();
});


const _ovStyle = document.createElement('style');
_ovStyle.textContent = '@keyframes fadeInOv{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}';
document.head.appendChild(_ovStyle);

<?php endif; ?>
</script>

<script>
const CUSTOMER_ID = <?= (int)$customer_id ?>;

const SB_URL = 'https://kyhndwabhbkduoaxeunq.supabase.co';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA';
const SEEN_KEY = 'ecab_seen_' + CUSTOMER_ID;
let _notifOpen = false, _notifData = [], _notifTimer = null;
let _seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');

const STATUS_CFG = {
    'Pending':     {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`, label:'Looking for a driver', color:'#F59E0B', page:'passenger_booking.php'},
    'Confirmed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`, label:'Driver is on the way!', color:'#00D084', page:'passenger_booking.php'},
    'In Progress': {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`, label:'Trip is in progress',   color:'#3B82F6', page:'passenger_tracking.php'},
    'Completed':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`, label:'Trip completed',        color:'#10B981', page:'passenger_trips.php'},
    'Cancelled':   {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`, label:'Booking was cancelled', color:'#EF4444', page:'passenger_trips.php'},
};

function toggleNotifPanel(e) {
    e.stopPropagation();
    _notifOpen = !_notifOpen;
    document.getElementById('notif-panel').classList.toggle('open', _notifOpen);
    if (_notifOpen) { fetchNotifs(); _notifTimer = setInterval(fetchNotifs, 8000); }
    else clearInterval(_notifTimer);
}

async function fetchNotifs() {
    try {
        const r = await fetch(SB_URL + '/rest/v1/core2_bookings?customer_id=eq.' + CUSTOMER_ID +
            '&select=booking_id,booking_reference,booking_status,total_amount,created_at&order=created_at.desc&limit=15',
            {headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY}});
        _notifData = await r.json();
        renderNotifs();
        updateBadge();
    } catch(e) {}
}

function renderNotifs() {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!_notifData.length) { list.innerHTML = '<div class="notif-empty">No notifications yet.</div>'; return; }
    list.innerHTML = _notifData.map(b => {
        const cfg = STATUS_CFG[b.booking_status] || {icon:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:b.booking_status, color:'#718096', page:'passenger_trips.php'};
        const key = b.booking_id + '_' + b.booking_status;
        const unread = !_seen.includes(key);
        const amt = '\u20B1' + parseFloat(b.total_amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
        const t = timeAgo(b.created_at);
        return `<div class="notif-item${unread?' unread':''}" onclick="goNotif('${cfg.page}',${b.booking_id},'${key}')">`
            +`<div class="notif-dot-ind"></div>`
            +`<div class="notif-item-icon" style="color:${cfg.color};">${cfg.icon}</div>`
            +`<div class="notif-item-body">`
            +`<div class="notif-item-title">${escH(b.booking_reference)}</div>`
            +`<div class="notif-item-sub" style="color:${cfg.color};">${cfg.label}</div>`
            +`<div class="notif-item-sub">${amt}</div>`
            +`<div class="notif-item-time">${t}</div>`
            +`</div></div>`;
    }).join('');
}

function updateBadge() {
    const cnt = _notifData.filter(b => !_seen.includes(b.booking_id+'_'+b.booking_status)).length;
    const el = document.getElementById('notif-count-badge');
    if (!el) return;
    if (cnt > 0) { el.textContent = cnt > 9 ? '9+' : cnt; el.style.display = 'flex'; }
    else el.style.display = 'none';
}

function goNotif(page, bid, key) {
    if (!_seen.includes(key)) { _seen.push(key); localStorage.setItem(SEEN_KEY, JSON.stringify(_seen)); }
    window.location.href = page + '?booking_id=' + bid;
}

function markAllRead() {
    _seen = _notifData.map(b => b.booking_id+'_'+b.booking_status);
    localStorage.setItem(SEEN_KEY, JSON.stringify(_seen));
    renderNotifs(); updateBadge();
}

function timeAgo(iso) {
    if (!iso) return '';
    const s = Math.floor((Date.now() - new Date(iso))/1000);
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s/60)+'m ago';
    if (s < 86400) return Math.floor(s/3600)+'h ago';
    return Math.floor(s/86400)+'d ago';
}

function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function openLogout() { document.getElementById('logout-overlay').classList.add('open'); }

document.addEventListener('click', function(e) {
    const panel = document.getElementById('notif-panel');
    const btn   = document.getElementById('notif-bell-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
        _notifOpen = false; panel.classList.remove('open'); clearInterval(_notifTimer);
    }
});

document.addEventListener('DOMContentLoaded', () => { if (CUSTOMER_ID) fetchNotifs(); });
</script>


<div class="logout-overlay" id="logout-overlay" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="logout-modal">
        <div class="logout-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </div>
        <div class="logout-modal-title">Log out?</div>
        <div class="logout-modal-sub">You'll need to sign in again to access your account.</div>
        <div class="logout-modal-btns">
            <button class="logout-cancel-btn" onclick="document.getElementById('logout-overlay').classList.remove('open')">Cancel</button>
            <button class="logout-confirm-btn" onclick="window.location.href='../auth/logout.php'">Log out</button>
        </div>
    </div>
</div>

<script>
(function(){
  var links=[
    'dashboard.php','passenger_booking.php','passenger_trips.php',
    'passenger_tracking.php','passenger_history.php','passenger_payments.php',
    'passenger_profile.php','passenger_feedback.php','my_rated_drivers.php'
  ];
  function prefetch(url){
    if(document.querySelector('link[rel="prefetch"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prefetch'; l.href=url; l.as='document';
    document.head.appendChild(l);
  }
  function prerender(url){
    if(document.querySelector('link[rel="prerender"][href="'+url+'"]')) return;
    var l=document.createElement('link');
    l.rel='prerender'; l.href=url;
    document.head.appendChild(l);
  }
  window.addEventListener('load',function(){
    setTimeout(function(){ links.forEach(prefetch); },300);
  });
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('a[href]').forEach(function(a){
      var href=a.getAttribute('href');
      if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
      a.addEventListener('mouseenter',function(){ prerender(href); },{ once:true });
      a.addEventListener('touchstart',function(){ prerender(href); },{ once:true, passive:true });
    });
    document.querySelectorAll('button[onclick]').forEach(function(btn){
      var oc=btn.getAttribute('onclick')||'';
      var m=oc.match(/location\.href=['"]([^'"]+)['"]/);
      if(m) btn.addEventListener('mouseenter',function(){ prerender(m[1]); },{ once:true });
    });
  });
  document.addEventListener('click',function(e){
    var a=e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href||href.startsWith('http')||href.startsWith('#')||href.startsWith('javascript')) return;
    e.preventDefault();
    document.body.style.opacity='0';
    document.body.style.transition='opacity .15s ease';
    setTimeout(function(){ window.location.href=href; },150);
  });
})();
</script>
</body>
</html>