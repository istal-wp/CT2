<?php
define('SUPABASE_URL',      'https://kyhndwabhbkduoaxeunq.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5aG5kd2FiaGJrZHVvYXhldW5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MzA1OTIsImV4cCI6MjA4NjIwNjU5Mn0.znUK7XAns21A6Pswb-tsMW4FO0q4ACt7B6eZrTvNTnA');

define('APP_NAME',        'EnviroCab');
define('APP_VERSION',     '1.0.0');
define('APP_ENV',         'development');
define('API_TIMEOUT',     30);
define('API_RATE_LIMIT',  100);

define('ENABLE_CORS',        true);
define('ALLOWED_ORIGINS',    '*');
define('SESSION_LIFETIME',   3600);
define('ENABLE_CACHE',       true);
define('CACHE_DURATION',     300);

// ── Supabase REST helpers ─────────────────────────────────────────────────────

function sb_get(string $table, array $params = []): array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    if ($params) $url .= '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) return json_decode($res, true) ?: [];
    error_log("SB GET {$table} HTTP {$code}: {$res}");
    return [];
}

function sb_post(string $table, array $data): ?array {
    $url = SUPABASE_URL . '/rest/v1/' . $table;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) {
        $r = json_decode($res, true);
        return is_array($r) ? ($r[0] ?? null) : null;
    }
    error_log("SB POST {$table} HTTP {$code}: {$res}");
    return null;
}

function sb_patch(string $table, array $filters, array $data): bool {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code < 200 || $code >= 300) { error_log("SB PATCH {$table} HTTP {$code}: {$res}"); return false; }
    return true;
}

function sb_delete(string $table, array $filters): bool {
    $url = SUPABASE_URL . '/rest/v1/' . $table . '?' . http_build_query($filters);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'DELETE',
        CURLOPT_HTTPHEADER     => [
            'apikey: '               . SUPABASE_ANON_KEY,
            'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        ],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code < 200 || $code >= 300) { error_log("SB DELETE {$table} HTTP {$code}: {$res}"); return false; }
    return true;
}

// ── Kept for backward compatibility (any file that calls getDatabaseConnection) ─

function getDatabaseConnection() {
    throw new RuntimeException(
        'getDatabaseConnection() is no longer available. ' .
        'Use sb_get(), sb_post(), sb_patch(), or sb_delete() instead.'
    );
}

// ── Utility functions (unchanged) ─────────────────────────────────────────────

function setCORSHeaders() {
    if (ENABLE_CORS) {
        header('Access-Control-Allow-Origin: '   . ALLOWED_ORIGINS);
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
        header('Access-Control-Max-Age: 86400');
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(204);
            exit();
        }
    }
}

function setJSONHeaders() {
    header('Content-Type: application/json; charset=UTF-8');
    setCORSHeaders();
}

function logAPIRequest($endpoint, $method, $userId = null) {
    if (APP_ENV === 'development') {
        error_log(sprintf(
            '[API] %s %s - User: %s - Time: %s',
            $method, $endpoint,
            $userId ?? 'guest',
            date('Y-m-d H:i:s')
        ));
    }
}

function handleAPIError($exception, $statusCode = 500) {
    http_response_code($statusCode);
    $response = [
        'success'   => false,
        'error'     => 'An error occurred',
        'timestamp' => date('Y-m-d H:i:s'),
    ];
    if (APP_ENV === 'development') {
        $response['message'] = $exception->getMessage();
        $response['trace']   = $exception->getTraceAsString();
    }
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit();
}

function validateParams($required, $params) {
    $missing = [];
    foreach ($required as $param) {
        if (!isset($params[$param]) || empty($params[$param])) $missing[] = $param;
    }
    if (!empty($missing)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing required parameters', 'missing' => $missing], JSON_PRETTY_PRINT);
        exit();
    }
}

function sanitizeInput($data) {
    if (is_array($data)) return array_map('sanitizeInput', $data);
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function apiResponse($success, $data = null, $message = null, $statusCode = 200) {
    http_response_code($statusCode);
    $response = ['success' => $success, 'timestamp' => date('Y-m-d H:i:s')];
    if ($data    !== null) $response['data']    = $data;
    if ($message !== null) $response['message'] = $message;
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit();
}

function checkRateLimit($userId = null) {
    $key       = $userId ?? $_SERVER['REMOTE_ADDR'];
    $cacheFile = sys_get_temp_dir() . '/rate_limit_' . md5($key);
    $now       = time();
    $requests  = [];
    if (file_exists($cacheFile)) {
        $requests = json_decode(file_get_contents($cacheFile), true);
        $requests = array_filter($requests, fn($t) => ($now - $t) < 60);
    }
    if (count($requests) >= API_RATE_LIMIT) {
        http_response_code(429);
        echo json_encode(['success' => false, 'error' => 'Rate limit exceeded', 'message' => 'Too many requests. Please try again later.']);
        exit();
    }
    $requests[] = $now;
    file_put_contents($cacheFile, json_encode($requests));
}