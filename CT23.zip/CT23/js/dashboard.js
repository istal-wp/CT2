class EnviroCabDashboard {
    constructor() {
        this.apiBase = 'api/';
        this.refreshInterval = 30000;
        this.updateTimer = null;
        this.init();
    }

    init() {
        console.log('EnviroCab Dashboard initializing...');
        this.loadDashboardData();
        this.setupEventListeners();
        this.startAutoRefresh();
        this.setupPullToRefresh();
    }

    async loadDashboardData() {
        try {
            const response = await fetch(`${this.apiBase}dashboard_data.php`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.success) {
                this.updateUI(data.data);
                console.log('Dashboard data loaded successfully');
            } else {
                console.error('Failed to load dashboard data:', data.error);
                this.showError('Failed to load dashboard data');
            }
        } catch (error) {
            console.error('Error fetching dashboard data:', error);
            this.loadCachedData();
        }
    }

    updateUI(data) {
        if (data.quickStats) {
            this.updateElement('todayBookings', data.quickStats.todayBookings);
            this.updateElement('totalRevenue', this.formatNumber(data.quickStats.totalRevenue));
            this.updateElement('activeTrips', data.quickStats.activeTrips);
            this.updateElement('avgRating', data.quickStats.avgRating);
        }

        if (data.bookingModule) {
            this.updateElement('pendingBookings', data.bookingModule.pending);
            this.updateElement('confirmedBookings', data.bookingModule.confirmed);
            this.updateElement('completedBookings', data.bookingModule.completed);
        }

        if (data.paymentModule) {
            this.updateElement('totalPayments', data.paymentModule.totalPayments);
            this.updateElement('paidCount', data.paymentModule.paidCount);
            this.updateElement('pendingPayments', data.paymentModule.pendingPayments);
        }

        if (data.crmModule) {
            this.updateElement('totalCustomers', this.formatNumber(data.crmModule.totalCustomers));
            this.updateElement('totalRatings', this.formatNumber(data.crmModule.totalRatings));
            this.updateElement('openReports', data.crmModule.openReports);
        }

        if (data.gpsModule) {
            this.updateElement('activeVehicles', data.gpsModule.activeVehicles);
            this.updateElement('totalDistance', this.formatNumber(data.gpsModule.totalDistance));
            this.updateElement('gpsPoints', data.gpsModule.gpsPoints);
        }

        if (data.analyticsModule) {
            this.updateElement('vehiclePerformance', data.analyticsModule.vehiclePerformance + '%');
            this.updateElement('driverPerformance', data.analyticsModule.driverPerformance + '%');
            this.updateElement('onTimePercent', data.analyticsModule.onTimePercent + '%');
        }

        if (data.complianceModule) {
            this.updateElement('sopDocuments', data.complianceModule.sopDocuments);
            this.updateElement('complianceRate', data.complianceModule.complianceRate + '%');
            this.updateElement('openIssues', data.complianceModule.openIssues);
        }

        this.cacheData(data);
    }

    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            if (element.textContent !== String(value)) {
                element.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    element.textContent = value;
                    element.style.transform = 'scale(1)';
                }, 150);
            }
        }
    }

    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    setupEventListeners() {
        const interactiveElements = document.querySelectorAll(
            '.module-card, .stat-card, .nav-item, .notification-bell'
        );

        interactiveElements.forEach(element => {
            element.addEventListener('touchstart', function() {
                this.style.opacity = '0.7';
            }, { passive: true });

            element.addEventListener('touchend', function() {
                this.style.opacity = '1';
            }, { passive: true });

            element.addEventListener('touchcancel', function() {
                this.style.opacity = '1';
            }, { passive: true });
        });

        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                console.log('App resumed, refreshing data...');
                this.loadDashboardData();
            }
        });
    }

    startAutoRefresh() {
        this.updateTimer = setInterval(() => {
            console.log('Auto-refreshing dashboard data...');
            this.loadDashboardData();
        }, this.refreshInterval);
    }

    stopAutoRefresh() {
        if (this.updateTimer) {
            clearInterval(this.updateTimer);
            this.updateTimer = null;
        }
    }

    setupPullToRefresh() {
        let startY = 0;
        let currentY = 0;
        let isPulling = false;

        document.addEventListener('touchstart', (e) => {
            if (window.scrollY === 0) {
                startY = e.touches[0].pageY;
                isPulling = true;
            }
        }, { passive: true });

        document.addEventListener('touchmove', (e) => {
            if (isPulling) {
                currentY = e.touches[0].pageY;
                const diff = currentY - startY;
                
                if (diff > 100) {
                    this.showRefreshIndicator();
                }
            }
        }, { passive: true });

        document.addEventListener('touchend', () => {
            if (isPulling && (currentY - startY) > 100) {
                this.loadDashboardData();
            }
            isPulling = false;
            this.hideRefreshIndicator();
        }, { passive: true });
    }

    showRefreshIndicator() {
        const header = document.querySelector('.header');
        if (!document.getElementById('refreshIndicator')) {
            const indicator = document.createElement('div');
            indicator.id = 'refreshIndicator';
            indicator.style.cssText = `
                position: absolute;
                top: 10px;
                left: 50%;
                transform: translateX(-50%);
                padding: 8px 16px;
                background: rgba(255, 255, 255, 0.3);
                border-radius: 20px;
                font-size: 12px;
                color: white;
            `;
            indicator.textContent = '🔄 Release to refresh';
            header.appendChild(indicator);
        }
    }

    hideRefreshIndicator() {
        const indicator = document.getElementById('refreshIndicator');
        if (indicator) {
            indicator.remove();
        }
    }

    cacheData(data) {
        try {
            localStorage.setItem('envirocab_dashboard_cache', JSON.stringify({
                data: data,
                timestamp: new Date().getTime()
            }));
        } catch (error) {
            console.error('Failed to cache data:', error);
        }
    }

    loadCachedData() {
        try {
            const cached = localStorage.getItem('envirocab_dashboard_cache');
            if (cached) {
                const { data, timestamp } = JSON.parse(cached);
                const age = new Date().getTime() - timestamp;
                
                if (age < 300000) {
                    console.log('Using cached data');
                    this.updateUI(data);
                    this.showOfflineIndicator();
                }
            }
        } catch (error) {
            console.error('Failed to load cached data:', error);
        }
    }

    showOfflineIndicator() {
        const header = document.querySelector('.header');
        const indicator = document.createElement('div');
        indicator.style.cssText = `
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 8px;
            background: rgba(255, 87, 34, 0.9);
            text-align: center;
            font-size: 12px;
            color: white;
        `;
        indicator.textContent = '📴 Offline - Using cached data';
        header.appendChild(indicator);
        
        setTimeout(() => indicator.remove(), 3000);
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            text-align: center;
        `;
        errorDiv.innerHTML = `
            <div style="font-size: 48px; margin-bottom: 12px;">⚠️</div>
            <div style="font-weight: 600; margin-bottom: 8px;">Error</div>
            <div style="color: #5A6C7D; font-size: 14px;">${message}</div>
        `;
        document.body.appendChild(errorDiv);
        
        setTimeout(() => errorDiv.remove(), 3000);
    }
}

function openModule(moduleName) {
    console.log('Opening module:', moduleName);
    
    const modulePages = {
        'booking': 'booking.html',
        'payment': 'payment.html',
        'crm': 'crm.html',
        'gps': 'gps.html',
        'analytics': 'analytics.html',
        'compliance': 'compliance.html'
    };
    
    showModuleTransition(moduleName);
}

function showModuleTransition(moduleName) {
    const overlay = document.createElement('div');
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(135deg, #00D084 0%, #0066CC 100%);
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 24px;
        font-weight: 700;
        animation: fadeIn 0.3s ease;
    `;
    
    const moduleNames = {
        'booking': 'Booking System',
        'payment': 'Payment & Fare',
        'crm': 'Customer Relations',
        'gps': 'GPS Tracking',
        'analytics': 'Analytics',
        'compliance': 'Compliance'
    };
    
    overlay.innerHTML = `
        <div style="text-align: center;">
            <div style="font-size: 48px; margin-bottom: 16px;">📱</div>
            <div>Loading ${moduleNames[moduleName]}...</div>
        </div>
    `;
    
    document.body.appendChild(overlay);
    
    setTimeout(() => {
        overlay.remove();
        alert(`Module: ${moduleNames[moduleName]}\n\nThis would navigate to the ${moduleName} module page with full functionality.`);
    }, 1000);
}

function navigateTo(section) {
    console.log('Navigating to:', section);
    
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    event.currentTarget.classList.add('active');
    
    const sectionPages = {
        'trips': 'trips.html',
        'earnings': 'earnings.html',
        'profile': 'profile.html'
    };
    
    showModuleTransition(section);
}

function showNotifications() {
    const notifications = [
        { icon: '📅', text: 'New booking from Juan Dela Cruz', time: '2 min ago' },
        { icon: '💰', text: 'Payment confirmed ₱380', time: '15 min ago' },
        { icon: '🚗', text: 'Trip completed: 15.2 km', time: '30 min ago' },
        { icon: '⚠️', text: 'License expiring in 30 days', time: '1 hour ago' }
    ];
    
    const notifDiv = document.createElement('div');
    notifDiv.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 9999;
        display: flex;
        align-items: flex-end;
        animation: fadeIn 0.3s ease;
    `;
    
    let notifContent = `
        <div style="
            background: white;
            width: 100%;
            max-height: 70vh;
            border-radius: 24px 24px 0 0;
            padding: 24px;
            animation: slideUp 0.3s ease;
        ">
            <div style="
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            ">
                <h3 style="font-size: 20px; font-weight: 700;">Notifications</h3>
                <button onclick="this.closest('.notif-modal').remove()" style="
                    background: none;
                    border: none;
                    font-size: 24px;
                    cursor: pointer;
                ">×</button>
            </div>
    `;
    
    notifications.forEach(notif => {
        notifContent += `
            <div style="
                padding: 16px;
                background: #f8fafb;
                border-radius: 12px;
                margin-bottom: 12px;
                display: flex;
                gap: 12px;
            ">
                <div style="font-size: 24px;">${notif.icon}</div>
                <div style="flex: 1;">
                    <div style="font-weight: 600; margin-bottom: 4px;">${notif.text}</div>
                    <div style="font-size: 12px; color: #5A6C7D;">${notif.time}</div>
                </div>
            </div>
        `;
    });
    
    notifContent += '</div>';
    notifDiv.innerHTML = notifContent;
    notifDiv.className = 'notif-modal';
    
    notifDiv.addEventListener('click', function(e) {
        if (e.target === this) {
            this.remove();
        }
    });
    
    document.body.appendChild(notifDiv);
}

let dashboard;
document.addEventListener('DOMContentLoaded', function() {
    dashboard = new EnviroCabDashboard();
});

const style = document.createElement('style');
style.textContent = `
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    @keyframes slideUp {
        from { transform: translateY(100%); }
        to { transform: translateY(0); }
    }
`;
document.head.appendChild(style);