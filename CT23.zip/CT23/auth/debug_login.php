<?php
// ─────────────────────────────────────────────
// TEMPORARY DEBUG FILE - DELETE AFTER FIXING
// Place in: C:\xampp\htdocs\TESTING\auth\debug_login.php
// Visit: http://localhost/TESTING/auth/debug_login.php
// ─────────────────────────────────────────────

define('SUPABASE_URL',      'https://smyqcayhidorzdxobepz.supabase.co');
define('SUPABASE_ANON_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNteXFjYXloaWRvcnpkeG9iZXB6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEwMzUyNjgsImV4cCI6MjA4NjYxMTI2OH0.hnvPFM35wVMsfIiq_3CgS0Nx3PD-y_Q4S9KGz2T5b78');

$email    = 'coredepartment12@gmail.com';
$password = 'zxcqwerty1111';

echo "<h2>🔍 Supabase Auth Debug</h2>";
echo "<pre>";

// ── TEST 1: Supabase Auth sign-in ──────────────────────
echo "=== TEST 1: Auth Sign-In ===\n";
$url = SUPABASE_URL . '/auth/v1/token?grant_type=password';
$ch  = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode(['email' => $email, 'password' => $password]),
    CURLOPT_HTTPHEADER     => [
        'apikey: '        . SUPABASE_ANON_KEY,
        'Content-Type: application/json',
    ],
]);
$resp      = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_err  = curl_error($ch);
curl_close($ch);

echo "HTTP Code : " . $http_code . "\n";
echo "cURL Error: " . ($curl_err ?: 'none') . "\n";
echo "Raw Response:\n" . $resp . "\n\n";

$auth_data = json_decode($resp, true);
if (!empty($auth_data['access_token'])) {
    echo "✅ AUTH SUCCESS - access_token received\n";
    echo "User ID: " . ($auth_data['user']['id'] ?? 'n/a') . "\n";
} else {
    echo "❌ AUTH FAILED\n";
    echo "Error      : " . ($auth_data['error'] ?? 'n/a') . "\n";
    echo "Description: " . ($auth_data['error_description'] ?? $auth_data['msg'] ?? $auth_data['message'] ?? 'n/a') . "\n";
}

echo "\n";

// ── TEST 2: Check admin_accounts table ────────────────
echo "=== TEST 2: admin_accounts Table ===\n";
$url2 = SUPABASE_URL . '/rest/v1/admin_accounts?email=eq.' . urlencode($email) . '&select=id,email,display_name,role';
$ch2  = curl_init($url2);
curl_setopt_array($ch2, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => [
        'apikey: '               . SUPABASE_ANON_KEY,
        'Authorization: Bearer ' . SUPABASE_ANON_KEY,
        'Content-Type: application/json',
    ],
]);
$resp2      = curl_exec($ch2);
$http_code2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
curl_close($ch2);

echo "HTTP Code : " . $http_code2 . "\n";
echo "Raw Response:\n" . $resp2 . "\n\n";

$admin_data = json_decode($resp2, true);
if (!empty($admin_data)) {
    echo "✅ ADMIN ACCOUNT FOUND\n";
    print_r($admin_data);
} else {
    echo "❌ NO ADMIN ACCOUNT ROW FOUND in admin_accounts table\n";
}

echo "\n";

// ── TEST 3: Check auth.users exists ───────────────────
echo "=== TEST 3: Check auth.users via service role (if accessible) ===\n";
echo "Note: auth.users is not accessible via anon key REST API.\n";
echo "Please verify manually in Supabase Dashboard > Authentication > Users\n";
echo "that the user '" . $email . "' exists and email is confirmed.\n";

echo "</pre>";
echo "<p style='color:red;font-weight:bold;'>⚠️ DELETE THIS FILE after debugging!</p>";
?>